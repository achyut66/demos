<!DOCTYPE html>
<html lang="en">

<head>
  <title><?php echo GNAME ?></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/bootstrap-reset.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <style type="text/css">
    :root {
      --bleeding: 0.5cm;
      --margin: 1cm;
    }

    /*  @page {*/
    /*  size: A4;
    margin: 0;
  }

  *{
    box-sizing: border-box;
  }*/
    body {
      /*font-family: Kalimati, Georgia, serif;*/
      margin: 0 auto;
      padding: 0;
      background: rgb(204, 204, 204);
      display: flex;
      flex-direction: column;
    }

    .page {
      display: inline-block;
      position: relative;
      height: 327mm;
      width: 160mm;
      font-size: 12pt;
      margin: 2em auto;
      padding: calc(var(--bleeding) + var(--margin));
      box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);
      background: white;
    }

    /*@media screen {*/
    .page::after {
      position: absolute;
      content: '';
      top: 0;
      left: 0;
      /*width: calc(100% - var(--bleeding) * 2);*/
      /*height: calc(100% - var(--bleeding) * 2);*/
      margin: var(--bleeding);
      outline: thin dashed black;
      pointer-events: none;
      z-index: 9999;
    }
    }

    /*@media print {
  .page {
    margin: 0;
    overflow: hidden;
  }
}*/

    /*.print_table {
  width: 100%;
  border: solid 1px;
  border-collapse: collapse;
  margin-top: 10px;
}
*/
    /*.print_table th {
  border-color: black;
  font-size: 16px;
  border: solid 1px;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  color:#000;
  background-color:#c2cdd8;
  text-align: center;
}*/

    /*.print_table td {
  border-color: black;
  font-size: 18px;
  border: solid 1px;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  text-align: center;
  width: auto;
}*/

    /*.print_table tr:nth-child(odd){
  background-color:#fff;
}
.print_table tr:nth-child(even){
  background-color:#ffffff;
}

.print_table table tfoot {
  background-color:#c2cdd8;
}*/

    .input-padder {
      padding-left: 0px;
    }

    .print-size-front {
      width: 400px;
    }

    .purna-idcard-wrapper {
      background: #e74c3c;
      height: auto;
      padding: 15px;
    }

    .asakta-idcard-wrapper {
      background: #3498db;
      height: auto;
      padding: 15px;
    }

    .madyam-idcard-wrapper {
      background: #f1c40f;
      height: auto;
      padding: 15px;
    }

    .samanya-idcard-wrapper {
      background: #ffffff;
      height: auto;
      padding: 10px 15px;
    }

    .idcard-border {
      padding: 0 5px;
      height: 100%;
    }

    .id-photo-frame {
      border: 1px solid #000;
      float: right;
      height: 80px;
      width: 80px;
      margin-top: 75px;
    }

    .id-title h1 {
      color: #000;
      text-align: center;
      font-weight: bold;
      font-size: 20px;
      /*-webkit-text-stroke: 1px rgba(255,255,255,0.3);*/
      margin-top: 0px;
    }

    .id-title p {

      color: #000;

      text-align: center;

      font-weight: bold;

      font-size: 14px;

      /*-webkit-text-stroke: 1px rgba(255,255,255,0.4);*/

      margin: 0 0 5px 0;

    }

    .id-title h2 {

      background: #fff;

      color: #FE0303;

      font-weight: bold;

      font-size: 15px;

      border-radius: 30px;

      text-align: center;

      padding: 10px 10px;

      display: table;

      margin: 0 auto;

    }

    .id-body {
      padding: 0 5px;
      font-weight: bold;
      color: #000;
      font-size: 13px;
      margin-top: -29px;

    }

    .note-nepali {

      color: #000;

      padding-top: 5px;

      font-weight: bold;

      font-size: 12px;

    }

    .note {

      color: #000;

      padding-top: 10px;

      font-weight: bold;

      font-size: 11px;

    }

    /*** Id Card Back ***/

    .print-size-back {

      width: 590px;

    }

    .idcard-back {

      padding: 5px;

      font-weight: bold;

      color: #000;

      font-size: 13px;

      line-height: 21px;

      margin-top: 50px;

    }

    .stamp-box p {

      text-align: center;

      font-weight: bold;

      padding: 0px;
      margin: 0px;

    }

    .stamp-box-border {

      border: 1px solid #000;

      width: 100px;

      height: 100px;

    }

    /** Custom **/

    @font-face {

      font-family: Kalimati;

      src: url("../../fonts/kalimati.ttf");

    }

    .borderless td,
    .borderless th {

      border: none !important;

    }

    .circle {

      height: 25px;

      width: 25px;

      border-radius: 50%;

      display: inline-block;

    }

    .photo_box {
      width: 80px;
      height: 80px;
      /*float: left;*/
      border: 1px solid #000;
      text-align: left;
      margin-top: 2px;
      margin-left: -40px;
    }

    .photo_box span {
      display: inline-block;
      vertical-align: middle;
      line-height: normal;
      padding-top: 32px;
    }



    .myclear {
      clear: both;
    }

    /*.page {

    font-family: Kalimati, Georgia, serif;

  }
*/


    /*.font-kalimati {

    font-family: Kalimati, Georgia, serif;

  }



  .font-eng {

    font-family: 'Roboto', Arial, Tahoma, sans-serif;

  }*/



    .cards {

      border-radius: 5px;

      text-align: center;

      padding: 15px;

      color: #fff;

      margin-bottom: 30px;

      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

    }

    .stamp_box {
      width: 80px;
      height: 80px;
      /*float: left;*/
      border: 1px solid #000;
      text-align: left;

    }
  </style>
</head>

<body style="--bleeding: 0.5cm;--margin: 1cm;">
  <div style="margin-left: 636px; margin-top: 20px;" class="hideme">
    <button class="btn btn-info btn-sm " style="color:#FFF;" id="basic"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस
    </button>
    <a href="<?php echo base_url() ?>" class="btn btn-success btn-sm"><i class="fa fa-home"></i> गृह पृष्ठमा जानुहोस</a>
  </div>
  <div class="page <?php echo $detail['bg_color'] ?>">
    <!-- header section -->
    <div class="row">
      <div class="col-md-2">
        <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" style="width: 80px;">
      </div>
      <div class="col-md-8">
        <div class="text-center" style="margin-left:-64px;">
          <p style="font-size: 12px;"><?php echo PSLOGAN ?></p>
          <h3><?php echo GNAME ?></h3>
          <p style="margin-left: 12px;"><?php echo SLOGAN ?><br> <?php echo ADDRESS ?>, <?php echo DISTRICT ?> <br>
            <?php echo STATENAME ?>, नेपाल</p>
          <h5
            style="background: #fff; color: #FE0303;font-weight: bold;font-size: 15px;border-radius: 30px;text-align: center;padding: 8px 8px;display: table;margin-left: 147px">
            <u>अपाङ्गताको परिचय-पत्र</u>
          </h5>
        </div>
      </div>
      <div class="col-md-2">
        <div class="photo_box">
          <?php if (!empty($detail['image'])) { ?>
            <img src="<?php echo base_url() ?>uploads/<?php echo $detail['image'] ?>" style="height: 80px;width: 80px;">
          <?php } ?>

        </div>
      </div>
      <div class="col-md-12">
        <div>प. प. नं.:<span
            class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['darta_no']) ?></span></div>

        <div>परिचयपत्रको किसिम:<span> <?php echo $detail['type_np'] ?></span></div>

        <div>नाम थर:<span> <?php echo $detail['name_np'] ?></span></div>

        <div>ठेगाना:<span> <?php echo $detail['gapa'] ?>,वडा नं:
            <?php echo $this->mylibrary->convertedcit($detail['ward_no']) ?>,<?php echo $detail['district_name'] ?></span>
        </div>

        <div>
          जन्म मिति:<span> <?php echo $this->mylibrary->convertedcit($detail['dob']) ?></span>
          <br>उमेर (बर्ष):<span> <?php echo $this->mylibrary->convertedcit($detail['age']) ?></span>
          <?php if (!empty($detail['birthcertificate_no'])) { ?>
            <span style="margin-left: 245px;margin-top:-20px;">जन्मदर्ता.नं.:
              <?php echo $this->mylibrary->convertedcit($detail['birthcertificate_no']) ?></span>
          <?php } else { ?>
            <span style="margin-left: 245px;margin-top:-20px;">ना. प्रा. नं.:
              <?php echo $this->mylibrary->convertedcit($detail['citizen_no']) ?></span>
          <?php } ?>
        </div>

        <div>लिङ्ग:<span>
            <?php if ($detail['gender'] == 1) {
              echo 'पुरुष';
            } elseif ($detail['gender'] == 2) {
              echo 'महिला';
            } else {
              echo 'अन्य';
            }
            ?>

          </span>
          <span style="margin-left: 262px;">रक्त समुह: <?php echo $detail['blood_group'] ?></span>
        </div>
        <div>प्रकृतिको आधारमा:<span> <?php echo $detail['type_np'] ?></span></div>
        <div>बाबुआमा वा संरक्षकको नामथर: <span><?php echo $detail['maid_name'] ?></span></div>
        <div>सम्पर्क नं: <span><?php echo $this->mylibrary->convertedcit($detail['contact_no']) ?></span></div>
      </div>

      <div class="col-md-6">
        <div>परिचयपत्र वाहकको सहिछाप:</div>
        <div class="row">
          <div class="col-md-3">
            <div class="stamp_box"></div>
          </div>
          <div class="col-md-3">
            <div class="stamp_box"></div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div>परिचय-पत्र प्रमाणित गर्ने</div>
        <div>हस्ताक्षर:<span></span></div>
        <div>नाम थर:<span> <?php echo $approved['name_np'] ?></span></div>
        <div>पद:<span> <?php echo $approved['position_np'] ?></span></div>
        <div>मिति:<span> <?php echo $this->mylibrary->convertedcit(convertDate(date('Y-m-d'))) ?></span></div>
      </div>

      <div class="col-md-12 text-center">
        <div class="col text-center note-nepali">यो परिचय-पत्र कसैले पाएमा नजिकैको प्रहरी चौकी वा स्थानीय तहमा बुझाइदिनु
          होला |</div>
      </div>
    </div>
    <!-- end  -->
  </div><!--end of page-->

  <script src="<?php echo base_url() ?>assets/js/jquery.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/jsprint/printThis.js"></script>
  <script type="text/javascript">
    $(document).ready(function () {
      $('#basic').on("click", function () {
        $('.hideme').hide();
        window.print();
        //$('#container').printThis();
      });
    });
  </script>
</body>

</html>