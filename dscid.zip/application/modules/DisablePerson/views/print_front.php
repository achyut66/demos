<!DOCTYPE html>



<html lang="en">







<head>



  <meta charset="UTF-8">



  <meta name="viewport" content="width=device-width, initial-scale=1.0">



  <meta http-equiv="X-UA-Compatible" content="ie=edge">



  <title></title>



  <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">



  <link href="<?php echo base_url()?>assets/css/bootstrap-reset.css" rel="stylesheet">



  <link href="<?php echo base_url()?>assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />



  <style type="text/css">



    :root {



      --bleeding: 0.5cm;



      --margin: 1cm;



    }







    @page {



      size: A4;



      margin: 0;



    }



    * {



      box-sizing: border-box;



    }







    body {



      font-family: Kalimati, Georgia, serif;



      margin: 0 auto;



      padding: 0;



      background: rgb(204, 204, 204);



      display: flex;



      flex-direction: column;



    }







    .page {



      display: inline-block;



      position: relative;



      /*height: 327mm;*/



      width: 290mm;



      font-size: 12pt;



      margin: 2em auto;



      padding: calc(var(--bleeding) + var(--margin));



      box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);



      background: white;



    }







    @media screen {



      .page::after {



        position: absolute;



        content: '';



        top: 0;



        left: 0;



        width: calc(100% - var(--bleeding) * 2);



        height: calc(100% - var(--bleeding) * 2);



        margin: var(--bleeding);



        /*outline: thin dashed black;*/



        pointer-events: none;



        z-index: 9999;



      }



    }

    @media print {

      .page {

        margin: 0;

        overflow: hidden;

      }

    }



    .input-padder{
      padding-left: 0px;
    }

    .print-size-front{
      width: 590px;
    }
    .purna-idcard-wrapper{
      background: #e74c3c;
      height: auto;
      padding: 15px;
    }
    .asakta-idcard-wrapper{
      background: #3498db;
      height: auto;
      padding: 15px;
    }
    .madyam-idcard-wrapper{
      background: #f1c40f;
      height: auto;
      padding: 15px;
    }
    .samanya-idcard-wrapper{
      background: #ffffff;
      height: auto;
      padding: 10px 15px;
    }

    .idcard-border{
      padding: 0 5px;
      height: 100%;
    }
    .id-photo-frame{
      border: 1px solid #000;
      float: right;
      height: 120px;
      width: 120px;
    }

    .id-title h1{
      color: #000;
      text-align: center;
      font-weight: bold;
      font-size: 20px;
      /*-webkit-text-stroke: 1px rgba(255,255,255,0.3);*/
      margin-top: 0px;
    }

    .id-title p{

      color: #000;

      text-align: center;

      font-weight: bold;

      font-size: 14px;

      /*-webkit-text-stroke: 1px rgba(255,255,255,0.4);*/

      margin: 0 0 5px 0;

    }

    .id-title h2{

      background: #fff;

      color: #FE0303;

      font-weight: bold;

      font-size: 15px;

      border-radius: 30px;

      text-align: center;

      padding: 10px 10px;

      display: table;

      margin: 0 auto;

    }

    .id-body{

      padding: 0 5px;

      font-weight: bold;

      color: #000;

      font-size: 13px;

      margin-top: -29px;

    }

/*.id-body .form-control {

  background: transparent;

  border: 0px;

  border-bottom: 2px dotted #333;

  padding: 0px;

  border-radius: 0;

}

.id-body .form-control:focus{

  box-shadow: 0px !important;

  }*/



  .note-nepali{

    color: #000;

    padding-top: 5px;

    font-weight: bold;

    font-size: 12px;

  }

  .note{

    color: #000;

    padding-top: 10px;

    font-weight: bold;

    font-size: 11px;

  }

  /*** Id Card Back ***/

  .print-size-back{

    width: 590px;

  }

  .idcard-back{

    padding: 5px;

    font-weight: bold;

    color: #000;

    font-size: 13px;

    line-height: 21px;

    margin-top: 50px;

  }

  .stamp-box p{

    text-align: center;

    font-weight: bold;

    padding: 0px; margin:0px;

  }

  .stamp-box-border{

    border: 2px solid #000;

    width: 100%;

    height: 117px;

  }

  /** Custom **/

  @font-face {

    font-family: Kalimati;

    src: url("../../fonts/kalimati.ttf");

  }

  .borderless td, .borderless th {

    border: none !important;

  }

  .circle {

    height: 25px;

    width: 25px;

    border-radius: 50%;

    display: inline-block;

  }

  .photo_box{

    width: 130px;

    height: 130px;

    float: left;

    margin: 15px;
    
    margin-top:5px;

    border: 1px solid #000;

    text-align: center;



  }

  .photo_box span{

    display: inline-block;

    vertical-align: middle;

    line-height: normal;

    padding-top: 45px;

  }



  .myclear{clear: both;}

  body {

    font-family: Kalimati, Georgia, serif;

  }



  .font-kalimati {

    font-family: Kalimati, Georgia, serif;

  }



  .font-eng {

    font-family: 'Roboto', Arial, Tahoma, sans-serif;

  }



  .cards {

    border-radius: 5px;

    text-align: center;

    padding: 15px;

    color: #fff;

    margin-bottom: 30px;

    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

  }

</style>
</head>

<body style="--bleeding: 0.5cm;--margin: 1cm;">

  <div class="page">

   

   <!-- Id Card Front Part -->

   <div style="" class="<?php echo $detail['bg_color']?>">

    <div class="row">

      <div class="col-md-2">

        <img src="<?php echo base_url()?>assets/img/nepal-govt.png" style="width: 80px;">

      </div>

      <div class="col-md-8">

        <div class="id-title">

          <h1><?php echo GNAME?></h1>

          <p><?php echo SLOGAN?><br> <?php echo ADDRESS?>, <?php echo DISTRICT?> <br> <?php echo STATENAME?>, नेपाल</p>

          <h2>मध्यम अपाङ्गताको परिचय-पत्र </h2>

        </div>

      </div>

      <div class="col-md-2">

        <div class="id-photo-frame"></div>

      </div>

    </div>

    <div class="id-body">

      <div class="row">

        <div class="col">प. प. नं. <span class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['darta_no'])?></span></div>

      </div>

      <div class="row">

        <div class="col">प. प. प्रकार: <span class="input-padder"><?php echo ''?></span></div>

      </div>

      <div class="row">

        <div class="col">नाम थर: <span class="input-padder"><?php echo $detail['name_np']?></span></div>

      </div>

      <div class="row">

        <div class="col">ठेगाना: <?php echo $detail['district_name']?>,<?php echo $detail['gapa']?>-<span class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['ward_no'])?></span></div>

      </div>

      <div class="row">

        <div class="col">जन्म मिति/उमेर: <span class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['dob'])?>/<?php echo $this->mylibrary->convertedcit($detail['age'])?></span></div>

        

      </div>

      <div class="row">
        <div class="col">ना. प्रा. नं.: <span class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['citizen_no'])?></span></div>
        <div class="col"> जारी मिति: <span class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['citizen_date'])?></span></div>

        <div class="col">लिङ्ग: <span class="input-padder">

          <?php if($detail['gender'] == 1){

          echo 'पुरुष';

        } elseif($detail['gender'] == 2) {

        echo 'महिला';

      } else {

      echo 'अन्य';

    }?>

  </span></div>

  <div class="col">रक्त समुह: <span class="input-padder"><?php echo $detail['blood_group']?></span></div>

</div>

<div class="row">

  <div class="col">अपाङ्गताको किसिम: प्रकृतिको आधारमा: <span class="input-padder"><?php echo $detail['type_np']?></span></div>

  <div class="col-4">गम्भिरता: <span class="input-padder"><?php echo $detail['level_np']?></span></div>

</div>

<div class="row">

  <div class="col">बाबुआमा वा संरक्षकको नामथर: <span class="input-padder"><?php echo $detail['maid_name']?></span></div>

</div>

<div class="row">

  <div class="col">परिचय-पत्र बाहकको दस्तखत:</div>

  <div class="col">परिचय-पत्र प्रमाणित गर्ने:

    <div class="row">

      <div class="col">हस्ताक्षर:</div>

    </div>

    <div class="row">

      <div class="col">नामथर:</div>

    </div>

    <div class="row">

      <div class="col">पद:</div>

    </div>

    <div class="row">

      <div class="col">मिति:</div>

    </div>

  </div>

</div>

<div class="row">

  <div class="col text-center note-nepali">यो परिचय-पत्र कसैले पाएमा नजिकैको प्रहरी चौकी वा स्थानीय तहमा बुझाइदिनु होला |</div>

</div>

</div>

   </div>

<!-- end of front part -->

<br>

<div style="margin-left: 646px; " class="hideme">

  <button class="btn btn-info btn-sm " style="color:#FFF;" id="basic"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </button>

  <a href="<?php echo base_url()?>" class ="btn btn-success btn-sm"><i class="fa fa-home"></i> गृह पृष्ठमा जानुहोस</a>

</div>

  <script src="<?php echo base_url()?>assets/js/jquery.js"></script>

  <script type="text/javascript" src="<?php echo base_url()?>assets/jsprint/printThis.js"></script>

  <script type="text/javascript">

    $(document).ready(function(){

      $('#basic').on("click", function () {

        $('.hideme').hide();

        window.print();

      });

    });

  </script>

</body>

</html>



