<style type="text/css">
  :root {
    --bleeding: 0.5cm;
    --margin: 1cm;
  }

  /*  @page {*/
  /*  size: A4;
    margin: 0;
  }

  *{
    box-sizing: border-box;
  }*/
  body {
    /*font-family: Kalimati, Georgia, serif;*/
    margin: 0 auto;
    padding: 0;
    background: rgb(204, 204, 204);
    display: flex;
    flex-direction: column;
    color: #000;
  }

  .page {
    display: inline-block;
    position: relative;
    /*height: 327mm;*/
    width: 190mm;
    font-size: 12pt;
    margin: 2em auto;
    padding: calc(var(--bleeding) + var(--margin));
    box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);
    background: white;
  }

  @media screen {
    .page::after {
      position: absolute;
      content: '';
      top: 0;
      left: 0;
      width: calc(100% - var(--bleeding) * 2);
      height: calc(100% - var(--bleeding) * 2);
      margin: var(--bleeding);
      /*outline: thin dashed black;*/
      pointer-events: none;
      z-index: 9999;
    }
  }

  /*@media print {
  .page {
    margin: 0;
    overflow: hidden;
  }
}*/

  /*.print_table {
  width: 100%;
  border: solid 1px;
  border-collapse: collapse;
  margin-top: 10px;
}
*/
  /*.print_table th {
  border-color: black;
  font-size: 16px;
  border: solid 1px;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  color:#000;
  background-color:#c2cdd8;
  text-align: center;
}*/

  /*.print_table td {
  border-color: black;
  font-size: 18px;
  border: solid 1px;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  text-align: center;
  width: auto;
}*/

  /*.print_table tr:nth-child(odd){
  background-color:#fff;
}
.print_table tr:nth-child(even){
  background-color:#ffffff;
}

.print_table table tfoot {
  background-color:#c2cdd8;
}*/

  .input-padder {
    padding-left: 0px;
  }

  .print-size-front {
    width: 590px;
  }

  .purna-idcard-wrapper {
    background: #e74c3c;
    height: auto;
    padding: 15px;
  }

  .asakta-idcard-wrapper {
    background: #3498db;
    height: auto;
    padding: 15px;
  }

  .madyam-idcard-wrapper {
    background: #f1c40f;
    height: auto;
    padding: 15px;
  }

  .samanya-idcard-wrapper {
    background: #ffffff;
    height: auto;
    padding: 10px 15px;
  }

  .idcard-border {
    padding: 0 5px;
    height: 100%;
  }

  .id-photo-frame {
    border: 1px solid #000;
    float: right;
    height: 80px;
    width: 80px;
    margin-top: 75px;
  }

  .id-title h1 {
    color: #000;
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    /*-webkit-text-stroke: 1px rgba(255,255,255,0.3);*/
    margin-top: 0px;
  }

  .id-title p {

    color: #000;

    text-align: center;

    font-weight: bold;

    font-size: 14px;

    /*-webkit-text-stroke: 1px rgba(255,255,255,0.4);*/

    margin: 0 0 5px 0;

  }

  .id-title h2 {

    background: #fff;

    color: #FE0303;

    font-weight: bold;

    font-size: 15px;

    border-radius: 30px;

    text-align: center;

    padding: 10px 10px;

    display: table;

    margin: 0 auto;

  }

  .id-body {
    padding: 0 5px;
    font-weight: bold;
    color: #000;
    font-size: 13px;
    margin-top: -29px;

  }

  /*.id-body .form-control {

  background: transparent;

  border: 0px;

  border-bottom: 2px dotted #333;

  padding: 0px;

  border-radius: 0;

}

.id-body .form-control:focus{

  box-shadow: 0px !important;

  }*/



  .note-nepali {

    color: #000;

    padding-top: 5px;

    font-weight: bold;

    font-size: 12px;

  }

  .note {

    color: #000;

    padding-top: 10px;

    font-weight: bold;

    font-size: 11px;

  }

  /*** Id Card Back ***/

  .print-size-back {

    width: 590px;

  }

  .idcard-back {

    padding: 5px;

    font-weight: bold;

    color: #000;

    font-size: 13px;

    line-height: 21px;

    margin-top: 50px;

  }

  .stamp-box p {

    text-align: center;

    font-weight: bold;

    padding: 0px;
    margin: 0px;

  }

  .stamp-box-border {

    border: 1px solid #000;

    width: 100px;

    height: 100px;

  }

  /** Custom **/

  @font-face {

    font-family: Kalimati;

    src: url("../../fonts/kalimati.ttf");

  }

  .borderless td,
  .borderless th {

    border: none !important;

  }

  .circle {

    height: 25px;

    width: 25px;

    border-radius: 50%;

    display: inline-block;

  }

  .photo_box {
    width: 80px;
    height: 80px;
    /*float: left;*/
    border: 1px solid #000;
    text-align: left;
    margin-top: 2px;
    margin-left: -96px !important;
  }

  .photo_box span {
    display: inline-block;
    vertical-align: middle;
    line-height: normal;
    padding-top: 32px;
  }



  .myclear {
    clear: both;
  }

  /*.page {

    font-family: Kalimati, Georgia, serif;

  }
*/


  /*.font-kalimati {

    font-family: Kalimati, Georgia, serif;

  }



  .font-eng {

    font-family: 'Roboto', Arial, Tahoma, sans-serif;

  }*/



  .cards {

    border-radius: 5px;

    text-align: center;

    padding: 15px;

    color: #fff;

    margin-bottom: 30px;

    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

  }

  .stamp_box {
    width: 80px;
    height: 80px;
    /*float: left;*/
    border: 1px solid #000;
    text-align: left;

  }
</style>

<div class="row">
  <div class="col-sm-12">
    <section class="card">
      <header class="card-header">
        <?php echo $pageTitle ?>
        <span class="tools">
          <?php if ($this->authlibrary->HasModulePermission('DISABLE-PERSON', "ADD")) { ?>
            <a class="btn btn-success btn-sm pull-right"
              href="<?php echo base_url() ?>DisablePerson/PrintBack/<?php echo $detail['id'] ?>" target="_blank"><i
                class="fa fa-print"></i> दोस्रो पृष्ट</a>
            <a class="btn btn-success btn-sm pull-right"
              href="<?php echo base_url() ?>DisablePerson/PrintFront/<?php echo $detail['id'] ?>" target="_blank"><i
                class="fa fa-print"></i> पहिलो पृष्ट</a>
          <?php } ?>
        </span>
      </header>

      <div class="card-body">
        <div class="page <?php echo $detail['bg_color'] ?>">
          <!-- header section -->
          <div class="row">
            <div class="col-md-2">
              <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" style="width: 80px;">
            </div>
            <div class="col-md-8">
              <div class="text-center" style="margin-left:-82px;">
                <p style="font-size: 12px;"><?php echo PSLOGAN ?></p>
                <h3><?php echo GNAME ?></h3>
                <p style="margin-left: 12px;"><?php echo SLOGAN ?><br> <?php echo ADDRESS ?>, <?php echo DISTRICT ?>
                  <br>
                  <?php echo STATENAME ?>, नेपाल
                </p>
                <h5
                  style="background: #fff; color: #FE0303;font-weight: bold;font-size: 15px;border-radius: 30px;text-align: center;padding: 8px 8px;display: table;margin-left: 184px">
                  अपाङ्गताको परिचय-पत्र </h5>
              </div>
            </div>
            <div class="col-md-2">
              <div class="photo_box" style="margin-top:-2px;">
                <?php if (!empty($detail['image'])) { ?>
                  <!--<div class="text" >-->
                  <img width="128" height="128" style="margin-top:-2px;"
                    src="<?php echo base_url() ?>uploads/<?php echo $detail['image'] ?>">
                  <!--</div>-->
                <?php } ?>

              </div>
            </div>
            <div class="col-md-12">
              <div>प. प. नं.:<span
                  class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['darta_no']) ?></span></div>

              <div>परिचयपत्रको किसिम:<span> <?php echo $detail['type_np'] ?></span></div>

              <div>नाम थर:<span> <?php echo $detail['name_np'] ?></span></div>

              <div>ठेगाना:<span> <?php echo $detail['gapa'] ?>,वडा नं:
                  <?php echo $this->mylibrary->convertedcit($detail['ward_no']) ?>,<?php echo $detail['district_name'] ?></span>
              </div>

              <div>जन्म मिति:<span> <?php echo $this->mylibrary->convertedcit($detail['dob']) ?></span>

                <br><span>उमेर (वर्ष):<span> <?php echo $this->mylibrary->convertedcit($detail['age']) ?></span>
                  <?php if (!empty($detail['birthcertificate_no'])) { ?>
                    <span style="margin-left: 274px;margin-top:-20px;">जन्मदर्ता.नं.:
                      <?php echo $this->mylibrary->convertedcit($detail['birthcertificate_no']) ?></span>
                  <?php } else { ?>
                    <span style="margin-left: 274px;margin-top:-20px;">ना. प्रा. नं.:
                      <?php echo $this->mylibrary->convertedcit($detail['citizen_no']) ?></span>
                  <?php } ?>
              </div>

              <div>लिङ्ग:<span>
                  <?php if ($detail['gender'] == 1) {
                    echo 'पुरुष';
                  } elseif ($detail['gender'] == 2) {
                    echo 'महिला';
                  } else {
                    echo 'अन्य';
                  }
                  ?>

                </span>
                <span style="margin-left: 287px;margin-top:-20px;">रक्त समुह:
                  <?php echo $detail['blood_group'] ?></span>
              </div>
              <div>प्रकृतिको आधारमा:<span> <?php echo $detail['type_np'] ?></span></div>
              <div>बाबुआमा वा संरक्षकको नामथर: <span><?php echo $detail['maid_name'] ?></span></div>
              <div>सम्पर्क नं: <span><?php echo $this->mylibrary->convertedcit($detail['contact_no']) ?></span></div>
            </div>

            <div class="col-md-6">
              <div>परिचयपत्र वाहकको सहिछाप:</div>
              <div class="row">
                <div class="col-md-3">
                  <div class="stamp_box"></div>
                </div>
                <div class="col-md-3">
                  <div class="stamp_box"></div>
                </div>
              </div>
            </div>

            <div class="col-md-6">
              <div>परिचय-पत्र प्रमाणित गर्ने</div>
              <div>हस्ताक्षर:<span></span></div>
              <div>नाम थर:<span> <?php echo $approved['name_np'] ?></span></div>
              <div>पद:<span> <?php echo $approved['position_np'] ?></span></div>
              <div>मिति:<span> <?php echo $this->mylibrary->convertedcit(convertDate(date('Y-m-d'))) ?></span></div>
            </div>

            <div class="col-md-12">
              <div class="col text-center note-nepali">यो परिचय-पत्र कसैले पाएमा नजिकैको प्रहरी चौकी वा स्थानीय तहमा
                बुझाइदिनु होला</div>
            </div>
          </div>
          <!-- end  -->
        </div><!--end of page-->

        <div class="page <?php echo $detail['bg_color'] ?>">
          <!-- header section -->
          <div class="row">
            <div class="col-md-2">
              <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" style="width: 80px;">
            </div>
            <div class="col-md-10">
              <div class="text-center">

                <h3 style="margin-left: -35px;"><?php echo GNAMEEN ?></h3>
                <p style="margin-left:-50px; margin-top: -10px;"><b><?php echo SLOGANEN ?></b><br>
                  <?php echo ADDRESSEN ?>, <?php echo DISTRICTEN ?> <br> <?php echo STATEEN ?>, Nepal</p>
                <h5
                  style="background: #fff; color: #FE0303;font-weight: bold;font-size: 15px;border-radius: 30px;text-align: center;padding: 8px 8px;display: table;margin-left: 125px">
                  Disability Identity Card </h5>
              </div>
            </div>
            <div class="col-md-2">
              <!--  <div class="photo_box">
          <img src="<?php echo base_url() ?>uploads/<?php echo $detail['image'] ?>" style="height: 80px;width: 80px;">
        </div> -->
            </div>
            <div class="col-md-12">
              <div>ID Card Number.:<span class="input-padder"><?php echo $detail['darta_no'] ?></span></div>

              <div>ID Card Type:<span> <?php echo $detail['type_en'] ?></span></div>

              <div>Full Name of Person:<span> <?php echo $detail['name_en'] ?></span></div>

              <div>Address:<span> <?php echo $detail['english_name'] ?>,Ward No:
                  <?php echo $detail['ward_no'] ?>,<?php echo $detail['dict'] ?></span></div>

              <div>Date of Birth:<span> <?php echo $detail['dob'] ?><span
                    style="margin-left: 30px;">Age:<?php echo $detail['age'] ?></span>
                  <?php if (!empty($detail['birthcertificate_no'])) { ?>
                    <span style="margin-left: 106px;">BirthCertificate Number.:
                      <?php echo $detail['birthcertificate_no'] ?></span></div>
              <?php } else { ?>
                <span style="margin-left: 106px;">Citizenship Number.: <?php echo $detail['citizen_no'] ?></span>
              </div>
            <?php } ?>

            <div>Gender:<span>
                <?php if ($detail['gender'] == 1) {
                  echo 'Male';
                } elseif ($detail['gender'] == 2) {
                  echo 'Female';
                } else {
                  echo 'Others';
                }
                ?>

              </span>
              <span style="margin-left: 265px;">Blood Group: <?php echo $detail['blood_group'] ?></span>
            </div>
            <div>On the basis of nature:<span> <?php echo $detail['type_en'] ?></span></div>
            <div>Name of Father/Mother/Gurdian: <span><?php echo $detail['father_name'] ?></span></div>
            <div>Contact No: <span><?php echo $detail['contact_no'] ?></span></div>
          </div>

          <div class="col-md-6">
            <div>Signature of Card Holder:</div>
            <div class="row">
              <div class="col-md-12">
                <div class="mail_box">
                  Email: galchhigapa@gmail.com<br>
                  Web: www.galchhimun.gov.np
                </div>
              </div>

            </div>
          </div>

          <div class="col-md-6">
            <div>Approved By</div>
            <div>Signature:<span></span></div>
            <div>Name:<span> <?php echo $approved['name_en'] ?></span></div>
            <div>Designation:<span> <?php echo $approved['position_en'] ?></span></div>

          </div>

          <div class="col-md-12">
            <div class="col text-center note-nepali">"अपाङ्गता भएका व्यक्तिहरु सहितको विकास <?php echo GNAME ?> सबै एक
              साथ"</div>
          </div>
        </div>
        <!-- end  -->
      </div><!--end of page-->
  </div>
  </section>
</div>
</div>