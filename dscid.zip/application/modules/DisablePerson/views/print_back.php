<!DOCTYPE html>



<html lang="en">







<head>



  <meta charset="UTF-8">



  <meta name="viewport" content="width=device-width, initial-scale=1.0">



  <meta http-equiv="X-UA-Compatible" content="ie=edge">



  <title></title>



  <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">



  <link href="<?php echo base_url()?>assets/css/bootstrap-reset.css" rel="stylesheet">



  <link href="<?php echo base_url()?>assets/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />



  <style type="text/css">



    :root {



      --bleeding: 0.5cm;



      --margin: 1cm;



    }







    @page {



      size: A4;



      margin: 0;



    }



    * {



      box-sizing: border-box;



    }







    body {



      font-family: Kalimati, Georgia, serif;



      margin: 0 auto;



      padding: 0;



      background: rgb(204, 204, 204);



      display: flex;



      flex-direction: column;



    }







    .page {



      display: inline-block;



      position: relative;



      /*height: 327mm;*/



      width: 290mm;



      font-size: 12pt;



      margin: 2em auto;



      padding: calc(var(--bleeding) + var(--margin));



      box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);



      background: white;



    }







    @media screen {



      .page::after {



        position: absolute;



        content: '';



        top: 0;



        left: 0;



        width: calc(100% - var(--bleeding) * 2);



        height: calc(100% - var(--bleeding) * 2);



        margin: var(--bleeding);



        /*outline: thin dashed black;*/



        pointer-events: none;



        z-index: 9999;



      }



    }

    @media print {

      .page {

        margin: 0;

        overflow: hidden;

      }

    }



    .input-padder{

      padding-left: 0px;

    }

    .print-size-front{

      width: 590px;

    }

    .purna-idcard-wrapper{

      background: #e74c3c;

      height: auto;

      padding: 15px;

    }

    .asakta-idcard-wrapper{

      background: #3498db;

      height: auto;

      padding: 15px;

    }

    .madyam-idcard-wrapper{

      background: #f1c40f;

      height: auto;

      padding: 15px;

    }

    .samanya-idcard-wrapper{

      background: #ffffff;

      height: auto;

      padding: 10px 15px;

    }

    .idcard-border{

      padding: 0 5px;

      height: 100%;

    }

    .id-photo-frame{

      border: 1px solid #000;

      float: right;

      height: 120px;

      width: 120px;

    }

    .id-title h1{

      color: #000;

      text-align: center;

      font-weight: bold;

      font-size: 20px;

      /*-webkit-text-stroke: 1px rgba(255,255,255,0.3);*/

      margin-top: 0px;

    }

    .id-title p{

      color: #000;

      text-align: center;

      font-weight: bold;

      font-size: 14px;

      /*-webkit-text-stroke: 1px rgba(255,255,255,0.4);*/

      margin: 0 0 5px 0;

    }

    .id-title h2{

      background: #fff;

      color: #FE0303;

      font-weight: bold;

      font-size: 15px;

      border-radius: 30px;

      text-align: center;

      padding: 10px 10px;

      display: table;

      margin: 0 auto;

    }

    .id-body{

      padding: 0 5px;

      font-weight: bold;

      color: #000;

      font-size: 13px;

      margin-top: -29px;

    }

/*.id-body .form-control {

  background: transparent;

  border: 0px;

  border-bottom: 2px dotted #333;

  padding: 0px;

  border-radius: 0;

}

.id-body .form-control:focus{

  box-shadow: 0px !important;

  }*/



  .note-nepali{

    color: #000;

    padding-top: 5px;

    font-weight: bold;

    font-size: 12px;

  }

  .note{

    color: #000;

    padding-top: 10px;

    font-weight: bold;

    font-size: 11px;

  }

  /*** Id Card Back ***/

  .print-size-back{

    width: 590px;

  }

  .idcard-back{

    padding: 5px;

    font-weight: bold;

    color: #000;

    font-size: 13px;

    line-height: 21px;

    margin-top: 50px;

  }

  .stamp-box p{

    text-align: center;

    font-weight: bold;

    padding: 0px; margin:0px;

  }

  .stamp-box-border{

    border: 2px solid #000;

    width: 100%;

    height: 117px;

  }

  /** Custom **/

  @font-face {

    font-family: Kalimati;

    src: url("../../fonts/kalimati.ttf");

  }

  .borderless td, .borderless th {

    border: none !important;

  }

  .circle {

    height: 25px;

    width: 25px;

    border-radius: 50%;

    display: inline-block;

  }

  .photo_box{

    width: 130px;

    height: 130px;

    float: left;

    margin: 15px;

    border: 1px solid #000;

    text-align: center;



  }

  .photo_box span{

    display: inline-block;

    vertical-align: middle;

    line-height: normal;

    padding-top: 45px;

  }



  .myclear{clear: both;}

  body {

    font-family: Kalimati, Georgia, serif;

  }



  .font-kalimati {

    font-family: Kalimati, Georgia, serif;

  }



  .font-eng {

    font-family: 'Roboto', Arial, Tahoma, sans-serif;

  }



  .cards {

    border-radius: 5px;

    text-align: center;

    padding: 15px;

    color: #fff;

    margin-bottom: 30px;

    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

  }

</style>







</head>

<body style="--bleeding: 0.5cm;--margin: 1cm;">

  <div class="page">

   

    <div class="<?php echo $detail['bg_color']?>">

      <div class="idcard-border">

        <div class="idcard-back">

          <div class="row">

            <div class="col">ID Card No: <span class="input-padder"><?php echo $detail['darta_no']?></span></div>

            <div class="col">ID Card Type: <span class="input-padder"> 'Ga'</span></div>

          </div>

          <div class="row">

            <div class="col">1) Name of Id Holder: <span class="input-padder"><?php echo $detail['name_en']?></span></div>

          </div>

          <div class="row">

            <div class="col">2) Address: <?php echo $detail['english_name'].'-'.$detail['ward_no']?>,<?php echo $detail['dict']?><span class="input-padder"></span></div>

          </div>

          <div class="row no-gutters">

            <div class="col-5">3) Date of Birth/Age: <span class="input-padder">,<?php echo $detail['dob']?>/<?php echo $detail['age']?></span></div>

            <div class="col no-gutters">4) Citizenship No./Issue District: <span class="input-padder"><?php echo $detail['citizen_no']?>/<?php echo $detail['citz_dis_en']?></span></div>

          </div>

          <div class="row">

            <div class="col">5) Issue Date: <span class="input-padder"><?php echo $detail['citizen_date']?></span></div>

            <div class="col">6) Sex: <span class="input-padder"><?php if($detail['gender'] == 1){echo 'Male';} elseif($detail['gender'] == 2){echo 'Female';}else{echo 'Others';}?></span></div>

            <div class="col">7) Blood Group: <span class="input-padder"><?php echo $detail['blood_group']?></span></div>

          </div>

          <div class="row">

            <div class="col-4">8) Types of Disability:</div>

            <div class="col-8">

              <div class="row">

                <div class="col">On the basis of Nature: <span class="input-padder"><?php echo $detail['type_en']?></span></div>

              </div>

              <div class="row">

                <div class="col">On the basis of Severity: <span class="input-padder"><?php echo $detail['level_en']?></span></div>

              </div>

            </div>

          </div>

          <div class="row">

            <div class="col">9) Father's Name/Mother's Name/ Name or Guardian: <span class="input-padder"><?php echo $detail['father_name']?></span></div>

          </div>

          <div class="row">

            <div class="col">10) Signature of ID Card Holder:</div>

            <div class="col">11) Approved By:</div>

          </div>

          <div class="row">

            <div class="col-6 mt-2">

              <div class="row">

                <div class="col-6">

                  <div class="stamp-box">

                    <p>Right</p>

                    <div class="stamp-box-border"></div>

                  </div>

                </div>

                <div class="col-6">

                  <div class="stamp-box">

                    <p>Left</p>

                    <div class="stamp-box-border"></div>

                  </div>

                </div>

              </div>

            </div>

            <div class="col-6 mt-4">

              <div class="row">

                <div class="col mb-2">Signature:</div>

              </div>

              <div class="row">

                <div class="col mb-2">Name:<?php echo $approved['name_en']?></div>

              </div>

              <div class="row">

                <div class="col mb-2">Designation:<?php echo $approved['position_en']?></div>

              </div>

              <div class="row">

                <div class="col mb-2">Date:<?php echo date('Y-m-d')?></div>

              </div>

            </div>

          </div>

          <div class="row">

            <div class="col text-center mt-3 note">If somebody finds this ID card, Please deposit this in the nearby police station or municipality office.</div>

          </div>

        </div>

      </div>

    </div>

    <br>

    <div style="margin-left: 646px; " class="hideme">

      <button class="btn btn-info btn-sm " style="color:#FFF;" id="basic"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </button>

      <a href="<?php echo base_url()?>" class ="btn btn-success btn-sm"><i class="fa fa-home"></i> गृह पृष्ठमा जानुहोस</a>

    </div>

    <script src="<?php echo base_url()?>assets/js/jquery.js"></script>

    <script type="text/javascript" src="<?php echo base_url()?>assets/jsprint/printThis.js"></script>

    <script type="text/javascript">

      $(document).ready(function(){

        $('#basic').on("click", function () {

          $('.hideme').hide();

          window.print();

        });

      });

    </script>

  </body>

  </html>



