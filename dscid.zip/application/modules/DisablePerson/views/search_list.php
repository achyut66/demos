<table  class="table table-bordered table-striped print_table" id="list">
  <thead>
    <tr>
      <th>क्र.सं</th>
      <th>प.प.नं</th>
      <th>नाम थर</th>
      <th>जन्म मिति (उमेर) </th>
      <th>ठेगानाः</th>
      <th>लिङ्ग</th>
      <th>रक्त समूह</th>
      <th>अपाङ्गताको प्रकृति </th>
      <th>अपाङ्गताको गम्भिरता</th>
      <th>फोटो</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php if(!empty($disable_person)) :
      $i = 1;
      foreach ($disable_person as $dp) :?>
        <tr>
          <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
          <td><?php echo $this->mylibrary->convertedcit($dp['darta_no'])?></td>
          <td><?php echo $dp['name_np']?></td>
          <td><?php echo $this->mylibrary->convertedcit($dp['dob'])?>(<?php echo $this->mylibrary->convertedcit($dp['age'])?> वर्ष)</td>
          <td><?php echo $dp['gapa'].'-'. $this->mylibrary->convertedcit($dp['ward_no'])?></td>
          <td>
            <?php
            if($dp['gender']==1){
              echo 'पुरुष';
            } elseif ($dp['gender']==2) {
              echo 'महिला';
            } else {
              echo 'अन्य';
            }
            ?>
          </td>
          <td><?php echo $dp['blood_group']?></td>
          <td><?php echo $dp['type_np']?></td>
          <td><?php echo $dp['level_np']?></td>
          <td>
            <?php if(!empty($dp['image'])) {?>

              <img src="<?php echo base_url()?>uploads/<?php echo $dp['image']?>" alt="" style="height: 50px;width: 50px;">
            <?php } else {
              echo '<div class="alert alert-danger">फोटो छैन</div>';
            } ?>
          </td>
          <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "EDIT") || $this->authlibrary->HasModulePermission('DISABLE-PERSON', "DELETE") ) { ?>
            <td class="center hidden-phone">
              <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "EDIT")) { ?>
                <button type="button" data-toggle="modal" href="#editModel" class="btn btn-primary" title="" data-url="<?php echo base_url()?>DisableType/Edit" data-id = "<?php echo $dp['id']?>"><i class="fa fa-pencil"></i></button>
              <?php } ?>
              <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "DELETE") ) { ?>
               <button data-url = "<?php echo base_url()?>DisableType/Delete" data-id = "<?php echo $dp['id']?>" class="btn btn-danger delete_data"><i class="fa fa-trash-o"></i></button>
             <?php } ?>
           </td>
         <?php } ?>
       </tr>
     <?php endforeach;endif;?>
   </tbody>
 </table>