
  <div class="row">
    <div class="col-sm-12">
      <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
      if(!empty($success_message)) { ?>
        <div class="alert alert-success">
          <button class="close" data-close="alert"></button>
          <span> <?php echo $success_message;?> </span>
        </div>
      <?php } ?>
      <section class="card">
        <header class="card-header">
          <?php echo $pageTitle?>
          <span class="tools">
            <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "ADD")) { ?>
             
             <a class="btn btn-danger btn-sm pull-right" href="<?php echo base_url()?>DisablePerson/Add"><i class="fa fa-plus-circle"></i> नयाँ थप्नुहोस्</a>
           <?php  } ?>
         </span>
        </header>
        <div class="card-body">
          <div class="">
           <div class="mail-option">
              <div class="btn-group hidden-phone">
                <input type="text" class="form-control col-md-12" id="pp_no" placeholder="प.प.नं" style="width: 200px;">
              </div>
              <div class="btn-group hidden-phone">
                <input type="text" class="form-control col-md-12" id="pp_no" placeholder="निगरिकता नं" style="width: 100px;">
              </div>

              <div class="btn-group hidden-phone">
                <select class="form-control col-md-12" style="width: 300px;" id="dt"> 
                  <option value="">अपाङ्गताको प्रकृति</option>
                  <?php if(!empty($disable_type)) : 
                      foreach($disable_type as $dt):?>
                        <option value="<?php echo $dt['id']?>"><?php echo $dt['type_np']?></option>
                  <?php endforeach;endif; ?>
                </select>
              </div>

              <div class="btn-group hidden-phone">
                <select class="form-control col-md-12" style="width: 200px;" id="dl">
                  <option value="">अपाङ्गताको गम्भीरता</option>
                  <?php if(!empty($disable_level)) : 
                      foreach($disable_level as $dl):?>
                        <option value="<?php echo $dl['id']?>"><?php echo $dl['level_np']?></option>
                  <?php endforeach;endif; ?>
                </select>
              </div>

              <div class="btn-group hidden-phone">
                <select class="form-control col-md-12" style="width: 100px;" id="ward">
                  <option value="">वार्ड नं </option>
                  <?php if(!empty($ward)) : 
                      foreach($ward as $ward):?>
                        <option value="<?php echo $ward['ward']?>"><?php echo $this->mylibrary->convertedcit($ward['ward'])?></option>
                  <?php endforeach;endif; ?>
                </select>
              </div>

              <div class="btn-group hidden-phone">
                <div class="">
                  <button type="button" class="btn btn-warning" title="खोजी गर्नुहोस्" id="searchDisablePerson"><i class="fa fa-search"></i> खोजी गर्नुहोस्</button>
                </div>
              </div>
            </div> 
            <div class="adv-table" id="search_list">
              <table  class="table table-bordered table-striped print_table" id="list">
                <thead>
                  <tr>
                    <th>क्र.सं</th>
                    <th>प.प.नं</th>
                    <th>नाम थर</th>
                    <th>जन्म मिति (उमेर) </th>
                    
                    <th>ठेगानाः</th>
                    <th>लिङ्ग</th>
                    <th>रक्त समूह</th>
                    <th>अपाङ्गताको प्रकृति </th>
                    <th>अपाङ्गताको गम्भिरता</th>
                    <th>फोटो</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                <?php if(!empty($disable_person)) :
                    $i = 1;
                    foreach ($disable_person as $dp) :?>
                      <tr>
                        <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                        <td><?php echo $this->mylibrary->convertedcit($dp['darta_no'])?></td>
                        <td><?php echo $dp['name_np']?></td>
                        <td><?php echo $this->mylibrary->convertedcit($dp['dob'])?>(<?php echo $this->mylibrary->convertedcit($dp['age'])?> वर्ष)</td>
                        
                        <td><?php echo $dp['gapa'].'-'. $this->mylibrary->convertedcit($dp['ward_no'])?></td>
                        <td>
                          <?php
                            if($dp['gender']==1){
                              echo 'पुरुष';
                            } elseif ($dp['gender']==2) {
                              echo 'महिला';
                            } else {
                              echo 'अन्य';
                            }
                          ?>
                        </td>
                        <td><?php echo $dp['blood_group']?></td>
                        <td><?php echo $dp['type_np']?></td>
                        <td><?php echo $dp['level_np']?></td>
                        <td>
                          <?php if(!empty($dp['image'])) {?>

                            <img src="<?php echo base_url()?>uploads/<?php echo $dp['image']?>" alt="" style="height: 50px;width: 50px;">
                          <?php } else {
                            echo '<div class="alert alert-danger">फोटो छैन</div>';
                        } ?>
                        </td>
                       <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "EDIT") || $this->authlibrary->HasModulePermission('DISABLE-PERSON', "DELETE") ) { ?>
                        <td class="center hidden-phone">

                            <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "EDIT")) { ?>
                              <a href="<?php echo base_url()?>DisablePerson/View/<?php echo $dp['id']?>" class="btn btn-warning" ><i class="fa fa-eye"></i></a>
                            <?php } ?>

                            <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "EDIT")) { ?>
                              <a href="<?php echo base_url()?>DisablePerson/Edit/<?php echo $dp['id']?>" class="btn btn-primary" ><i class="fa fa-pencil"></i></a>
                            <?php } ?>
                              <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "DELETE") ) { ?>
                                 <button data-url = "<?php echo base_url()?>DisablePerson/Delete" data-id = "<?php echo $dp['id']?>" class="btn btn-danger delete_data"><i class="fa fa-trash-o"></i></button>
                            <?php } ?>
                        </td>
                      <?php } ?>
                      </tr>
                <?php endforeach;endif;?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
  <!-- page end-->
</section>
</section>
<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>

