<?php
class DisablePerson extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("DisablePersonMdl");

        $this->module_code = 'DISABLE-PERSON';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
    }

    public function List()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $this->breadcrumb->populate(
                array(
                    'ड्यासबोर्ड' => '',
                    'अपाङ्गता व्यक्ति' => 'DisablePerson/List',
                    'सुची'

                )
            );
            $data['page'] = 'list_all';
            $data['pageTitle'] = 'अपाङ्गता व्यक्तिहरुको सुची';
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['blood_type'] = $this->CommonModel->getData('blood_group');
            $data['disable_type'] = $this->CommonModel->getData('disable_type');
            $data['disable_level'] = $this->CommonModel->getData('disable_level');
            $data['disable_person'] = $this->DisablePersonMdl->getList('disable_person', 'DESC');
            $data['ward'] = $this->CommonModel->getData('wardwise_address', 'ASC', 'ward');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function Add()
    {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['pageTitle'] = 'अपाङ्गता व्यक्ति';
            $this->breadcrumb->populate(
                array(
                    'ड्यासबोर्ड' => '',
                    'अपाङ्गता व्यक्ति' => 'DisablePerson/List',
                    'नया थप्नुहोस '
                )
            );
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['state'] = $this->CommonModel->getData('provinces');
            $data['districts'] = $this->DisablePersonMdl->getAssociateDistricts();
            $data['dists'] = $this->CommonModel->getdata('settings_district');
            $data['gapa_napa'] = $this->DisablePersonMdl->getAssociateGapa('settings_vdc_municipality');
            $data['ward_no'] = $this->DisablePersonMdl->getAssociateWard();
            $data['blood_type'] = $this->CommonModel->getData('blood_group');
            $data['disable_type'] = $this->CommonModel->getData('disable_type');
            $data['disable_level'] = $this->CommonModel->getData('disable_level');
            $data['page'] = 'add';
            $this->load->vars($data);
            $this->load->view('main');
        }
    }

    /**
     * Call on ajax request
     * save fiscal year
     * @return NULL
     */
    public function Save()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name_np', 'name_np', 'required');
            $this->form_validation->set_rules('name_en', 'name_en', 'required');
            $this->form_validation->set_rules('state', 'state', 'required');
            $this->form_validation->set_rules('district', 'district');
            $this->form_validation->set_rules('gapa_napa', 'gapa_napa', 'required');
            $this->form_validation->set_rules('ward_no', 'ward_no', 'required');
            $this->form_validation->set_rules('dob', 'dob', 'required');
            $this->form_validation->set_rules('age', 'age', 'required');
            $this->form_validation->set_rules('blood_group', 'blood_group');
            $this->form_validation->set_rules('gender', 'gender', 'required');
            $this->form_validation->set_rules('father_name_np', 'father_name_np', 'required');
            $this->form_validation->set_rules('father_name_en', 'father_name_en', 'required');
            $this->form_validation->set_rules('citizen_no', 'citizen_no');
            $this->form_validation->set_rules('citizen_date', 'citizen_date');
            $this->form_validation->set_rules('citizen_district', 'citizen_district');
            $this->form_validation->set_rules('birthcertificate_no', 'birthcertificate_no');
            $this->form_validation->set_rules('birthcertificate_district', 'birthcertificate_district');
            $this->form_validation->set_rules('birthcertificate_date', 'birthcertificate_date');
            $this->form_validation->set_rules('disable_type', 'disable_type', 'required');
            $this->form_validation->set_rules('disable_level', 'disable_level', 'required');
            $getMaxDartaNo = $this->DisablePersonMdl->getMaxDartaNo();
            $darta_no = $getMaxDartaNo + 1;
            if ($this->form_validation->run() == false) {
                $response = array(
                    'status' => 'validation_error',
                    'message' => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }

            $name_np = $this->input->post('name_np');
            $name_en = $this->input->post('name_en');
            $state = $this->input->post('state');
            $district = $this->input->post('district');
            $gapa_napa = $this->input->post('gapa_napa');
            $ward_no = $this->input->post('ward_no');
            $dob = $this->input->post('dob');
            $age = $this->input->post('age');
            $blood_group = $this->input->post('blood_group');
            $gender = $this->input->post('gender');
            $father_name_np = $this->input->post('father_name_np');
            $father_name_en = $this->input->post('father_name_en');
            $citizen_no = $this->input->post('citizen_no');
            $contact_no = $this->input->post('contact_no');
            $citizen_date = $this->input->post('citizen_date');
            $citizen_district = $this->input->post('citizen_district');
            $birthcertificate_no = $this->input->post('birthcertificate_no');
            $birthcertificate_district = $this->input->post('birthcertificate_district');
            $birthcertificate_date = $this->input->post('birthcertificate_date');
            $disable_type = $this->input->post('disable_type');
            $disable_level = $this->input->post('disable_level');
            $fiscal_year = get_current_fiscal_year();
            if (!empty($_FILES['userfile']['name'])) {
                $file_name = $this->randomize_image_name($_FILES['userfile']['name']);
                $config = array(
                    'upload_path' => APPPATH . '../uploads',
                    'allowed_types' => "jpg|png|JPEG",
                    'overwrite' => TRUE,
                    'file_name' => $file_name,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) {
                    $response = array(
                        'status' => 'error',
                        'data' => $this->upload->display_errors(),
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $this->upload->do_upload();
                }
            }
            $post_data = array(
                'name_np' => $name_np,
                'name_en' => $name_en,
                'state' => $state,
                'district' => $district,
                'gapa_napa' => $gapa_napa,
                'ward_no' => $ward_no,
                'dob' => $dob,
                'age' => $age,
                'blood_group' => $blood_group,
                'gender' => $gender,
                'maid_name' => $father_name_np,
                'father_name' => $father_name_en,
                'citizen_no' => $citizen_no,
                'citizen_date' => $citizen_date,
                'citizen_district' => $citizen_district,
                'birthcertificate_no' => $birthcertificate_no,
                'birthcertificate_district' => $birthcertificate_district,
                'birthcertificate_date' => $birthcertificate_date,
                'disable_type' => $disable_type,
                'disable_level' => $disable_level,
                'image' => !empty($file_name) ? $file_name : '',
                'contact_no' => $contact_no,
                'status' => 1,
                'fiscal_year' => $fiscal_year,
                'darta_no' => $darta_no,
                'created_at' => date('Y-m-d'),
                'created_by' => $this->session->userdata('DISABLE_USER_ID'),
                'created_ip' => $this->input->ip_address(),
            );
            // pp($post_data);
            $result = $this->CommonModel->insertData('disable_person', $post_data);
            if ($result) {
                $response = array(
                    'status' => 'success',
                    'data' => "सफलतापूर्वक सम्मिलित गरियो",
                    'message' => 'redirect',
                    'redirect_url' => base_url() . "DisablePerson/View/" . $result,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
     * On ajax call load view
     * @param  $id $_POST['id']
     * @return void
     */
    public function Edit()
    {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['title'] = 'अपाङ्गता व्यक्ति';
            $data['pageTitle'] = 'अपाङ्गता व्यक्ति विवरण सम्पादन गर्नुहोस';
            $id = $this->uri->segment(3);
            if (empty($id)) {
                redirect(show_404());
            }
            $data['row'] = $this->CommonModel->getDataByID('disable_person', $id);
            $data['state'] = $this->CommonModel->getData('provinces');
            $data['districts'] = $this->DisablePersonMdl->getAssociateDistrictsById($data['row']['state']);
            $data['dists'] = $this->CommonModel->getdata('settings_district');
            $data['gapa_napa'] = $this->DisablePersonMdl->getAssociateGapaById($data['row']['district']);
            $data['ward_no'] = $this->DisablePersonMdl->getAssociateWard();
            $data['blood_type'] = $this->CommonModel->getData('blood_group');
            $data['disable_type'] = $this->CommonModel->getData('disable_type');
            $data['disable_level'] = $this->CommonModel->getData('disable_level');
            $this->breadcrumb->populate(
                array(
                    'ड्यासबोर्ड' => '',
                    'अपाङ्गता व्यक्ति' => 'DisablePerson/List',
                    'सम्पन्दन गर्नुहोस '
                )
            );
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['page'] = 'edit';
            $this->load->view('main', $data);
        }
    }

    /**
     * This function on ajaxcall update land area type data
     * @param  $_POST
     * @return json response
     */
    public function Update()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name_np', 'name_np', 'required');
            $this->form_validation->set_rules('name_en', 'name_en', 'required');
            $this->form_validation->set_rules('state', 'state', 'required');
            $this->form_validation->set_rules('district', 'district');
            $this->form_validation->set_rules('gapa_napa', 'gapa_napa', 'required');
            $this->form_validation->set_rules('ward_no', 'ward_no', 'required');
            $this->form_validation->set_rules('dob', 'dob', 'required');
            $this->form_validation->set_rules('age', 'age', 'required');
            $this->form_validation->set_rules('blood_group', 'blood_group');
            $this->form_validation->set_rules('gender', 'gender', 'required');
            $this->form_validation->set_rules('father_name_np', 'father_name_np', 'required');
            $this->form_validation->set_rules('father_name_en', 'father_name_en', 'required');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');
            $this->form_validation->set_rules('disable_type', 'disable_type', 'required');
            $this->form_validation->set_rules('disable_level', 'disable_level', 'required');
            $getMaxDartaNo = $this->DisablePersonMdl->getMaxDartaNo();
            //$darta_no = $getMaxDartaNo + 1;
            if ($this->form_validation->run() == false) {
                $response = array(
                    'status' => 'validation_error',
                    'message' => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id = $this->input->post('id');
            $name_np = $this->input->post('name_np');
            $name_en = $this->input->post('name_en');
            $state = $this->input->post('state');
            $district = $this->input->post('district');
            $gapa_napa = $this->input->post('gapa_napa');
            $ward_no = $this->input->post('ward_no');
            $dob = $this->input->post('dob');
            $age = $this->input->post('age');
            $blood_group = $this->input->post('blood_group');
            $gender = $this->input->post('gender');
            $father_name_np = $this->input->post('father_name_np');
            $father_name_en = $this->input->post('father_name_en');
            $citizen_no = $this->input->post('citizen_no');
            $contact_no = $this->input->post('contact_no');
            $citizen_date = $this->input->post('citizen_date');
            $citizen_district = $this->input->post('citizen_district');
            $disable_type = $this->input->post('disable_type');
            $disable_level = $this->input->post('disable_level');
            $old_file = $this->input->post('old_file');

            if (!empty($_FILES['userfile']['name'])) {
                $file_name = $this->randomize_image_name($_FILES['userfile']['name']);
                $config = array(
                    'upload_path' => APPPATH . '../uploads',
                    'allowed_types' => "jpg|png|JPEG",
                    'overwrite' => TRUE,
                    'file_name' => $file_name,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) {
                    $response = array(
                        'status' => 'error',
                        'data' => $this->upload->display_errors(),
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $this->upload->do_upload();
                }
            }
            $post_data = array(
                'name_np' => $name_np,
                'name_en' => $name_en,
                'state' => $state,
                'district' => $district,
                'gapa_napa' => $gapa_napa,
                'ward_no' => $ward_no,
                'dob' => $dob,
                'age' => $age,
                'blood_group' => $blood_group,
                'gender' => $gender,
                'maid_name' => $father_name_np,
                'father_name' => $father_name_en,
                'contact_no' => $contact_no,
                'citizen_no' => $citizen_no,
                'citizen_date' => $citizen_date,
                'citizen_district' => $citizen_district,
                'disable_type' => $disable_type,
                'disable_level' => $disable_level,
                'image' => !empty($file_name) ? $file_name : $old_file,
                'status' => 1,
                'modified_at' => date('Y-m-d'),
                'modified_by' => $this->session->userdata('DISABLE_USER_ID'),
                'modified_ip' => $this->input->ip_address(),
            );
            $result = $this->CommonModel->updateData('disable_person', $id, $post_data);
            if ($result) {
                $response = array(
                    'status' => 'success',
                    'data' => "सफलतापूर्वक सम्मिलित गरियो",
                    'message' => 'redirect',
                    'redirect_url' => base_url() . "DisablePerson/View/" . $id,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
     * This function delete data from database.
     * check proper id is in format of not.
     * @param $id int pk
     * @return boolean.
     */
    public function Delete()
    {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('vehicle_sale', $id);
            if ($result) {
                $response = array(
                    'status' => 'success',
                    'data' => "सफलतापूर्वक हटाइयो",
                    'message' => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status' => 'error',
                    'data' => "Oops something goes worng!!! Please try again",
                    'message' => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed!!!');
        }
    }


    public function View()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $this->breadcrumb->populate(
                array(
                    'ड्यासबोर्ड' => '',
                    'अपाङ्गता व्यक्ति' => 'DisablePerson/List',
                    'पुरा विवरण' => '',
                )
            );
            $data['pageTitle'] = 'अपाङ्गता व्यक्ति';
            $data['breadcrumb'] = $this->breadcrumb->output();
            $id = $this->uri->segment(3);
            $data['page'] = 'details';
            $data['detail'] = $this->DisablePersonMdl->getListByID($id);
            // pp($data['detail']);
            $data['approved'] = $this->CommonModel->getDataById('office_staffs', '1');
            // pp($data['detail']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function Search()
    {
        if ($this->input->is_ajax_request()) {
            $pp_no = $this->input->post('pp_no');
            $dt = $this->input->post('dt');
            $dl = $this->input->post('dl');
            $ward = $this->input->post('ward');
            $data['disable_person'] = $this->DisablePersonMdl->getSearch($pp_no, $dt, $dl, $ward);
            $data_view = $this->load->view('search_list', $data, true);
            $response = array(
                'status' => 'success',
                'data' => $data_view
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    public function getDistrictByState()
    {
        if ($this->input->is_ajax_request()) {
            $state = $this->input->post('state');
            get_district_dropdown($state);
        } else {
            exit('no direct script allowed');
        }
    }

    //get Gapanapa By Districts
    public function getGapanapaByDistricts()
    {
        if ($this->input->is_ajax_request()) {
            $district = $this->input->post('district');
            get_ganapa_dropdown($district);
        } else {
            exit('no direct script allowed');
        }
    }

    public function RemoveImage($id)
    {
        $id = $this->uri->segment(3);
        $image = array('image' => '');
        $data['row'] = $this->CommonModel->getDataByID('disable_person', $id);
        $query = $this->CommonModel->updateData('disable_person', $id, $image);
        if ($query) {
            unlink(FCPATH . "uploads/" . $data['row']['image']);
            redirect('DisablePerson/Edit/' . $id);
        }
    }

    public function PrintFront()
    {
        $data['pageTitle'] = 'जेष्ठ नागरिक विवरण';
        $data['breadcrumb'] = $this->breadcrumb->output();
        $id = $this->uri->segment(3);
        //$data['page']                = 'details';
        $data['detail'] = $this->DisablePersonMdl->getListByID($id);
        $data['approved'] = $this->CommonModel->getDataById('office_staffs', '1');
        $this->load->view('print_front_page', $data);
    }

    public function PrintBack()
    {
        $data['pageTitle'] = 'जेष्ठ नागरिक विवरण';
        $data['breadcrumb'] = $this->breadcrumb->output();
        $id = $this->uri->segment(3);
        // $data['page']                = 'print_back';
        $data['detail'] = $this->DisablePersonMdl->getListByID($id);
        $data['approved'] = $this->CommonModel->getDataById('office_staffs', '1');
        $this->load->view('print_back_page', $data);
    }
}//end of class
