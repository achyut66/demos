  <section class="card">
    <header class="card-header">
      <?php echo form_open('Groups/EditGroupPerm/'.$this->uri->segment(3), array('name'=>'EditGroupPerm', 'id'=>'EditGroupPerm', 'method'=>'post', 'class'=>'form-horizontal'));?>
      <span class="tools pull-right">
        <a href="javascript:;" id="savegroupperm_button" class="btn btn-sm btn-info " style="color:#fff"><i class="fa fa-save"></i> Save</a>
        <a href="javascript:;" id="cancelgroup_button" class="btn btn btn-sm btn-danger" style="color: #fff"><i class="fa fa-remove"></i> Cancel</a>
      </span>
    </header>
    <div class="card-body">
      <?php
      $msg_success = $this->session->flashdata('MSG_SUC_ADD');
      $msg_error = $this->session->flashdata('MSG_ERR_ADD');
      $MSG_ERR_POST = $this->session->flashdata('MSG_ERR_POST');
      if ($msg_success) {
        ?>
        <div class="alert alert-success alert-dismissable" id="msg_success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
          <strong>Success!</strong><?php echo $msg_success;?>
        </div>
      <?php } ?>
      <?php if ($msg_error) {
        ?>
        <div class="alert alert-warning alert-dismissable" id="msg_success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
          <strong>Success!</strong><?php echo $msg_error;?>
        </div>
      <?php } ?>

      <?php if ($MSG_ERR_POST) {
        ?>
        <div class="alert alert-danger alert-dismissable" id="msg_success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
          <strong>Success!</strong><?php echo $MSG_ERR_POST;?>
        </div>
      <?php } ?>
      <table  class="display table table-bordered table-striped" id="dynamic-table">
        <tbody>
          <?php 
          $group_id = $this->uri->segment(3);
          $grouppermissions = '';
          $checkCount = 0;
          $moduleCount = 0;
          if ($parentmodules) {                        
            $grouppermissions .= '<table cellpadding="5" cellspacing="0" border="0" width="100%" class="table table-striped table-hover">
            <tbody>
            <tr>
            <td colspan="100%" align="right"><a href="javascript:void(0);" data-id="group-select-all" data-type="all">All</a>&nbsp;<a href="javascript:void(0);" data-id="group-select-all" data-type="none">None</a></td>
            </tr>';
            $qrymodules = $this->Groupsmodel->listmodule();
            if ($qrymodules) {
              foreach ($qrymodules as $module_row):
                $grouppermissions .= '<tr>';
                $grouppermissions .= '<td>'. $module_row->menu_name . '</td>';
                $qryuseraction = $this->Groupsmodel->listuseraction();
                if($qryuseraction){                 
                  foreach ($qryuseraction as $action_row):
                    $permission = $this->Groupsmodel->checkgroup_permision($module_row->menuid,$action_row->user_action_id,$group_id);
                    $checkbox_id = $module_row->menuid ."_". $action_row->user_action_id;
                    if($permission)
                      $checked = "checked";
                    else
                      $checked = "";
                    $class = 'group-select-all group-select-'.$checkCount.' module-select-'.$moduleCount;
                    $checkbox = form_input(array('type'=>'checkbox','name'=>'chk_permission[]', 'id'=>'chk_permission', 'value'=> $checkbox_id, $checked=>$checked,  'class'=>$class));
                    $grouppermissions .= '<td>'.  $action_row->user_action_name. '&nbsp;&nbsp;' . $checkbox . '</td>';
                  endforeach;
                }
                $mk = 'module-select-'.$moduleCount;
                $grouppermissions .= '<td align="right"><a data-id="'.$mk.'" data-type="all" href="javascript:void(0);">All</a>&nbsp;<a data-id="'.$mk.'" href="javascript:void(0);" data-type="none">None</a></td>';
                $moduleCount++;
              endforeach; 
            }
            $checkCount++;
            $grouppermissions .='</tbody>';
          }
          $grouppermissions .="</table>";
          echo $grouppermissions;
          ?>

          <?php $groupid = (isset($query->groupid) && $query->groupid!='')?$query->groupid:''?>
          <?php echo form_input(array('type'=>'hidden','name'=>'ID', 'id'=>'ID','value'=>$groupid, 'class'=>'form-control', 'required'=>'required'));?>
          <?php echo form_input(array('type'=>'hidden','name'=>'Submit', 'id'=>'Submit','value'=>'Submit', 'class'=>'form-control', 'required'=>'required'));?>
          <?php echo form_close();?>
        </tbody>
      </table>
    </div>
  </section>

  </section>
</section>