 <!-- BEGIN PAGE LEVEL PLUGINS -->
 <script src="<?php echo base_url()?>assets/resources/datatables/scripts/datatable.js" type="text/javascript"></script>
 <script src="<?php echo base_url()?>assets/resources/datatables/datatables.min.js" type="text/javascript"></script>
 <script src="<?php echo base_url()?>assets/resources/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>

 <script src="<?php echo base_url()?>assets/resources/datatables/table-datatables-managed.min.js" type="text/javascript"></script>
 

<!-- END PAGE LEVEL PLUGINS -->