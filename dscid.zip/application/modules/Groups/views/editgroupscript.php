<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/loaders/pace.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/loaders/blockui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/selects/select2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/forms/styling/uniform.min.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/notifications/jgrowl.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/ui/moment/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/pickers/anytime.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/pickers/pickadate/picker.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/pickers/pickadate/picker.date.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/pickers/pickadate/picker.time.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/pickers/pickadate/legacy.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/notifications/bootbox.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/notifications/sweet_alert.min.js"></script>
<script type="text/javascript">
	/* ------------------------------------------------------------------------------
*
*  # Form layouts
*
*  Specific JS code additions for form layouts pages
*
*  Version: 1.0
*  Latest update: Aug 1, 2015
*
* ---------------------------------------------------------------------------- */

$(function() {


    // Select2 select
    // ------------------------------

    // Basic
    $('.select').select2();


    //
    // Select with icons
    //

    // Format icon
    function iconFormat(icon) {
        var originalOption = icon.element;
        if (!icon.id) { return icon.text; }
        var $icon = "<i class='icon-" + $(icon.element).data('icon') + "'></i>" + icon.text;

        return $icon;
    }

    // Initialize with options
    $(".select-icons").select2({
        templateResult: iconFormat,
        minimumResultsForSearch: Infinity,
        templateSelection: iconFormat,
        escapeMarkup: function(m) { return m; }
    });

		$('.pickadate').pickadate({
        format: 'yyyy-mm-dd',
        formatSubmit: 'yyyy-mm-dd',
				selectMonths: true,
  			selectYears: 100
    });

    // Alert if all the information are correct. If correct then submit the form.
    // Alert combination
    $('#BtnSaveContinue').on('click', function() {
        swal({
            title: "Are you sure?",
            text: "The information added to the form would be submitted!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#EF5350",
            confirmButtonText: "Yes, Proceed!",
            cancelButtonText: "No, Wait!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function(isConfirm){
            if (isConfirm) {
                $('#EditGroup').submit();
            }
        });
    });

    // Alert if the user wants to discard the current form. If yes then go back to the listing page.
    $('#BtnDiscardExit').on('click', function() {
        swal({
            title: "Are you sure?",
            text: "Any information added to the form would be discarded and lost!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#EF5350",
            confirmButtonText: "Yes, Discard!",
            cancelButtonText: "No, Wait!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function(isConfirm){
            if (isConfirm) {
                window.location = '<?php echo base_url();?>Users/ListAll';
            }
        });
    });
});
</script>
<script type="text/javascript">
    $('#save_button').on('click', function () {
        $('#Submit').click();
    });

    $('#cancel_button').on('click', function () {
        window.location.assign('<?php echo base_url()?>Groups/ListAll');
    });
    $('#savegroup_button').on('click',function(){
        if($("#FirstName").val() != ''){
        $('#AddGroup').submit();
        }else{
            alert("Role name should not be empty");
            $("#FirstName").focus();
        }
    });
    $('#savegroupperm_button').on('click',function(){
        $('#EditGroupPerm').submit();
    });
    $('#saveperm_button').on('click',function(){
        $('#EditUserPerm').submit();
    });
    $('#cancelgroup_button').on('click', function () {
        window.location.assign('<?php echo base_url()?>Groups/');
    });
    $('.password , .cpassword').on('keyup',function(){
        $('.save_button').attr('disabled', 'disabled');
        var password = $('.password').val();
        var cpassword = $('.cpassword').val();
        if(password === cpassword)
        {
            $('.save_button').removeAttr('disabled');
        }
    });
    $('.changepassword').on('click',function(){
        var checked = $('.changepassword:checked').val();
        console.log(checked);
        if(checked == 'No'){
            $('.changepasswordform').addClass('hidden');
        }
        else
        {
            $('.changepasswordform').removeClass('hidden');
        }
    });

     $('[data-id^="group-select-"]').on('click',function(){
        var type = $(this).data('type');
        var id = $(this).data('id');
        if(type=='all'){
            $('.'+id).prop('checked','checked');
        } else if(type=='none'){
            $('.'+id).prop('checked','');
        }
    });

    $('[data-id^="module-select-"]').on('click',function(){
        var type = $(this).data('type');
        var id = $(this).data('id');
        if(type=='all'){
            $('.'+id).prop('checked','checked');
        } else if(type=='none'){
            $('.'+id).prop('checked','');
        }
    });
</script>
