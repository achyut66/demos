<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
        <span class="tools">
          <?php if($this->authlibrary->HasModulePermission('LAND-RATE', "ADD")) { ?>
            <button type="button" data-toggle="modal" class="btn btn-primary btn-sm pull-right" href="#addModel" data-url="<?php echo base_url()?>Groups/AddGroup" data-id = "">नयाँ थप्नुहोस्</button>
          <?php } ?>
        </span>
      </header>
      <div class="card-body">
        <table  class="display table table-bordered table-striped">
          <thead style="background: #1b5693; color:#fff">
            <tr>
              <th text-aligh="right">#</th> 
              <th>भूमिका</th>
              <th class="hidden-phone">.....</th>
            </tr>
          </thead>
          <tbody>
            <?php if(!empty($groups)) :
              $i = 1;
              foreach($groups as $key => $value) : ?>
                <tr class="gradeX">
                  <td><?php echo $i++?></td>
                  <td><?php echo $value['group_name']?></td>
                  <td class="center hidden-phone">
                    <button type='button' data-toggle='modal' href='#editModel' class='btn-primary btn-sm' data-url='<?php echo base_url()?>Groups/EditGroup' data-id = "<?php echo $value['groupid']?>">विवरण सम्पादन गर्नुहोस </button>
                    <a href = "<?php echo base_url()?>Groups/EditGroupPerm/<?php echo $value['groupid']?>" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" >अनुमति प्रबन्ध गर्नुहोस्</a>
                  </td>
                </tr>
              <?php endforeach;endif; ?>
            </tbody>
          </table>
        </section>
      </div>
    </div>
    <!-- page end-->
  </section>
</section>