<?php
/**
 * Created By: Balram Upadhyay.
 */
class Groupsmodel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function listgroup($limit = null)
    {
        $this->db->where('status', 0);
        $this->db->where('groupid!=', '1');
        (!$limit == null)?$this->db->limit($limit['start'], $limit['end']):"";
        $res =  $this->db->get('group');
        return $res->result_array();
    }
    public function addGroup($data)
    {
        $this->db->insert('group', $data);
    }
    public function getGroup($id)
    {
        $this->db->where('groupid', $id);
        $query = $this->db->get('group');
        if ($query->num_rows()>0) {
            return $query->row();
        } else {
            return '';
        }
    }
    public function editGroup($data, $id)
    {
        $this->db->where('groupid', $id);
        $this->db->update('group', $data);
    }
    public function listmodule($parent_id = 0, $limit=null)
    {
        $this->db->select('*');
        $this->db->from('admin_menu');
        if ($this->session->userdata('usergroup')!=1) {
            $this->db->where('status', '1');
        }
        (!$limit == null)?$this->db->limit($limit['start'], $limit['end']):"";
        $res = $this->db->get();
        return $res->result();
    }
    public function getgroupname($group_id)
    {
        $this->db->select('group_name');
        $this->db->where('groupid', $group_id);
        $query = $this->db->from('group');
        $result = $this->db->get();
        $group = $result->row();
        return $group->group_name;
    }
    public function listuseraction($limit=null)
    {
        $this->db->select('*');
        $this->db->from('user_actions');
        (!$limit == null)?$this->db->limit($limit['start'], $limit['end']):"";
        $res = $this->db->get();
        return $res->result();
    }
    public function checkgroup_permision($module_id, $user_action_id, $group_id)
    {
        $query = "SELECT
                    fn_CheckGroupPermission(". $module_id .",". $user_action_id .",". $group_id .")
                  AS permission
                 ";
        $result = $this->db->query($query);
        $permission = $result->row();
        return $permission->permission;
    }
    public function updategroup_permision($permissions, $group_id, $login_id)
    {
        $this->db->trans_start();
        $permission_set = '';
        if (count($permissions)>0) {
            $permission_set = implode(",", $permissions);
        }
        $parameters = array($permission_set, $group_id,$login_id);
        $qry_res = $this->db->query('CALL sp_InsertGroupPermission(?,?,?)', $parameters);
        $this->db->trans_complete();
    }
    public function getgroupid($user_id)
    {
        $this->db->select('user_group');
        $this->db->where('userid', $user_id);
        $query = $this->db->from('users');
        $result = $this->db->get();
        $group = $result->row();
        return $group->user_group;
    }
    public function checkuser_perm($module_id, $user_action_id, $user_id)
    {
        $query = "SELECT
                    fn_CheckUserPermission(". $module_id .",". $user_action_id .",". $user_id .")
                  AS permission
                 ";
        $result = $this->db->query($query);
        $permission = $result->row();
        return $permission->permission;
    }
    public function updateuser_perm($permissions, $user_id, $login_id)
    {
        $this->db->trans_start();
        $permission_set = '';
        if (count($permissions)>0) {
            $permission_set = implode(",", $permissions);
        }
        $parameters = array($permission_set, $user_id, $login_id);
        $qry_res = $this->db->query('CALL sp_InsertUserPermission(?,?,?)', $parameters);
        $this->db->trans_complete();
    }
}
