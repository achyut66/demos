
              <div class="row">
                <div class="col-sm-12">
                  <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
                      if(!empty($success_message)) { ?>
                      <div class="alert alert-success">
                          <button class="close" data-close="alert"></button>
                          <span> <?php echo $success_message;?> </span>
                      </div>
                    <?php } ?>
                  <section class="card">
                    <header class="card-header">
                      <?php echo $pageTitle?>
                      <span class="tools">
                        <?php if($this->authlibrary->HasModulePermission('VEHICLE-PURCHASE', "ADD")) { ?>
                         <a class="btn btn-primary btn-sm pull-right" href="<?php echo base_url()?>VehiclePurchase/Add"><i class="fa fa-plus-circle"></i> नयाँ थप्नुहोस्</a>
                        <?php } ?>
                       </span>
                    </header>
                    <div class="card-body">
                      <div class="adv-table">
                        <div class="mail-option">
                          <div class="btn-group hidden-phone">
                            <input type="text" class="form-control col-md-12" id="org_name" placeholder="नाम" style="width: 500px;">
                          </div>
                          <div class="btn-group hidden-phone">
                            <input type="text" class="form-control col-md-12" id="darta_no" placeholder="नागरिकता नं." style="width: 300px;">
                          </div>
                          <div class="btn-group hidden-phone">
                            <div class="">
                              <button type="button" class="btn btn-warning" title="खोजी गर्नुहोस्" id="filter"><i class="fa fa-search"></i> खोजी गर्नुहोस्</button>
                            </div>
                          </div>

                        </div>

                        <table  class="table table-striped table-bordered print_table" id="listpurchase">
                          <thead>
                            <tr>
                              <th rowspan="2" style="background-color: #f0f1f3">क्र.सं</th>
                              <th colspan="4" class="text-center">सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण</th>
                              <th colspan="3" style="width:180px;">नागरिकता विवरण </th>
                              <th colspan="4" style="width:180px;">सवारी आयकर तिरेको प्रमाण</th>
                              <th rowspan="2" style="width:300px;background-color: #f0f1f3"></th>
                            </tr>
                            <tr>
                              <th style="width:180px;">नाम</th>
                              <th style="width:180px;">ठेगाना</th>
                              <th style="width:180px;">बावु / पतिको नाम</th>
                              <th style="width:180px;">बाजेको नाम थर</th>
                              <th style="width:180px;">नागरिकता नं</th>
                              <th style="width:180px;">जारी मिति</th>
                              <th style="width:180px;">जारी जिल्ला</th>
                              <th style="width:180px;">कार्यालय</th>
                              <th style="width:180px;">अवधि</th>
                              <th style="width:180px;">मिति</th>
                              <th style="width:180px;">रसिद नं</th>
                            </tr>
                          </thead>
                          <tbody>
                           
                          </tbody>
                        </table>
                      </div>
                    
                </div>
              </div>
              <!-- page end-->
          </section>
      </section>

    <script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>
    <script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
    <script type="text/javascript">
    $(document).ready(function(){
      fetch_all_data();
      function fetch_all_data(org_name,darta_no){
        var oTable = $('#listpurchase').DataTable({
          "order": [[ 0, 'desc' ]],
          "searching": false,
          'lengthChange':false,
          "processing": true,
          "serverSide": true,
          // "ordering": false,
          'language': {
              'loadingRecords': '&nbsp;',
              'processing': '<div class="spinner"></div>'
          },
          "ajax":{
            "url": "<?php echo base_url('VehiclePurchase/GetVechilePurchase') ?>",
            "dataType": "json",
            "type": "POST",
            "data":{  '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',org_name:org_name,darta_no:darta_no}
            },
           "columns": [
                { "data" : "sn" },
                { "data" : "name" },
                { "data" : "address" },
                { "data" : "father_name" },
                { "data" : "grand_father_name" },
                { "data" : "citizen_no" },
                { "data" : "citizen_date" },
                { "data" : "citizen_district" },
                { "data" : "tax_office" },
                { "data" : "tax_period" },
                { "data" : "tax_date" },
                { "data" : "tax_bill_no" },
                {
                "data": "", render: function ( data, type, row ) {
                  var res = "";
               
                  // <?php //if($this->authlibrary->HasModulePermission('VEHICLE-SALE', "EDIT")) { ?>
                  //     res += '<a class="btn btn-warning btn-sm" title="विवरण हेर्नुहोस" href = "<?php //echo base_url()?>VehicleSale/View/'+row.id+'" style="margin-top:3px;"><i class="fa fa-file"></i></a>&nbsp;';
                  // <?php //} ?>


                  <?php if($this->authlibrary->HasModulePermission('VEHICLE-PURCHASE', "EDIT")) { ?>
                      res += '<a class="btn btn-primary btn-sm" title="सम्पन्दन गर्नुहोस " href = "<?php echo base_url()?>VehiclePurchase/Edit/'+row.id+'" style="margin-top:3px;"><i class="fa fa-pencil"></i></a>&nbsp;';
                  <?php } ?>
                  <?php if($this->authlibrary->HasModulePermission('VEHICLE-PURCHASE', "DELETE") ) { ?>
                     res += '<button data-url = "<?php echo base_url()?>VehiclePurchase/Delete" data-id = "'+row.id+'" class="btn btn-danger btn-sm delete_data" title="हटाउनुहोस्" style="margin-top:3px;"><i class="fa fa-trash-o"></i></button>&nbsp;';
                  <?php } ?>
                  return res;
                },"bVisible": true, "bSearchable": false, "bSortable": false
              },
            ]
        });
      }
    
      $('#filter').click(function(){
        var org_name          = $('#org_name').val();
        var darta_no          = $('#darta_no').val();

        $('#listpurchase').DataTable().destroy();
          fetch_all_data(org_name,darta_no);
        });
    
      $(document).on('click','.btn-delete', function(e){
        var id = $(this).data('id'); //Fetch id from modal trigger button
        var url = $(this).data('url');
        if (confirm("Are you sure want to delete?") == true) {
                $.ajax({
                  type : 'POST',
                  url : url, //Here you will fetch records 
                  data: {id:id,'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'}, //Pass $id
                  success : function(resp){
                  //   return;
                    if(resp.status == 'success') {
                      toastr.options = {
                        "closeButton": true,
                        "debug": true,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "showDuration": "200",
                        "hideDuration": "1000",
                        "timeOut": "3000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                      };
                      toastr.success(resp.data);
                      setTimeout(function(){ 
                        location.reload();
                      }, 2000);
                    } else {
                      toastr.options = {
                        "closeButton": true,
                        "debug": true,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                      };
                      toastr.success(resp.data);
                      setTimeout(function(){ 
                        location.reload();
                      }, 2000);
                    }
                   }
                });
        } else {
          return false;
        }
      });
    });
  </script>
