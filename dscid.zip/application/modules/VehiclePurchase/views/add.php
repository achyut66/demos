<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
  
     
    <?php echo form_open_multipart('VehiclePurchase/Save', array('name'=>'vehicle_purchase', 'id'=>'vehicle_purchase', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <div class="row">
          <div class="col-md-12">
            <section class="card">
              <header class="card-header">सवारी खरिद गर्ने / लिलाम साकार गर्ने / उपहार / बकस पाउनेको विवरण</header>
                <div class="card-body">
                  <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label> नाम थर </label>
                          <?php echo form_input(array('name'=>'name', 'id'=>'org_name', 'class'=>'form-control '));?>
                        </div>
                      </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>वर्ष </label>
                        <?php echo form_input(array('name'=>'age', 'id'=>'age', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>ठेगानाः </label>
                        <?php echo form_input(array('name'=>'address', 'id'=>'address', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बावु / पतिको नाम थर</label>
                        <?php echo form_input(array('name'=>'father_name', 'id'=>'father_name', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बाजेको नाम थर</label>
                        <?php echo form_input(array('name'=>'grand_father_name', 'id'=>'grand_father_name', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नागरिकता नं </label>
                        <?php echo form_input(array('name'=>'citizen_no', 'id'=>'citizen_no', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी मिति</label>
                        <?php echo form_input(array('name'=>'citizen_date', 'id'=>'citizen_date', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी जिल्ला</label>
                        <?php echo form_input(array('name'=>'citizen_district', 'id'=>'citizen_district', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> कर बुझाएको कार्यालय </label>
                        <?php echo form_input(array('name'=>'tax_office', 'id'=>'tax_office', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> मिति</label>
                        <?php echo form_input(array('name'=>'tax_date', 'id'=>'tax_date', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> अवधिः</label>
                        <?php echo form_input(array('name'=>'tax_period', 'id'=>'tax_period', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label> रसिद नं.</label>
                        <?php echo form_input(array('name'=>'tax_bill_no', 'id'=>'tax_bill_no', 'class'=>'form-control '));?>
                      </div>
                    </div>

                  </div>
                  <div class="col-md-12 text-center">
                      <hr>
                      <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
                      <a href="<?php echo base_url()?>VehiclePurchase/List" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
                    </div>
                  </div>
                </div>
            </section>
          </div>

         
        </div>
    <?php echo form_close()?>
    </div>
  </div>
  <!-- page end-->
</section>
</section>
