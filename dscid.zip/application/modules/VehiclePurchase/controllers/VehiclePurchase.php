<?php
class VehiclePurchase extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("VehiclePurchasemdl");

        $this->module_code = 'VEHICLE-REGISTER';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index(){}

    public function List() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'सवारी खरिद'         => 'VehiclePurchase/List',
                
            ));
            $data['pageTitle'] = 'सवारी खरिद गर्ने / लिलाम साकार गर्ने / उपहार / बकस पाउनेको विवरण';
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['page'] = 'list_all';
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function Add() {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['title']                          = 'सवारी खरिद गर्ने';
            $data['pageTitle']                      = 'सवारी खरिद गर्ने / लिलाम साकार गर्ने / उपहार / बकस पाउनेको विवरण';
            $data['documents']                      = $this->CommonModel->getData('document_type');
            $this->breadcrumb->populate(array(
              'ड्यासबोर्ड'                            => '',
              'सवारी खरिद '                           => 'VehiclePurchase/List',
              'नया थप्नुहोस '
            ));
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['page']                           = 'add';
            $this->load->vars($data);
            $this->load->view('main');
        }
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function Save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name', 'name', 'required');
            $this->form_validation->set_rules('address', 'address', 'required');
            $this->form_validation->set_rules('father_name', 'father_name', 'required');
            $this->form_validation->set_rules('grand_father_name', 'grand_father_name');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');
            $this->form_validation->set_rules('tax_office', 'tax_office', 'required');
            $this->form_validation->set_rules('tax_date', 'tax_date', 'required');
            $this->form_validation->set_rules('tax_period', 'tax_period', 'required');
            $this->form_validation->set_rules('tax_bill_no', 'tax_bill_no', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $name                       = $this->input->post('name');
            $age                        = $this->input->post('age');
            $address                    = $this->input->post('address');
            $father_name                = $this->input->post('father_name');
            $grand_father_name          = $this->input->post('grand_father_name');
            $citizen_no                 = $this->input->post('citizen_no');
            $citizen_date               = $this->input->post('citizen_date');
            $citizen_district           = $this->input->post('citizen_district');
            $tax_office                 = $this->input->post('tax_office');
            $tax_date                   = $this->input->post('tax_date');
            $tax_period                 = $this->input->post('tax_period');
            $tax_bill_no                = $this->input->post('tax_bill_no');
            $post_data = array(
                'name'                  => $name,
                'age'                   => $age,
                'address'               => $address,
                'father_name'           => $father_name,
                'grand_father_name'     => $grand_father_name,
                'citizen_no'            => $citizen_no,
                'citizen_date'          => $citizen_date,
                'citizen_district'      => $citizen_district,
                'tax_office'            => $tax_office,
                'tax_date'              => $tax_date,
                'tax_period'            => $tax_period,
                'tax_bill_no'           => $tax_bill_no,
                'created_at'            => date('Y-m-d'),
                'created_by'            => $this->session->userdata('PRJ_USER_ID'),
                'created_ip'            => $this->input->ip_address(),

            );
            $result = $this->CommonModel->insertData('vehicle_purchase',$post_data);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'VehiclePurchase/List',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
            exit('no direct script allowed');
        }
    }

    /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
     */
    public function Edit() {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['title']                          = 'सवारी खरिद गर्नुहोस';
            $data['pageTitle']                      = 'सवारी खरिद गर्नुहोस';
            $id                                     = $this->uri->segment(3);
            if(empty($id)) {
                redirect(show_404());
            }
            $data['query']                          = $this->CommonModel->getDataByID('vehicle_purchase', $id);
            $this->breadcrumb->populate(array(
              'ड्यासबोर्ड'                            => '',
              'सवारी खरिद'                           => 'VehiclePurchase/List',
              'सुची'
            ));
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['page']                           = 'edit';
            $this->load->view('main',$data);
        }
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name', 'name', 'required');
            $this->form_validation->set_rules('address', 'address', 'required');
            $this->form_validation->set_rules('father_name', 'father_name', 'required');
            $this->form_validation->set_rules('grand_father_name', 'grand_father_name');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');
            $this->form_validation->set_rules('tax_office', 'tax_office', 'required');
            $this->form_validation->set_rules('tax_date', 'tax_date', 'required');
            $this->form_validation->set_rules('tax_period', 'tax_period', 'required');
            $this->form_validation->set_rules('tax_bill_no', 'tax_bill_no', 'required');
           
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id                         = $this->input->post('id');
            $name                       = $this->input->post('name');
            $age                        = $this->input->post('age');
            $address                    = $this->input->post('address');
            $father_name                = $this->input->post('father_name');
            $grand_father_name          = $this->input->post('grand_father_name');
            $citizen_no                 = $this->input->post('citizen_no');
            $citizen_date               = $this->input->post('citizen_date');
            $citizen_district           = $this->input->post('citizen_district');
            $tax_office                 = $this->input->post('tax_office');
            $tax_date                   = $this->input->post('tax_date');
            $tax_period                 = $this->input->post('tax_period');
            $tax_bill_no                = $this->input->post('tax_bill_no');
            $post_data = array(
                'name'                  => $name,
                'age'                   => $age,
                'address'               => $address,
                'father_name'           => $father_name,
                'grand_father_name'     => $grand_father_name,
                'citizen_no'            => $citizen_no,
                'citizen_date'          => $citizen_date,
                'citizen_district'      => $citizen_district,
                'tax_office'            => $tax_office,
                'tax_date'              => $tax_date,
                'tax_period'            => $tax_period,
                'tax_bill_no'           => $tax_bill_no,
                'modified_at'           => date('Y-m-d'),
                'modified_by'           => $this->session->userdata('PRJ_USER_ID'),
                'modified_ip'           => $this->input->ip_address(),

            );
            $result = $this->CommonModel->UpdateData('vehicle_purchase',$id, $post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
                exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('vehicle_purchase',$id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक हटाइयो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Oops something goes worng!!! Please try again",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed!!!');
        }
    }


    /**
        * This function on ajaxcall load server side data into datatable
        * @param  NULL
        * @return json 
    */
    public function GetVechilePurchase() 
    {
      if($this->input->is_ajax_request()) {
          $columns = array( 
            0   => 'id',
           
          );

          $limit                    = $this->input->post('length');
          $start                    = $this->input->post('start');
          $sn                       = $start + 1;
          $org_name                 = $this->input->post('org_name');
          $darta_no                 = $this->input->post('darta_no');
         
          $order                    = $columns[$this->input->post('order')[0]['column']];
          $dir                      = $this->input->post('order')[0]['dir'];
          $totalData                = $this->VehiclePurchasemdl->CountList($org_name,$darta_no);
          $totalFiltered            = $totalData;
          $posts                    = $this->VehiclePurchasemdl->getList($limit,$start,$order,$dir,$org_name,$darta_no);
          $data           = array();
          if(!empty($posts))
          {
              $i = 1;
              foreach ($posts as $post)
              {
                $nestedData['sn']                     = $this->mylibrary->convertedcit($sn++);
                $nestedData['id']                     = $post->id;
                $nestedData['name']                   = $post->name;
                $nestedData['address']                = $post->address;
                $nestedData['father_name']            = $post->father_name;
                $nestedData['grand_father_name']      = $post->grand_father_name;
                $nestedData['citizen_no']             = $post->citizen_no;
                $nestedData['citizen_date']           = $post->citizen_date;
                $nestedData['citizen_district']       = $post->citizen_district;
                $nestedData['tax_office']             = $post->tax_office;
                $nestedData['tax_date']               = $post->tax_date;
                $nestedData['tax_period']             = $post->tax_period;
                $nestedData['tax_bill_no']            = $post->tax_bill_no;
                if($post->status == 1 ) {
                    $nestedData['status']             = '<p class="badge badge-danger">स्वीकृत नभएको</p>';
                } elseif($post->status == 2 ){
                    $nestedData['status']             = '<p class="badge badge-danger">स्वीकृत भएको</p>';
                } else {
                    $nestedData['status']             = "";
                }
                $data[] = $nestedData;
              }
          }
          $json_data = array(
                      "draw"            => intval($this->input->post('draw')),  
                      "recordsTotal"    => intval($totalData),                    "recordsFiltered" => intval($totalFiltered), 
                      "data"            => $data   
                      );
              
          echo json_encode($json_data);
      } else {
          exit('HTTPS!!');
      }
    }

    public function View() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'              => '',
                'सवारी दर्ता'             => 'VehicleRegister/List',
                'पुरा विवरण'              => '',
            ));
            $data['pageTitle']          = 'सवारी दर्ता';
            $data['breadcrumb']         = $this->breadcrumb->output();
            $id                         = $this->uri->segment(3);
            $data['page']               = 'view_details';
            $data['query']              = $this->CommonModel->getDataByID('vehicle_purchase', $id);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

}//end of class
