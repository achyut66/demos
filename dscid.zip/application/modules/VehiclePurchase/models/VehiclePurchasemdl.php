<?php 

class VehiclePurchasemdl extends CI_Model {

	/*
        * this funcrtion get all main topic list 
        * @param null
        @ return array main topic list.
    */
	public function getList($limit,$start,$col,$dir,$org_name,$darta_no) {
		$this->db->select('*');
        $this->db->from('vehicle_purchase');
        if(!empty($org_name)){
            $this->db->where('name', $org_name);
        }
        if(!empty($darta_no)){
            $this->db->where('citizen_no', $darta_no);
        }
        $this->db->limit($limit, $start);
        $this->db->order_by($col,$dir);
        $query = $this->db->get();
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
	}

    /**
        * This function get sanrachan land and sanrachana.
        * @param NULL
        * @return array
    */
    public function CountList($org_name,$darta_no)
    {
        $this->db->select('*')->from('vehicle_purchase');
        if(!empty($org_name)){
            $this->db->where('name', $org_name);
        }
        if(!empty($darta_no)){
            $this->db->where('citizen_no', $darta_no);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }
}