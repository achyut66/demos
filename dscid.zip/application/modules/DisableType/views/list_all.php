
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">
          आर्थिक वर्षको सूची
            <span class="tools">
              <?php if($this->authlibrary->HasModulePermission('DISABLE-TYPE', "ADD")) { ?>
               <button type="button" data-toggle="modal" class="btn btn-danger btn-sm pull-right" href="#addModel" data-url="<?php echo base_url()?>DisableType/Add" data-id = ""><i class="fa fa-plus-circle"></i> नयाँ थप्नुहोस्</button>
              <?php } ?>
             </span>
          </header>
          <div class="card-body">
            <div class="adv-table" id="search_list">
              <table  class="table table-bordered table-striped print_table">
                <thead>
                    <tr>
                      <th text-aligh="right">#</th> 
                      <th>अपाङ्गको प्रकृतिको </th>
                      <th>अपाङ्गको प्रकृतिको(English) </th>
                      <th></th>
                    </tr>
                </thead>
                <tbody>
                  <?php if(!empty($sections)) :
                    $i = 1;
                    foreach($sections as $key => $value) : ?>
                    <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['type_np'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['type_en'])?></td>
                        <?php if($this->authlibrary->HasModulePermission('DISABLE-TYPE', "EDIT") || $this->authlibrary->HasModulePermission('DISABLE-TYPE', "DELETE") ) { ?>
                        <td class="center hidden-phone">
                          <?php if($this->authlibrary->HasModulePermission('DISABLE-TYPE', "EDIT")) { ?>
                              <button type="button" data-toggle="modal" href="#editModel" class="btn btn-primary" title="" data-url="<?php echo base_url()?>DisableType/Edit" data-id = "<?php echo $value['id']?>"><i class="fa fa-pencil"></i></button>
                            <?php } ?>
                              <?php if($this->authlibrary->HasModulePermission('DISABLE-TYPE', "DELETE") ) { ?>
                                 <button data-url = "<?php echo base_url()?>DisableType/Delete" data-id = "<?php echo $value['id']?>" class="btn btn-danger delete_data"><i class="fa fa-trash-o"></i></button>
                            <?php } ?>
                        </td>
                      <?php } ?>
                    </tr>
                    <?php endforeach;endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
</section>
</section>

<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>
<script src="<?php echo base_url('assets/datatable/datatables.min.js') ?>"></script>
<!-- <script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click','.delete_data', function(e){
      var id = $(this).data('id'); //Fetch id from modal trigger button
      var url = $(this).data('url');
      if (confirm("Are you sure want to delete?") == true) {
              $.ajax({
                type : 'POST',
                url : url, //Here you will fetch records 
                data: {id:id,'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'}, //Pass $id
                success : function(resp){
                //   return;
                  if(resp.status == 'success') {
                    toastr.options = {
                      "closeButton": true,
                      "debug": true,
                      "progressBar": true,
                      "positionClass": "toast-top-right",
                      "showDuration": "200",
                      "hideDuration": "1000",
                      "timeOut": "3000",
                      "extendedTimeOut": "1000",
                      "showEasing": "swing",
                      "hideEasing": "linear",
                      "showMethod": "fadeIn",
                      "hideMethod": "fadeOut"
                    };
                    toastr.success(resp.data);
                    setTimeout(function(){ 
                      location.reload();
                    }, 2000);
                  } else {
                    toastr.options = {
                      "closeButton": true,
                      "debug": true,
                      "progressBar": true,
                      "positionClass": "toast-top-right",
                      "showDuration": "300",
                      "hideDuration": "1000",
                      "timeOut": "5000",
                      "extendedTimeOut": "1000",
                      "showEasing": "swing",
                      "hideEasing": "linear",
                      "showMethod": "fadeIn",
                      "hideMethod": "fadeOut"
                    };
                    toastr.success(resp.data);
                    setTimeout(function(){ 
                      location.reload();
                    }, 2000);
                  }
                 }
              });
      } else {
        return false;
      }
    });
  });
</script> -->