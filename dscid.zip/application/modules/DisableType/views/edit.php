<form action="<?php echo base_url()?>DisableType/Update" method="post" class="form save_post">
  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <div class="form-group">
    <div class="col-md-12">
       <input type="hidden" class="form-control" placeholder=""  name="id" value="<?php echo $row['id']?>">
      <div class="form-group">
        <label>अपाङ्गको प्रकृति (नेपाली)<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="type_np" value="<?php echo $row['type_np']?>" required="required">
      </div>

      <div class="form-group">
        <label>अपाङ्गको प्रकृति (English) <span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="type_en" value="<?php echo $row['type_en']?>" required="required">
      </div>

    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सम्पादन गर्नुहोस्</button>
    <button type="button" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" data-dismiss="modal">रद्द गर्नुहोस्</button>
  </div>
</form>