<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php echo form_open_multipart('Chalani/Save', array('name'=>'add_chalani', 'id'=>'add_chalani', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <div class="row">
          <div class="col-md-12">
            <section class="card">
              <header class="card-header">चलानी गर्नुहोस</header>
                <div class="card-body">
                  <div class="row">
                    <input type="hidden" name="file_id" value="<?php echo $fileDetails['file_id']?>">
                    <input type="hidden" name="id" value="<?php echo $fileDetails['id']?>">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>मिति </label>
                        <div class="iconic-input right">
                          <i class="fa fa-calendar f14" style="color:red"></i>
                          <input type="text" class="form-control"  name="chalani_date" id="chalani_date" value="<?php echo convertDate(date('Y-m-d'))?>">
                        </div>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label>किसिम</label>
                       
                       <input type="text" class="form-control" name="file_type" value="<?php echo $fileDetails['file_type']?>" readonly ="true">
                      </div>
                    </div>
                    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>सवारी नं</label>
                        <input type="text" class="form-control" name="vehicle_no" value="<?php echo $fileDetails['vehicle_no']?>" readonly ="true">
                      </div>
                    </div>

                 
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>चलानी गर्नुपर्ने फाँट</label>
                        <select class="form-control" name="department" required="true">
                          <option value="">छानुहोस</option>
                          <?php if(!empty($department)) : 
                            foreach ($department as $depart) : ?>
                              <option value="<?php echo $depart['department_name']?>"><?php echo $depart['department_name']?></option>
                          <?php endforeach;endif;?>
                        </select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label>बुझिलिनेको नाम</label>
                        <?php echo form_input(array('name'=>'name', 'id'=>'name', 'class'=>'form-control', 'required' =>'true'));?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label>कैफियत</label>
                        <?php echo form_input(array('name'=>'remarks', 'id'=>'remarks', 'class'=>'form-control '));?>
                      </div>
                    </div>

                    <div class="col-md-12">
                      <hr>
                      <div class="text-center">
                        <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
                        <a href="<?php echo base_url()?>Chalani" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
                      </div>
                     
                    </div>
                  </div>
                  
                </div>
            </section>

          <!--   <section class="card">
                <div class="card-body">
                
                </div>
            </section> -->

          </div>

        </div>
    <?php echo form_close()?>
    </div>
  </div>
  <!-- page end-->
</section>
</section>
<script type="text/javascript">
  $(document).ready(function(){
    var mainInput = $("#chalani_date");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 10
    });

  });
</script>