
    <div class="row">
      <div class="col-sm-12">
       
        <section class="card">
          <header class="card-header">
         चलानी किताब
          
          </header>
          <div class="card-body">
            <div class="adv-table">
              <table  class="table table-inbox table-bordered table-striped print_table">
                <thead>
                    <tr>
                      <th>मिति</th> 
                      <th>चलानी नं</th>
                      <th>सवारी नं</th>
                      <th>चलानी गर्नुपर्ने फाँट</th>
                      <th>बुझिलिनेको नाम</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($chalanidetals['chalani_date'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($chalanidetals['chalani_no'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($chalanidetals['vehicle_no'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($chalanidetals['department'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($chalanidetals['name'])?></td>
                    </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
</section>
</section>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>

