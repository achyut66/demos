<?php
class Chalani extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->module_code = 'CHALANI';
        $this->load->model("CommonModel");
        $this->load->model("ChalaniMdl");
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page'] = 'list_all';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'चलानी किताब'     
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['chalani'] = $this->CommonModel->getData('chalani','DESC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function Add() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $id = $this->uri->segment(3);
            $data['fileDetails'] = $this->CommonModel->getDataByID('file_storage', $id);
            $data['page'] = 'add';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'           => '',
                'चलानी'              => 'Chalani',
            ));
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['department']     = $this->CommonModel->getData('department');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('chalani_date',  'chalani_date', 'required');
            $this->form_validation->set_rules('file_type',     'file_type', 'required');
            $this->form_validation->set_rules('vehicle_no',    'vehicle_no', 'required');
            $this->form_validation->set_rules('department',    'department', 'required');
            $this->form_validation->set_rules('name',  'name', 'required');
            $file_id = $this->input->post('file_id');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => 'validation_errors()',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $getMaxChalaniNo            = $this->ChalaniMdl->getMaxChalaniNo();
            $getMaxChalaniNo                   = $getMaxChalaniNo + 1;
            $post_data = array(
                'chalani_date'      => $this->input->post('chalani_date'),
                'vehicle_no'        => $this->input->post('vehicle_no'),
                'file_type'         => $this->input->post('file_type'),
                'file_id'           => $this->input->post('id'),
                'department'        => $this->input->post('department'),
                'name'              => $this->input->post('name'),
                'chalani_no'        => $getMaxChalaniNo,
                'status'            => 1,
            );
           
            $result = $this->CommonModel->insertData('chalani',$post_data);
            if($result) {
                $status = array('status'=>2);
                $this->CommonModel->updateDataByField('file_storage', 'file_id',$file_id, $status);
                $response = array(
                    'status'       => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'      => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'       => 'success',
                    'data'         => "सफल भएन ",
                    'message'      => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
     */
    public function edit() {
        $id = $this->input->post('id');
        $data['row'] = $this->CommonModel->getDataByID('room',$id);
        $this->load->view('edit',$data);
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->form_validation->set_rules('room_no', 'room_no', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => '<div class="alert alert-danger">'.validation_errors().'</div>',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data = array(
                'room_no'    => $this->input->post('room_no'),
            );
            $result = $this->CommonModel->UpdateData('room',$id,$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
                exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('room',$id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक हटाइयो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Oops something goes worng!!! Please try again",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed!!!');
        }
    }

    public function View() {
        $id = $this->uri->segment(3);
        $data['page'] = 'view_details';
        $data['chalanidetals'] = $this->CommonModel->getDataBySelectedFields('chalani', 'id', $id);
        $this->load->view('main', $data);
    }
}