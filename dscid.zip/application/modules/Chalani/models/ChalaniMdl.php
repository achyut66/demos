<?php 
class ChalaniMdl extends CI_Model {

	public function getMaxChalaniNo()
    {
        $sql = "select MAX(chalani_no) as max_id from chalani";
        $query = $this->db->query($sql);
        if ($query->num_rows() == 1) {
            $result = $query->row();
            return $result->max_id;
        } else {
            return FALSE;
        }
    }

}