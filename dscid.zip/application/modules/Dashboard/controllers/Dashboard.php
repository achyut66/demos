<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Dashboard extends MX_Controller

{	

	public function __construct()
	{
		parent:: __construct();
        $this->load->model('DashboardModel');
        if(!$this->authlibrary->IsLoggedIn()){
            $this->session->set_userdata('return_url', current_url());
            redirect('Login');
        }
		$this->container='main';
	}



	public function Index()
	{
      
        $data['page'] = 'dashboard';
        $data['title'] = '';
        $data['pagetitle'] = '';
        $data['type'] = $this->DashboardModel->getCountByDisableType();
        $data['level'] = $this->DashboardModel->getCountByDisableLevel();
        $data['total_disable']  = $this->DashboardModel->getTotal('disable_person');
        $data['total_senior_citizen']  = $this->DashboardModel->getTotal('senior_citizen');
        $this->load->view('main', $data);
	}
   
    public function dbbackup(){
        $this->load->dbutil();
        $config = array(  
            'format'      => 'zip',  
            'filename'    => 'db_disable_backup.sql'
        );
        $backup =  $this->dbutil->backup($config);
        $db_name = 'backup-on-'. date("Y-m-d-H-i-s") .'.zip';
        $save = FCPATH.'assets/dbbackup/'.$db_name;
        $this->load->helper('file');
        write_file($save, $backup); 
    }

}