<div class="row">
    <div class="col-md-2">
        <a href="#">
            <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" alt="">
        </a>
    </div>
    <div class="col-md-8">
        <div style="text-align: center;">
            <h1 style="color:#000"><b><?php echo GNAME ?></b></h3>
                <h3 style="color:#000; margin-top: -11px;"><b><?php echo SLOGAN ?></b></h3>
                <p style="color:#000;margin-top: -11px;"><?php echo ADDRESS ?>,
                    <?php echo DISTRICT ?>,<br><?php echo STATENAME ?>, नेपाल</<p>
        </div>
    </div>
    <div class="col-md-2">
        <a href="#">
            <img src="<?php echo base_url() ?>assets/img/logo_g.png" alt="" style="height: 127px">
        </a>
    </div>
</div>
<hr>
<div>
    <h3 class="text-center">जेष्ठ नागरिक / अपाङ्ग व्यक्ति विवरण अभिलेख प्रणाली</h3>
    <h3 class="text-center" style="color:#000;margin-top: -11px;">(परिचय-पत्र वितरण)</h3>
</div>
<hr>
<div class="row state-overview">
    <div class="col-lg-6 col-sm-6">
        <section class="card">
            <div class="symbol total_bar">
                <i class="fa fa-users"></i>
            </div>
            <div class="value">
                <h1 class="count"><?php echo $this->mylibrary->convertedcit($total_disable) ?></h1>
                <h1>अपाङ्गता व्यक्तिहरु</h1>
            </div>
        </section>
    </div>
    <div class="col-lg-6 col-sm-6">
        <section class="card">
            <div class="symbol total_bar">
                <i class="fa fa-users"></i>
            </div>
            <div class="value">
                <h1 class=" count2"><?php echo $this->mylibrary->convertedcit($total_disable) ?></h1>
                <h1>ज्येष्ठ नागरिक</h1>
            </div>
        </section>
    </div>
</div>
<!-- Start of nepali patro badge -->
<div class="row">
    <div class="col-lg-6">
        <!--work progress start-->
        <section class="card">
            <div class="card-body progress-card">
                <div class="task-progress">
                    <h1>अपाङ्गताको प्रकृति आधारमा विवरण </h1>
                </div>
            </div>
            <table class="table table-hover personal-task">
                <tbody>
                    <?php
                    $ttotal = 0;
                    if (!empty($type)):
                        foreach ($type as $type): ?>
                            <tr>
                                <?php $ttotal += $type->totalStat ?>
                                <td><?php echo $type->type_np ?></td>
                                <td><?php echo $this->mylibrary->convertedcit($type->totalStat) . ' जना' ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>जम्मा</td>
                        <td align="right"><?php echo $this->mylibrary->convertedcit($ttotal) . ' जना' ?></td>
                    </tr>
                </tfoot>
            </table>
        </section>
        <!--work progress end-->
    </div>
    <div class="col-lg-6">
        <!--work progress start-->
        <section class="card">
            <div class="card-body progress-card">
                <div class="task-progress">
                    <h1>अपाङ्गताको प्रकृति आधारमा विवरण </h1>
                </div>
            </div>
            <table class="table table-hover personal-task">
                <tbody>
                    <?php
                    $total = 0;
                    if (!empty($level)):
                        foreach ($level as $level): ?>
                            <tr class="<?php echo $level->bg_color ?>">
                                <?php $total += $level->totalStat ?>
                                <td><?php echo $level->level_np ?></td>
                                <td><?php echo $this->mylibrary->convertedcit($level->totalStat) . ' जना' ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                <tfoot>
                    <tr>
                        <td>जम्मा</td>
                        <td align="right"><?php echo $this->mylibrary->convertedcit($total) . ' जना' ?></td>
                    </tr>
                </tfoot>
                </tbody>
            </table>
        </section>
        <!--work progress end-->
    </div>
</div>