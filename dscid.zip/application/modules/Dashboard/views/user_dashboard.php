<section id="main-content">

  <section class="wrapper">
  	<div class="dashboard">
        <img src="<?php echo base_url('assets/img/nepal-govt.png'); ?>" alt="">
    </div>
   
  </section>

</section>

</section>
</section>