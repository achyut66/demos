<div class="row">

  <div class="col-sm-12">



    <section class="card">

      <header class="card-header">

        <?php echo $pageTitle ?>

        </span>

      </header>

      <div class="card-body">

        <div class="row">

          <div class="col-sm-12">

            <?php echo form_open_multipart('SeniorCitizen/Save', array('name' => 'add_disable_person', 'id' => 'add_disable_person', 'method' => 'post', 'class' => 'form-horizontal save_post')); ?>

            <div class="row">

              <input type="hidden" name="" value="<?php echo get_current_year() ?>" id="current_year">

              <input type="hidden" name="" value="<?php echo convertDate(date('Y-m-d')) ?>" id="current_date">

              <div class="col-md-6">

                <div class="form-group">

                  <label>नाम, थर <span style="color: red">*</span></label>

                  <input type="text" class="form-control" name="name_np" required="true">

                </div>

              </div>

              <div class="col-md-6">

                <div class="form-group">

                  <label>टोल/गाउँ<span style="color: red">*</span></label>

                  <input type="text" class="form-control" name="tol" required="true">

                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>प्रदेश <span style="color: red">*</span></label>

                  <select class="form-control npl_state" name="state">

                    <option value=""> छानुहोस </option>

                    <?php if (!empty($state)):

                      foreach ($state as $state): ?>

                        <option value="<?php echo $state['ID'] ?>" <?php

                           if ($state['ID'] == STATE) {

                             echo 'selected';

                           }

                           ?>>
                          <?php echo $state['Title'] ?>
                        </option>

                      <?php endforeach; endif; ?>

                  </select>

                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>जिल्ला <span style="color: red">*</span></label>

                  <select class="form-control npl_districts" name="district" required="true">

                    <option></option>

                    <?php if (!empty($districts)):

                      foreach ($districts as $dis): ?>

                        <option value="<?php echo $dis['id'] ?>" <?php

                           if ($dis['id'] == DID) {

                             echo 'selected';

                           }

                           ?>>
                          <?php echo $dis['name'] ?>
                        </option>

                      <?php endforeach; endif; ?>

                  </select>

                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>नपा/ गापा <span style="color: red">*</span></label>

                  <select class="form-control npl_gapana" name="gapa_napa" required="true">

                    <option></option>

                    <?php if (!empty($gapa_napa)):

                      foreach ($gapa_napa as $gapa_napa): ?>

                        <option value="<?php echo $gapa_napa['id'] ?>" <?php

                           if ($gapa_napa['id'] == GID) {

                             echo 'selected';

                           }

                           ?>><?php echo $gapa_napa['name'] ?></option>

                      <?php endforeach; endif; ?>



                  </select>

                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>वार्ड नं <span style="color: red">*</span></label>

                  <select class="form-control" name="ward_no" required="true">

                    <option></option>

                    <?php if (!empty($ward_no)):

                      foreach ($ward_no as $ward_no): ?>

                        <option value="<?php echo $ward_no['ward'] ?>">

                          <?php

                          echo $this->mylibrary->convertedcit($ward_no['ward'])

                            ?>
                        </option>



                      <?php endforeach; endif; ?>



                  </select>

                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>जन्म मिति <span style="color: red">*</span></label>

                  <div class="iconic-input right">

                    <i class="fa fa-calendar f14" style="color:red"></i>

                    <input type="text" class="form-control nepaliDate2" name="dob" id="dob" value="" required="true">

                  </div>

                </div>

              </div>

              <div class="col-md-2">

                <div class="form-group">

                  <label>उमेर<span style="color: red">*</span> </label>

                  <input type="text" class="form-control" name="age" id="age" value="" readonly="true" required="true">

                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>रक्त समूह <span style="color: red">*</span></label>

                  <select class="form-control" name="blood_group" required="true">

                    <option></option>

                    <?php if (!empty($blood_type)):

                      foreach ($blood_type as $bg): ?>

                        <option value="<?php echo $bg['group_name'] ?>"><?php echo $bg['group_name'] ?></option>

                      <?php endforeach; endif; ?>

                  </select>

                </div>

              </div>

              <div class="col-md-4">

                <div class="form-group">

                  <label>लिङ्ग <span style="color: red">*</span></label>

                  <div class="col-lg-10">

                    <div class="custom-control custom-radio custom-control-inline">

                      <input type="radio" id="customRadioInline1" name="gender" class="custom-control-input" value="1"
                        checked="true">

                      <label class="custom-control-label" for="customRadioInline1">पुरुष</label>

                    </div>

                    <div class="custom-control custom-radio custom-control-inline">

                      <input type="radio" id="customRadioInline2" name="gender" class="custom-control-input" value="2">

                      <label class="custom-control-label" for="customRadioInline2"> महिला</label>

                    </div>

                    <div class="custom-control custom-radio custom-control-inline">

                      <input type="radio" id="customRadioInline3" name="gender" class="custom-control-input" value="3">

                      <label class="custom-control-label" for="customRadioInline3">अन्य</label>

                    </div>

                  </div>

                </div>

              </div>

              <div class="col-md-4">

                <div class="form-group">

                  <label>ना.प्रा.नं <span style="color: red">*</span></label>

                  <input type="text" class="form-control" name="citizen_no" required="true">

                </div>

              </div>

              <!--  <input type="text" class="form-control" name="citizen_district" required="true"> -->

              <div class="col-md-4">

                <div class="form-group">

                  <label>ना.प्रा. जारी जिल्ला <span style="color: red">*</span></label>

                  <select class="form-control" name="citizen_district" required="true">

                    <?php if (!empty($dists)):

                      foreach ($dists as $dis): ?>

                        <option value="<?php echo $dis['name'] ?>" <?php if ($dis['name'] == DISTRICT) {
                             echo 'selected';
                           } ?>>
                          <?php echo $dis['name'] ?>
                        </option>

                      <?php endforeach; endif; ?>

                  </select>

                </div>

              </div>

              <div class="col-md-4">

                <div class="form-group">

                  <label>जारी मिति <span style="color: red">*</span></label>

                  <div class="iconic-input right">

                    <i class="fa fa-calendar f14" style="color:red"></i>

                    <input type="text" class="form-control nepaliDate2 " name="citizen_date" id="citizen_date" value=""
                      required="true">

                  </div>

                </div>

              </div>

              <div class="col-md-6">

                <div class="form-group">

                  <label>पति/पत्नीको नाम </label>

                  <input type="text" class="form-control" name="wife_name">

                </div>

              </div>

              <div class="col-md-6">

                <div class="form-group">

                  <label>उपलब्ध छुट तथा सुविधाहरु</label>

                  <input type="text" class="form-control" name="discount_offer">

                </div>

              </div>

              <div class="col-md-4">

                <div class="form-group">

                  <label>सम्पर्क गर्नुपर्ने व्यक्तिको नाम <span style="color: red">*</span></label>

                  <input type="text" class="form-control" name="contact_person" required="true">

                </div>

              </div>



              <div class="col-md-4">

                <div class="form-group">

                  <label>सम्पर्क गर्नुपर्ने व्यक्तिको ठेगाना <span style="color: red">*</span></label>

                  <input type="text" class="form-control" name="contact_person_address" required="true">

                </div>

              </div>

              <div class="col-md-4">

                <div class="form-group">

                  <label>सम्पर्क नं <span style="color: red">*</span></label>

                  <input type="text" class="form-control" name="contact_no" required="true">

                </div>

              </div>


              <div class="col-md-6">

                <div class="form-group">

                  <label>अपाङ्गता प्रमाणपत्र भए प्रमाणपत्र नं</label>

                  <input type="text" class="form-control" name="pp_no">

                </div>

              </div>



              <div class="col-md-6">

                <div class="form-group">

                  <label>हेरचाह केन्द्रमा बसेको भए सो को नाम</label>

                  <input type="text" class="form-control" name="care_center">

                </div>

              </div>



              <div class="col-md-6">

                <div class="form-group">

                  <label>रोग भए रोगको नाम</label>

                  <input type="text" class="form-control" name="diseases">

                </div>

              </div>



              <div class="col-md-6">

                <div class="form-group">

                  <label>सेवन गरिएको औषधि</label>

                  <input type="text" class="form-control" name="medicine">

                </div>

              </div>



              <div class="col-md-4">

                <div class="form-group">

                  <label>फोटो</label>

                  <input type="file" class="form-control userfile" name="userfile" id="" value="">

                </div>

              </div>



              <div class="col-md-12">

                <hr>

                <div class="text-center">

                  <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्"
                    name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>

                  <a href="<?php echo base_url() ?>SeniorCitizen/List" class="btn btn-danger btn-xs"
                    data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>

                </div>

              </div>



            </div>

            <?php echo form_close() ?>

          </div>

        </div>

      </div>

    </section>

  </div>

</div>

</section>

</section>



<script type="text/javascript"
  src="<?php echo base_url() ?>assets/nepali_datepicker/nepali.datepicker.v2.1.min.js"></script>

<script type="text/javascript">

  $(document).ready(function () {



    $('#citizen_date').nepaliDatePicker({

      onFocus: true,

      npdMonth: true,

      npdYear: true,

    });



    $('#dob').nepaliDatePicker({

      onFocus: true,

      npdMonth: true,

      npdYear: true,

      disableAfter: '2077-07-04',

      onChange: function () {

        var dob = $('#dob').val();
        var current_date = $("#current_date").val();
        var current_year = $("#current_year").val();
        var age = parseInt(current_year) - parseInt(dob);

        age = parseInt(current_year) - parseInt(dob);

        if (age == '0') {

          age = 1;

        }
        // for date of birth date
        var dateOfBirth = new Date(dob);
        var year = dateOfBirth.getFullYear();
        var month = dateOfBirth.getMonth() + 1;
        var day = dateOfBirth.getDate();

        // for current year date
        var currentYear = new Date(current_date);
        var cur_year = currentYear.getFullYear();
        var cur_month = currentYear.getMonth() + 1;
        var cur_day = currentYear.getDate();

        if (cur_year - year === 60 && cur_month === month && cur_day === day) {
          $('#age').val(age);
        } else {
          alert("६० बर्ष भन्दा कम उमेर समूहको सदस्य भएकाले सफल हुन सक्दैन !!!");
          location.reload();
        }
      }

    });



    $(document).on('change', '.npl_state', function () {

      obj = $(this);

      var state = obj.val();

      var name = $('#land_owner_name_en').val();

      var ganapa = $('.lo_gapanapa').val();

      var ward = $('.address_ward').val();

      $.ajax({

        url: base_url + 'DisablePerson/getDistrictByState',

        method: "POST",

        data: { state: state },



        beforeSend: function () {

          $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');



        },



        success: function (resp) {

          if (resp.status == 'success') {

            $('.npl_districts').html(resp.option);

            $('.loading_state').hide();

          }

        }

      });

    });



    $(document).on('change', '.npl_districts', function () {

      obj = $(this);

      var district = obj.val();

      $.ajax({

        url: base_url + 'DisablePerson/getGapanapaByDistricts',

        method: "POST",

        data: { district: district },

        success: function (resp) {

          if (resp.status == 'success') {

            $('.npl_gapana').html(resp.option);

            $('#lo_owner_symbol').val('');

          }

        }

      });

    });





  });

</script>