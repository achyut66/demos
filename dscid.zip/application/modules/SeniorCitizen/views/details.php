<style type="text/css">
  :root {
    --bleeding: 0.5cm;
    --margin: 1cm;
  }

  /*  @page {*/
  /*  size: A4;
        margin: 0;
      }

      *{
        box-sizing: border-box;
      }*/
  body {
    /*font-family: Kalimati, Georgia, serif;*/
    margin: 0 auto;
    padding: 0;
    background: rgb(204, 204, 204);
    display: flex;
    flex-direction: column;
    color: #000;
  }

  .page {
    display: inline-block;
    position: relative;
    /*height: 327mm;*/
    width: 220mm;
    font-size: 12pt;
    margin: 2em auto;
    padding: calc(var(--bleeding) + var(--margin));
    box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);
    background: white;
  }

  @media screen {
    .page::after {
      position: absolute;
      content: '';
      top: 0;
      left: 0;
      width: calc(100% - var(--bleeding) * 2);
      height: calc(100% - var(--bleeding) * 2);
      margin: var(--bleeding);
      /*outline: thin dashed black;*/
      pointer-events: none;
      z-index: 9999;
    }
  }

  /*@media print {
      .page {
        margin: 0;
        overflow: hidden;
      }
    }*/

  /*.print_table {
      width: 100%;
      border: solid 1px;
      border-collapse: collapse;
      margin-top: 10px;
    }
    */
  /*.print_table th {
      border-color: black;
      font-size: 16px;
      border: solid 1px;
      border-collapse: collapse;
      margin: 0;
      padding: 0;
      color:#000;
      background-color:#c2cdd8;
      text-align: center;
    }*/

  /*.print_table td {
      border-color: black;
      font-size: 18px;
      border: solid 1px;
      border-collapse: collapse;
      margin: 0;
      padding: 0;
      text-align: center;
      width: auto;
    }*/

  /*.print_table tr:nth-child(odd){
      background-color:#fff;
    }
    .print_table tr:nth-child(even){
      background-color:#ffffff;
    }

    .print_table table tfoot {
      background-color:#c2cdd8;
    }*/

  .input-padder {
    padding-left: 0px;
  }

  /* .print-size-front{
      width: 590px;
    }*/
  .purna-idcard-wrapper {
    background: #e74c3c;
    height: auto;
    padding: 15px;
  }

  .asakta-idcard-wrapper {
    background: #3498db;
    height: auto;
    padding: 15px;
  }

  .madyam-idcard-wrapper {
    background: #f1c40f;
    height: auto;
    padding: 15px;
  }

  .samanya-idcard-wrapper {
    background: #ffffff;
    height: auto;
    padding: 10px 15px;
  }

  .idcard-border {
    padding: 0 5px;
    height: 100%;
  }

  .id-photo-frame {
    border: 1px solid #000;
    float: right;
    height: 80px;
    width: 80px;
    margin-top: 75px;
  }

  .id-title h1 {
    color: #000;
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    /*-webkit-text-stroke: 1px rgba(255,255,255,0.3);*/
    margin-top: 0px;
  }

  .id-title p {

    color: #000;

    text-align: center;

    font-weight: bold;

    font-size: 14px;

    /*-webkit-text-stroke: 1px rgba(255,255,255,0.4);*/

    margin: 0 0 5px 0;

  }

  .id-title h2 {

    background: #fff;

    color: #FE0303;

    font-weight: bold;

    font-size: 15px;

    border-radius: 30px;

    text-align: center;

    padding: 10px 10px;

    display: table;

    margin: 0 auto;

  }

  .id-body {
    padding: 0 5px;
    font-weight: bold;
    color: #000;
    font-size: 13px;
    margin-top: -29px;

  }

  /*.id-body .form-control {

      background: transparent;

      border: 0px;

      border-bottom: 2px dotted #333;

      padding: 0px;

      border-radius: 0;

    }

    .id-body .form-control:focus{

      box-shadow: 0px !important;

      }*/



  .note-nepali {

    color: #000;

    padding-top: 5px;

    font-weight: bold;

    font-size: 12px;

  }

  .note {

    color: #000;

    padding-top: 10px;

    font-weight: bold;

    font-size: 11px;

  }

  /*** Id Card Back ***/

  .print-size-back {

    width: 590px;

  }

  .idcard-back {

    padding: 5px;

    font-weight: bold;

    color: #000;

    font-size: 13px;

    line-height: 21px;

    margin-top: 50px;

  }

  .stamp-box p {

    text-align: center;

    font-weight: bold;

    padding: 0px;
    margin: 0px;

  }

  .stamp-box-border {

    border: 1px solid #000;

    width: 100px;

    height: 100px;

  }

  /** Custom **/

  @font-face {

    font-family: Kalimati;

    src: url("../../fonts/kalimati.ttf");

  }

  .borderless td,
  .borderless th {

    border: none !important;

  }

  .circle {

    height: 25px;

    width: 25px;

    border-radius: 50%;

    display: inline-block;

  }

  .photo_box {
    width: 80px;
    height: 80px;
    /*float: left;*/
    border: 1px solid #000;
    text-align: left;
    margin-top: -7px;
    /*margin-left: -26px;*/
  }

  .photo_box span {
    display: inline-block;
    vertical-align: middle;
    line-height: normal;
    padding-top: 32px;
  }



  .myclear {
    clear: both;
  }

  /*.page {

        font-family: Kalimati, Georgia, serif;

      }
    */


  /*.font-kalimati {

        font-family: Kalimati, Georgia, serif;

      }



      .font-eng {

        font-family: 'Roboto', Arial, Tahoma, sans-serif;

      }*/



  .cards {

    border-radius: 5px;

    text-align: center;

    padding: 15px;

    color: #fff;

    margin-bottom: 30px;

    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

  }

  .stamp_box {
    width: 120px;
    height: 120px;
    margin-left: 122px;
    /*float: left;*/
    border: 1px solid #000;
    text-align: left;

  }
</style>
<div class="row">
  <div class="col-sm-12">
    <section class="card">
      <header class="card-header">
        <?php echo $pageTitle ?>
        <span class="tools">
          <?php if ($this->authlibrary->HasModulePermission('SENIOR-CITIZEN', "ADD")) { ?>
            <a class="btn btn-success btn-sm pull-right"
              href="<?php echo base_url() ?>SeniorCitizen/PrintBack/<?php echo $detail['id'] ?>" target="_blank"><i
                class="fa fa-print"></i> दोस्रो पृष्ट</a>
            <a class="btn btn-success btn-sm pull-right"
              href="<?php echo base_url() ?>SeniorCitizen/PrintFront/<?php echo $detail['id'] ?>" target="_blank"><i
                class="fa fa-print"></i> पहिलो पृष्ट</a>
          <?php } ?>
        </span>
      </header>
      <div class="card-body">
        <div class="row">
          <div class="col-md-6">
            <div class="page">
              <div class="row">
                <div class="col-md-2">
                  <img src="<?php echo base_url() ?>assets/img/nepal-govt.png" style="width: 80px;">
                </div>
                <div class="col-md-8">
                  <div class="text-center">
                    <h3 style="color:#e21a1a"><?php echo GNAME ?></h3>
                    <p style="margin-left: 12px; color:#e21a1a"><?php echo SLOGAN ?><br> <?php echo ADDRESS ?>,
                      <?php echo DISTRICT ?> <br> <?php echo STATENAME ?>, नेपाल
                    </p>
                    <h5
                      style="background: #fff;border: 1px solid #000; color: #FE0303;font-weight: bold;font-size: 15px;border-radius: 30px;text-align: center;padding: 8px 8px;display: table;margin-left: 156px;">
                      जेष्ठ नागरिक परिचय-पत्र </h5>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="photo_box" style="height: 100px;width: 100px;">
                    <img src="<?php echo base_url() ?>uploads/<?php echo $detail['image'] ?>"
                      style="height: 80px;width: 80px;">
                  </div>
                </div>
                <div class="col-md-12">
                  <div>प. प. नं.:<span
                      class="input-padder"><?php echo $this->mylibrary->convertedcit($detail['darta_no']) ?></span>
                  </div>
                  <div>नाम थर:<span> <?php echo $detail['name'] ?></span></div>
                  <div>जन्म मिति:<span> <?php echo $this->mylibrary->convertedcit($detail['dob']) ?></span>
                    <span style="margin-left: 344px;">
                      लिङ्ग:<?php if ($detail['gender'] == 1) {
                        echo 'पुरुष';
                      } elseif ($detail['gender'] == 2) {
                        echo 'महिला';
                      } else {
                        echo 'अन्य';
                      }
                      ?>
                    </span>
                  </div>
                  <div>ना. प्रा. नं.:
                    <span> <?php echo $this->mylibrary->convertedcit($detail['citizen_no']) ?></span>
                    <span style="margin-left: 318px;">जारी जिल्ला:
                      <?php echo $this->mylibrary->convertedcit($detail['citizen_district']) ?></span>
                  </div>
                  <div>ठेगाना:<span> <?php echo $detail['gapa'] ?>
                      <span style="margin-left:334px;">वडा नं:
                        <?php echo $this->mylibrary->convertedcit($detail['ward_no']) ?></span>
                      <span>, <?php echo $detail['district_name'] ?></span>
                  </div>
                  <div>गाउ/टोल:<span> <?php echo $detail['tol'] ?></span></div>
                  <div>उपलब्ध छुट तथा सुविधाहरु:<span> <?php echo $detail['discount_offer'] ?></span></div>
                  <div>पति/पत्नीको नाम थर:<span> <?php echo $detail['wife_name'] ?></span></div>
                  <div>हेरचाह केन्द्रमा बसेको भए सो को नाम:<span> <?php echo $detail['care_center'] ?></span></div>
                  <div class="col-md-12">
                    <div class="text-center note-nepali"><?php echo PSLOGAN ?></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="page">
              <!-- header section -->
              <div class="row">
                <div class="col-md-12">
                  <div>संरक्षकको नाम थर: <span class="input-padder"><?php echo $detail['contact_person'] ?></span></div>
                  <div>सम्पर्क ठेगाना:<span> <?php echo $detail['contact_person_address'] ?></span></div>
                  <div>सम्पर्क नं :<span> <?php echo $this->mylibrary->convertedcit($detail['contact_no']); ?></span>
                    <span style="margin-left:334px;"> रक्त समूह: <?php echo $detail['blood_group'] ?></span>
                  </div>
                  <div>रोग भए रोगको नाम र सेवन गरिएको औषधि :<span>
                      <?php echo $detail['diseases'] ?><?php if (!empty($detail['medicine'])) {
                           echo ',';
                         } ?><?php echo $detail['medicine'] ?></span>
                  </div>
                  <div>जेष्ठ नागरिक दस्तखत:</div>
                </div>
                <div class="col-md-6">
                  <div><span style="text-decoration: underline;"><b>प्रमाणित गर्ने अधिकृत</b></span></div>
                  <div>दस्तखत:<span></span></div>
                  <div>नाम थर:<span> <?php echo $approved['name_np'] ?></span></div>
                  <div>पद:<span> <?php echo $approved['position_np'] ?></span></div>
                  <div>मिति:<span> <?php echo $this->mylibrary->convertedcit(convertDate(date('Y-m-d'))) ?></span></div>
                  <div>कार्यालय:<span> <?php echo SLOGAN ?> <?php echo ADDRESS ?>, <?php echo DISTRICT ?></span></div>
                </div>
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="stamp_box"><span style="font-size: 10px;margin-left: 20px;">कार्यालयको छाप</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="col text-center note-nepali">यो परिचय-पत्र कसैले फेला पार्नु भएमा सम्बन्धित वडा कार्यालय,
                    गाउँपालिका कार्यालयको कार्यालय वा नजिकको प्रहरी कार्यालयमा बुझाई दिनुहुन अनुरोध छ ।</div>
                </div>
              </div>
              <!-- end  -->
            </div><!--end of page-->
          </div>
        </div>

      </div>
    </section>
  </div>
</div>
<!-- page end-->
</section>
</section>