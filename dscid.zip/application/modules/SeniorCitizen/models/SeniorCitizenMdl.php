<?php 



class SeniorCitizenMdl extends CI_Model {



	/**

        * this funcrtion get all main topic list 

        * @param null

        * @return array main topic list.

    */

    public function getMaxDartaNo()

    {

        $sql = "select MAX(darta_no) as max_id from senior_citizen";

        $query = $this->db->query($sql);

        if ($query->num_rows() == 1) {

            $result = $query->row();

            return $result->max_id;

        } else {

            return FALSE;

        }

    }



    public function getAssociateDistricts() {

        $this->db->select('*')->from('settings_district');

        $this->db->where('state', STATE);

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getAssociateGapa() {

        $this->db->select('*')->from('settings_vdc_municipality');

        $this->db->where('district_id', DID);

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getAssociateDistrictsById($state) {

        $this->db->select('*')->from('settings_district');

        $this->db->where('state', $state);

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getAssociateGapaById($district) {

        $this->db->select('*')->from('settings_vdc_municipality');

        $this->db->where('district_id', $district);

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getAssociateWard() {

        $this->db->select('*')->from('wardwise_address');

        $this->db->order_by('ward', 'ASC');

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getList() {

        $this->db->select('t1.*, t2.Title, t3.name as district_name, t4.name as gapa');

        $this->db->from('senior_citizen t1');

        $this->db->join('provinces t2', 't1.state = t2.ID','left');

        $this->db->join('settings_district t3', 't1.district = t3.id','left');

        $this->db->join('settings_vdc_municipality t4', 't1.gapa_napa = t4.id','left');

      

        $this->db->order_by('t1.darta_no','DESC');

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getSearch($pp_no =NULL, $dt = NULL, $dl=NULL, $ward=NULL) {

        $this->db->select('t1.*, t2.Title, t3.name as district_name, t4.name as gapa, t5.type_np, t6.level_np');

        $this->db->from('senior_citizen t1');

        $this->db->join('provinces t2', 't1.state = t2.ID','left');

        $this->db->join('settings_district t3', 't1.district = t3.id','left');

        $this->db->join('settings_vdc_municipality t4', 't1.gapa_napa = t4.id','left');

        $this->db->join('disable_type t5', 't1.disable_type = t5.id','left');

        $this->db->join('disable_level t6', 't1.disable_level = t6.id','left');

        if(!empty($pp_no)) {

            $this->db->where('t1.darta_no', $pp_no);

        }

        if(!empty($dt)) {

            $this->db->where('t1.disable_type', $dt);

        }

         if(!empty($dl)) {

            $this->db->where('t1.disable_level', $dl);

        }

         if(!empty($ward)) {

            $this->db->where('t1.ward_no', $ward);

        }

        $query = $this->db->get();

        return $query->result_array();

    }



    public function getListById($id) {

        $this->db->select('t1.*, t1.name as jname, t2.Title, t3.name as district_name, t4.name as gapa');

        $this->db->from('senior_citizen t1');

        $this->db->join('provinces t2', 't1.state = t2.ID','left');

        $this->db->join('settings_district t3', 't1.district = t3.id','left');

        $this->db->join('settings_vdc_municipality t4', 't1.gapa_napa = t4.id','left');

        $this->db->where('t1.id', $id);

        $query = $this->db->get();

        return $query->row_array();

    }

}