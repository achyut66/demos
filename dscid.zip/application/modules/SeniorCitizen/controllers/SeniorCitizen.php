<?php
class SeniorCitizen extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("SeniorCitizenMdl");

        $this->module_code = 'SENIOR-CITIZEN';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index(){}

    public function List() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                => '',
                'जेष्ठ नागरिक'              => 'DisablePerson/List',
                'सुची'
                
            ));
            $data['page'] = 'list_all';
            $data['pageTitle']                      = 'ज्येष्ठ नागरिकहरुको  सुची';
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['blood_type']                     = $this->CommonModel->getData('blood_group');
            $data['disable_type']                   = $this->CommonModel->getData('disable_type');
            $data['disable_level']                  = $this->CommonModel->getData('disable_level');
            $data['disable_person']                 = $this->SeniorCitizenMdl->getList('disable_person','DESC');
            $data['ward']                           = $this->CommonModel->getData('wardwise_address','ASC','ward');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function Add() {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['pageTitle']                  = 'अपाङ्गता व्यक्ति';
            $this->breadcrumb->populate(array(
              'ड्यासबोर्ड'                        => '',
              'जेष्ठ नागरिक'                      => 'SeniorCitizen/List',
              'नया थप्नुहोस '
            ));
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['state']                          = $this->CommonModel->getData('provinces');
            $data['districts']                      = $this->SeniorCitizenMdl->getAssociateDistricts();
            $data['gapa_napa']                      = $this->SeniorCitizenMdl->getAssociateGapa('settings_vdc_municipality');
            $data['ward_no']                        = $this->SeniorCitizenMdl->getAssociateWard();
            $data['blood_type']                     = $this->CommonModel->getData('blood_group');
            $data['disable_type']                   = $this->CommonModel->getData('disable_type');
            $data['disable_level']                  = $this->CommonModel->getData('disable_level');
            $data['dists']                          = $this->CommonModel->getdata('settings_district');
            $data['page']                           = 'add';
            $this->load->vars($data);
            $this->load->view('main');
        }
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
    */
    public function Save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name_np', 'name_np', 'required');
            $this->form_validation->set_rules('tol', 'tol', 'required');
            $this->form_validation->set_rules('state', 'state', 'required');
            $this->form_validation->set_rules('district', 'district');
            $this->form_validation->set_rules('gapa_napa', 'gapa_napa', 'required');
            $this->form_validation->set_rules('ward_no', 'ward_no', 'required');
            $this->form_validation->set_rules('dob', 'dob', 'required');
            $this->form_validation->set_rules('age', 'age', 'required');
            $this->form_validation->set_rules('blood_group', 'blood_group', 'required');
            $this->form_validation->set_rules('gender', 'gender', 'required');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');

            $getMaxDartaNo = $this->SeniorCitizenMdl->getMaxDartaNo();
            $darta_no = $getMaxDartaNo + 1;
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }

            $name_np                    = $this->input->post('name_np');
            $name_en                    = $this->input->post('tol');
            $state                      = $this->input->post('state');
            $district                   = $this->input->post('district');
            $gapa_napa                  = $this->input->post('gapa_napa');
            $ward_no                    = $this->input->post('ward_no');
            $tol                        = $this->input->post('tol');
            $dob                        = $this->input->post('dob');
            $age                        = $this->input->post('age');
            $blood_group                = $this->input->post('blood_group');
            $gender                     = $this->input->post('gender');
            $citizen_no                 = $this->input->post('citizen_no');
            $contact_no                 = $this->input->post('contact_no');
            $citizen_date               = $this->input->post('citizen_date');
            $citizen_district           = $this->input->post('citizen_district');
            $wife_name                  = $this->input->post('wife_name');
            $discount_offer             = $this->input->post('discount_offer');
            $contact_person             = $this->input->post('contact_person');
            $contact_person_address     = $this->input->post('contact_person_address');
            $pp_no                      = $this->input->post('pp_no');
            $care_center                = $this->input->post('care_center');
            $diseases                   = $this->input->post('diseases');
            $medicine                   = $this->input->post('medicine');
            $fiscal_year                = get_current_fiscal_year();

            if(!empty($_FILES['userfile']['name'])) {
                $file_name = $this->randomize_image_name($_FILES['userfile']['name']);
                $config = array(
                    'upload_path'   => APPPATH .'../uploads',
                    'allowed_types' => "jpg|png|JPEG",
                    'overwrite'     => TRUE,
                    'file_name'     => $file_name,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if(!$this->upload->do_upload()) {
                    $response = array(
                        'status'        => 'error',
                        'data'          => $this->upload->display_errors(),
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else{
                    $this->upload->do_upload();
                }
            }
            $post_data = array(
                'name'                => $name_np,
                'tol'                    => $tol,
                'state'                  => $state,
                'district'               => $district,
                'gapa_napa'              => $gapa_napa,
                'ward_no'                => $ward_no,
                'dob'                    => $dob,
                'age'                    => $age,
                'blood_group'            => $blood_group,
                'gender'                 => $gender,
                'citizen_no'             => $citizen_no,
                'citizen_date'           => $citizen_date,
                'citizen_district'       => $citizen_district,
                'wife_name'              => $wife_name,
                'discount_offer'         => $discount_offer,
                'contact_person'         => $contact_person,
                'contact_person_address' => $contact_person_address,
                'contact_no'             => $contact_no,
                'pp_no'                  => $pp_no,
                'care_center'            => $care_center,
                'diseases'               => $diseases,
                'medicine'               => $medicine,
                'image'                  => !empty($file_name)?$file_name:'',
                'fiscal_year'            => $fiscal_year,
                'darta_no'               => $darta_no,
                'created_at'             => date('Y-m-d'),
                'created_by'             => $this->session->userdata('DISABLE_USER_ID'),
                'created_ip'             => $this->input->ip_address(),
            );
         
            $result = $this->CommonModel->insertData('senior_citizen',$post_data);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url()."SeniorCitizen/View/".$result,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
            exit('no direct script allowed');
        }
    }

    /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
    */
    public function Edit() {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['title']                          = 'अपाङ्गता व्यक्ति';
            $data['pageTitle']                      = 'अपाङ्गता व्यक्ति विवरण सम्पादन गर्नुहोस';
            $id                                     = $this->uri->segment(3);
            if(empty($id)) {
                redirect(show_404());
            }
            $data['row']                            = $this->CommonModel->getDataByID('senior_citizen', $id);
            $data['state']                          = $this->CommonModel->getData('provinces');
            $data['districts']                      = $this->SeniorCitizenMdl->getAssociateDistrictsById($data['row']['state']);
            $data['gapa_napa']                      = $this->SeniorCitizenMdl->getAssociateGapaById($data['row']['district']);
            $data['ward_no']                        = $this->SeniorCitizenMdl->getAssociateWard();
            $data['blood_type']                     = $this->CommonModel->getData('blood_group');
            $data['disable_type']                   = $this->CommonModel->getData('disable_type');
            $data['disable_level']                  = $this->CommonModel->getData('disable_level');
            $data['dists']                          = $this->CommonModel->getdata('settings_district');
            $this->breadcrumb->populate(array(
              'ड्यासबोर्ड'                            => '',
              'अपाङ्गता व्यक्ति'                       => 'DisablePerson/List',
              'सम्पन्दन गर्नुहोस '
            ));
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['page']                           = 'edit';
            $this->load->view('main',$data);
        }
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
       if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name_np', 'name_np', 'required');
            $this->form_validation->set_rules('tol', 'tol', 'required');
            $this->form_validation->set_rules('state', 'state', 'required');
            $this->form_validation->set_rules('district', 'district');
            $this->form_validation->set_rules('gapa_napa', 'gapa_napa', 'required');
            $this->form_validation->set_rules('ward_no', 'ward_no', 'required');
            $this->form_validation->set_rules('dob', 'dob', 'required');
            $this->form_validation->set_rules('age', 'age', 'required');
            $this->form_validation->set_rules('blood_group', 'blood_group', 'required');
            $this->form_validation->set_rules('gender', 'gender', 'required');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');

            $getMaxDartaNo = $this->SeniorCitizenMdl->getMaxDartaNo();
            $darta_no = $getMaxDartaNo + 1;
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id                         = $this->input->post('id');
            $name_np                    = $this->input->post('name_np');
            $name_en                    = $this->input->post('tol');
            $state                      = $this->input->post('state');
            $district                   = $this->input->post('district');
            $gapa_napa                  = $this->input->post('gapa_napa');
            $ward_no                    = $this->input->post('ward_no');
            $tol                        = $this->input->post('tol');
            $dob                        = $this->input->post('dob');
            $age                        = $this->input->post('age');
            $blood_group                = $this->input->post('blood_group');
            $gender                     = $this->input->post('gender');
            $citizen_no                 = $this->input->post('citizen_no');
            $citizen_date               = $this->input->post('citizen_date');
            $citizen_district           = $this->input->post('citizen_district');
            $wife_name                  = $this->input->post('wife_name');
            $discount_offer             = $this->input->post('discount_offer');
            $contact_person             = $this->input->post('contact_person');
            $contact_no                 = $this->input->post('contact_no');
            $contact_person_address     = $this->input->post('contact_person_address');
            $pp_no                      = $this->input->post('pp_no');
            $care_center                = $this->input->post('care_center');
            $diseases                   = $this->input->post('diseases');
            $medicine                   = $this->input->post('medicine');
            $old_file                   = $this->input->post('old_file');

            if(!empty($_FILES['userfile']['name'])) {
                $file_name = $this->randomize_image_name($_FILES['userfile']['name']);
                $config = array(
                    'upload_path'   => APPPATH .'../uploads',
                    'allowed_types' => "jpg|png|JPEG",
                    'overwrite'     => TRUE,
                    'file_name'     => $file_name,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if(!$this->upload->do_upload()) {
                    $response = array(
                        'status'        => 'error',
                        'data'          => $this->upload->display_errors(),
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else{
                    $this->upload->do_upload();
                }
            }
            $post_data = array(
                'name'                => $name_np,
                'tol'                    => $tol,
                'state'                  => $state,
                'district'               => $district,
                'gapa_napa'              => $gapa_napa,
                'ward_no'                => $ward_no,
                'dob'                    => $dob,
                'age'                    => $age,
                'blood_group'            => $blood_group,
                'gender'                 => $gender,
                'citizen_no'             => $citizen_no,
                'contact_no'             => $contact_no,
                'citizen_date'           => $citizen_date,
                'citizen_district'       => $citizen_district,
                'wife_name'              => $wife_name,
                'discount_offer'         => $discount_offer,
                'contact_person'         => $contact_person,
                'contact_person_address' => $contact_person_address,
                'pp_no'                  => $pp_no,
                'care_center'            => $care_center,
                'diseases'               => $diseases,
                'medicine'               => $medicine,
                'image'                 => !empty($file_name)?$file_name:$old_file,
                'darta_no'              => $darta_no,
                'created_at'            => date('Y-m-d'),
                'created_by'            => $this->session->userdata('DISABLE_USER_ID'),
                'created_ip'            => $this->input->ip_address(),
            );
         
            $result = $this->CommonModel->updateData('senior_citizen', $id, $post_data);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url()."SeniorCitizen/View/".$id,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
            exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('senior_citizen',$id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक हटाइयो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Oops something goes worng!!! Please try again",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed!!!');
        }
    }


    public function View() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'              => '',
                'जेष्ठ नागरिक'            => 'SeniorCitizen/List',
                'पुरा विवरण'              => '',
            ));
            $data['pageTitle']           = 'जेष्ठ नागरिक विवरण';
            $data['breadcrumb']          = $this->breadcrumb->output();
            $id                          = $this->uri->segment(3);
            $data['page']                = 'details';
            $data['detail']               = $this->SeniorCitizenMdl->getListById($id);
            $data['approved']               = $this->CommonModel->getDataById('office_staffs','1');
           // pp($data['detail']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function Search() {
        if($this->input->is_ajax_request()) {
            $pp_no                      = $this->input->post('pp_no');
            $dt                         = $this->input->post('dt');
            $dl                         = $this->input->post('dl');
            $ward                       = $this->input->post('ward');
            $data['disable_person']     = $this->SeniorCitizenMdl->getSearch($pp_no,$dt,$dl,$ward);
            $data_view                  = $this->load->view('search_list', $data, true);
            $response                   = array(
              'status'                  => 'success',
              'data'                    => $data_view
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    public function getDistrictByState() {
        if($this->input->is_ajax_request()) {
            $state = $this->input->post('state');
            get_district_dropdown($state);
        } else {
          exit('no direct script allowed');
        }
    }

    //get Gapanapa By Districts
    public function getGapanapaByDistricts() {
        if($this->input->is_ajax_request()) {
            $district = $this->input->post('district');
            get_ganapa_dropdown($district);
        } else {
          exit('no direct script allowed');
        }
    }

    public function RemoveImage($id) {
        $id             = $this->uri->segment(3);
        $image          = array('image' => '');
        $data['row']    = $this->CommonModel->getDataByID('senior_citizen', $id);
        $query          = $this->CommonModel->updateData('senior_citizen',$id, $image);
        if($query) {
            unlink( FCPATH . "uploads/" . $data['row']['image']);
            redirect('SeniorCitizen/Edit/'.$id);
        }
    }

    public function PrintFront() {
        $data['pageTitle']           = 'जेष्ठ नागरिक विवरण';
        $data['breadcrumb']          = $this->breadcrumb->output();
        $id                          = $this->uri->segment(3);
        $data['page']                = 'details';
        $data['detail']              = $this->SeniorCitizenMdl->getListById($id);
        $data['approved']            = $this->CommonModel->getDataById('office_staffs','1');
        $this->load->view('print_front_page', $data);
    }

    public function PrintBack() {
        $data['pageTitle']           = 'जेष्ठ नागरिक विवरण';
        $data['breadcrumb']          = $this->breadcrumb->output();
        $id                          = $this->uri->segment(3);
        $data['page']                = 'details';
        $data['detail']              = $this->SeniorCitizenMdl->getListById($id);
        $data['approved']            = $this->CommonModel->getDataById('office_staffs','1');
        $this->load->view('print_back_page', $data);
    }
}//end of class
