<?php
class VehicleSale extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("VehicleSalemdl");

        $this->module_code = 'VEHICLE-REGISTER';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index(){}

    public function List() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण'         => 'VehicleSale',
                
            ));
            $data['pageTitle'] = 'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण';
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['page'] = 'list_all';
            $data['vehicle_register'] = $this->CommonModel->getData('vehicle_register','DESC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function Add() {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['title']                          = 'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण';
            $data['pageTitle']                      = 'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण';
            $id                                     = $this->uri->segment(3);
            $data['ownerdetails']                   = $this->CommonModel->getDataByID('vehicle_register', $id);
            $this->breadcrumb->populate(array(
              'ड्यासबोर्ड'                            => '',
              'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण'                          => 'VehicleSale/List',
              'नया थप्नुहोस '
            ));
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['page']                           = 'vehicle_darta_no';
            $this->load->vars($data);
            $this->load->view('main');
        }
    }

    public function getAddForm() {
        if($this->input->is_ajax_request()) {
            $state                          = $this->input->post('state');
            $lot                            = $this->input->post('lot');
            $bike_m                         = $this->input->post('bike_m');
            $number                         = $this->input->post('number');
            if($state == 1) {
                $state = 'सुदूरपश्चिम प्रदेश ';
            } elseif($state == 2 ) {
                $state =  'मा';
            } else {
                $state = 'से';
            }
            $vehicle_no                 = $state.$lot.$bike_m.$number;
            $data['vehicle_no']         = $vehicle_no;
            $data['darta_details']      = $this->CommonModel->getDataBySelectedFields('vehicle_register','vehicle_no', $vehicle_no);
            $data['ownerdetails']       = $this->VehicleSalemdl->getOwnerDetails($vehicle_no);
            $data['sales']              = $this->VehicleSalemdl->getSalesDetails($vehicle_no);
            $data_view                  = $this->load->view('add', $data, true);
            $response                   = array(
              'status'                  => 'success',
              'data'                    => $data_view
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
    */
    public function Save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name', 'name', 'required');
            $this->form_validation->set_rules('address', 'address', 'required');
            $this->form_validation->set_rules('father_name', 'father_name', 'required');
            $this->form_validation->set_rules('grand_father_name', 'grand_father_name');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');
            $this->form_validation->set_rules('tax_office', 'tax_office', 'required');
            $this->form_validation->set_rules('tax_date', 'tax_date', 'required');
            $this->form_validation->set_rules('tax_period', 'tax_period', 'required');
            $this->form_validation->set_rules('tax_bill_no', 'tax_bill_no', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }

            $company_details        = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));
            if($company_details['UserGroup'] == 4) {
                $company_id             = $company_details['ID'];
                $palika_id              = $company_details['created_by'];
            } elseif($company_details['UserGroup'] == 5) {
                $company_id             = $company_details['created_by'];
                $palika_id              = $company_details['branch'];
            } else {
                $company_id             = '';
                $palika_id              = '';
            }
            $name                       = $this->input->post('name');
            $age                        = $this->input->post('age');
            $address                    = $this->input->post('address');
            $father_name                = $this->input->post('father_name');
            $grand_father_name          = $this->input->post('grand_father_name');
            $citizen_no                 = $this->input->post('citizen_no');
            $citizen_date               = $this->input->post('citizen_date');
            $citizen_district           = $this->input->post('citizen_district');
            $tax_office                 = $this->input->post('tax_office');
            $tax_date                   = $this->input->post('tax_date');
            $tax_period                 = $this->input->post('tax_period');
            $tax_bill_no                = $this->input->post('tax_bill_no');
            $vehicle_darta_no           = $this->input->post('vechile_datra_no');
            $vehicle_register           = $this->input->post('vechile_register');

            /*---------------------------------------------------------------------*/
            //buyer details
            $buyer_name                       = $this->input->post('buyer_name');
            $buyer_age                        = $this->input->post('buyer_age');
            $buyer_address                    = $this->input->post('buyer_address');
            $buyer_father_name                = $this->input->post('buyer_father_name');
            $buyer_grand_father_name          = $this->input->post('buyer_grand_father_name');
            $buyer_citizen_no                 = $this->input->post('buyer_citizen_no');
            $buyer_citizen_date               = $this->input->post('buyer_citizen_date');
            $buyer_citizen_district           = $this->input->post('buyer_citizen_district');
            $buyer_tax_office                 = $this->input->post('buyer_tax_office');
            $buyer_tax_date                   = $this->input->post('buyer_tax_date');
            $buyer_tax_period                 = $this->input->post('buyer_tax_period');
            $buyer_tax_bill_no                = $this->input->post('buyer_tax_bill_no');
            $buyer_vehicle_darta_no           = $this->input->post('vechile_datra_no');
            $buyer_vehicle_register           = $this->input->post('vechile_register');
            $vehicle_no                       = $this->input->post('vehicle_no');
            $company_id                       = $this->input->post('company_id');
            $palika_id                       = $this->input->post('palika_id');
            /*---------------------------------------------------------------------*/
            $post_data = array(
                'company_id'            => $company_id,
                'palika_id'             => $palika_id,
                'name'                  => $name,
                'age'                   => $age,
                'address'               => $address,
                'father_name'           => $father_name,
                'grand_father_name'     => $grand_father_name,
                'citizen_no'            => $citizen_no,
                'citizen_date'          => $citizen_date,
                'citizen_district'      => $citizen_district,
                'tax_office'            => $tax_office,
                'tax_date'              => $tax_date,
                'tax_period'            => $tax_period,
                'tax_bill_no'           => $tax_bill_no,
                'vehicle_register_no'   => $vehicle_register,
                'vehicle_darta_no'      => $vehicle_darta_no,
                'company_id'            => $company_id,
                'palika_id'             => $palika_id,
                'status'                => 1,
                'vehicle_no'            => $vehicle_no,
                'created_at'            => date('Y-m-d'),
                'created_by'            => $this->session->userdata('PRJ_USER_ID'),
                'created_ip'            => $this->input->ip_address(),
            );

            $buyer_data = array(
                'company_id'            => $company_id,
                'palika_id'             => $palika_id,
                'name'                  => $buyer_name,
                'age'                   => $buyer_age,
                'address'               => $buyer_address,
                'father_name'           => $buyer_father_name,
                'grand_father_name'     => $buyer_grand_father_name,
                'citizen_no'            => $buyer_citizen_no,
                'citizen_date'          => $buyer_citizen_date,
                'citizen_district'      => $buyer_citizen_district,
                'tax_office'            => $buyer_tax_office,
                'tax_date'              => $buyer_tax_date,
                'tax_period'            => $buyer_tax_period,
                'tax_bill_no'           => $buyer_tax_bill_no,
                'vehicle_register_no'   => $buyer_vehicle_register,
                'vehicle_darta_no'      => $buyer_vehicle_darta_no,
                'company_id'            => $company_id,
                'palika_id'             => $palika_id,
                'vehicle_no'            => $vehicle_no,
                'created_at'            => date('Y-m-d'),
                'created_by'            => $this->session->userdata('PRJ_USER_ID'),
                'created_ip'            => $this->input->ip_address(),
            );
            $result = $this->CommonModel->insertData('vehicle_sale',$post_data);
            if($result) {
                // $owner_details = $this->CommonModel->getDataBySelectedFields('owner_details','vehicle_darta_no', $vehicle_darta_no);
                // if(!empty($owner_details)) {
                //     $id     = array('initial_flag' => $result);
                //     $data   = array_merge($id, $buyer_data);
                //     $this->CommonModel->insertData('owner_details', $data);
                // } else {
                    $id             = array('initial_flag' => $result);
                    $purchase_id    = array('purchase_id' => $result);
                    $data           = array_merge($id, $buyer_data);
                    // $purchase_data  = array_merge(array1)
                    $this->CommonModel->insertData('owner_details', $data);
                   // $this->CommonModel->insertData('vehicle_purchase', $data);
                // }
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'VehicleSale/List',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
            exit('no direct script allowed');
        }
    }

    /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
    */
    public function Edit() {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['title']                          = 'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण';
            $data['pageTitle']                      = 'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण';
            $id                                     = $this->uri->segment(3);
            if(empty($id)) {
                redirect(show_404());
            }
            $data['query']                          = $this->CommonModel->getDataByID('vehicle_sale', $id);
            //$data['ownerdetails'] = $this->CommonModel->VehicleSalemdl->getEditOwnerDetails($id);
            $data['ownerdetails'] = $this->CommonModel->VehicleSalemdl->getOwnerDetails($data['query']['vehicle_darta_no']);
            $this->breadcrumb->populate(array(
              'ड्यासबोर्ड'                            => '',
              'सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण'                           => 'VehicleSale/List',
              'सम्पन्दन गर्नुहोस '
            ));
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['page']                           = 'edit';
            $this->load->view('main',$data);
        }
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name', 'name', 'required');
            $this->form_validation->set_rules('address', 'address', 'required');
            $this->form_validation->set_rules('father_name', 'father_name', 'required');
            $this->form_validation->set_rules('grand_father_name', 'grand_father_name');
            $this->form_validation->set_rules('citizen_no', 'citizen_no', 'required');
            $this->form_validation->set_rules('citizen_date', 'citizen_date', 'required');
            $this->form_validation->set_rules('citizen_district', 'citizen_district', 'required');
            $this->form_validation->set_rules('tax_office', 'tax_office', 'required');
            $this->form_validation->set_rules('tax_date', 'tax_date', 'required');
            $this->form_validation->set_rules('tax_period', 'tax_period', 'required');
            $this->form_validation->set_rules('tax_bill_no', 'tax_bill_no', 'required');
           
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id                         = $this->input->post('id');
            $name                       = $this->input->post('name');
            $age                        = $this->input->post('age');
            $address                    = $this->input->post('address');
            $father_name                = $this->input->post('father_name');
            $grand_father_name          = $this->input->post('grand_father_name');
            $citizen_no                 = $this->input->post('citizen_no');
            $citizen_date               = $this->input->post('citizen_date');
            $citizen_district           = $this->input->post('citizen_district');
            $tax_office                 = $this->input->post('tax_office');
            $tax_date                   = $this->input->post('tax_date');
            $tax_period                 = $this->input->post('tax_period');
            $tax_bill_no                = $this->input->post('tax_bill_no');
            $post_data = array(
                'name'                  => $name,
                'age'                   => $age,
                'address'               => $address,
                'father_name'           => $father_name,
                'grand_father_name'     => $grand_father_name,
                'citizen_no'            => $citizen_no,
                'citizen_date'          => $citizen_date,
                'citizen_district'      => $citizen_district,
                'tax_office'            => $tax_office,
                'tax_date'              => $tax_date,
                'tax_period'            => $tax_period,
                'tax_bill_no'           => $tax_bill_no,
                'created_at'            => date('Y-m-d'),
                'created_by'            => $this->session->userdata('PRJ_USER_ID'),
                'created_ip'            => $this->input->ip_address(),

            );
            $result = $this->CommonModel->UpdateData('vehicle_sale',$id, $post_data);
            if($result) {
                $this->CommonModel->updateDataByField('owner_details','initial_flag', $id, $post_data);
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
                exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('vehicle_sale',$id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक हटाइयो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Oops something goes worng!!! Please try again",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed!!!');
        }
    }


    /**
        * This function on ajaxcall load server side data into datatable
        * @param  NULL
        * @return json 
    */
    public function GetVechileSale() 
    {
      if($this->input->is_ajax_request()) {
          $columns = array( 
            0   => 'id',
          );
          $limit                    = $this->input->post('length');
          $start                    = $this->input->post('start');
          $sn                       = $start + 1;
          $org_name                 = $this->input->post('org_name');
          $darta_no                 = $this->input->post('darta_no');
         
          $order                    = $columns[$this->input->post('order')[0]['column']];
          $dir                      = $this->input->post('order')[0]['dir'];
          $totalData                = $this->VehicleSalemdl->CountList($org_name,$darta_no);
          $totalFiltered            = $totalData;
          $posts                    = $this->VehicleSalemdl->getList($limit,$start,$order,$dir,$org_name,$darta_no);

          $data           = array();
          if(!empty($posts))
          {
              $i = 1;
              foreach ($posts as $post)
              {
                $nestedData['sn']                     = $this->mylibrary->convertedcit($sn++);
                $nestedData['darta_no']               = '<a href ="'.base_url().'VehicleSale/view/'.$post->vehicle_no.'" class="badge badge-warning">'.$this->mylibrary->convertedcit($post->vehicle_no).'</a>';
                $nestedData['id']                     = $post->id;
                $nestedData['name']                   = $post->name;
                $nestedData['address']                = $post->address;
                $nestedData['father_name']            = $post->father_name;
                $nestedData['grand_father_name']      = $post->grand_father_name;
                $nestedData['citizen_no']             = $post->citizen_no;
                $nestedData['citizen_date']           = $post->citizen_date;
                $nestedData['citizen_district']       = $post->citizen_district;
                $nestedData['tax_office']             = $post->tax_office;
                $nestedData['tax_date']               = $post->tax_date;
                $nestedData['tax_period']             = $post->tax_period;
                $nestedData['tax_bill_no']            = $post->tax_bill_no;
                $nestedData['approved_status']        = $post->status;
                if($post->status == 1 ) {
                    $nestedData['status']             = '<a class="btn btn-info btn-sm" title="रुजु गर्नुहोस्" href = "'. base_url().'VehicleRegister/RegisterVehicle/'.$post->id.'" style="margin-top:7px;"> सबारी दर्ता गर्नुहोस </a>';
                } elseif($post->status == 2 ){
                    $nestedData['status']             = '<p class="badge badge-danger">स्वीकृत भएको</p>';
                } else {
                    $nestedData['status']             = "";
                }

                if($this->session->userdata('PRJ_USER_GROUP') == 2) {
                    if($post->status == 1) {
                        $nestedData['status'] = '<a class="btn btn-info btn-sm" title="रुजु गर्नुहोस्" href = "'. base_url().'VehicleRegister/view/'.$post->id.'" style="margin-top:7px;"> रुजु गर्नुहोस् </a>';
                    } elseif($post->status == 2) {
                        $nestedData['status'] = '<p class="badge badge-warning">प्रशोधनमा</p>';
                    } else {
                        $nestedData['status'] = '<p class="badge badge-success">नामसारी सफल भएको</p>';
                    }
                } elseif($this->session->userdata('PRJ_USER_GROUP') == 3) {
                     if($post->status == 1) {
                        $nestedData['status'] = '<p class="badge badge-danger"><i class="fa fa-check-circle"></i> रुजु नभएको</p>';
                    } elseif($post->status == 2) {
                        $nestedData['status'] = '<a class="btn btn-info btn-sm" title="रुजु गर्नुहोस्" href = "'. base_url().'VehicleRegister/RegisterVehicle/'.$post->id.'" style="margin-top:7px;"> सबारी दर्ता गर्नुहोस </a>';
                    }
                    else {

                        $nestedData['status'] = '<p class="badge badge-success">दर्ता सफल भयो</p>';
                    }
                } else {
                    if($post->status == 3 ) {
                        $nestedData['status'] = '<p class="badge badge-success"><i class="fa fa-check-circle"></i> रुजु भएको </p>';
                    } elseif($post->status == 2) {
                         $nestedData['status'] = '<p class="badge badge-warning"><i class="fa fa-exclamation-circle"></i> प्रशोधनमा </p>';
                    } else {
                        $nestedData['status'] = '<p class="badge badge-danger"><i class="fa fa-times-circle"></i> रुजु नभएको</p>';
                    }
                }

                $data[] = $nestedData;
              }
          }
          $json_data = array(
                      "draw"            => intval($this->input->post('draw')),  
                      "recordsTotal"    => intval($totalData),                    "recordsFiltered" => intval($totalFiltered), 
                      "data"            => $data   
                      );
              
          echo json_encode($json_data);
      } else {
          exit('HTTPS!!');
      }
    }

    public function View() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'              => '',
                'सवारी दर्ता'             => 'VehicleSale/List',
                'पुरा विवरण'              => '',
            ));
            $data['pageTitle']          = 'सवारी दर्ता';
            $data['breadcrumb']         = $this->breadcrumb->output();
            $id                         = $this->uri->segment(3);
            $data['page']               = 'view_details';
            $data['sales']              = $this->VehicleSalemdl->getSalesDetailsByID($id);
            $data['purchase']           = $this->VehicleSalemdl->getPurchaseDetails($id);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function GenerateDartaNo() {
        if($this->input->is_ajax_request()) {
            $id                             = $this->input->post('id');
            $vehicle_register_no            = $this->input->post('vehicle_register_no');
            $darta_no                       = $this->VehicleSalemdl->getMaxDartaNo();
            $darta_no                       = $darta_no + 1;
            $post_data = array(
                'status'                    => 2,
                'darta_no'                  => $darta_no,
                'register_date'             => convertDate(date('Y-m-d')),
                'register_by'               => $this->session->userdata('PRJ_USER_ID'),
                'register_ip'               => $this->input->ip_address(),
            );
            $result = $this->CommonModel->UpdateData('vehicle_sale',$id, $post_data);
            if($result) {
                $data = array('darta_no' => $darta_no);
                $this->CommonModel->updateDataByField('owner_details','initial_flag',$id, $data);
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'VehicleSale/List',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    public function TransferFiles() {
        $id                         = $this->uri->segment(3);
        $data['page']               = 'transfer_files';
        $data['pageTitle']          = 'इन्ट्री गर्नुहोस';
        $this->breadcrumb->populate(array(
            'ड्यासबोर्ड'              => '',
            'सवारी दर्ता सुची'         => 'VehicleRegister/List',
            'सबारी नं दर्ता'
        ));
        $data['breadcrumb']         = $this->breadcrumb->output();
        $data['vehicle_register']   = $this->CommonModel->getDataByID('vehicle_sale', $id);
        $data['rooms']              = $this->CommonModel->getData('room');
        $data['raks']               = $this->CommonModel->getData('rak');
        $data['rak_section']        = $this->CommonModel->getData('rak_section');
        $this->load->view('main', $data);
    }

     public function saveLocation() {
        if($this->input->is_ajax_request()) {
            $file_id                        = $this->input->post('file_id');
            $file_type                      = $this->input->post('file_type');
            $vehicle_no                     = $this->input->post('vehicle_no');
            $room                           = $this->input->post('room');
            $rak                            = $this->input->post('rak');
            $rak_section                    = $this->input->post('rak_section');
            $remarks                        = $this->input->post('remarks');
            $darta_no                       = $this->VehicleSalemdl->getMaxSDartaNo();
            $darta_no                       = $darta_no + 1;
            $post_data = array(
                'fiscal_year'               => get_current_fiscal_year(),
                'file_id'                   => $file_id,
                'file_type'                 => $file_type,
                'vehicle_no'                => $vehicle_no,
                'rak'                       => $rak,
                'rak_section'               => $rak_section,
                'status'                    => 1,
                'darta_no'                  => $darta_no,
                'room'                      => $room,
                'created_at'                => convertDate(date('Y-m-d')),
                'created_by'                => $this->session->userdata('PRJ_USER_ID'),
                'created_ip'                => $this->input->ip_address(),
            );
            
            $result = $this->CommonModel->insertData('file_storage',$post_data);
            if($result) {
                $status = array('status' => 3);
                $this->CommonModel->updateData('vehicle_sale', $file_id, $status);
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'VehicleSale/List',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }
}//end of class
