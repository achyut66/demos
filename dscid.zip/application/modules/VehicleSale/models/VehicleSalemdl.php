<?php 

class VehicleSalemdl extends CI_Model {

	/**
        * this funcrtion get all main topic list 
        * @param null
        * @return array main topic list.
    */
	public function getList($limit,$start,$col,$dir,$org_name,$darta_no) {
		$this->db->select('*');
        $this->db->from('vehicle_sale');
        if(!empty($org_name)){
            $this->db->where('name', $org_name);
        }
        if(!empty($darta_no)){
            $this->db->where('citizen_no', $darta_no);
        }
        $this->db->limit($limit, $start);
        $this->db->order_by($col,$dir);
        $query = $this->db->get();
        if($query->num_rows()>0)
        {
            return $query->result(); 
        }
        else
        {
            return null;
        }
	}

    /**
        * This function get sanrachan land and sanrachana.
        * @param NULL
        * @return array
    */
    public function CountList($org_name,$darta_no)
    {
        $this->db->select('*')->from('vehicle_sale');
        if(!empty($org_name)){
            $this->db->where('name', $org_name);
        }
        if(!empty($darta_no)){
            $this->db->where('citizen_no', $darta_no);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

    //get max darta number
    public function getOwnerDetails($darta_no) {
        $this->db->select('*')->from('vehicle_sale');
        $this->db->where('vehicle_register_no', $darta_no);
        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getEditOwnerDetails($id) {
        $this->db->select('*')->from('owner_details');
        $this->db->where('initial_flag', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getSalesDetails($darta_no) {
        $this->db->select('*')->from('vehicle_sale');
        $this->db->where('vehicle_no', $darta_no);
        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getSalesDetailsByID($id) {
        $this->db->select('*')->from('vehicle_sale');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getPurchaseDetails($id) {
        $this->db->select('*')->from('owner_details');
        $this->db->where('initial_flag', $id);
        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getMaxDartaNo()
    {
        $sql = "select MAX(darta_no) as max_id from vehicle_sale";
        $query = $this->db->query($sql);
        if ($query->num_rows() == 1) {
            $result = $query->row();
            return $result->max_id;
        } else {
            return FALSE;
        }
    }

    public function getMaxSDartaNo()
    {
        $sql = "select MAX(darta_no) as max_id from file_storage";
        $query = $this->db->query($sql);
        if ($query->num_rows() == 1) {
            $result = $query->row();
            return $result->max_id;
        } else {
            return FALSE;
        }
    }
}