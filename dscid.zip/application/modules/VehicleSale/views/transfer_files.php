
  <div class="row">
    <div class="col-sm-12">
      <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
      if(!empty($success_message)) { ?>
        <div class="alert alert-success">
          <button class="close" data-close="alert"></button>
          <span> <?php echo $success_message;?> </span>
        </div>
      <?php } ?>
      <section class="card">
        <header class="card-header">
          <?php echo $pageTitle?>
          <span class="tools">
            <?php if($this->authlibrary->HasModulePermission('VEHICLE-REGISTER', "ADD")) { ?>
              <?php if($this->session->userdata('PRJ_USER_GROUP') == 4 || $this->session->userdata('PRJ_USER_GROUP')==5) {?>
             <a class="btn btn-primary btn-sm pull-right" href="<?php echo base_url()?>VehicleRegister/Add"><i class="fa fa-plus-circle"></i> नयाँ थप्नुहोस्</a>
           <?php } } ?>
         </span>
        </header>
        <div class="card-body">
          <?php echo form_open_multipart('VehicleSale/saveLocation', array('name'=>'file_location', 'id'=>'file_location', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
          <div class="row">
            <!-- <div class="col-md-6">
              <div class="form-group">
                <label>कागजातको प्रकार</label>
                <select class="form-control" name="document_type">
                  <option value="सवारी दर्ता">मोटरसाइकल</option>
                  <option value="सवारी नामसारी">स्कूटर</option>
                </select>
              </div>
            </div> -->
            <input type="hidden" name="file_id" value="<?php echo $vehicle_register['id']?>">
            <input type="hidden" name="vehicle_no" value="<?php echo $vehicle_register['vehicle_no']?>">
            <div class="col-md-6">
              <div class="form-group">
                <label>परियोजन</label>
                <?php echo form_input(array('name'=>'file_type', 'id'=>'file_type', 'class'=>'form-control', 'value'=> 'सवारी नामसारी', 'readonly'=> true));?>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label>कोठा नं</label>
                <select class="form-control" name="room">
                  <option value=""></option>
                  <?php if(!empty($rooms)) : 
                    foreach ($rooms as $key => $room) :?>
                      <option value="<?php echo $room['room_no']?>"><?php echo $room['room_no']?></option>
                  <?php endforeach;endif;?>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label>रायक नं</label>
               <select class="form-control" name="rak">
                  <option value=""></option>
                  <?php if(!empty($raks)) : 
                    foreach ($raks as $key => $rak) :?>
                      <option value="<?php echo $rak['rak_name']?>"><?php echo $rak['rak_name']?></option>
                  <?php endforeach;endif;?>
                </select>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label>रयाकको खण्ड न०</label>
               <select class="form-control" name="rak_section">
                  <option value=""></option>
                  <?php if(!empty($rak_section)) : 
                    foreach ($rak_section as $key => $section) :?>
                      <option value="<?php echo $section['section_name']?>"><?php echo $section['section_name']?></option>
                  <?php endforeach;endif;?>
                </select>
              </div>
            </div>

            <div class="col-md-12">
              <div class="form-group">
                <label>कैफियत</label>
                <textarea class="form-control" name="remarks"></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <hr>
              <div class="text-center">
                <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
                <a href="<?php echo base_url()?>VehicleRegister" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
              </div>
             
            </div>
          </div>
          <?php echo form_close()?>
        </div>
      </section>
    </div>
  </div>
  <!-- page end-->
</section>
</section>

<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>
