<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
  
    <?php
        $id                   = !empty($sales['id'])?$sales['id']:'';
        $name                 = !empty($sales['name'])?$sales['name']:'';
        $address              = !empty($sales['address'])?$sales['address']:'';
        $age                  = !empty($sales['age'])?$sales['age']:'';
        $father_name          = !empty($sales['father_name'])?$sales['father_name']:'';
        $grand_father_name    = !empty($sales['grand_father_name'])?$sales['grand_father_name']:'';
        $citizen_no           = !empty($sales['citizen_no']) ?$sales['citizen_no']:'';
        $citizen_date         = !empty($sales['citizen_date'])?$sales['citizen_date']:'';
        $citizen_district     = !empty($sales['citizen_district'])?$sales['citizen_district']:'';
        $tax_office           = !empty($sales['tax_office'])?$sales['tax_office']:'';
        $tax_date             = !empty($sales['tax_date'])?$sales['tax_date']:'';
        $tax_date             = !empty($sales['tax_date'])?$sales['tax_date']:'';
        $tax_period           = !empty($sales['tax_period'])?$sales['tax_period']:'';
        $tax_bill_no          = !empty($sales['tax_bill_no'])?$sales['tax_bill_no']:'';
    ?>
    <!-- page start-->
<?php 
  $purchasename                     = !empty($purchase) ? $purchase['name'] : '';
  $purchaseage                      = !empty($purchase) ? $purchase['age'] : '';
  $purchaseaddress                  = !empty($purchase) ? $purchase['address'] : '';
  $purchasefather_name              = !empty($purchase) ? $purchase['father_name'] : '';
  $purchasegrand_father_name        = !empty($purchase) ? $purchase['grand_father_name'] : '' ;
  $purchasecitizen_no               = !empty($purchase) ? $purchase['citizen_no'] : '';
  $purchasecitizen_district         = !empty($purchase) ? $purchase['citizen_district'] : '';
  $purchasecitizen_date             = !empty($purchase) ? $purchase['citizen_date'] : '';
  $purchasetax_office               = !empty($purchase) ? $purchase['tax_office'] : '';
  $purchasetax_date                 = !empty($purchase) ? $purchase['tax_date'] : '';
  $purchasetax_period               = !empty($purchase) ? $purchase['tax_period'] : '';
  $purchasetax_bill_no              = !empty($purchase) ? $purchase['tax_bill_no'] : '';
?>

    <?php echo form_open_multipart('VehicleSale/GenerateDartaNo', array('name'=>'vehicle_register', 'id'=>'vehicle_register', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <div class="row">
          <input type="hidden" value="<?php echo $sales['id']?>" name="id">
          <div class="col-md-6">
            <section class="card">
                <header class="card-header">सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण </header>
                <div class="card-body" style="border: 1px solid #e5e5e5">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नाम थर </label>
                        <?php echo form_input(array('name'=>'buyer_name', 'id'=>'org_name', 'class'=>'form-control','value' => $purchasename ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>वर्ष </label>
                        <?php echo form_input(array('name'=>'buyer_age', 'id'=>'age', 'class'=>'form-control','value' => $purchaseage,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>ठेगानाः </label>
                        <?php echo form_input(array('name'=>'buyer_address', 'id'=>'address', 'class'=>'form-control','value' => $purchaseaddress,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बावु / पतिको नाम थर</label>
                        <?php echo form_input(array('name'=>'buyer_father_name', 'id'=>'father_name', 'class'=>'form-control','value' => $purchasefather_name,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बाजेको नाम थर</label>
                        <?php echo form_input(array('name'=>'buyer_grand_father_name', 'id'=>'grand_father_name', 'class'=>'form-control','value' => $purchasegrand_father_name,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नागरिकता नं </label>
                        <?php echo form_input(array('name'=>'buyer_citizen_no', 'id'=>'citizen_no', 'class'=>'form-control','value' => $purchasecitizen_no,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी मिति</label>
                        <?php echo form_input(array('name'=>'buyer_citizen_date', 'id'=>'citizen_date', 'class'=>'form-control','value' => $purchasecitizen_district,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी जिल्ला</label>
                        <?php echo form_input(array('name'=>'buyer_citizen_district', 'id'=>'citizen_district', 'class'=>'form-control','value' => $purchasecitizen_date,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> कर बुझाएको कार्यालय </label>
                        <?php echo form_input(array('name'=>'buyer_tax_office', 'id'=>'tax_office', 'class'=>'form-control','value' => $purchasetax_office,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> मिति</label>
                        <?php echo form_input(array('name'=>'buyer_tax_date', 'id'=>'tax_date', 'class'=>'form-control','value' => $purchasetax_date,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> अवधिः</label>
                        <?php echo form_input(array('name'=>'buyer_tax_period', 'id'=>'tax_period', 'class'=>'form-control','value' => $purchasetax_period,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> रसिद नं.</label>
                        <?php echo form_input(array('name'=>'buyer_tax_bill_no', 'id'=>'tax_bill_no', 'class'=>'form-control','value' => $purchasetax_bill_no,'readonly' => true));?>
                      </div>
                    </div>
                  </div>
                </div>
            </section>
          </div>
          <div class="col-md-6">
            <section class="card">
                <header class="card-header">सवारी खरिद गर्ने / लिलाम साकार गर्ने / उपहार / बकस पाउनेको विवरण </header>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नाम थर </label>
                        <?php echo form_input(array('name'=>'name', 'id'=>'org_name', 'class'=>'form-control','value' => $name ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>वर्ष </label>
                        <?php echo form_input(array('name'=>'age', 'id'=>'age', 'class'=>'form-control','value' => $age ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>ठेगानाः </label>
                        <?php echo form_input(array('name'=>'address', 'id'=>'address', 'class'=>'form-control','value' => $address ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बावु / पतिको नाम थर</label>
                        <?php echo form_input(array('name'=>'father_name', 'id'=>'father_name', 'class'=>'form-control','value' => $father_name ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बाजेको नाम थर</label>
                        <?php echo form_input(array('name'=>'grand_father_name', 'id'=>'grand_father_name', 'class'=>'form-control','value' => $grand_father_name ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नागरिकता नं </label>
                        <?php echo form_input(array('name'=>'citizen_no', 'id'=>'citizen_no', 'class'=>'form-control','value' => $purchasename ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी मिति</label>
                        <?php echo form_input(array('name'=>'citizen_date', 'id'=>'citizen_date', 'class'=>'form-control','value' => $citizen_no ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी जिल्ला</label>
                        <?php echo form_input(array('name'=>'citizen_district', 'id'=>'citizen_district', 'class'=>'form-control','value' => $citizen_district ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> कर बुझाएको कार्यालय </label>
                        <?php echo form_input(array('name'=>'tax_office', 'id'=>'tax_office', 'class'=>'form-control','value' => $tax_office ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> मिति</label>
                        <?php echo form_input(array('name'=>'tax_date', 'id'=>'tax_date', 'class'=>'form-control','value' => $tax_date ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> अवधिः</label>
                        <?php echo form_input(array('name'=>'tax_period', 'id'=>'tax_period', 'class'=>'form-control','value' => $tax_period ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> रसिद नं.</label>
                        <?php echo form_input(array('name'=>'tax_bill_no', 'id'=>'tax_bill_no', 'class'=>'form-control','value' => $tax_bill_no ,'readonly' => true ));?>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 text-center">
                    <hr>
                    <?php if($this->session->userdata('PRJ_USER_GROUP') == 2) {?>
                      <?php if($sales['status'] == 1) { ?>
                        <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> रुजु गर्नुहोस्</button>
                      <?php } ?>
                    <?php } ?>
                     <?php if($this->session->userdata('PRJ_USER_GROUP') == 3) {?>
                      <?php if($sales['status'] == 2) { ?>
                        <a href="<?php echo base_url()?>VehicleSale/TransferFiles/<?php echo $id?>" class="btn btn-success">दर्ता गर्नुहोस</a>
                      <?php } ?>
                    <?php } ?>
                  </div>
                </div>
            </section>
          </div>
        </div>
    <?php echo form_close()?>
    </div>
  </div>
 
</section>
</section>
