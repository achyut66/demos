<!-- page start-->
<?php 
  $name                     = !empty($sales) ? $sales['name'] : $darta_details['org_name'];
  $age                      = !empty($sales) ? $sales['age'] : '';
  $address                  = !empty($sales) ? $sales['address'] : $darta_details['org_address'];
  $father_name              = !empty($sales) ? $sales['father_name'] : '';
  $grand_father_name        = !empty($sales) ? $sales['grand_father_name'] : '' ;
  $citizen_no               = !empty($sales) ? $sales['citizen_no'] : '';
  $citizen_district         = !empty($sales) ? $sales['citizen_district'] : '';
  $citizen_date             = !empty($sales) ? $sales['citizen_date'] : '';
  $tax_office               = !empty($sales) ? $sales['tax_office'] : '';
  $tax_date                 = !empty($sales) ? $sales['tax_date'] : '';
  $tax_period               = !empty($sales) ? $sales['tax_period'] : '';
  $tax_bill_no              = !empty($sales) ? $sales['tax_bill_no'] : '';
?>
<?php if(!empty($darta_details)) : ?>
<div class="row">
    <?php echo form_open_multipart('VehicleSale/Save', array('name'=>'vehicle_register', 'id'=>'vehicle_register', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <div class="row">
          <div class="col-md-6">
            <section class="card">
                <header class="card-header">सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण </header>
                <div class="card-body" style="border: 1px solid #e5e5e5">
                  <div class="row">
                    <input type="hidden" name="vehicle_no" value="<?php echo $vehicle_no?>">
                    <input type="hidden" name="company_id" value="<?php echo $darta_details['company_id']?>">
                    <input type="hidden" name="palika_id" value="<?php echo $darta_details['palika_id']?>">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नाम थर </label>
                        <?php echo form_input(array('name'=>'buyer_name', 'id'=>'org_name', 'class'=>'form-control','value' => $name ,'readonly' => true ));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>वर्ष </label>
                        <?php echo form_input(array('name'=>'buyer_age', 'id'=>'age', 'class'=>'form-control','value' => $age,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>ठेगानाः </label>
                        <?php echo form_input(array('name'=>'buyer_address', 'id'=>'address', 'class'=>'form-control','value' => $address,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बावु / पतिको नाम थर</label>
                        <?php echo form_input(array('name'=>'buyer_father_name', 'id'=>'father_name', 'class'=>'form-control','value' => $father_name,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बाजेको नाम थर</label>
                        <?php echo form_input(array('name'=>'buyer_grand_father_name', 'id'=>'grand_father_name', 'class'=>'form-control','value' => $grand_father_name,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नागरिकता नं </label>
                        <?php echo form_input(array('name'=>'buyer_citizen_no', 'id'=>'citizen_no', 'class'=>'form-control','value' => $citizen_no,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी मिति</label>
                        <?php echo form_input(array('name'=>'buyer_citizen_date', 'id'=>'citizen_date', 'class'=>'form-control','value' => $citizen_district,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी जिल्ला</label>
                        <?php echo form_input(array('name'=>'buyer_citizen_district', 'id'=>'citizen_district', 'class'=>'form-control','value' => $citizen_date,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> कर बुझाएको कार्यालय </label>
                        <?php echo form_input(array('name'=>'buyer_tax_office', 'id'=>'tax_office', 'class'=>'form-control','value' => $tax_office,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> मिति</label>
                        <?php echo form_input(array('name'=>'buyer_tax_date', 'id'=>'tax_date', 'class'=>'form-control','value' => $tax_date,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> अवधिः</label>
                        <?php echo form_input(array('name'=>'buyer_tax_period', 'id'=>'tax_period', 'class'=>'form-control','value' => $tax_period,'readonly' => true));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> रसिद नं.</label>
                        <?php echo form_input(array('name'=>'buyer_tax_bill_no', 'id'=>'tax_bill_no', 'class'=>'form-control','value' => $tax_bill_no,'readonly' => true));?>
                      </div>
                    </div>
                  </div>
                </div>
            </section>
          </div>
          <input type="hidden" name="vechile_register" value="<?php echo $darta_details['id']?>">
          <input type="hidden" name="vechile_datra_no" value="<?php echo $darta_details['vehicle_darta_no']?>">
          <div class="col-md-6">
            <section class="card">
                <header class="card-header">सवारी खरिद गर्ने / लिलाम साकार गर्ने / उपहार / बकस पाउनेको विवरण </header>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नाम थर </label>
                        <?php echo form_input(array('name'=>'name', 'id'=>'org_name', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>वर्ष </label>
                        <?php echo form_input(array('name'=>'age', 'id'=>'age', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>ठेगानाः </label>
                        <?php echo form_input(array('name'=>'address', 'id'=>'address', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बावु / पतिको नाम थर</label>
                        <?php echo form_input(array('name'=>'father_name', 'id'=>'father_name', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> बाजेको नाम थर</label>
                        <?php echo form_input(array('name'=>'grand_father_name', 'id'=>'grand_father_name', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> नागरिकता नं </label>
                        <?php echo form_input(array('name'=>'citizen_no', 'id'=>'citizen_no', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी मिति</label>
                       <!--  <?php //echo form_input(array('name'=>'citizen_date', 'id'=>'citizen_date nepali-datepicker', 'class'=>'form-control'));?> -->
                        <input type="text" class="form-control"  name="citizen_date" id="citizen_date" value="<?php echo convertDate(date('Y-m-d'))?>">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> जारी जिल्ला</label>
                        <?php echo form_input(array('name'=>'citizen_district', 'id'=>'citizen_district', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> कर बुझाएको कार्यालय </label>
                        <?php echo form_input(array('name'=>'tax_office', 'id'=>'tax_office', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> मिति</label>
                        <?php //echo form_input(array('name'=>'tax_date', 'id'=>'tax_date', 'class'=>'form-control'));?>
                        <input type="text" class="form-control"  name="tax_date" id="tax_date" value="<?php echo convertDate(date('Y-m-d'))?>">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> अवधिः</label>
                        <?php echo form_input(array('name'=>'tax_period', 'id'=>'tax_period', 'class'=>'form-control '));?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label> रसिद नं.</label>
                        <?php echo form_input(array('name'=>'tax_bill_no', 'id'=>'tax_bill_no', 'class'=>'form-control '));?>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 text-center">
                      <hr>
                      <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
                      <a href="<?php echo base_url()?>VehicleSale/List" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
                  </div>
                </div>
            </section>
          </div>
        </div>
    <?php echo form_close()?>
</div>
<?php else : ?>
  <div class="alert alert-danger">सबारी दर्ता  भएको छैन </div>
<?php endif;?>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var mainInput = $("#citizen_date");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 10
    });

    var tds = $("#tax_date");
    tds.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 10
    });


  });
</script>