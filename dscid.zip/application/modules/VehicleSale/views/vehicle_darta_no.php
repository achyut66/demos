<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
  
        <div class="row">
          <div class="col-md-12">
            <section class="card">
                <header class="card-header">सवारी बिक्री / लिलाम / बकस गरी दिनेको विवरण </header>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <select class="form-control" name="state" id="state">
                            <option value="1">सुदूरपश्चिम प्रदेश</option>
                            <option value="2">महाकाली</option>
                            <option value="3">सेती</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-3">
                      <div class="form-group">
                        <?php echo form_input(array('name'=>'lot', 'id'=>'lot', 'class'=>'form-control','value'=> ''));?>
                      </div>
                      </div>    
                      <div class="col-md-2">
                        <div class="form-group">
                          <?php echo form_input(array('name'=>'bike_m', 'id'=>'bike_m', 'class'=>'form-control', 'value'=> 'प','readonly'=> true));?>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <?php echo form_input(array('name'=>'number', 'id'=>'number', 'class'=>'form-control'));?>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <button class="btn btn-success" type="button" id="search_vehicle_details"><i class="fa fa-search f14"></i> खोज्नुहोस </button>
                        </div>
                      </div>
                    </div>
                  </div>
                 <div class=" loadfrm"></div>
                </div>
            </section>
          </div>
        </div>
    </div>
  </div>
  <!-- page end-->
</section>
</section>
<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click', '#search_vehicle_details', function() {
      obj = $(this);
      var state     = $('#state').val();
      var lot       = $('#lot').val();
      var bike_m    = $('#bike_m').val();
      var number    = $('#number').val();
      $.ajax({
        url:base_url+'VehicleSale/getAddForm',
        method:"POST",
        data:{state:state,lot:lot,bike_m:bike_m,number:number,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        success : function(resp){
          if(resp.status == 'success') {
            $('.loadfrm').html(resp.data);
          }
        }
      });


    });

  });
</script>