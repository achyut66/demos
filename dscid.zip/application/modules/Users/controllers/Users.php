<?php

/**

 * Created By: Balram Upadhyay

 */

class Users extends MY_Controller

{

    public function __construct()

    {

        parent::__construct();

        $this->load->model('Usersmodel');

        $this->load->model('CommonModel');

        $this->module_code = 'USER-MANAGEMENT';

        if ($this->authlibrary->IsLoggedIn() == false) {

            $this->session->set_flashdata('MSG_ERR_LOGIN', 'You have to Login First');

            redirect('Login');

        }

    }



    public function Index()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'VIEW')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            redirect('Users/ListAll', 'location');

        }

    }



    public function ListAll()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'VIEW')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['users']      = $this->Usersmodel->listUser();

            $data['title']      = 'प्रोयोगकर्ताको सुची';

            $data['pageTitle']  = 'प्रोयोगकर्ताको सुची';

            $data['page']       = 'list';

            $data['script']     = 'listscript';

            $this->breadcrumb->populate(array(

                'ड्यासबोर्ड'          => '',

                'प्रोयोगकर्ता'         => 'Users/ListAll',

                'सुची'

                ));



            $data['breadcrumb'] = $this->breadcrumb->output();

            $this->load->vars($data);

            $this->load->view('main');

        }

    }

    public function Add()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        }   else {

                $data['title']                          = 'Add New User';

                $data['subtitle']                       = '';

                $data['pageTitle']                      = 'Add New User';

                $data['script']                         =  'addscript';

                $this->breadcrumb->populate(array(

                  'ड्यासबोर्ड'                                => '',

                  'प्रोयोगकर्ता'                               => 'Users/ListAll',

                  'नया थप्नुहोस'

                ));


                $data['groups']                         = $this->Usersmodel->listgroup();

                $data['provinces']                      = $this->CommonModel->getData('provinces', 'DESC');

                $data['districts']                      = getDistricts();

                $data['breadcrumb']                     = $this->breadcrumb->output();

                $data['page']                           = 'add';

                $this->load->vars($data);

                $this->load->view('main');

        }

    }



    public function SaveUsers() {

        if ($this->input->is_ajax_request()) {

            $palika_name = $this->CommonModel->getDataByID('settings_vdc_municipality', $this->input->post('lo_gapanapa'));

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($password != $cPassword){



                $response = array(

                    'status'      => 'validation_error',

                    'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            }
            $value['details']['UserGroup']            = $this->input->post('role');
            $value['details']['FullName']             = $this->input->post('name');
            $value['details']['UserType']             = $this->input->post('role');
            $value['details']['UserName']             = $this->input->post('userName');
            $value['details']['Email']                = $this->input->post('email');
            $value['details']['Status']               = 'Active';
            $value['details']['Password']             = md5($this->input->post('password'));
            $value['details']['designation']          = $this->input->post('designation');
            $value['details']['state']                = $this->input->post('npl_state'); 
            $value['details']['district']             = $this->input->post('lo_district_id');
            $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');
            $value['details']['contact_no']           = $this->input->post('contact_no');
            $value['details']['branch']               = $this->input->post('branch');
            $value['details']['created_at']           = date('Y-m-d');
            $value['details']['created_by']           = $this->session->userdata('DISABLE_USER_ID');
            $value['details']['created_ip']           = $this->input->ip_address();
            $result                                   = $this->Usersmodel->insertuser($value['details']);
            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/ListAll',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }



    public function Detail()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'VIEW')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $id = $this->uri->segment(3);

            $this->breadcrumb->populate(array(

                'Home' => '',

                'Users' => 'Users/ListAll',

                'Detail'

              ));

            $data['breadcrumb'] = $this->breadcrumb->output();

            $data['users'] = $this->Usersmodel->listUserByID($id);

            $data['title']  = 'Manage Users';

            $data['pagetitle'] = 'Manage Users';

            $data['page'] = 'detailuser';

            $data['script'] = 'listscript';

            $this->load->vars($data);

            $this->load->view('main');

        }

    }



    public function EditUser()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'EDIT')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            if ($this->input->post('PostConfirm')) {

                $id                                 = $this->input->post('UserID');

                // $value['details']['UserGroup']     = $this->input->post('role');

                // $value['details']['FullName']           = $this->input->post('fullName');

                // $value['details']['UserName']      = $this->input->post('userName');

                // $value['details']['Email']          = $this->input->post('email');

                // $value['details']['Status']         = $this->input->post('Status');

                $value['details']['UserGroup']            = $this->input->post('role');
                $value['details']['FullName']             = $this->input->post('name');
                $value['details']['UserType']             = $this->input->post('role');
                $value['details']['UserName']             = $this->input->post('userName');
                $value['details']['Email']                = $this->input->post('email');
                $value['details']['Status']               = 'Active';
                $value['details']['Password']             = md5($this->input->post('password'));
                $value['details']['designation']          = $this->input->post('designation');
                $value['details']['state']                = $this->input->post('npl_state'); 
                $value['details']['district']             = $this->input->post('lo_district_id');
                $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');
                $value['details']['contact_no']           = $this->input->post('contact_no');
                $value['details']['branch']               = $this->input->post('branch');
                $value['details']['modified_at']           = date('Y-m-d');
                $value['details']['modified_by']           = $this->session->userdata('DISABLE_USER_ID');
                $value['details']['modified_ip']           = $this->input->ip_address();


                if ($this->input->post('changepassword') == "Yes") {

                    $value['details']['Password']       = md5($this->input->post('password'));

                }

                $result = $this->Usersmodel->updateuser($id, $value['details']);

                if ($result!=0) {

                    $this->session->set_flashdata('MSG_SUC_ADD', 'User Information successfully changed for '.$this->input->post('userName'));

                    redirect('Users/ListAll');

                } else {

                    $this->session->set_flashdata('MSG_ERR_ADD', 'Nothing to update.');

                    redirect('Users/ListAll');

                }

            } else {

                $id = $this->uri->segment(3);

                $data['query'] = $this->Usersmodel->getUserData($id);

                $data['groups'] = $this->Usersmodel->listgroup();

                $data['provinces']                      = $this->CommonModel->getData('provinces', 'DESC');

                $data['districts']                      = getDistricts();

                $this->breadcrumb->populate(array(

                    'Home' => '',

                    'Users' => 'Users/ListAll',

                    'Edit'

                ));

                $data['breadcrumb'] = $this->breadcrumb->output();

                $data['title'] = 'Edit User Details';

                $data['pageTitle'] = 'Edit User Details';

                $data['page'] = 'edit';

                $data['script'] = 'editscript';

                $this->load->vars($data);

                $this->load->view('main');

            }

        }

    }



    public function updateUser() {

        if ($this->input->is_ajax_request()) {

            $palika_name = $this->CommonModel->getDataByID('settings_vdc_municipality', $this->input->post('lo_gapanapa'));

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($this->input->post('change_password') == 1){

                if($password != $cPassword){



                    $response = array(

                        'status'      => 'validation_error',

                        'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                    );

                    header("Content-type: application/json");

                    echo json_encode($response);

                    exit;

                }

            }

            $id                                       = $this->input->post('id');

            $value['details']['UserGroup']            = 2;

            $value['details']['FullName']             = $palika_name['name'];

            $value['details']['UserType']             = 'Admin';

            $value['details']['UserName']             = $this->input->post('userName');

            $value['details']['Email']                = $this->input->post('email');

            $value['details']['Status']               = 'Active';

            if(!empty($password)) {

                $value['details']['Password']         = md5($this->input->post('password'));

            }

            $value['details']['designation']          = $this->input->post('designation');

            $value['details']['state']                = $this->input->post('npl_state'); 

            $value['details']['district']             = $this->input->post('lo_district_id');

            $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');

            $value['details']['contact_no']           = $this->input->post('contact_no');

            $value['details']['branch']               = $this->input->post('branch');

            $value['details']['created_at']           = date('Y-m-d');

            $value['details']['created_ip']           = $this->input->ip_address();

            $result                                   = $this->Usersmodel->updateuser($id, $value['details']);

            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/ListAll',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }



    public function EditUserPerm()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'EDIT')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            if ($this->input->post('Submit')) {

                $chk_permission             = $this->input->post('chk_permission');

                $login_id                   = $this->session->userdata('PRJ_USER_ID');

                $user_id                    = $this->uri->segment(3);

                $this->Usersmodel->updateuser_perm($chk_permission, $user_id, $login_id);

                $this->session->set_flashdata('MSG_SUC_ADD', 'User Permission Saved Successfully.');

                redirect('Users/EditUserPerm/'.$user_id, 'location');

            } else {

                $user_id                    = $this->uri->segment(3);

                $group_id                   = $this->Usersmodel->getgroupid($user_id);

                $parentmodules              = $this->Usersmodel->listmodule();

                $this->breadcrumb->populate(array(

                'Home'                      => '',

                'Users'                     => 'Users/ListAll',

                'Edit User Permission'      => 'EditUserPerm'

              ));

                $data['breadcrumb']         = $this->breadcrumb->output();

                $data['group_id']           = $group_id;

                $data['parentmodules']      = $parentmodules;

                $data['pageTitle']          = 'Edit User Permission';

                $data['title']              = 'Edit User Permission';

                $data['script']             = 'editpermscript';

                $data['page']               = 'edituserperm';

                $this->load->vars($data);

                $this->load->view('main');

            }

        }

    }



    public function generateStrongPassword($length = 9, $add_dashes = false, $available_sets = 'luds')

    {

        $sets = array();

        if (strpos($available_sets, 'l') !== false) {

            $sets[] = 'abcdefghjkmnpqrstuvwxyz';

        }

        if (strpos($available_sets, 'u') !== false) {

            $sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';

        }

        if (strpos($available_sets, 'd') !== false) {

            $sets[] = '23456789';

        }

        if (strpos($available_sets, 's') !== false) {

            $sets[] = '!@#$%&*?';

        }

        $all = '';

        $password = '';

        foreach ($sets as $set) {

            $password .= $set[array_rand(str_split($set))];

            $all .= $set;

        }

        $all = str_split($all);

        for ($i = 0; $i < $length - count($sets); $i++) {

            $password .= $all[array_rand($all)];

        }

        $password = str_shuffle($password);

        if (!$add_dashes) {

            return $password;

        }

        $dash_len = floor(sqrt($length));

        $dash_str = '';

        while (strlen($password) > $dash_len) {

            $dash_str .= substr($password, 0, $dash_len) . '-';

            $password = substr($password, $dash_len);

        }

        $dash_str .= $password;

        return $dash_str;

    }



    /**-----------------------------------------------------------------------------------------------

    --------------------------------------------------------------------------------------------------*/

    public function PalikaUsers() {

        if (!$this->authlibrary->HasModulePermission('PALIKA-USERS', 'VIEW')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['users']      = $this->Usersmodel->listPalikaUser();

            $data['title']      = 'पालिका प्रोयोगकर्ता';

            $data['pageTitle']  = 'पालिका प्रोयोगकर्ता';

            $data['page']       = 'palika/list_palika_user';

            $data['script']     = 'listscript';

            $this->breadcrumb->populate(array(

                'ड्यासबोर्ड'          => '',

                'पालिका प्रोयोगकर्ता'         => 'Users/PalikaUsers',

                'सुची'

            ));

            $data['breadcrumb'] = $this->breadcrumb->output();

            $this->load->vars($data);

            $this->load->view('main');

        }

    }



    //add palika user

    public function AddPalikauser() {

        if (!$this->authlibrary->HasModulePermission('PALIKA-USERS', 'ADD')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['title']                           = 'प्रोयोगकर्ता थप्नुहोस';

            $data['pageTitle']                       = 'प्रोयोगकर्ता थप्नुहोस';

            $data['script']                          =  'addscript';

            $this->breadcrumb->populate(array(

              'ड्यासबोर्ड'                             => '',

              'प्रोयोगकर्ता'                            => 'Users/PalikaUsers',

              'नया थप्नुहोस '

            ));



            $data['groups']                          = $this->Usersmodel->listgroup();

            $data['provinces']                       = $this->CommonModel->getData('provinces', 'DESC');

            $data['districts']                       = getDistricts();

            $data['breadcrumb']                      = $this->breadcrumb->output();
            $data['shakha']                         = $this->CommonModel->getData('department', 'DESC');

            $data['page']                            = 'palika/add_palika';

            $data['script']                          = 'addscript';

            $this->load->vars($data);

            $this->load->view('main');

        }

    }



    public function SavePalikaUsers() {

        if ($this->input->is_ajax_request()) {

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($password != $cPassword){



                $response = array(

                    'status'      => 'validation_error',

                    'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            }

            $userexits = checkUserExits($this->input->post('userName'));

            if($userexits == 1 ) {
                 $response = array(

                    'status'      => 'error',

                    'message'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग गरिएको छ',

                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;

            }
            $palika_name = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));
            $value['details']['UserGroup']            = 3;
            $value['details']['UserType']             = 'Palika-User';
            $value['details']['FullName']             = $this->input->post('name');
            $value['details']['UserName']             = $this->input->post('userName');
            $value['details']['Email']                = $this->input->post('email');
            $value['details']['Status']               = 'Active';
            $value['details']['Password']             = md5($this->input->post('password'));
            $value['details']['designation']          = $this->input->post('designation');
            $value['details']['state']                = $palika_name['state']; 
            $value['details']['district']             = $palika_name['district'];
            $value['details']['gapa_napa']            = $palika_name['gapa_napa'];
            $value['details']['contact_no']           = $this->input->post('contact_no');
            $value['details']['branch']               = $palika_name['FullName'];
            $value['details']['created_by']           = $this->session->userdata('PRJ_USER_ID');
            $value['details']['shakha']               = $this->input->post('shakha');
            $value['details']['created_at']           = date('Y-m-d');
            $value['details']['created_ip']           = $this->input->ip_address();
            $result                                   = $this->Usersmodel->insertuser($value['details']);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'Users/PalikaUsers',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 

        } else {
            exit('NO DIRECT SCRIPT ALLOWED!!!');
        }
    }



    public function EditPalikUser()

    {

        if (!$this->authlibrary->HasModulePermission('PALIKA-USERS', 'EDIT')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $id = $this->uri->segment(3);
            $data['query'] = $this->Usersmodel->getUserData($id);
            $data['groups'] = $this->Usersmodel->listgroup();
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड' => '',
                'पालिका प्रोयोगकर्ता' => 'Users/PalikaUsers',
                'सम्पादन गर्नुहोस'
            ));

            $data['breadcrumb'] = $this->breadcrumb->output();

            $data['title'] = 'पालिकाको प्रयोगकर्ता सम्पादन गर्नुहोस ';

            $data['pageTitle'] = 'पालिकाको प्रयोगकर्ता सम्पादन गर्नुहोस ';

            $data['page'] = 'palika/edit';

            $data['script'] = 'editscript';

            $this->load->vars($data);

            $this->load->view('main');

        }

    }



    public function UpdatePalikaUsers() {

        if ($this->input->is_ajax_request()) {

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($this->input->post('change_password') == 1){

                if($password != $cPassword){

                    $response = array(

                        'status'      => 'validation_error',

                        'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                    );

                    header("Content-type: application/json");

                    echo json_encode($response);

                    exit;

                }

            }

            $id = $this->input->post('id');

            $value['details']['FullName']              = $this->input->post('name');

            $value['details']['UserName']              = $this->input->post('userName');

            $value['details']['Email']                 = $this->input->post('email');

            $value['details']['Status']                = 'Active';

            if(!empty($password)) {

                $value['details']['Password']          = md5($this->input->post('password'));

            }

            $value['details']['designation']           = $this->input->post('designation');

            $value['details']['contact_no']            = $this->input->post('contact_no');

            $value['details']['modified_by']           = $this->session->userdata('PRJ_USER_ID');

            $value['details']['modified_at']           = date('Y-m-d');

            $value['details']['modified_ip']           = $this->input->ip_address();

            $result                                    = $this->Usersmodel->updateuser($id, $value['details']);

            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/PalikaUsers',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }



    /**-----------------------------------------------------------------------------------------------

    -------------------------------------------------------------------------------------------------*/



    public function CompanyUser() {



        if (!$this->authlibrary->HasModulePermission('COMPANY-USERS', 'VIEW')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['users']      = $this->Usersmodel->listCompanyUser();

            $data['title']      = 'कम्पनी प्रोयोग्कर्ता';

            $data['pageTitle']  = 'कम्पनी प्रोयोग्कर्ता';

            $data['page']       = 'company/list';

            $data['script']     = 'listscript';

            $this->breadcrumb->populate(array(

                'ड्यासबोर्ड'                 => '',

                'कम्पनी प्रोयोग्कर्ता'         => 'Users/CompayUser',

                'सुची'

            ));



            $data['breadcrumb'] = $this->breadcrumb->output();

            $this->load->vars($data);

            $this->load->view('main');

        }

    }

    //add palika user

    public function AddCompanyuser() {

        if (!$this->authlibrary->HasModulePermission('COMPANY-USERS', 'ADD')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['title']                          = 'Add New User';

            $data['subtitle']                       = '';

            $data['pageTitle']                      = 'Add New User';

            $data['script']                         =  'addscript';

            $this->breadcrumb->populate(array(

              'Home'                                => '',

              'Company User'                        => 'Users/CompanyUser',

              'Add'

            ));
            $data['groups']                         = $this->Usersmodel->listgroup();
            $data['breadcrumb']                     = $this->breadcrumb->output();
            $data['provinces']                      = $this->CommonModel->getData('provinces', 'DESC');
            
            $data['districts']                      = getDistricts();
            $data['page']                           = 'company/add';
            $data['script']                         = 'addscript';
            $this->load->vars($data);

            $this->load->view('main');

        }

    }

    public function SaveCompanyUsers() {

        if ($this->input->is_ajax_request()) {

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($password != $cPassword){

                $response = array(

                    'status'      => 'validation_error',

                    'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            }

            $userexits = checkUserExits($this->input->post('userName'));

            if($userexits == 1 ) {

                 $response = array(

                    'status'      => 'error',

                    'message'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग गरिएको छ',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            }
            $palika_name = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));
            $value['details']['UserType']             = 'Company';
            $value['details']['UserGroup']            = 4;
            $value['details']['FullName']             = $this->input->post('name');
            $value['details']['UserName']             = $this->input->post('userName');
            $value['details']['Email']                = $this->input->post('email');
            $value['details']['Status']               = 'Active';
            $value['details']['Password']             = md5($this->input->post('password'));
            $value['details']['contact_no']           = $this->input->post('contact_no');
            $value['details']['branch']               = $palika_name['ID'];
            $value['details']['state']                = $this->input->post('npl_state');
            $value['details']['district']             = $this->input->post('lo_district_id');
            $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');
            $value['details']['pan_no']               = $this->input->post('pan_no');
            $value['details']['address']              = $this->input->post('address');
            $value['details']['created_by']           = $this->session->userdata('PRJ_USER_ID');
            $value['details']['created_at']           = date('Y-m-d');
            $value['details']['created_ip']           = $this->input->ip_address();
            $result                                   = $this->Usersmodel->insertuser($value['details']);
            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/CompanyUser',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }

    public function EditCompanyUser()

    {

        if (!$this->authlibrary->HasModulePermission('COMPANY-USERS', 'EDIT')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            if ($this->input->post('PostConfirm')) {

                $id                                 = $this->input->post('UserID');

                $value['details']['UserGroup']            = 4;

                $value['details']['FullName']             = $this->input->post('name');

                $value['details']['UserName']             = $this->input->post('userName');

                $value['details']['Email']                = $this->input->post('email');

                $value['details']['Status']               = 'Active';

                //$value['details']['Password']             = md5($this->input->post('password'));

               // $value['details']['designation']          = $this->input->post('designation');

                $value['details']['contact_no']           = $this->input->post('contact_no');

               // $value['details']['branch']               = $this->input->post('branch');

                $value['details']['state']                = $this->input->post('npl_state'); 

                $value['details']['district']             = $this->input->post('lo_district_id');

                $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');

                $value['details']['address']              = $this->input->post('address');

                $value['details']['pan_no']               = $this->input->post('pan_no');

                $value['details']['modified_by']          = $this->session->userdata('PRJ_USER_ID');

                $value['details']['modified_at']          = date('Y-m-d');

                $value['details']['modified_ip']           = $this->input->ip_address();



                if ($this->input->post('password') != "") {

                    $value['details']['Password']       = md5($this->input->post('password'));

                }

                $result = $this->Usersmodel->updateuser($id, $value['details']);

                if ($result!=0) {

                    $this->session->set_flashdata('MSG_SUC_ADD', 'User Information successfully changed for '.$this->input->post('userName'));

                    redirect('Users/CompanyUser');

                } else {

                    $this->session->set_flashdata('MSG_ERR_ADD', 'Nothing to update.');

                    redirect('Users/CompanyUser');

                }

            } else {

                $id = $this->uri->segment(3);

                $data['query'] = $this->Usersmodel->getUserData($id);

                $data['groups'] = $this->Usersmodel->listgroup();

                $this->breadcrumb->populate(array(

                    'Home' => '',

                    'Company User' => 'Users/CompanyUser',

                    'Edit'

                ));

                $data['breadcrumb'] = $this->breadcrumb->output();

                $data['title'] = 'पालिकाको प्रयोगकर्ता सम्पादन गर्नुहोस ';

                $data['pageTitle'] = 'पालिकाको प्रयोगकर्ता सम्पादन गर्नुहोस ';

                $data['provinces']    = $this->CommonModel->getData('provinces', 'DESC');

                $data['districts']    = getDistricts();

                $data['page'] = 'company/edit';

                $data['script'] = 'editscript';

                $this->load->vars($data);

                $this->load->view('main');

            }

        }

    }

    public function UpdateCompanyUsers() {

        if ($this->input->is_ajax_request()) {

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($this->input->post('change_password') == 1){

                if($password != $cPassword){

                    $response = array(

                        'status'      => 'validation_error',

                        'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                    );

                    header("Content-type: application/json");

                    echo json_encode($response);

                    exit;

                }

            }

            if($this->input->post('oldusername') != $this->input->post('userName')) {

                $userexits = checkUserExits($this->input->post('userName'));

                if($userexits == 1 ) {

                     $response = array(

                        'status'      => 'error',

                        'message'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग गरिएको छ',

                    );

                    header("Content-type: application/json");

                    echo json_encode($response);

                    exit;

                } 

            }

            $id                                       = $this->input->post('id');

            $palika_name                              = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));

            $value['details']['UserType']             = 'Company';

            $value['details']['UserGroup']            = 4;

            $value['details']['FullName']             = $this->input->post('name');

            $value['details']['UserName']             = $this->input->post('userName');

            $value['details']['Email']                = $this->input->post('email');

            $value['details']['Status']               = 'Active';

            if(!empty($password)) {

                $value['details']['Password']          = md5($this->input->post('password'));

            }

            $value['details']['contact_no']           = $this->input->post('contact_no');

            $value['details']['branch']               = $palika_name['gapa_napa'];

            $value['details']['state']                = $this->input->post('npl_state'); 

            $value['details']['district']             = $this->input->post('lo_district_id');

            $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');

            $value['details']['pan_no']               = $this->input->post('pan_no');

            $value['details']['address']              = $this->input->post('address');

            $value['details']['created_by']           = $this->session->userdata('PRJ_USER_ID');

            $value['details']['created_at']           = date('Y-m-d');

            $value['details']['created_ip']           = $this->input->ip_address();

            $result                                   = $this->Usersmodel->updateuser($id, $value['details']);

            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/CompanyUser',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }

    /*----------------------------------------------------------------------------------

    ------------------------------------------------------------------------------------*/

    public function GeneralUser() {



        if (!$this->authlibrary->HasModulePermission('GENERAL-USERS', 'VIEW')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['users']      = $this->Usersmodel->listGeneralUser();

            $data['title']      = 'प्रोयोग्कर्ता';

            $data['pageTitle']  = 'प्रोयोग्कर्ता';

            $data['page']       = 'users/list';

            $data['script']     = 'listscript';

            $this->breadcrumb->populate(array(

                'ड्यासबोर्ड'                 => '',

                'कम्पनी प्रोयोग्कर्ता'         => 'Users/GeneralUser',

                'सुची'

            ));



            $data['breadcrumb'] = $this->breadcrumb->output();

            $this->load->vars($data);

            $this->load->view('main');

        }

    }

    //add palika user

    public function AddGernaluser() {

        if (!$this->authlibrary->HasModulePermission('GENERAL-USERS', 'ADD')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['title']                          = 'Add New User';

            $data['subtitle']                       = '';

            $data['pageTitle']                      = 'Add New User';

            $data['script']                         =  'addscript';

            $this->breadcrumb->populate(array(

              'Home'                                => '',

              'Company User'                        => 'Users/CompanyUser',

              'Add'

            ));



            $data['groups']                         = $this->Usersmodel->listgroup();

            $data['company_details']                = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));

           // pp($data['company_details']);

            $data['breadcrumb']                     = $this->breadcrumb->output();

            $data['provinces']                      = $this->CommonModel->getData('provinces', 'DESC');

            $data['districts']                      = getDistricts();

            $data['page']                           = 'users/add';

            $data['script']                         = 'addscript';

            $this->load->vars($data);

            $this->load->view('main');

        }

    }

    public function SaveGeneralUsers() {

        if ($this->input->is_ajax_request()) {

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($password != $cPassword){

                $response = array(

                    'status'      => 'validation_error',

                    'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            }

            if($this->input->post('oldusername') != $this->input->post('userName')) {
                $userexits = checkUserExits($this->input->post('userName'));
                if($userexits == 1 ) {
                     $response = array(
                        'status'      => 'error',
                        'message'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग गरिएको छ',
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            }

            $palika_name = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));
            $value['details']['UserType']             = 'General';
            $value['details']['UserGroup']            = 5;
            $value['details']['FullName']             = $this->input->post('name');
            $value['details']['UserName']             = $this->input->post('userName');
            $value['details']['Email']                = $this->input->post('email');
            $value['details']['Status']               = 'Active';
            $value['details']['Password']             = md5($this->input->post('password'));
            $value['details']['contact_no']           = $this->input->post('contact_no');
            $value['details']['branch']               = $palika_name['branch'];
            $value['details']['state']                = $this->input->post('npl_state'); 
            $value['details']['district']             = $this->input->post('lo_district_id');
            $value['details']['gapa_napa']            = $this->input->post('lo_gapanapa');
            $value['details']['designation']          = $this->input->post('designation');
            $value['details']['pan_no']               = $this->input->post('pan_no');
            $value['details']['company_name']         = $this->input->post('company_name');
            $value['details']['address']              = $this->input->post('address');
            $value['details']['company_id']           = $this->session->userdata('PRJ_USER_ID');
            $value['details']['created_by']           = $this->session->userdata('PRJ_USER_ID');
            $value['details']['created_at']           = date('Y-m-d');
            $value['details']['created_ip']           = $this->input->ip_address();
            $result                                   = $this->Usersmodel->insertuser($value['details']);
            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/GeneralUser',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }

    public function EditGeneralUser()

    {

        if (!$this->authlibrary->HasModulePermission('GENERAL-USERS', 'EDIT')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $id = $this->uri->segment(3);

            $data['query'] = $this->Usersmodel->getUserData($id);

            $data['groups'] = $this->Usersmodel->listgroup();

            $this->breadcrumb->populate(array(

                'Home' => '',

                'Company User' => 'Users/CompanyUser',

                'Edit'

            ));

            $data['breadcrumb']     = $this->breadcrumb->output();

            $data['title']          = 'पालिकाको प्रयोगकर्ता सम्पादन गर्नुहोस ';

            $data['pageTitle']      = 'पालिकाको प्रयोगकर्ता सम्पादन गर्नुहोस ';

            $data['provinces']      = $this->CommonModel->getData('provinces', 'DESC');

            $data['districts']      = getDistricts();

            $data['page']           = 'users/edit';

            $data['script']         = 'editscript';

            $this->load->vars($data);

            $this->load->view('main');

        }

    }



    public function UpdateGeneralUsers() {

        if ($this->input->is_ajax_request()) {

            $password = $this->input->post('password');

            $cPassword = $this->input->post('cpassword');

            if($this->input->post('change_password') == 1){

                if($password != $cPassword){

                    $response = array(

                        'status'      => 'validation_error',

                        'message'     => 'पासवोर्ड सुनिश्चित मेल भएन',

                    );

                    header("Content-type: application/json");

                    echo json_encode($response);

                    exit;

                }

            }

            if($this->input->post('oldusername') != $this->input->post('userName')) {

                $userexits = checkUserExits($this->input->post('userName'));

                if($userexits == 1 ) {

                     $response = array(

                        'status'      => 'error',

                        'message'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग गरिएको छ',

                    );

                    header("Content-type: application/json");

                    echo json_encode($response);

                    exit;

                } 

            }

            $id                                       = $this->input->post('id');

            $palika_name                              = $this->CommonModel->getDataByID('users', $this->session->userdata('PRJ_USER_ID'));

            $value['details']['UserType']             = 'Company';

            $value['details']['FullName']             = $this->input->post('name');

            $value['details']['UserName']             = $this->input->post('userName');

            $value['details']['Email']                = $this->input->post('email');

            $value['details']['designation']          = $this->input->post('designation');

            if(!empty($password)) {

                $value['details']['Password']          = md5($this->input->post('password'));

            }

            $value['details']['contact_no']           = $this->input->post('contact_no');

            $value['details']['created_by']           = $this->session->userdata('PRJ_USER_ID');

            $value['details']['created_at']           = date('Y-m-d');

            $value['details']['created_ip']           = $this->input->ip_address();

            $result                                   = $this->Usersmodel->updateuser($id, $value['details']);

            if($result) {

                $response = array(

                    'status'        => 'success',

                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",

                    'message'       => 'redirect',

                    'redirect_url'  => base_url().'Users/GeneralUser',

                );

                header("Content-type: application/json");

                echo json_encode($response);

                exit;

            } 

        } else {

            exit('NO DIRECT SCRIPT ALLOWED!!!');

        }

    }



    /*---------------------------------------------------------------------

    -----------------------------------------------------------------------*/

    //get district by state

    public function getDistrictByState() {

        if($this->input->is_ajax_request()) {

            $state = $this->input->post('state');

            get_district_dropdown($state);

        } else {

          exit('no direct script allowed');

      }

    }



    //get Gapanapa By Districts

    public function getGapanapaByDistricts() {

        if($this->input->is_ajax_request()) {

            $district = $this->input->post('district');

            get_ganapa_dropdown($district);

        } else {

          exit('no direct script allowed');

        }

    }

}

