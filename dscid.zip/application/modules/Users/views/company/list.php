<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
        <span class="tools">
          <?php if($this->authlibrary->HasModulePermission('COMPANY-USERS', "ADD")) { ?>
           <a href="<?php echo base_url()?>Users/AddCompanyuser" class ="btn btn-success pull-right"><i class="fa fa-plus-circle"></i> Add New</a>
          <?php } ?>
        </span>
      </header>
      <div class="card-body">
       <table class=" display table table-striped table-bordered table-hover print_table">
        <thead>
          <tr>
            <th>#</th>
            <th> कम्पनीको नाम</th>
            <th> पान नम्बर. </th>
            <th> प्रदेश </th>
            <th> जिल्ला </th>
            <th> नपा /गपा </th>
            <th> सम्पर्क नं </th>
            <th> इमेल </th>
           
            
            <th>प्रयोगकर्ता ID</th>
            
            <?php if($this->authlibrary->HasModulePermission('COMPANY-USERS', 'EDIT') || $this->authlibrary->HasModulePermission('COMPANY-USERS','DELETE')){?>
              <th>Action</th>
            <?php }?>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; 
          if ($users) {
            foreach ($users as $user) { ?>
              <tr>
                <td><?php echo $i++;?></td>
                <td><?php echo $user->FullName; ?></td>
                <td><?php echo $user->pan_no; ?></td>
                <?php $state = $this->CommonModel->getDataById('provinces', $user->state);?>
                <td><?php echo $state['Title']; ?></td>
                <?php $district = $this->CommonModel->getDataById('settings_district', $user->district);?>
                <td><?php echo $district['name']; ?></td>
                 <?php $gapa = $this->CommonModel->getDataById('settings_vdc_municipality', $user->gapa_napa);?>
                <td><?php echo $gapa['name'];?></td>
                <td><?php echo $user->contact_no;?></td>
                <td><?php echo $user->Email;?></td>
                <td><?php echo $user->UserName;?></td>
                <?php if($this->authlibrary->HasModulePermission('COMPANY-USERS', 'EDIT') || $this->authlibrary->HasModulePermission($this->module_code,'DELETE')){?>
                  <td>
                    <?php if($this->authlibrary->HasModulePermission('COMPANY-USERS','EDIT')){ ?>
                      <a href="<?php echo base_url();?>Users/EditCompanyUser/<?php echo $user->ID;?>" class="btn btn-info"><i class="fa fa-edit"></i> </a>
                    <?php } ?>
                    <?php if($this->authlibrary->HasModulePermission('COMPANY-USERS','VIEW')){ ?>
                      <a href="<?php echo base_url()?>Users/EditUserPerm/<?php echo $user->ID?>" class="btn btn-warning"><i class="fa fa-file"></i> </a>
                    <?php } ?>
                    <?php if($this->authlibrary->HasModulePermission('COMPANY-USERS','DELETE')){ ?>
                     <!--  <a href="" class="btn btn-danger"><i class="fa fa-times"></i> </a> -->
                    <?php } ?>
                  </td>
                <?php } ?>
              </tr>
            <?php } } ?>
          </tbody>
        </table>
       
      </div>
    </section>
    </div>
    <!-- page end-->
  </section>
</section>