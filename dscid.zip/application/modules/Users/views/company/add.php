<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
      </header>
      <div class="card-body">
        <?php echo form_open('Users/SaveCompanyUsers', array('name'=>'addCompanyUser', 'id'=>'addCompanyUser', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <div class="form-body">
          <div class="row">
             <div class="col-md-6">
                <div class="form-group">
                  <label>कम्पनीको नाम</label>
                  <?php echo form_input(array('name'=>'name', 'id'=>'Name', 'class'=>'form-control ', 'required'=>'required'));?>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label>पान नम्बर.</label>
                  <?php echo form_input(array('name'=>'pan_no', 'id'=>'Name', 'class'=>'form-control number_field ', 'required'=>'required'));?>
                </div>
              </div>
          </div> 

          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">प्रदेश <div class="loading_state"></div></label>
                <select class="form-control dd_select npl_state" name="npl_state" required id="province">
                  <option value="">छान्नुहोस्</option>
                  <?php if(!empty($provinces)) : 
                    foreach ($provinces as $key => $p) : ?>
                      <option value="<?php echo $p['ID']?>"><?php echo $p['Title']?></option>
                    <?php endforeach;endif;?>
                  </select>
              </div>
            </div>
            
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label"> जिल्ला </label>
                <select class="form-control dd_select npl_districts" id="district" required name="lo_district_id" >
                  <option value=""></option>
                  
                  </select>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label"> न. पा/ग .पा  </label>
                <select class="form-control npl_gapana dd_select lo_gapanapa" name="lo_gapanapa" id="metro" required>
               
                      <option value=""></option>
                    
                    </select>
              </div>
            </div>
            <!--/span-->
          </div>

          <div class="row">

            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">ठेगाना</label>
                <input type="text" id="email" class="form-control" name="address">
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">इमेल</label>
                <input type="text" id="email" class="form-control" name="email">
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">सम्पर्क नं </label>
                <input type="text" class="form-control number_field" name="contact_no">
              </div>
            </div>
          </div>

            <!--/row-->
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">प्रयोगकर्ता इड(username)</label>
                <input type="text" class="form-control" name="userName">
              </div>
            </div>
            
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">पासवोर्ड </label>
                <input type="password" id="password" class="form-control"  name="password">
              </div>
            </div>
            <!--/span-->
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">पासवोर्ड सुनिस्चित गर्नुहोस </label>
                <input type="password" id="cpassword" class="form-control"  name="cpassword">
              </div>
            </div>
          </div>
          <hr>
          <div class="col-md-12 text-center">
            <div class="error_message"></div>
            <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
            <a href="<?php echo base_url()?>Users/CompanyUsers" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
          </div>

        </div>
      </form>
    </div>
  </div>
</section>
  <!-- page end-->
</section>
</section>

<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('change', '.npl_state', function() {
      obj = $(this);
      var state = obj.val();
      var name = $('#land_owner_name_en').val();
      var ganapa = $('.lo_gapanapa').val();
      var ward = $('.address_ward').val();
      $.ajax({
        url:base_url+'Users/getDistrictByState',
        method:"POST",
        data:{state:state},

        beforeSend: function () {
          $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
        
        },

        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_districts').html(resp.option);
            $('.loading_state').hide();
          }
        }
      });
    });

    $(document).on('change', '.npl_districts', function() {
      obj = $(this);
      var district = obj.val();
      $.ajax({
        url:base_url+'Users/getGapanapaByDistricts',
        method:"POST",
        data:{district:district},
        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_gapana').html(resp.option);
            $('#lo_owner_symbol').val('');
          }
        }
      });
    });

  });
</script>