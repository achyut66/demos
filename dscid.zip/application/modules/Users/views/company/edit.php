<!-- page start-->


 <?php
    $id = (isset($query->ID) && $query->ID!='')?$query->ID:'';
    $fullName = (isset($query->FullName) && $query->FullName!='')?$query->FullName:'';
    $UserName = (isset($query->UserName) && $query->UserName!='')?$query->UserName:'';
    $designation = (isset($query->designation) && $query->designation!='')?$query->designation:'';
    $branch = (isset($query->branch) && $query->branch!='')?$query->branch:'';
    $Email = (isset($query->Email) && $query->Email!='')?$query->Email:'';
    $contact_no = (isset($query->contact_no) && $query->contact_no!='')?$query->contact_no:'';
    $pan_no = (isset($query->pan_no) && $query->pan_no!='')?$query->pan_no:'';
    $state = (isset($query->state) && $query->state!='')?$query->state:'';
    $district = (isset($query->district) && $query->district!='')?$query->district:'';
    $gapa_napa = (isset($query->gapa_napa) && $query->gapa_napa!='')?$query->gapa_napa:'';
    $address = (isset($query->address) && $query->address!='')?$query->address:'';
  ?>


<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
      </header>
      <div class="card-body">
        <?php echo form_open('Users/UpdateCompanyUsers', array('name'=>'addCompanyUser', 'id'=>'addCompanyUser', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <input type="hidden" name="id" value="<?php echo $id?>">
        <div class="form-body">
          <div class="row">
             <input type="hidden" name="UserID" value="<?php echo $id?>">
             <div class="col-md-6">
                <div class="form-group">
                  <label>कम्पनीको नाम</label>
                  <?php echo form_input(array('name'=>'name', 'id'=>'Name', 'class'=>'form-control ', 'required'=>'required','value' => $fullName));?>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label>पान नम्बर.</label>
                  <?php echo form_input(array('name'=>'pan_no', 'id'=>'Name', 'class'=>'form-control number_field ', 'required'=>'required','value' => $pan_no));?>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label class="control-label">प्रदेश <div class="loading_state"></div></label>
                  <select class="form-control dd_select npl_state" name="npl_state" required id="province">
                    <option value="">छान्नुहोस्</option>
                    <?php if(!empty($provinces)) : 
                      foreach ($provinces as $key => $p) : ?>
                        <option value="<?php echo $p['ID']?>" <?php if($state ==$p['ID']){ echo 'selected';}?>><?php echo $p['Title']?></option>
                      <?php endforeach;endif;?>
                    </select>
                  </div>
              </div>

              <div class="col-md-6">
                  <div class="form-group">
                    <label class="control-label"> जिल्ला </label>
                    <select class="form-control dd_select npl_districts" id="district" required name="lo_district_id">
                      <?php $npl_districts = $this->CommonModel->getAllDataByField('settings_district', 'state', $state) ?>
                      <?php if(!empty($npl_districts)) : 
                        foreach ($npl_districts as $key => $dis) :?>
                          <option value="<?php echo $dis['id']?>" <?php if($district ==$dis['id']){echo 'selected';}?> ><?php echo $dis['name']?></option>
                        <?php endforeach;endif;?>
                      </select>
                    </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label class="control-label"> न. पा/ग .पा  </label>
                  <select class="form-control npl_gapana dd_select lo_gapanapa" name="lo_gapanapa" id="metro" required>

                    <?php $npl_gapa = $this->CommonModel->getAllDataByField('settings_vdc_municipality', 'district_id', $district) ?>
                    <?php if(!empty($npl_gapa)) : 
                      foreach ($npl_gapa as $key => $ganapa) :?>
                        <option value="<?php echo $ganapa['id']?>" <?php if($gapa_napa ==$ganapa['id']){echo 'selected';}?> ><?php echo $ganapa['name']?></option>
                      <?php endforeach;endif;?>

                    </select>
                  </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label class="control-label">ठेगाना</label>
                  <input type="text" id="email" class="form-control" name="address" value="<?php echo $address?>">
                </div>
              </div>
          </div>

          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">इमेल</label>
                <input type="text" id="email" class="form-control" name="email" value="<?php echo $Email?>" >
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">सम्पर्क नं </label>
                <input type="text" class="form-control number_field" name="contact_no" value="<?php echo $contact_no?>">
              </div>
            </div>

             <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">प्रयोगकर्ता आइड(username)</label>
                <input type="text" class="form-control" name="userName" value="<?php echo $UserName?>">
                <input type="hidden" class="form-control" name="oldusername" value="<?php echo $UserName?>">
              </div>
            </div>
          </div>

          <div class="form-check mb-5">
              <input class="form-check-input show_change_password" name="change_password" type="checkbox" id="autoSizingCheck" value="1">
              <label class="control-label form-check-label" for="autoSizingCheck">
               पासवोर्ड परिवर्तन ?
             </label>
          </div>
            <div id="change_password">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="control-label">पासवोर्ड</label>
                    <input type="password" class="form-control" name="password" autocomplete="off">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="control-label">पासवोर्ड सुनिश्चित </label>
                    <input type="password" class="form-control" name="cpassword" autocomplete="off">
                  </div>
                </div>
              </div>
              
            </div>
          <hr>
          <div class="col-md-12 text-center">
            <div class="error_message"></div>
            <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
            <a href="<?php echo base_url()?>Setting/SadakKoKisim" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
          </div>

        </div>
      </form>
    </div>
  </div>
</section>
  <!-- page end-->
</section>
</section>

<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('change', '.npl_state', function() {
      obj = $(this);
      var state = obj.val();
      var name = $('#land_owner_name_en').val();
      var ganapa = $('.lo_gapanapa').val();
      var ward = $('.address_ward').val();
      $.ajax({
        url:base_url+'Users/getDistrictByState',
        method:"POST",
        data:{state:state},

        beforeSend: function () {
          $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
        
        },

        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_districts').html(resp.option);
            $('.loading_state').hide();
          }
        }
      });
    });

    $(document).on('change', '.npl_districts', function() {
      obj = $(this);
      var district = obj.val();
      $.ajax({
        url:base_url+'Users/getGapanapaByDistricts',
        method:"POST",
        data:{district:district},
        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_gapana').html(resp.option);
            $('#lo_owner_symbol').val('');
          }
        }
      });
    });


    $('#change_password').hide();

    $('.show_change_password').click(function(){
      //var change_password = $(this).val();
      if ($(this).prop('checked')) {
        $('#change_password').show();
      } else {
        $('#change_password').hide();
      }
    });


  });
</script>