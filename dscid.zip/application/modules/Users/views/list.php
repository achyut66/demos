<!-- page start-->

<div class="row">

  <div class="col-sm-12">

    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");

    if(!empty($success_message)) { ?>

      <div class="alert alert-success">

        <button class="close" data-close="alert"></button>

        <span> <?php echo $success_message;?> </span>

      </div>

    <?php } ?>

    

    <section class="card" style="margin-bottom: -25px;">

      <header class="card-header">

        <?php echo $pageTitle?>

        <span class="tools">

          <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT', "ADD")) { ?>

           <a href="<?php echo base_url()?>Users/Add" class ="btn btn-success pull-right"><i class="fa fa-plus-circle"></i> Add New</a>

          <?php } ?>

        </span>

      </header>

      <div class="card-body">

       <table class=" display table table-striped table-bordered table-hover print_table">

        <thead>

          <tr>

            <th> # </th>

            <th> पालिकाको नाम</th>

            <th> ठेगाना </th>

            <th> इमेल</th>

            <th> सम्पर्क नं </th>

            <th> प्रयोगकर्ता आइड </th>

            <th> आवस्था </th>

            <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT', 'EDIT') && $this->authlibrary->HasModulePermission($this->module_code,'DELETE')){?>

              <th>Action</th>

            <?php }?>

          </tr>

        </thead>

        <tbody>

          <?php $i=1; 

          if ($users) {

            foreach ($users as $user) { ?>

              <tr>

                <td><?php echo $i++;?></td>

                <td><?php echo $user->FullName; ?></td>

                <td>

                <?php

                  $state = $this->CommonModel->getDataByID('provinces', $user->state);

                  $district = $this->CommonModel->getDataByID('settings_district', $user->district);



                  echo $district['name'].','.$state['Title'];

                ?></td>

                <td><?php echo $user->Email; ?></td>

                <td><?php echo $user->contact_no; ?></td>

                <td><?php echo $user->UserName; ?></td>

                <td><?php echo $user->Status;?></td>

                <?php if($this->authlibrary->HasModulePermission($this->module_code, 'EDIT') || $this->authlibrary->HasModulePermission($this->module_code,'DELETE')){?>

                  <td>

                    <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT','EDIT')){ ?>

                      <a href="<?php echo base_url();?>Users/EditUser/<?php echo $user->ID;?>" class="btn btn-info"><i class="fa fa-pencil"></i> </a>

                    <?php } ?>

                    <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT','DELETE')){ ?>

                      <a href="" class="btn btn-danger"><i class="fa fa-trash-o"></i> </a>

                    <?php } ?>

                  </td>

                <?php } ?>

              </tr>

            <?php } } ?>

          </tbody>

        </table>

       

      </div>

    </section>

    </div>

    <!-- page end-->

  </section>

</section>