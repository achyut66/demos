<script type="text/javascript">
     $('[data-id^="group-select-"]').on('click',function(){
        var type = $(this).data('type');
        var id = $(this).data('id');
        if(type=='all'){
            $('.'+id).prop('checked','checked');
        } else if(type=='none'){
            $('.'+id).prop('checked','');
        }
    });

    $('[data-id^="module-select-"]').on('click',function(){
        var type = $(this).data('type');
        var id = $(this).data('id');
        if(type=='all'){
            $('.'+id).prop('checked','checked');
        } else if(type=='none'){
            $('.'+id).prop('checked','');
        }
    });
</script>
