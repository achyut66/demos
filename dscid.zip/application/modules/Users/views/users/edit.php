<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
      </header>
      <div class="card-body">

       <?php
          $id = (isset($query->ID) && $query->ID!='')?$query->ID:'';
          $fullName = (isset($query->FullName) && $query->FullName!='')?$query->FullName:'';
          $UserName = (isset($query->UserName) && $query->UserName!='')?$query->UserName:'';
          $designation = (isset($query->designation) && $query->designation!='')?$query->designation:'';
          $branch = (isset($query->branch) && $query->branch!='')?$query->branch:'';
          $Email = (isset($query->Email) && $query->Email!='')?$query->Email:'';
          $contact_no = (isset($query->contact_no) && $query->contact_no!='')?$query->contact_no:'';
          $company_name = (isset($query->company_name) && $query->company_name!='')?$query->company_name:'';
        ?>
        <?php echo form_open('Users/UpdateGeneralUsers/', array('name'=>'edituser', 'id'=>'edituser', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
        <div class="form-body">
          <input type="hidden" name="id" value="<?php echo $id?>">
          <div class="row">
            <input type="hidden" name="UserID" value="<?php echo $id?>">
            <div class="col-md-6">
              <div class="form-group">
                <label>प्रयोगकर्ताको नाम</label>
                <?php echo form_input(array('name'=>'name', 'id'=>'Name', 'class'=>'form-control ', 'required'=>'required','value'=> $fullName));?>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label>प्रयोगकर्ता पद.</label>
                <?php echo form_input(array('name'=>'designation', 'id'=>'Name', 'class'=>'form-control ', 'required'=>'required' ,'value'=> $designation));?>
              </div>
            </div>
          </div> 

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">इमेल</label>
                <input type="text" id="email" class="form-control" name="email" value="<?php echo $Email?>">
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">सम्पर्क नं </label>
                <input type="text" class="form-control" name="contact_no" value="<?php echo $contact_no?>">
              </div>
            </div>
          </div>
            <!--/row-->
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">प्रयोगकर्ता इड(username)</label>
                <input type="text" class="form-control" name="userName" value="<?php echo $UserName?>">
                <input type="hidden" class="form-control" name="oldusername" value="<?php echo $UserName?>">
              </div>
            </div>

            <div class="form-check mb-5">
              <input class="form-check-input show_change_password" name="change_password" type="checkbox" id="autoSizingCheck" value="1">
              <label class="control-label form-check-label" for="autoSizingCheck">
               पासवोर्ड परिवर्तन ?
             </label>
            </div>
          </div>

           <div id="change_password">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label class="control-label">पासवोर्ड</label>
                  <input type="password" class="form-control" name="password" autocomplete="off">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="control-label">पासवोर्ड सुनिश्चित </label>
                  <input type="password" class="form-control" name="cpassword" autocomplete="off">
                </div>
              </div>
            </div>
              
          </div>
          <hr>
          <div class="col-md-12 text-center">
            <div class="error_message"></div>

            <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
            <a href="<?php echo base_url()?>Users/PalikaUsers" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
          </div>

        </div>
      </form>
    </div>
  </div>
  <!-- page end-->
</section>
</section>

<script type="text/javascript">
  $(document).ready(function(){

    $(document).on('change', '.npl_state', function() {
      obj = $(this);
      var state = obj.val();
      var name = $('#land_owner_name_en').val();
      var ganapa = $('.lo_gapanapa').val();
      var ward = $('.address_ward').val();
      $.ajax({
        url:base_url+'Users/getDistrictByState',
        method:"POST",
        data:{state:state},

        beforeSend: function () {
          $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
        
        },

        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_districts').html(resp.option);
            $('.loading_state').hide();
          }
        }
      });
    });
    $(document).on('change', '.npl_districts', function() {
      obj = $(this);
      var district = obj.val();
      $.ajax({
        url:base_url+'Users/getGapanapaByDistricts',
        method:"POST",
        data:{district:district},
        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_gapana').html(resp.option);
            $('#lo_owner_symbol').val('');
          }
        }
      });
    });
    $('#change_password').hide();

    $('.show_change_password').click(function(){
      //var change_password = $(this).val();
      if ($(this).prop('checked')) {
        $('#change_password').show();
      } else {
        $('#change_password').hide();
      }
    });
  });
</script>