<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
        <span class="tools">
          <?php if($this->authlibrary->HasModulePermission('GENERAL-USERS', "ADD")) { ?>
           <a href="<?php echo base_url()?>Users/AddGernaluser" class ="btn btn-success pull-right"><i class="fa fa-plus-circle"></i> Add New</a>
          <?php } ?>
        </span>
      </header>
      <div class="card-body">
       <table class=" display table table-striped table-bordered table-hover print_table">
        <thead>
          <tr>
            <th>#</th>
            <th>कम्पनी</th>
            <th>प्रयोगकर्ताको नाम</th>
            <th>प्रयोगकर्ताको पद</th>
            <th>इमेल</th>
            <th>सम्पर्क नं</th>
            <th>प्रयोगकर्ता आइडी(USER NAME)</th>
            <?php if($this->authlibrary->HasModulePermission('GENERAL-USERS', 'EDIT') || $this->authlibrary->HasModulePermission('PALIKA-USERS','DELETE')){?>
              <th>Action</th>
            <?php }?>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; 
          if ($users) {
            foreach ($users as $user) { ?>
              <tr>
                <td><?php echo $i++;?></td>
                <td><?php echo $user->branch; ?></td>
                <td><?php echo $user->FullName; ?></td>
                <td><?php echo $user->designation; ?></td>
                <td><?php echo $user->Email; ?></td>
                <td><?php echo $user->contact_no;?></td>
                <td><?php echo $user->UserName;?></td>
                <?php if($this->authlibrary->HasModulePermission('GENERAL-USERS', 'EDIT') || $this->authlibrary->HasModulePermission('GENERAL-USERS','DELETE')){?>
                  <td>
                    <?php if($this->authlibrary->HasModulePermission('GENERAL-USERS','EDIT')){ ?>
                      <a href="<?php echo base_url();?>Users/EditGeneralUser/<?php echo $user->ID;?>" class="btn btn-info"><i class="fa fa-edit"></i> </a>
                    <?php } ?>
                    <?php if($this->authlibrary->HasModulePermission('GENERAL-USERS','VIEW')){ ?>
                      <a href="<?php echo base_url()?>Users/EditUserPerm/<?php echo $user->ID?>" class="btn btn-warning"><i class="fa fa-file"></i> </a>
                    <?php } ?>
                    <?php if($this->authlibrary->HasModulePermission('GENERAL-USERS','DELETE')){ ?>
                     <!--  <a href="" class="btn btn-danger"><i class="fa fa-times"></i> </a> -->
                    <?php } ?>
                  </td>
                <?php } ?>
              </tr>
            <?php } } ?>
          </tbody>
        </table>
       
      </div>
    </section>
    </div>
    <!-- page end-->
  </section>
</section>