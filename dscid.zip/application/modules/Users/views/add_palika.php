<!-- page start-->
<div class="row">
  <div class="col-sm-12">
    <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
    if(!empty($success_message)) { ?>
      <div class="alert alert-success">
        <button class="close" data-close="alert"></button>
        <span> <?php echo $success_message;?> </span>
      </div>
    <?php } ?>
    
    <section class="card" style="margin-bottom: -25px;">
      <header class="card-header">
        <?php echo $pageTitle?>
      </header>
      <div class="card-body">

      <!--  <form action="<?php echo base_url()?>Users/Add" id="frm_adduser" class="horizontal-form" method="post"> -->
        <?php //echo form_open('Users/AddPalikauser/', array('name'=>'signupForm', 'id'=>'signupForm', 'method'=>'post', 'class'=>'form-horizontal'));?>
         <form class="cmxform form-horizontal tasi-form" id="signupForm" method="get" action="#">
        <div class="form-body">
          <div class="row">
             <div class="col-md-4">
                <div class="form-group">
                  <label>प्रयोगकर्ता कर्मचारीको नाम</label>
                  <?php echo form_input(array('name'=>'name', 'id'=>'Name', 'class'=>'form-control '));?>
                </div>
              </div>
<!-- 
              <div class="col-md-6">
                <div class="form-group">
                  <label>प्रयोगकर्ता संकेत नं.</label>
                  <?php //echo form_input(array('name'=>'symbol_no', 'id'=>'Name', 'class'=>'form-control '));?>
                </div>
              </div> -->

              <div class="col-md-4">
                <div class="form-group">
                  <label>प्रयोगकर्ता पद.</label>
                  <?php echo form_input(array('name'=>'designation', 'id'=>'Name', 'class'=>'form-control '));?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <label>शाखा.</label>
                  <?php echo form_input(array('name'=>'branch', 'id'=>'Name', 'class'=>'form-control '));?>
                </div>
              </div>

          </div> 

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">इमेल</label>
                <input type="text" id="email" class="form-control" name="email">
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label class="control-label">सम्पर्क नं </label>
                <input type="text" class="form-control" name="userName">
              </div>
            </div>
          </div>

            <!--/row-->
          <div class="row">

             <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">प्रयोगकर्ता इड(username)</label>
                <input type="text" class="form-control" name="userName">
              </div>
            </div>
            
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">पासवोर्ड </label>
                <input type="password" id="password" class="form-control"  name="password">
              </div>
            </div>
            <!--/span-->
            <div class="col-md-4">
              <div class="form-group">
                <label class="control-label">पासवोर्ड सुनिस्चित गर्नुहोस </label>
                <input type="password" id="cpassword" class="form-control"  name="confirmPassword">
              </div>
            </div>
          </div>


          <hr>
          <div class="col-md-12 text-center">
            <div class="error_message"></div>

            <button class="btn btn-primary btn-xs" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
            <a href="<?php echo base_url()?>Setting/SadakKoKisim" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
          </div>

        </div>
      </form>
    </div>
  </div>
  <!-- page end-->
</section>
</section>
<script src="<?php echo base_url()?>assets/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>

<script type="text/javascript">
  var Script = function () {

    $.validator.setDefaults({
        submitHandler: function() { alert("submitted!"); }
    });

    $().ready(function() {
        // validate the comment form when it is submitted
        $("#signupForm").validate();

        // validate signup form on keyup and submit
        $("#signupForm").validate({
            rules: {
                name: "required",
                // lastname: "required",
                // username: {
                //     required: true,
                //     minlength: 2
                // },
                // password: {
                //     required: true,
                //     minlength: 5
                // },
                // confirm_password: {
                //     required: true,
                //     minlength: 5,
                //     equalTo: "#password"
                // },
                // email: {
                //     required: true,
                //     email: true
                // },
                // topic: {
                //     required: "#newsletter:checked",
                //     minlength: 2
                // },
                // agree: "required"
            },
            messages: {
                name: "Please enter your firstname",
            //     lastname: "Please enter your lastname",
            //     username: {
            //         required: "Please enter a username",
            //         minlength: "Your username must consist of at least 2 characters"
            //     },
            //     password: {
            //         required: "Please provide a password",
            //         minlength: "Your password must be at least 5 characters long"
            //     },
            //     confirm_password: {
            //         required: "Please provide a password",
            //         minlength: "Your password must be at least 5 characters long",
            //         equalTo: "Please enter the same password as above"
            //     },
            //     email: "Please enter a valid email address",
            //     agree: "Please accept our policy"
            // }
        });
      
    });


}();
</script>