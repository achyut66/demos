
<div class="row">
  <div class="col-sm-12">

    <section class="card">
      <header class="card-header">
        <?php //echo $pageTitle?>
        <span class="tools">
          <?php if($this->authlibrary->HasModulePermission('DISABLE-PERSON', "ADD")) { ?>
           <a class="btn btn-danger btn-sm pull-right" href="<?php echo base_url()?>VehicleSale/Add"><i class="fa fa-plus-circle"></i> नयाँ थप्नुहोस्</a>
         <?php  } ?>
       </span>
      </header>
      <div class="card-body">
        <div class="row">
          <div class="col-sm-12">
            <?php echo form_open_multipart('ImportData/ImportPalika', array('name'=>'add_disable_person', 'id'=>'add_disable_person', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
              
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Select File <span style="color: red">*</span></label>
                      <input type="file" class="form-control"  name="userfile" id="" value="" >
                  </div>
                </div>

                <div class="col-md-12">
                  <hr>
                 
                    <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title=" सेभ  गर्नुहोस्" name="PostConfirm" type="submit" value="Save"> सेभ गर्नुहोस्</button>
                    <a href="<?php echo base_url()?>DisablePerson/List" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्">रद्द गर्नुहोस्</a>
                 
                </div>

              </div>
            <?php echo form_close()?>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
</section>
</section>

<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/nepali.datepicker.v2.1.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){

    $('#citizen_date').nepaliDatePicker({
      onFocus: true,
      npdMonth: true,
      npdYear: true,
    });

    $('#dob').nepaliDatePicker({
        onFocus: true,
        npdMonth: true,
        npdYear: true,
        disableAfter:'2077-07-04',
        onChange: function() {
          var dob = $('#dob').val();
          var current_year = $("#current_year").val();
          var age = parseInt(current_year) - parseInt(dob);
          age = parseInt(current_year) - parseInt(dob);
          if(age == '0') {
            age = 1;
          } 
          $('#age').val(age);
        }
    });

    $(document).on('change', '.npl_state', function() {
      obj = $(this);
      var state = obj.val();
      var name = $('#land_owner_name_en').val();
      var ganapa = $('.lo_gapanapa').val();
      var ward = $('.address_ward').val();
      $.ajax({
        url:base_url+'DisablePerson/getDistrictByState',
        method:"POST",
        data:{state:state},

        beforeSend: function () {
          $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
        
        },

        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_districts').html(resp.option);
            $('.loading_state').hide();
          }
        }
      });
    });

    $(document).on('change', '.npl_districts', function() {
      obj = $(this);
      var district = obj.val();
      $.ajax({
        url:base_url+'DisablePerson/getGapanapaByDistricts',
        method:"POST",
        data:{district:district},
        success : function(resp){
          if(resp.status == 'success') {
            $('.npl_gapana').html(resp.option);
            $('#lo_owner_symbol').val('');
          }
        }
      });
    });


  });
</script>
