
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">
          आर्थिक वर्षको सूची
           
          </header>
          <div class="card-body">
           <ul class="summary-list">
            <li>
              <a href="<?php echo base_url()?>ImportData/ImportFiles">
                <i class=" fa fa-table text-primary"></i>
                नगरपालिका / गाउँपालिका 
              </a>
            </li>
            <!-- <li>
              <a href="javascript:;">
                <i class="fa fa-envelope text-info"></i>
                15 Emails
              </a>
            </li>
            <li>
              <a href="javascript:;">
                <i class=" fa fa-picture-o text-muted"></i>
                2 Photo Upload
              </a>
            </li>
            <li>
              <a href="javascript:;">
                <i class="fa fa-tags text-success"></i>
                19 Sales
              </a>
            </li>
            <li>
              <a href="javascript:;">
                <i class="fa fa-microphone text-danger"></i>
                4 Audio
              </a>
            </li> -->
          </ul>
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
</section>
</section>