
<form action="<?php echo base_url()?>ApprovalName/Update" method="post" class="form save_post">

   <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
   <div class="form-group">
    <div class="col-md-12">
      <input type="hidden" class="form-control" placeholder=""  name="id" value="<?php echo $row['id']?>">
      <div class="form-group">
        <label>नाम (नेपाली)<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="name_np" value="<?php echo $row['name_np']?>" required="required">
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <label>नाम (English)<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="name_en" value="<?php echo $row['name_en']?>" required="required">
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <label>पद (नेपाली)<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="position_np" value="<?php echo $row['position_np']?>" required="required">
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <label>पद (English)<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="position_en" value="<?php echo $row['position_en']?>" required="required">
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <label>कार्यालय<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="office_name" value="<?php echo $row['office_name']?>" required="required">
      </div>
    </div>
    
  </div>
  <div class="modal-footer">
    <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सम्पादन गर्नुहोस्</button>
    <button type="button" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" data-dismiss="modal">रद्द गर्नुहोस्</button>
  </div>
</form>