<?php
class ApprovalName extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->module_code = 'APPROVAL-NAME';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page'] = 'list_all';
            $data['pageTitle'] = 'प्रमाणित गर्ने';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'रयाक नं'         => 'RakNo',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['office_staffs'] = $this->CommonModel->getData('office_staffs','DESC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function Add() {
        $this->load->view('add');
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name_np', 'name_np', 'required');
            $this->form_validation->set_rules('name_en', 'name_en', 'required');
            $this->form_validation->set_rules('position_np', 'position_np', 'required');
            $this->form_validation->set_rules('position_en', 'position_en', 'required');
            $this->form_validation->set_rules('office_name', 'office_name', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data = array(
                'name_np'        => $this->input->post('name_np'),
                'name_en'        => $this->input->post('name_en'),
                'position_np'    => $this->input->post('position_np'),
                'position_en'    => $this->input->post('position_en'),
                'office_name'    => $this->input->post('office_name'),
                'created_at'     => date('Y-m-d'),
                'created_by'     => $this->session->userdata('DISABLE_USER_ID'),
                'created_ip'     => $this->input->ip_address(),
                'status'        => 1
            );
            $result = $this->CommonModel->insertData('office_staffs',$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
            exit('no direct script allowed');
        }
    }

     /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
     */
    public function Edit() {
        $id = $this->input->post('id');
        $data['row'] = $this->CommonModel->getDataByID('office_staffs',$id);
        $this->load->view('edit',$data);
    }

     /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->form_validation->set_rules('name_np', 'name_np', 'required');
            $this->form_validation->set_rules('name_en', 'name_en', 'required');
            $this->form_validation->set_rules('position_np', 'position_np', 'required');
            $this->form_validation->set_rules('position_en', 'position_en', 'required');
            $this->form_validation->set_rules('office_name', 'office_name', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => '<div class="alert alert-danger">'.validation_errors().'</div>',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data = array(
                'name_np'        => $this->input->post('name_np'),
                'name_en'        => $this->input->post('name_en'),
                'position_np'    => $this->input->post('position_np'),
                'position_en'    => $this->input->post('position_en'),
                'office_name'    => $this->input->post('office_name'),
                'modified_at'    => date('Y-m-d'),
                'modified_by'    => $this->session->userdata('DISABLE_USER_ID'),
                'modified_ip'    => $this->input->ip_address(),
            );
            $result = $this->CommonModel->UpdateData('office_staffs',$id,$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
                exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('office_staffs',$id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक हटाइयो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Oops something goes worng!!! Please try again",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed!!!');
        }
    }


}