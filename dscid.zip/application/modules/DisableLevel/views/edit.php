<div class="valid_errors"></div>
<form action="<?php echo base_url()?>DisableLevel/Update" method="post" class="form save_post">
  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <div class="form-group">

    <div class="col-md-12">
       <input type="hidden" class="form-control" placeholder=""  name="id" value="<?php echo $row['id']?>">
      <div class="form-group">
        <label>अपाङ्गको गम्भिरता (नेपाली)<span style="color:red">*</span></label>
        <input type="text" class="form-control" placeholder=""  name="level_np" value="<?php echo $row['level_np']?>" required="required">
      </div>
    </div>

    <div class="col-md-12">
      
      <div class="form-group">
        <label>अपाङ्गको गम्भिरता (English)</label>
        <input type="text" class="form-control" placeholder=""  name="level_en" value="<?php echo $row['level_en']?>" required="required">
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <label>Select Color<span style="color:red">*</span></label>
        <select class="form-control" name="bg_color" required="true">
          <option value="samanya-idcard-wrapper" <?php if($row['bg_color']=='samanya-idcard-wrapper'){echo 'selected';}?>>सेतो</option>
          <option value="asakta-idcard-wrapper" <?php if($row['bg_color']=='asakta-idcard-wrapper'){echo 'selected';}?>>निलो</option>
          <option value="purna-idcard-wrapper" <?php if($row['bg_color']=='purna-idcard-wrapper'){echo 'selected';}?>>रातो</option>
          <option value="madyam-idcard-wrapper" <?php if($row['bg_color']=='madyam-idcard-wrapper'){echo 'selected';}?>>पहेलो</option>
        </select>
      </div>
    </div>

  </div>
  <div class="modal-footer">
    <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सम्पादन गर्नुहोस्</button>
    <button type="button" class="btn btn-danger btn-xs" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" data-dismiss="modal">रद्द गर्नुहोस्</button>
  </div>
</form>