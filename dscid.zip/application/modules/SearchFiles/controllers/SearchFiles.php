<?php
class SearchFiles extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("SearchFilesMdl");
        $this->module_code = 'SEARCH-FILE';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page'] = 'list_all';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'             => '',
                'फाइलखोज्नुहोस'         => 'SearchFiles',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function getDetails() {
        if($this->input->is_ajax_request()) {
            $state                          = $this->input->post('state');
            $lot                            = $this->input->post('lot');
            $bike_m                         = $this->input->post('bike_m');
            $number                         = $this->input->post('number');
            if($state == 1) {
                $state = 'सुदूरपश्चिम प्रदेश ';
            } elseif($state == 2 ) {
                $state =  'मा';
            } else {
                $state = 'से';
            }
            $vehicle_no                 = $state.$lot.$bike_m.$number;
            $data['details']    = $this->SearchFilesMdl->searchDetails($vehicle_no);
            $data_view          = $this->load->view('search_details', $data, true);
            $response           = array(
              'status'          => 'success',
              'data'            => $data_view
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit; 
        } else {
            exit('HTTPS');
        }
    }
}