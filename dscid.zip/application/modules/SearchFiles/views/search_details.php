<div class="row">
	<div class="col-md-12">
		<?php if(!empty($details)) : ?>
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>सवारी नं</th>
					<th>कोठा नं</th>
					<th>रयाक  नं</th>
					<th>रयाकको खण्ड नं </th>
					<th>सवारी नं</th>
					<th>आवस्था</th>
					<th></th>
				</tr>

			</thead>

			<tbody>

				<tr>

					<td><?php echo $this->mylibrary->convertedcit($details['vehicle_no'])?></td>

					<td><?php echo $this->mylibrary->convertedcit($details['room'])?></td>

					<td><?php echo $this->mylibrary->convertedcit($details['rak'])?></td>

					<td><?php echo $this->mylibrary->convertedcit($details['rak_section'])?></td>
					<td><?php echo $this->mylibrary->convertedcit($details['vehicle_no'])?></td>
					<td>
					<?php if($details['status'] == 1 ) { ?>
						<p class="badge badge-info">चलानी नभएको</p>
					<?php } else { ?>
						<p class="badge badge-danger">चलानी भएको</p>
					<?php } ?>
					</td>
					<td>
					<?php if($details['status'] == 1 ) { ?>
						<a href="<?php echo base_url()?>Chalani/Add/<?php echo $details['id']?>" class="btn btn-info"><i class="fa fa-share"></i> चलानी गर्नुहोस</a>
					<?php } else { ?>
						<a href="<?php echo base_url()?>Chalani/View/<?php echo $details['id']?>" class="btn btn-info"><i class="fa fa-eye"></i> विवरण हेर्नुहोस</a>
					<?php } ?>
					</td>
				</tr>

			</tbody>

		</table>
		<?php else: ?>
			<div class="alert alert-warning">फाइल इन्ट्री गरिएको छैन !</div>
		<?php endif;?>
	</div>
</div>