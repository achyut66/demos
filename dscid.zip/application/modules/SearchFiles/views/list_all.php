
    <div class="row">
      <div class="col-sm-12">
        <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
            if(!empty($success_message)) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span> <?php echo $success_message;?> </span>
            </div>
          <?php } ?>
        <section class="card">
          <header class="card-header">
          फाइल खोज्नुहोस
            <span class="tools">
              <?php if($this->authlibrary->HasModulePermission('ROOM', "ADD")) { ?>
               <button type="button" data-toggle="modal" class="btn btn-primary btn-sm pull-right" href="#addModel" data-url="<?php echo base_url()?>Room/add" data-id = ""><i class="fa fa-plus-circle"></i> नयाँ थप्नुहोस्</button>
              <?php } ?>
             </span>
          </header>
          <div class="card-body">
            <div class="adv-table">
              <div class="row">
                <div class="col-md-3">
                    <select class="form-control" name="state" id="state">
                      <option value="1">सुदूरपश्चिम प्रदेश</option>
                      <option value="2">महाकाली</option>
                      <option value="3">सेती</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <?php echo form_input(array('name'=>'lot', 'id'=>'lot', 'class'=>'form-control','value'=> ''));?>
                </div>
                <div class="col-md-2">
                   <?php echo form_input(array('name'=>'bike_m', 'id'=>'bike_m', 'class'=>'form-control', 'value'=> 'प','readonly'=> true));?>
                </div>
                <div class="col-md-2">
                    <?php echo form_input(array('name'=>'number', 'id'=>'number', 'class'=>'form-control'));?>
                </div>
                <div class="col-md-2">
                  <button type="button" class="btn btn-warning" title="खोजी गर्नुहोस्" id="filter"><i class="fa fa-search"></i> खोजी गर्नुहोस्</button>
                </div>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="adv-table">
              <div class="row">
                <div class="col-md-12">
                  <div class="load_content"></div>
                </div>
              </div>
            </div>

          
          </div>
        </section>
      </div>
    </div>
    <!-- page end-->
</section>
</section>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
     $(document).on('click', '#filter', function() {
      obj = $(this);
      //var darta_no = $('#darta_no').val();
      //var vehicle_no = $('#vehicle_no').val();
      var state     = $('#state').val();
      var lot       = $('#lot').val();
      var bike_m    = $('#bike_m').val();
      var number    = $('#number').val();
      $.ajax({
        url:base_url+'SearchFiles/getDetails',
        method:"POST",
        data:{state:state,lot:lot,bike_m:bike_m,number:number,'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'},
        beforeSend: function () {
         $('#filter').html('<i class="fa fa-spinner fa-spin"></i> खोजी गर्नुहोस्!');
         $('#filter').attr('disabled',true);
        },
        success : function(resp){
          if(resp.status == 'success') {
            $('.load_content').html(resp.data);
            $('#filter').attr('disabled',false);
            $('#filter').html('<i class="fa fa-search"></i> खोजी गर्नुहोस्!');
          }
        }
      });
    });
  });
</script>

