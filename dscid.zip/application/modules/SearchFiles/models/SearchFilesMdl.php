<?php 

class SearchFilesMdl extends CI_Model {

	public function searchDetails( $vehicle_no) {
        $this->db->select('*')->from('file_storage');
        $this->db->where('vehicle_no', $vehicle_no);
        $query = $this->db->get();
        return $query->row_array();
    }
}