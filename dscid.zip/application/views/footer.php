

<!--main content start-->

    </section>

  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <div class="modal fade" id="editModel" role="dialog">

      <div class="modal-dialog modal-lg">

        <div class="modal-content" id="modalContent">

          <div class="modal-header" style="background: #1b5693">

            <h4 class="modal-title"><?php echo !empty(EDIT_PAGE_TITLE) ? EDIT_PAGE_TITLE: '';?></h4>

          </div>

          <div class="modal-body">

            <div class="modal-view" id="modal_view"></div>

          </div>

        </div>

      </div>

    </div>



    <!-- js placed at the end of the document so the pages load faster -->

    <div class="modal fade" id="addModel" role="dialog">

      <div class="modal-dialog modal-lg">

        <div class="modal-content" id="modalContent">

          <div class="modal-header" style="background: #1b5693">

            <h4 class="modal-title"><?php echo !empty(EDIT_PAGE_TITLE) ? EDIT_PAGE_TITLE: '';?></h4>

          </div>

          <div class="modal-body">

            <div class="modal-view" id="modal_view"></div>

          </div>

        </div>

      </div>

    </div>



    <!-- js placed at the end of the document so the pages load faster -->

    <div class="modal fade" id="previewModel" role="dialog">

      <div class="modal-dialog modal-lg">

        <div class="modal-content" id="modalContent">

          <div class="modal-header" style="background: #1b5693">

            <h4 class="modal-title"><?php echo !empty($pageTitle) ? $pageTitle:'रद्ध गर्नुको कारण'?></h4>

          </div>

          <div class="modal-body">

            <div class="modal-view" id="modal_view"></div>

          </div>

        </div>

      </div>

    </div>



   <!--   -->

    <!-- <footer class="site-footer">

      <div class="text-center">



    

  </div>

</footer -->

</section>

<script src="<?php echo base_url()?>assets/js/bootstrap.bundle.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo base_url()?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo base_url()?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo base_url()?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/assets/gritter/js/jquery.gritter.js"></script>
<script src="<?php echo base_url()?>assets/js/respond.min.js" ></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/jquery.pulsate.min.js"></script>

<!--right slidebar-->
<script src="<?php echo base_url()?>assets/js/slidebars.min.js"></script>

<!--common script for all pages-->
<script src="<?php echo base_url()?>assets/js/common-scripts.js"></script>

<!--script for this page only-->
<script src="<?php echo base_url()?>assets/js/gritter.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/js/pulstate.js" type="text/javascript"></script>

<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>


<script src="<?php echo base_url()?>assets/toastr-master/toastr.js"></script>




<script type="text/javascript">

  $(document).ready(function() {

 


  })

</script>

</body>

</html>

