<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/* load the MX_Router class */
require APPPATH . "third_party/MX/Controller.php";

class MY_Controller extends MX_Controller
{	

	function __construct() 
	{
		parent::__construct();
		$this->_hmvc_fixes();
		$this->load->model('CommonModel');
	}
	
	function _hmvc_fixes()
	{		
		//fix callback form_validation		
		//https://bitbucket.org/wiredesignz/codeigniter-modular-extensions-hmvc
		$this->load->library('form_validation');
		$this->form_validation->CI =& $this;
	}

	public function do_upload_image($file,$field_name,$upload_path,$redirect_url,$height=NULL,$width=NULL)
    {
        $config = array(
            'upload_path'=>$upload_path,
            'allowed_types'=> "jpg|png|gif|PNG",
            'overwrite' => TRUE,
            'file_name' => $file,
        );
        $this->load->library('upload');
        $this->upload->initialize($config);
        if(!$this->upload->do_upload($field_name)) {
            $error =  'Could Not upload'.$this->upload->display_errors();
            print_r($error);
            exit;
            // $this->session->set_flashdata('ERR_UPLOAD',$error);
            // redirect($redirect_url);
        } else{
            $this->upload->do_upload();
        }
    }

    public function randomize_image_name($img)
    {
        $file =  preg_replace('/\s+/', '_', $img);
        $img=time().'-'.$file;
        return $img;
    }

}

/* End of file MY_Controller.php */
/* Location: ./application/core/MY_Controller.php */