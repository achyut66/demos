<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


  if ( ! function_exists('get_current_fiscal_year')){
   function get_current_fiscal_year(){
       //get main CodeIgniter object
       $ci =& get_instance();
       //load databse library
       $ci->load->database();
       //get data from database
       $query = $ci->db->get_where('fiscal_year',array('is_current'=>1));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['year'];
       }else{
           return false;
       }
   }
  }

  if(! function_exists('get_gender_text')) {
    function get_gender_text($gender) {
      if($gender == 1 ) {
        return 'पुरूष';
      } elseif($gender == 2) {
        return 'महिला';
      } elseif($gender == 3) {
        return 'अन्य';
      }
    }
  }

  if ( ! function_exists('get_current_login_user'))
  {
    function get_current_login_user($userid){
      $ci =& get_instance();
       //load databse library
      $ci->load->database();
       //get data from database
      $query = $ci->db->get_where('users',array('userid'=>$userid));
      if($query->num_rows() > 0){
          $result = $query->row_array();
          return $result;
      } else {
          return false;
      }
    }
  }

  if ( ! function_exists('checkUserExits'))
  {
    function checkUserExits($username){
     
      $ci =& get_instance();
       //load databse library
      $ci->load->database();
       //get data from database
      $ci->db->where('UserName', $username);
      $ci->db->where('status', 'Active');
      $query = $ci->db->get('users');
      if ($query->num_rows() > 0){
            return true;
      }
      else {
          return false;
      }
    }
  }

  /** 
    * This function generate file no for land owner
    * @param string $_POST['name'], int ward $_POST['ward'], int GAPANPA ID $_POST['gapana']
    * @return string file_no
  */
  if(!function_exists('getDistricts'))
  {
    function getDistricts($state = NULL) 
    {
      $ci =& get_instance();
      //load databse library
      $ci->load->database();
     //get data from database
      if(!empty($state)){
        $ci->db->where('state', $state);
      }
      $query = $ci->db->get('settings_district');
      if ($query->num_rows() > 0){
        return $query->result_array();
      }
      else {
          return false;
      }
    }
  }

  if(!function_exists('get_district_dropdown')) {
    function get_district_dropdown($state) {
      if(!empty($state)) {
        $state = $state;
      } else {
        $state = STATE;
      }
      $district = getDistricts($state);
      if(!empty($district)){
        $option = '';
        $option .= '<option value="">छान्नुहोस्</option>';
        foreach ($district as $key => $value) :
          $option .= "<option value = '".$value['id']."''>".$value['name']."</option>";
        endforeach;
        $response = array(
          'status'      => 'success',
          'option' => $option,
        );
        header("Content-type: application/json");
        echo json_encode($response);
        exit;
      }
    }
  }
  if(!function_exists('get_gapanapa'))
  {
    function get_gapanapa($district = NULL) 
    {
      $ci =& get_instance();
      //load databse library
      $ci->load->database();
     //get data from database
      if(!empty($district)){
        $ci->db->where('district_id', $district);
      } else {
        $ci->db->where('district_id', DID);
      }
      $query = $ci->db->get('settings_vdc_municipality');
      if ($query->num_rows() > 0){
          return $query->result_array();
      }
      else {
          return false;
      }
    }
  }

  if(!function_exists('get_ganapa_dropdown')) {
    function get_ganapa_dropdown($district = NULL) {
      if(!empty($district)) {
        $district = $district;
      } else {
        $district = DID;
      }
      $gapa = get_gapanapa($district);
      if(!empty($gapa)){
        $option = '';
        $option .= '<option value="">छान्नुहोस्</option>';
        foreach ($gapa as $key => $value) :
          $option .= "<option value = '".$value['id']."''>".$value['name']."</option>";
        endforeach;
        $response = array(
          'status'      => 'success',
          'option' => $option,
        );
        header("Content-type: application/json");
        echo json_encode($response);
        exit;
      }
    }
  }

  

  
