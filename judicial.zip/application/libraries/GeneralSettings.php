<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class GeneralSettings {
	/**

	 * CodeIgniter global

	 *

	 * @var string

	 **/
	protected $ci;
	/**

	 * account status ('not_activated', etc ...)

	 *

	 * @var string

	 **/
	protected $status;
	public $adjacencyList;
	public $adjacencyCheckboxlist;
	/**
	 * error message (uses lang file)
	 *
	 * @var string
	 **/
	protected $errors = array();
	public $members_data;
	 public function __construct()
	{
		$this->ci =& get_instance();
		$this->referer = (isset($_SERVER['HTTP_REFERER'])) ? $_SERVER['HTTP_REFERER'] : "";
		$this->onpage = $_SERVER['REQUEST_URI'];
		$site_info = $this->get_site_settings_info();
		$letter_head = $this->get_letter_head_info();
		$ward_info = $this->getWardInfo();
		if(empty($site_info)) {
			echo " !!!! Invalid Access !!!";
			exit;
		}
		/*-------------------------------------------------
		english constants
		---------------------------------------------------*/
		// define('SITE_OFFICE'       ,$site_info['state_np']);
		// define('SITE_WARD_OFFICE'  ,"नं वडा कार्यालय");
		// define('SITE_OFFICE'       ,$site_info['state_np']);
		// define('SITE_OFFICE'       ,$site_info['state_np']);
		// define('SITE_OFFICE'       ,$site_info['state_np']);
		// define('SITE_OFFICE'       ,$site_info['state_np']);
		// define('SITE_OFFICE'      ,$site_info['state_np']);
		// print_r($this->ci->session->userdata('ward_no'));
		// exit;
		define('SITE_OFFICE'       	 ,$site_info['palika_name']);
		define('SITE_WARD_OFFICE'  	 ,"नं वडा कार्यालय");
		// define('SITE_SUB_ADD'  		 ,"कुश्मा");
		define('SITE_PALIKA'         ,$site_info['karay_palika_np']);
		define('SITE_ADDRESS'        , "लामखेत");
		define('SITE_STATE'          , $site_info['state_np']);
		define('SITE_OFFICE_TYPE'    , 'गाउँपालिका');
		define('SITE_DISTRICT'       , $site_info['district_np']);
		define('SITE_OFFICE_ADDRESS'       , $site_info['office_address']);
		define('SITE_SLOGAN'         , $site_info['palika_slogan']);
		if(empty($site_info['palika_logo'])) {
			$palika_logo = 'n/a';
		} else {
			$palika_logo = $site_info['palika_logo'];
		}

		if(empty($site_info['sarkar_logo'])) {
			$sarkar_logo = 'n/a';
		} else {
			$sarkar_logo = $site_info['sarkar_logo'];
		}
		define('SITE_PALIKA_LOGO', $palika_logo);
		define('SITE_SARKAR_LOGO', $sarkar_logo);
		define('SITE_OFFICE_ENG'        ,$site_info['palika_name_en']);
		define('SITE_WARD_OFFICE_ENG'  	 ,"No. Ward Office");
		define('SITE_PALIKA_ENG'        	 , $site_info['karay_palika_en']);
		define('SITE_ADDRESS_ENG'            ,"Lamkhet");
		define('SITE_STATE_ENG'              ,$site_info['state_en']);
		define('SITE_OFFICE_TYPE_ENG'        , 'Rural Municipality');
		define('SITE_DISTRICT_ENG'           ,$site_info['district_en']);
		define('SITE_SLOGAN_ENG'            ,$site_info['palika_slogan_en']);
		// if($this->ci->session->userdata('mode') == 'user') {
		// 	define('SITE_SLOGAN_ENG', $ward_info['slogan']);
		// } else {
		// 	define('SITE_SLOGAN_ENG', $site_info['palika_slogan_en']);
		// }

		if($this->ci->session->userdata('mode') == 'user') {
			define('SITE_EMAIL', $ward_info['email']);
		} else {
			define('SITE_EMAIL', $site_info['email']);
		}
		define('SITE_WEBSITE', $site_info['website']);

		if($this->ci->session->userdata('mode') == 'user') {
			define('SITE_PHONE', $ward_info['phone_no']);
		} else {
			define('SITE_PHONE', $site_info['phone_no']);
		}
		//define('SITE_PHONE', $site_info['phone_no']);
		define('SITE_FB', $site_info['facebook']);
		define('SITE_OFFICE_FONT', $letter_head['site_office']);
		define('SITE_PALIKA_FONT', $letter_head['site_palika']);
		define('SITE_WEBSITE_FONT', $letter_head['site_website']);
		define('SITE_EMAIL_FONT', $letter_head['site_email']);
		define('SITE_SLOGAN_FONT', $letter_head['site_slogan']);
		define('SITE_WEBSITE_ALIGNMENT', $letter_head['site_website_alignment']);
		define('SITE_EMAIL_ALIGNMENT', $letter_head['site_email_alignment']);
		define('SITE_SLOGAN_ALIGMENT', $letter_head['site_slogan_alignment']);
		define('SITE_PHONE_ALIGNMENT', $letter_head['site_phone_alignment']);
		define('SITE_OFFICE_FONT_ENG', $letter_head['site_office_en']);
		define('SITE_PALIKA_FONT_ENG', $letter_head['site_palika_en']);
		define('SITE_WEBSITE_FONT_ENG', $letter_head['site_website_en']);
		define('SITE_EMAIL_FONT_ENG', $letter_head['site_email_en']);
		define('SITE_SLOGAN_FONT_ENG', $letter_head['site_slogan_en']);
		define('SITE_WEBSITE_ALIGNMENT_ENG', $letter_head['site_website_alignment_en']);
		define('SITE_EMAIL_ALIGNMENT_ENG', $letter_head['site_email_alignment_en']);
		define('SITE_SLOGAN_ALIGMENT_ENG', $letter_head['site_slogan_alignment_en']);
		define('SITE_PHONE_ALIGNMENT_ENG', $letter_head['site_phone_alignment_en']);
	}


	public function get_letter_head_info() {
		$query = $this->ci->db->get("letter_head");
		if ($query->num_rows() > 0) 
		{
			$data=$query->row_array();				
		}		
		$query->free_result();
		return $data;
	}

	public function getWardInfo() {
		$this->ci->db->select('*')->from('settings_ward');
		$this->ci->db->where('name', $this->ci->session->userdata('ward_no'));
		$query = $this->ci->db->get();
		if($query->num_rows() > 0) {
			return $query->row_array();
		} else {
			return false;
		}
	}

	public function insert_new_visit() {
		if ($this->check_last_visit() ) :
			$adminfolder=ADMIN_FOLDER;
			$brwurl=site_url($_SERVER['REQUEST_URI']);
			if (stripos($brwurl,$adminfolder) !== false) {	
			}
			else
			{

			$dataarray=array(

				'ip_adr'=>$_SERVER['REMOTE_ADDR'],

				'referer'=>$this->referer,

				'country'=>'',

				'client'=>$_SERVER['HTTP_USER_AGENT'],

				'visit_date'=> date("Y-m-d"),

				'time'=> date("H:i:s"),

				'on_page'=>$this->onpage

				);

			$this->ci->db->insert('ip2visits',$dataarray);

		}

		endif;

	}

	public function check_last_visit() {
		$this->ci->db->select('time + 0 as times');
		$this->ci->db->from('ip2visits');
		$this->ci->db->where(array('ip_adr'=>$_SERVER['REMOTE_ADDR'],'visit_date'=>date("Y-m-d"),'on_page'=>$this->onpage));
		$this->ci->db->order_by('time','DESC');
		$this->ci->db->limit(1,0);
		$qry=$this->ci->db->get();
		$queryCount=$qry->row();
		if($qry->num_rows() >0):
		$last_hour = date("H") - 0; 
		$check_time = date($last_hour."is");
		if ($queryCount->times < $check_time)
			return true;
		else
			return false;
		else:
			return true;
		endif;
	}

	public function timezone_list($name, $default='') {
		static $timezones = null;
		if ($timezones === null) {
			$timezones = [];
			$offsets = [];
			$now = new DateTime();
			foreach (DateTimeZone::listIdentifiers() as $timezone) {
				$now->setTimezone(new DateTimeZone($timezone));
				$offsets[] = $offset = $now->getOffset();
				$hours = intval($offset / 3600);
				$minutes = abs(intval($offset % 3600 / 60));
				$gmt_ofset = 'GMT' . ($offset ? sprintf('%+03d:%02d', $hours, $minutes) : '');
				$timezone_name = str_replace('/', ', ', $timezone);
				$timezone_name = str_replace('_', ' ', $timezone_name);
				$timezone_name = str_replace('St ', 'St. ', $timezone_name);
				$timezones[$timezone] = $timezone_name.' (' . $gmt_ofset . ')';
			}
			array_multisort($offsets, $timezones);
		}
		$formdropdown = form_dropdown($name, $timezones, trim($default));
		return $formdropdown;
	}

	public function get_pagination_config(&$config)
	{        
        $config['first_link'] = 'First';
        $config['first_tag_open'] = '';
        $config['first_tag_close'] = '';
        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '';
        $config['last_tag_close'] = '';
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Previous';
        $config['next_tag_open'] = '';
        $config['next_tag_close'] = '';
        $config['cur_tag_open'] = '<span>';
        $config['cur_tag_close'] = '</span>';
        $config['num_tag_open'] = '';
        $config['num_tag_close'] = '';
        $get_vars = $this->ci->input->get();
        if(is_array($get_vars)){
           $config['suffix'] = '?'.http_build_query($get_vars,'','&'); 
        }
        return $config;    
    }
	//pagination config for frontend
	public function frontend_pagination_config(&$config)
	{ 
        $config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['next_link'] = 'Next';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_link'] = 'Prev';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0)"><span>';
		$config['cur_tag_close'] = '</span></a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
        $get_vars = $this->ci->input->get();
        if(is_array($get_vars)){
           $config['suffix'] = '?'.http_build_query($get_vars,'','&'); 
        }
        return $config;       
    }

	
	//function to log admins activity

	function log_admin_activity($data){
        $this->ci->load->library('user_agent');
        $extra_info = '';
        if($this->ci->agent->mobile())
            $extra_info .= 'mobile:'.$this->ci->agent->mobile();
			if($data['extra_info'])
			{
            	$extra_info .= $data['extra_info'];

        	}
        	$data_log = array('log_user_id' => $data['user_id'], 'log_user_type' => $data['user_type'], 'module_name' => $data['module'], 'module_desc' => $data['module_desc'], 'log_action' => $data['action'], 'log_ip' => $this->ci->input->ip_address(), 'log_platform' => $this->ci->agent->platform(), 'log_browser' => $this->ci->agent->browser().' | '.$this->ci->agent->version(), 'log_agent' => $this->ci->input->user_agent(), 'log_referrer' => $this->ci->agent->referrer(), 'log_extra_info' => $extra_info);
			$this->ci->db->insert("log_admin_activity",$data_log);
    }

	//log admin's login error

	function log_invalid_logins($data){           
        $this->ci->load->library('user_agent');
        $encrypted_pwd = $this->ci->encrypt->encode($data['password'],'kks');
        //Extra Info
        $extra_info = '';
        if($this->ci->agent->mobile())
            $extra_info .= 'mobile:'.$this->ci->agent->mobile();
        $data_log = array('log_module' => $data['module'], 'log_username' => $data['username'], 'log_password' => $encrypted_pwd, 'log_ip' => $this->ci->input->ip_address(), 'log_platform' => $this->ci->agent->platform(), 'log_browser' => $this->ci->agent->browser().' | '.$this->ci->agent->version(), 'log_agent' => $this->ci->input->user_agent(), 'log_referrer' => $this->ci->agent->referrer(), 'log_desc' => $data['desc'], 'log_extra_info' => $extra_info);

        $this->ci->db->insert('log_invalid_logins', $data_log);
    }

	public function string_limit($string,$limit)
	{
		$name = (strlen($string) > $limit) ? substr($string , 0 , $limit).'...' : $string;
     	return $name;
	}
	//function to check admin logged in

	public function admin_logged_in()
	{		
		return $this->ci->session->userdata(ADMIN_LOGIN_ID);
	}
	//function to admin logout
	public function admin_logout()
	{
		$this->ci->db->where('id',$this->ci->session->userdata(ADMIN_LOGIN_ID));
		$this->ci->db->update('members',array('is_login' => '0'));
		$this->ci->session->unset_userdata(ADMIN_LOGIN_ID);
		return true;
	}

	//find user real ip address
	public function get_real_ipaddr()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
			$ip=$_SERVER['HTTP_CLIENT_IP'];
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
	    	$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
		else
			$ip=$_SERVER['REMOTE_ADDR'];
		return $ip;
	}
	public function get_Mac_Address(){
       ob_start();  
       system('ipconfig /all');  
       $mycomsys=ob_get_contents();  
       ob_clean();  
       $find_mac = "Physical";   
       $pmac = strpos($mycomsys, $find_mac);  
       $macaddress=substr($mycomsys,($pmac+36),17);  
       return $macaddress;  
    }

	//Change & Get Time Zone based on settings

	function get_local_time($time="none")
	{
		if($time!='none')
		return date("Y-m-d H:i:s");
		else
			return date("Y-m-d");
	}

	function get_local_time_clock()
	{
		$time=date("H:i:s");				
		$piece = explode(":",$time);
		return $piece[0]*60*60+$piece[1]*60+$piece[2];	
	}

	//date format only

	//for date in format: 12th march 2014

	function date_formate($date)
	{
		$str_date=strtotime($date);
		$dt_frmt=date("D, dS M Y",$str_date);
		return $dt_frmt;
	}

	//for date in format: 12 apr 2014
	function date_format1($date)
	{
		$str_date=strtotime($date);
		$dt_frmt=date("d M Y",$str_date);
		return $dt_frmt;
	}

	

	//for date in format: 12 april 2014

	function date_format2($date)

	{

		$str_date=strtotime($date);
		$dt_frmt=date("d F Y",$str_date);
		return $dt_frmt;
	}
	//date & time format only
	function date_time_formate($str)
	{ 
		$str_date=strtotime($str);			
		$dt_frmt=date("d m Y",$str_date).' '.date("H:i",$str_date);			
		return $dt_frmt;
	}

		

	//long date time format for admin panel only

	function long_date_time_format($str)
	{
		return date('D, M d, Y H:i A',strtotime($str));
	}

	//short date time format for admin panel only
	function short_date_format($date)
	{
		return date("d M Y",strtotime($date));
	}

	public function get_site_settings_info()
	{
		$query = $this->ci->db->get("set_up");
		if ($query->num_rows() > 0) 
		{
			$data=$query->row_array();				
		} else {
			exit('#cheating huh !');
		}
		$query->free_result();
		return $data;
	}
	function random_number() 
	{
		return mt_rand(100, 999) . mt_rand(100,999) . mt_rand(11, 99);
	}

	function clean_url($str, $replace=array(), $delimiter='-') 
	{
		if( !empty($replace) ) {$str = str_replace((array)$replace, ' ', $str);}
		$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
		$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
		$clean = strtolower(trim($clean, '-'));
		$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);
		return $clean;
	}

	function check_float_vlaue($str) 
	{
	  if (preg_match("/^[0-9]+(\.[0-9]{1,2})?$/",$str)) 
	  {return true;} 
	  else 
	  {return false;}
	}
	function check_int_vlaue($str) 
	{
	  if (preg_match("/^[0-9]+$/",$str)) 
	  {return true;} 
	  else 
	  {return false;}	
	}
	public function salt() 
	{
		return substr(md5(uniqid(rand(), true)), 0, '10');
	}

	public function generate_username() 
	{
		return substr(md5(uniqid(rand(), true)), 0, '10');
	}

	public function hash_password($password, $salt) 
	{
		return  sha1($salt.sha1($salt.sha1($password)));	
	}

	function create_password($length=8,$use_upper=1,$use_lower=1,$use_number=1,$use_custom="")
	{
		$upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$lower = "abcdefghijklmnopqrstuvwxyz";
		$number = "0123456789";
		$seed_length = '';
		$seed = '';
		$password = '';
		if($use_upper)
		{
			$seed_length += 26;
			$seed .= $upper;
		}
		if($use_lower)
		{
			$seed_length += 26;

			$seed .= $lower;

		}

		if($use_number)

		{

			$seed_length += 10;

			$seed .= $number;

		}

		if($use_custom)

		{

			$seed_length +=strlen($use_custom);

			$seed .= $use_custom;

		}

		

		for($x=1;$x<=$length;$x++)

		{

			$password .= $seed{rand(0,$seed_length-1)};

		}

	

		return $password;

	}

	

	public function check_banned_ip()

	{

		//get user ip and check with banned IP address lists.

		$user_ip = $this->get_real_ipaddr();

					

		if($this->check_block_ip($user_ip)!==0)

		{			

			redirect($this->lang_uri('/ipbanned'), 'refresh');exit;

		}

	}



	

	public function get_first_letter($str){

		return substr($str,0,1);

	}



	public function get_user_info($id=false)
	{
		$this->ci->db->select('m.*,md.*');
		$this->ci->db->from('samati_name m');
		$this->ci->db->join('users md','md.TPID=m.id','left');
		$this->ci->db->where('m.id',$id);
		$qry=$this->ci->db->get();
		if($qry->num_rows()>0)
		{
			return $qry->row();
		}
		return false;
	}

	public function get_user_name($id=false)
	{
		$this->ci->db->select('m.*');
		$this->ci->db->from('users m');
		//$this->ci->db->join('users md','md.TPID=m.id','left');
		$this->ci->db->where('m.id',$id);
		$qry=$this->ci->db->get();
		if($qry->num_rows()>0)
		{
			return $qry->row();
		}
		return false;
	}



	public function get_status_info($status=false)
	{
		if($status=='1')
		{
			return 'Pending';
		}
		else if($status=='2')
		{
			return 'Onboard';
		}
		else if($status=='3')
		{
			return 'Finished';
		} else {
			return 'Cancled';
		}
		// 1=Active,2=InActive,3=Closed,4=Suspened
	}
	public function get_job_status($status)
	{
		if($status==1)
		{
			return 'पेश गरिएको';
		}
		else if($status==2)
		{
			return 'रुजु गरिएको';
		}
		else if($status==3)
		{
			return 'अर्को बैठकमा प्रेश गरिने';
		}
		else
		{
			return 'प्रस्ताव रद्ध गरिएको';
		}
	}

public function get_job_status_info($status)

	{

		// echo $status;

		if($status=='1')

		{

			return 'Rejected';

		}

		else if($status=='2')

		{

			return 'Pending';

		}

		else if($status=='3')

		{

			return 'Shortlisted';

		}

		else if($status=='4')

		{

			return 'Waiting';

		}

		else if($status=='5')

		{

			return 'blocked';

		}

	}


	public function unix_to_date_format($date=false,$time=false,$monthformat=false)

	{

		if($monthformat)

		{

			if($time)

				{



			return date("Y-M-d h:i:s A",$date);	

				}

		

			return date("Y-M-d",$date);

		}

		else

		{

			if($time)

				{



			return date("Y-m-d h:i:s A",$date);	

				}

		

			return date("Y-m-d",$date);

		}

		

	}



	public function get_left_days($date1=false,$date2=false)
	{
		$startTimeStamp = strtotime($date1);
		$endTimeStamp = strtotime($date2);
		$timeDiff = abs($endTimeStamp - $startTimeStamp);
		$numberDays = $timeDiff/86400;  // 86400 seconds in one day
		// and you might want to convert to integer
		$numberDays = intval($numberDays);
		return $numberDays;
	}

 	public function get_count_table_rows($id=false,$fields=false,$table=false)
	{
		$qry=$this->ci->db->get_where($table,array($fields=>$id));
		if($qry->num_rows()>0)
		{
			return $qry->num_rows();
		}
		return 0;
	}
	public function get_tbl_data($select,$table=false,$where=false,$order=false,$order_by='ASC')
	{
		$this->ci->db->select($select);
		if($where)
		{
			$this->ci->db->where($where,null,false);
		}
		if($order)
		{
			$this->ci->db->order_by($order,$order_by);
		}
		$qry=$this->ci->db->get($table);
		if($qry->num_rows()>0)
		{
			return $qry->result();
		}
		return false;
	}

	

}