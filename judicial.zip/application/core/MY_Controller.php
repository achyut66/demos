<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/* load the MX_Router class */
require APPPATH . "third_party/MX/Controller.php";

class MY_Controller extends MX_Controller
{	

	function __construct() 
	{
		parent::__construct();
		$this->_hmvc_fixes();
		$this->load->model('CommonModel');
	}
	
	function _hmvc_fixes()
	{	
		$this->load->library('form_validation');
		$this->form_validation->CI =& $this;
	}

	public function do_upload_image($file,$field_name,$upload_path,$redirect_url,$height=NULL,$width=NULL)
    {
        $config = array(
            'upload_path'=>$upload_path,
            'allowed_types'=> "jpg|png|gif|PNG",
            'overwrite' => TRUE,
            'file_name' => $file,
        );
        $this->load->library('upload');
        $this->upload->initialize($config);
        if(!$this->upload->do_upload($field_name)) {
            $error =  $this->upload->display_errors();
            return $error;
        } else{
            $this->upload->do_upload();
            return true;
        }
    }

    public function randomize_image_name($img)
    {
        $file =  preg_replace('/\s+/', '-', $img);
        $img=time().'-'.$file;
        return $img;
    }

    //send sms
    public function sendSMS($numbers=NULL, $message) {
        if(empty($numbers)) {
            return 'error';
        } else {
            $sender         = 'BMS';
            $token          = 'PrCr1YH3kEhZloT3370TwsewnodUO0WZVlN';
            $content        = [
                'token'     => rawurlencode($token),
                'to'        => $numbers,
                'sender'    => rawurlencode($sender),
                'message'   => nl2br($message),
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,"http://beta.thesmscentral.com/api/v3/sms?");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$content);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec ($ch);
            curl_close ($ch);
            return $server_output;
        }
    }

    public function sendMail($email, $message) {
        
        $this->load->library('email');

        $config['charset'] = 'utf-8';
        $config['wordwrap'] = TRUE;
        $config['mailtype'] = 'html';

        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from('bmsneptech@gmail.com');
        $this->email->to($email);
        $this->email->subject('बैठकमा उपस्थित हुन');
        $this->email->message($message);
                
        // $this->load->library('email');
        // $config['protocol']    = 'smtp';
        // $config['smtp_host']    = 'ssl://smtp.gmail.com';
        // $config['smtp_port']    = '465';
        // //$config['smtp_timeout'] = '7';
        // $config['smtp_user']    = 'bmsneptech@gmail.com';
        // $config['smtp_pass']    = 'bms@12345';
        // $config['charset']    = 'utf-8';
        // $config['newline']    = "\r\n";
        // $config['mailtype'] = 'text'; // or html
        // $config['validation'] = TRUE; // bool whether to validate email or not      

        // $this->email->initialize($config);
        // $config = Array(
        //     'protocol'    => 'smtp',
        //     'smtp_host'   => 'smtp.gmail.com',
        //     'smtp_crypto' => 'tls',
        //     'smtp_port'   => 587,
        //     'smtp_user'   => 'bmsneptech@gmail.com', // change it to yours
        //     'smtp_pass'   => 'bms@12345', // change it to yours
        //     'newlin'    => "\r\n",
        //     'mailtype'    => 'html',
        //     'charset'     => 'iso-8859-1',
        //     'wordwrap'    => TRUE
        // );

        // //$message = '';
        // 
        // $this->email->set_newline("\r\n");
        // $this->email->from('bnod.bnod@gmail.com'); // change it to yours
        // $this->email->to($email);// change it to yours
        // $this->email->subject('बैठकमा उपस्थित हुनेबारे ');
        // $this->email->message($message);
        if($this->email->send())
        {
            return true;
        }
        else
        {
            return $this->email->print_debugger();
           //pp($this->email->print_debugger());
        }
    }
}

/* End of file MY_Controller.php */
/* Location: ./application/core/MY_Controller.php */