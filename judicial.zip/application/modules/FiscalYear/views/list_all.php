<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box anusuchi">
            <div class="">
              <?php if ($this->authlibrary->HasModulePermission('FISCAL-YEAR', "ADD")) { ?>
                <div class="controls-above-table">
                  <div class="row">
                    <div class="col-sm-6">
                      <a class="btn btn-outline-primary" href="#editModel" data-toggle="modal" data-url="<?php echo base_url() ?>FiscalYear/add" data-id=""><i class="os-icon os-icon-ui-22"></i><span></span>नयाँ थप्नुहोस</a>
                    </div>
                  </div>
                </div>
              <?php } ?>

              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th text-aligh="right">#</th>
                      <th>आर्थिक वर्ष</th>
                      <th>चालू आर्थिक वर्ष</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($fiscal_year)) :
                      $i = 1;
                      foreach ($fiscal_year as $key => $value) : ?>
                        <tr class="gradeX">
                          <td><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['year']) ?></td>
                          <td><?php
                              if ($value['is_current'] == 1) { ?>
                              <p class=""><i class=" fa fa-check" style="color:green"></i></p>
                            <?php } else { ?>
                              <p class=""><i class=" fa fa-times " style="color:red"></i></p>
                            <?php  } ?>
                          </td>

                          <?php if ($this->authlibrary->HasModulePermission('FISCAL-YEAR', "EDIT") || $this->authlibrary->HasModulePermission('FISCAL-YEAR', "DELETE")) { ?>
                            <td class="center hidden-phone">
                              <?php if ($this->authlibrary->HasModulePermission('FISCAL-YEAR', "EDIT")) { ?>
                                <button type="button" data-toggle="modal" href="#editModel" class="btn btn-outline-info btn-sm" title="जग्गाको क्षेत्रगत किसिम थप्नुहोस्" data-url="<?php echo base_url() ?>FiscalYear/edit" data-id="<?php echo $value['id'] ?>"><i class="fa fa-pencil"></i></button>
                              <?php } ?>

                            </td>
                          <?php } ?>
                        </tr>
                    <?php endforeach;
                    endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>