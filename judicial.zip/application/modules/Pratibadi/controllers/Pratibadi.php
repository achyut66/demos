<?php
class Pratibadi extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("AnuMdl");
        $this->load->model("Darta/DartaMdl");
        $this->module_code = 'DARTA';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {}

    public function viewAnusuchList() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $darta_no = $this->uri->segment(3);
            if(empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR','दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'list';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'मुद्दाको अनुसुचीहरु'      
            ));
            $data['breadcrumb']                 = $this->breadcrumb->output();
            $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
            $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
            $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
            $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
            $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
            $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function view() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $darta_no       = $this->uri->segment(3);
            $letter_type    = $this->uri->segment(4);
            $print_type     = $this->uri->segment(5);
            if(empty($letter_type)) {
                $this->session->set_flashdata('MSG_ERR','Invalid Request');
                redirect('Darta');
            }
            if(empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR','दर्ता नं भेटिएन.');
                redirect('Darta');
            }

            if($letter_type == 1 ){
                $data['page']   = 'first';
                $data['witness']     = $this->CommonModel->getResultByMultipleCondition('witness',array('darta_no' => $darta_no,'type' => 1));
                $data['anusuchi_1']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_1',array('darta_no' => $darta_no,'anu_type' =>'pratibadi'));
            } else if($letter_type == 2 ){
                $data['page'] = 'second';
                $data['anusuchi_2']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no,'type' =>'pratibadi'));

            } else if($letter_type == 3 ){
                $data['page'] = 'third';
                $data['anusuchi_3']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_3',array('darta_no' => $darta_no,'type' =>'pratibadi'));

            } else if($letter_type == 4 ){
                $data['page'] = 'forth';
                $data['anusuchi_4']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_4',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 5 ){
                $data['page'] = 'fifth';
                $data['witness']     = $this->CommonModel->getResultByMultipleCondition('witness',array('darta_no' => $darta_no,'type' => 2));
                $data['anusuchi_5']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_5',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 6 ){
                $data['page'] = 'sixth';
                $data['anusuchi_6']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_6',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 7 ){
                $data['page'] = 'seven';
                $data['anusuchi_7']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_7',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 8 ){
                $data['page'] = 'eigth';
                $data['anusuchi_8']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_8',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 9 ){
                $data['page'] = 'nine';
                $data['anusuchi_9']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_9',array('darta_no' => $darta_no,'type' =>'pratibadi'));
                $data['anusuchi_5']  = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
            }else if($letter_type == 10 ){
                $data['page'] = 'ten';
                $data['anusuchi_10']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_10',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 11 ){
                $data['page'] = 'eleven';
                $data['anusuchi_11']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_11',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 12 ){
                $data['page'] = 'tweleve';
                $data['anusuchi_12']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_12',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 13 ){
                $data['page'] = 'thirteen';
                $data['anusuchi_13']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_13',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 14 ){
                $data['page'] = 'fourteen';
                $data['anusuchi_14']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_14',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else if($letter_type == 15 ){
                $data['page'] = 'fifteen';
                $data['anusuchi_15']  = $this->CommonModel->getRowByMultipleCondition('anusuchi_15',array('darta_no' => $darta_no,'type' =>'pratibadi'));
            } else {
                $this->session->set_flashdata('MSG_ERR','Invalid Request');
                redirect('Darta');
            }
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'आनुसुची विवरणमा जानुहोस'       => 'BadiAnusuchi/viewAnusuchList/'.$darta_no,
                'अनुसूची-'.$this->mylibrary->convertedcit($letter_type),      
            ));
            $data['breadcrumb']                 = $this->breadcrumb->output();
            $data['type']                       = $letter_type;
            $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
            $data['workers']                    = $this->CommonModel->getData('staff','ASC');
            $data['badi_pratibadi']             = $print_type;
            $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
            $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
            $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
            $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
            $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /*----------------------------------------------------------------------
    anusuchi 1
    -----------------------------------------------------------------------*/
    //save form aanusichi 1
    public function save_anusuchi_1() {
        if($this->input->post('submit')) {
            $darta_no       = $this->input->post('darta_no');
            $anusuchi_id    = $this->input->post('anusuchi_id');
            $type           = $this->input->post('type');
            $this->form_validation->set_rules('dastur', 'dastur', 'required|trim');
            $this->form_validation->set_rules('case_details', 'case_details', 'required|trim');
            $this->form_validation->set_rules('proof', 'proof', 'required|trim');
            if($this->form_validation->run() == false) {
               $this->session->set_flashdata('MSG_ERR','Please fill all required fields');
               redirect('BadiAnusuchi/view/'.$darta_no.'/'.$type);
            }
            $total_print = $this->AnuMdl->Totalprint('anusuchi_1',$darta_no);
            $data = array(
                'darta_no'      => $darta_no,
                'status'        => 1,
                'date'          => convertDate(date('Y-m-d')),
                'dastur'        => $this->input->post('dastur'),
                'anu_type'      => 'badi',
                'print_count'   => $total_print + 1,
            );
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no' => $darta_no,
                    'type'     => 'badi',
                    'print_count' => $total_print + 1,
                    'anusuchi_name' => 1,
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            
            $case_details               = $this->input->post('case_details');             
            $proof                      = $this->input->post('proof');             
            $has_lawyer                 = $this->input->post('has_lawyer');
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_1', $data);
            } else {
                $result = $this->CommonModel->UpdateData('anusuchi_1', $anusuchi_id,$data);
            }
            if($result) {
                $darta_updates      = array(
                    'case_details'  => $case_details,
                    'has_lawyer'    => $has_lawyer,
                    'proof'         => $proof,
                );
                $this->CommonModel->updateDataByField('darta', 'darta_no', $darta_no,$darta_updates);
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi            = array();
                if(empty($anusuchi_id)) {
                    if(!empty($w_name)) {
                        foreach ($w_name as $key => $wit) {
                            $sachi[]      = array(
                                'name'      => $w_name[$key],
                                'age'       => $w_age[$key],
                                'phone'     => $w_phone[$key],
                                'address'   => $w_address[$key],
                                'darta_no'  => $darta_no
                            );
                        }
                        $this->CommonModel->batchInsert($sachi,'witness');
                    }
                } else {
                    $update_saachi = array();
                    if(!empty($w_name)) {
                        foreach ($w_name as $key => $wit) {
                            $sachi[]      = array(
                                'id'        => $w_id[$key],
                                'name'      => $w_name[$key],
                                'age'       => $w_age[$key],
                                'phone'     => $w_phone[$key],
                                'address'   => $w_address[$key],
                                'darta_no'  => $darta_no
                            );
                        }
                        $this->CommonModel->batchUpdate('witness',$w_id,$sachi);
                    }

                    $w_name_new             = $this->input->post('w_name_new');
                    $w_phone_new            = $this->input->post('w_phone_new');
                    $w_age_new              = $this->input->post('w_age_new');
                    $w_address_new          = $this->input->post('w_address_new');
                    $sachi_new            = array();
                    if(!empty($w_name_new)) {
                        foreach ($w_name_new as $key => $wit) {
                            $sachi_new[]      = array(
                                'name'      => $w_name_new[$key],
                                'age'       => $w_age_new[$key],
                                'phone'     => $w_phone_new[$key],
                                'address'   => $w_address_new[$key],
                                'darta_no'  => $darta_no
                            );
                        }
                        $this->CommonModel->batchInsert($sachi_new,'witness');
                    }

                }// end of else.
                if(empty($anusuchi_id)) {
                    redirect('BadiAnusuchi/printAnusuchi_1/'.$darta_no);
                } else {
                    redirect('BadiAnusuchi/view/'.$darta_no.'/'.$anusuchi_id);
                }
                
            }
        }
    }

    //generate pdf
    public function printAnusuchi_1($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_1']                 = $this->AnuMdl->getAnusuchi('anusuchi_1',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_1',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    /*----------------------------------------------------------------------
    anusuchi 2
    -----------------------------------------------------------------------*/
    public function save_anusuchi_2() {
        if($this->input->post('submit')) {
            $darta_no               = $this->input->post('darta_no');
            $anusuchi_2_id          = $this->input->post('anusuchi_2_id');
            $total_print            = $this->AnuMdl->Totalprint('anusuchi_2',$darta_no);
            $data['anusuchi_1']     = $this->AnuMdl->getAnusuchi('anusuchi_1',$darta_no);
            if(empty($data['anusuchi_1'])) {
                $this->session->set_flashdata('MSG_ERR','अनुसूची १ को कार्य सम्पन गर्नुहोस ');
                redirect('BadiAnusuchi/viewAnusuchList/'.$darta_no);
            }
            $data = array(
                'darta_no'            => $darta_no,
                'staff_id'            => $this->input->post('staff_id'),
                'worker_name'         => $this->input->post('worker_name'),
                'date'                => $this->input->post('date'),
                'designation'         => $this->input->post('worker_deg'),
                'type'                => 'badi',
                'print_count'         => $total_print + 1,
                'status'              => 1,
                'created_at'          => convertDate(date('Y-m-d')),
                'created_by'          => $this->session->userdata('EM_USER_ID')
            );
            
            if(empty($anusuchi_2_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 2,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if(empty($anusuchi_2_id)) {
                $result = $this->CommonModel->insertData('anusuchi_2', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_2',$anusuchi_2_id, $data);
            }
            if($result) {
                if(empty($anusuchi_2_id)) {
                    redirect('BadiAnusuchi/printAnusuchi_2/'.$darta_no);
                } else {
                    redirect('BadiAnusuchi/printAnusuchi_2/'.$darta_no);
                }
            }
        }
    }

    public function printAnusuchi_2($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_2']                 = $this->AnuMdl->getAnusuchi('anusuchi_2',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_2',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    /*----------------------------------------------------------------------
    anusuchi 3
    -----------------------------------------------------------------------*/
    public function save_anusuchi_3() {
        if($this->input->post('submit')) {
            $darta_no               = $this->input->post('darta_no');
            $anusuchi_3_id          = $this->input->post('anusuchi_3_id');
            $total_print            = $this->AnuMdl->Totalprint('anusuchi_3',$darta_no);
            // $data['anusuchi_2']     = $this->AnuMdl->getAnusuchi('anusuchi_2',$darta_no);
            // if(empty($data['anusuchi_2'])) {
            //     $this->session->set_flashdata('MSG_ERR','अनुसूची २ को कार्य सम्पन गर्नुहोस ');
            //     redirect('Anusuchi/viewAnusuchList/'.$darta_no);
            // }
            $data = array(
                'darta_no'            => $darta_no,
                'worker_name'         => $this->input->post('worker_name'),
                'date_1'              => $this->input->post('mdate'),
                'detail_1'            => $this->input->post('sdate'),
                'details'             => $this->input->post('details'),
                'designation'         => $this->input->post('worker_deg'),
                'print_count'         => $total_print + 1,
                'status'              => 1,
                'type'                => 'badi'
            );
            if(empty($anusuchi_3_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 3,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if(empty($anusuchi_3_id)) {
                $result = $this->CommonModel->insertData('anusuchi_3', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_3', $anusuchi_3_id,$data);
            }
            if($result) {
                if(empty($anusuchi_3_id)) {
                    redirect('BadiAnusuchi/printAnusuchi_3/'.$darta_no);
                } else {
                    redirect('BadiAnusuchi/printAnusuchi_3/'.$darta_no);
                }
            }
        }
    }

    public function printAnusuchi_3($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_3']                 = $this->AnuMdl->getAnusuchi('anusuchi_3',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_3',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    /*----------------------------------------------------------------------
    anusuchi 4
    -----------------------------------------------------------------------*/
    public function save_anusuchi_4() {
        if($this->input->post('submit')) {
            $darta_no               = $this->input->post('darta_no');
            $anusuchi_4_id          = $this->input->post('anusuchi_4_id');
            $total_print            = $this->AnuMdl->Totalprint('anusuchi_4',$darta_no);
            $this->form_validation->set_rules('darta_no', 'darta_no', 'required|trim');
            $this->form_validation->set_rules('work', 'work', 'required|trim');
            $this->form_validation->set_rules('time', 'time', 'required|trim');
            if($this->form_validation->run() == false) {
               $this->session->set_flashdata('MSG_ERR','Please fill all required fields');
               redirect('Anusuchi/view/'.$darta_no.'/'.$type);
            }
            //$data['anusuchi_2']     = $this->AnuMdl->getAnusuchi('anusuchi_2',$darta_no);
            // if(empty($data['anusuchi_2'])) {
            //     $this->session->set_flashdata('MSG_ERR','अनुसूची २ को कार्य सम्पन गर्नुहोस ');
            //     redirect('Anusuchi/viewAnusuchList/'.$darta_no);
            // }
            $data = array(
                'darta_no'          => $darta_no,
                'date'              => $this->input->post('mdate'),
                'work'              => $this->input->post('work'),
                'time'              => $this->input->post('time'),
                'print_count'       => $total_print + 1,
                'type'              => 'badi',
            );
            if(empty($anusuchi_4_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 4,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if(empty($anusuchi_4_id)) {
                $result = $this->CommonModel->insertData('anusuchi_4', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_4', $anusuchi_4_id,$data);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_4/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_4($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_4']                 = $this->AnuMdl->getAnusuchi('anusuchi_4',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_4',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }


    /*----------------------------------------------------------------------
    anusuchi 5
    -----------------------------------------------------------------------*/
    public function save_anusuchi_5() {
        if($this->input->post('submit')) {
            $darta_no = $this->input->post('darta_no');
            $anusuchi_id = $this->input->post('anusuchi_id');
            $type = $this->input->post('type');
            $this->form_validation->set_rules('dastur', 'dastur', 'required|trim');
            $this->form_validation->set_rules('details', 'case_details', 'required|trim');
            $this->form_validation->set_rules('proof', 'proof', 'required|trim');
            if($this->form_validation->run() == false) {
               $this->session->set_flashdata('MSG_ERR','Please fill all required fields');
               redirect('Anusuchi/view/'.$darta_no.'/'.$type);
            }
            $total_print = $this->AnuMdl->Totalprint('anusuchi_1',$darta_no);
            $data = array(
                'darta_no'      => $darta_no,
                'status'        => 1,
                'date'          => convertDate(date('Y-m-d')),
                'dastur'        => $this->input->post('dastur'),
                'details'       => $this->input->post('details'),
                'type'          => 'badi',
                'proof'         => $this->input->post('proof'),
                'has_laywer'    => $this->input->post('has_lawyer'),
                'print_count'   => $total_print + 1,
            );
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_5', $data);
            } else {
                $result = $this->CommonModel->UpdateData('anusuchi_5', $anusuchi_id,$data);
            }
            if($result) {
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi            = array();
                if(empty($anusuchi_id)) {
                    if(!empty($w_name)) {
                        foreach ($w_name as $key => $wit) {
                            $sachi[]      = array(
                                'name'      => $w_name[$key],
                                'age'       => $w_age[$key],
                                'phone'     => $w_phone[$key],
                                'address'   => $w_address[$key],
                                'darta_no'  => $darta_no,
                                'type'      => '2',
                            );
                        }
                        $this->CommonModel->batchInsert($sachi,'witness');
                    }
                } else {
                    $update_saachi = array();
                    if(!empty($w_name)) {
                        foreach ($w_name as $key => $wit) {
                            $sachi[]      = array(
                                'id'        => $w_id[$key],
                                'name'      => $w_name[$key],
                                'age'       => $w_age[$key],
                                'phone'     => $w_phone[$key],
                                'address'   => $w_address[$key],
                                'darta_no'  => $darta_no,
                                'type'      => '2',
                            );
                        }
                        $this->CommonModel->batchUpdate('witness',$w_id,$sachi);
                    }

                    $w_name_new             = $this->input->post('w_name_new');
                    $w_phone_new            = $this->input->post('w_phone_new');
                    $w_age_new              = $this->input->post('w_age_new');
                    $w_address_new          = $this->input->post('w_address_new');
                    $sachi_new            = array();
                    if(!empty($w_name_new)) {
                        foreach ($w_name_new as $key => $wit) {
                            $sachi_new[]      = array(
                                'name'      => $w_name_new[$key],
                                'age'       => $w_age_new[$key],
                                'phone'     => $w_phone_new[$key],
                                'address'   => $w_address_new[$key],
                                'darta_no'  => $darta_no,
                                'type'      => '2',
                            );
                        }
                        $this->CommonModel->batchInsert($sachi_new,'witness');
                    }

                }// end of else.

                if(empty($anusuchi_id)) {
                    $anusuchi_print = array(
                        'darta_no'      => $darta_no,
                        'type'          => 'badi',
                        'print_count'   => $total_print + 1,
                        'anusuchi_name' => 5,
                        'created_on'    => convertDate(date('Y-m-d'))
                    );
                    $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
                }
                redirect('BadiAnusuchi/printAnusuchi_5/'.$darta_no);
            }
        }
    }

    //generate pdf
    public function printAnusuchi_5($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getResultByMultipleCondition('witness',array('darta_no' => $darta_no,'type' => 2));
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_5',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }


    /*----------------------------------------------------------------------
    anusuchi 6
    -----------------------------------------------------------------------*/
    public function save_anusuchi_6() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_6_id              = $this->input->post('anusuchi_6_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_6',$darta_no);
            //$data['anusuchi_1']     = $this->AnuMdl->getAnusuchi('anusuchi_1',$darta_no);
            // if(empty($data['anusuchi_1'])) {
            //     $this->session->set_flashdata('MSG_ERR','अनुसूची १ को कार्य सम्पन गर्नुहोस ');
            //     redirect('Anusuchi/viewAnusuchList/'.$darta_no);
            // }
            $data = array(
                'darta_no'            => $darta_no,
                'staff_id'            => $this->input->post('staff_id'),
                'worker_name'         => $this->input->post('worker_name'),
                'date'                => $this->input->post('date'),
                'designation'         => $this->input->post('worker_deg'),
                'type'                => 'badi',
                'print_count'         => $total_print + 1,
                'status'              => 1,
            );
            if(empty($anusuchi_6_id)) {
                $result = $this->CommonModel->insertData('anusuchi_6', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_6',$anusuchi_6_id, $data);
            }
            if(empty($anusuchi_6_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 6,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_6/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_6($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_6']                 = $this->AnuMdl->getAnusuchi('anusuchi_6',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_6',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }


    /*----------------------------------------------------------------------
    anusuchi 6
    -----------------------------------------------------------------------*/
    public function save_anusuchi_7() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_7',$darta_no);
            $decision                   = $this->input->post('decision');
            $samiti_decision            = $this->input->post('samiti_decision');
            $new_decision               = implode('<>', $decision);
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => $new_decision,
                'samiti_decision'       => $samiti_decision,
                'date'                  => convertDate(date('Y-m-d')),
                'print_count'           => $total_print + 1,
                'status'                => 1,
            );
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_7', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_7',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 7,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_7/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_7($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_7']                 = $this->AnuMdl->getAnusuchi('anusuchi_7',$darta_no);
        $data['year']                       = substr($data['anusuchi_7']['date'], 0,4);
        $data['month']                      = substr($data['anusuchi_7']['date'], 0,4);
        $data['year']                       = substr($data['anusuchi_7']['date'], 0,4);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_7',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }


    /*----------------------------------------------------------------------
    anusuchi 9
    -----------------------------------------------------------------------*/
    public function save_anusuchi_9() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_9',$darta_no);
            $decision                   = $this->input->post('decision');
            $new_decision = implode('<>', $decision);
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => $new_decision,
                'type'                  => 'badi',
                'date'                  => convertDate(date('Y-m-d')),
                'print_count'           => $total_print + 1,
                'status'                => 1,
            );
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_9', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_9',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 9,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_9/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_9($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_9']                 = $this->AnuMdl->getAnusuchi('anusuchi_9',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_9',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    /*----------------------------------------------------------------------
    anusuchi 10
    -----------------------------------------------------------------------*/
    public function save_anusuchi_10() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_10',$darta_no);
            $decision                   = $this->input->post('decision');
            $new_decision = implode('<>', $decision);
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => $new_decision,
                'date'                  => convertDate(date('Y-m-d')),
                'print_count'           => $total_print + 1,
                'status'                => 1,
                'type'                  => 'badi',
            );
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_10', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_10',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 10,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_10/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_10($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_10']                 = $this->AnuMdl->getAnusuchi('anusuchi_10',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_10',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    /*----------------------------------------------------------------------
    anusuchi 10
    -----------------------------------------------------------------------*/
    public function save_anusuchi_11() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_11',$darta_no);
            $decision                   = $this->input->post('decision');
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => $decision,
                'name'                  => $this->input->post('name'),
                'date'                  => $this->input->post('date'),
                'print_count'           => $total_print + 1,
                'status'                => 1,
                'type'                  => 'badi',
            );

            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_11', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_11',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 11,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_11/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_11($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_11']                 = $this->AnuMdl->getAnusuchi('anusuchi_11',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_11',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    /*----------------------------------------------------------------------
    anusuchi 12
    -----------------------------------------------------------------------*/
    public function save_anusuchi_12() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_12',$darta_no);
            $decision                   = $this->input->post('decision');
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => '',
                'name'                  => $this->input->post('name'),
                'date'                  => $this->input->post('date'),
                'dastur'                => $this->input->post('dastur'),
                'print_count'           => $total_print + 1,
                'status'                => 1,
                'type'                  => 'badi'
            );

            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_12', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_12',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 12,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_12/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_12($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_12']                 = $this->AnuMdl->getAnusuchi('anusuchi_12',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_12',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }


    /*----------------------------------------------------------------------
    anusuchi 13
    -----------------------------------------------------------------------*/
    public function save_anusuchi_13() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_13',$darta_no);
            $decision                   = $this->input->post('decision');
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => '',
                'name'                  => $this->input->post('name'),
                'date'                  => $this->input->post('date'),
                'details_decision'      => $this->input->post('details'),
                'ndate'                 => $this->input->post('ndate'),
                'adate'                 => $this->input->post('adate'),
                'dastur'                => $this->input->post('dastur'),
                'print_count'           => $total_print + 1,
                'status'                => 1,
                'type'                  => 'badi'
            );

            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_13', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_13',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 13,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_13/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_13($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_13']                 = $this->AnuMdl->getAnusuchi('anusuchi_13',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_13',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

     /*----------------------------------------------------------------------
    anusuchi 14
    -----------------------------------------------------------------------*/
    public function save_anusuchi_14() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_14',$darta_no);
            $decision                   = $this->input->post('decision');
            $m                          = $this->input->post('member');
            $member = implode('+',$m);
            $data = array(
                'darta_no'              => $darta_no,
                'date'                  => convertDate(date('Y-m-d')),
                'samyojak'              => $this->input->post('samyojak'),
                'members'               => $member,
                'ward_no'               => $this->input->post('ward_no'),
                'area'                  => $this->input->post('area'),
                'kitta_no'              => $this->input->post('kitta_no'),
                'type'                  => $this->input->post('type'),
                'sqm'                   => $this->input->post('sqm'),
                'detail'                => $this->input->post('detail'),
                'print_count'           => $total_print + 1,
                'status'                => 1,
                'type'                  => 'badi',
            );
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_14', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_14',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 14,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_14/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_14($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_14']                = $this->AnuMdl->getAnusuchi('anusuchi_14',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_14',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }


    /*----------------------------------------------------------------------
    anusuchi 12
    -----------------------------------------------------------------------*/
    public function save_anusuchi_15() {
        if($this->input->post('submit')) {
            $darta_no                   = $this->input->post('darta_no');
            $anusuchi_id                = $this->input->post('anusuchi_id');
            $total_print                = $this->AnuMdl->Totalprint('anusuchi_15',$darta_no);
            $decision                   = $this->input->post('decision');
            $data = array(
                'darta_no'              => $darta_no,
                'details_decision'      => implode('<>',$decision),
                'name'                  => $this->input->post('name'),
                'date'                  => convertDate(date('Y-m-d')),
                'dastur'                => $this->input->post('dastur'),
                'print_count'           => $total_print + 1,
                'status'                => 1,
                'type'                  => 'badi'
            );
            if(empty($anusuchi_id)) {
                $result = $this->CommonModel->insertData('anusuchi_15', $data);
            } else {
                $result = $this->CommonModel->updateData('anusuchi_15',$anusuchi_id, $data);
            }
            if(empty($anusuchi_id)) {
                $anusuchi_print = array(
                    'darta_no'      => $darta_no,
                    'type'          => 'badi',
                    'print_count'   => $total_print + 1,
                    'anusuchi_name' => 15,
                    'created_on'    => convertDate(date('Y-m-d'))
                );
                $this->CommonModel->insertData('anusuchi_history', $anusuchi_print);
            }
            if($result) {
                redirect('BadiAnusuchi/printAnusuchi_15/'.$darta_no);
            }
        }
    }

    public function printAnusuchi_15($darta_no) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters','ASC');
        $data['workers']                    = $this->CommonModel->getData('staff','ASC');
        $data['anusuchi_15']                 = $this->AnuMdl->getAnusuchi('anusuchi_15',$darta_no);
        $data['anusuchi_5']                 = $this->AnuMdl->getAnusuchi('anusuchi_5',$darta_no);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta','darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail','darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail','darta_no', $darta_no);
        $data['witness']                    = $this->CommonModel->getAllDataByField('witness','darta_no', $darta_no);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye','id', $data['darta_detail']['id']);
        $html                               = $this->load->view('anusuchi_pdf_15',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
        //$mpdf->Output('सवारी दर्ता प्रतिबेदन.pdf','D'); // it downloads the file into the user system, with give name
    }

    //get workers.
    public function getWorkers() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('workers_id');
            $result = $this->CommonModel->getDataByID('staff', $id);
            if($result) {
                $response = array(
                        'status'      => 'success',
                        'name'        => $result['name'],
                        'deg'        => $result['designation'],
                    );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
            }
        }
    } 

    public function deleteWitness() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('witness', $id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'  => 'successfully removed' 
                );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
            }
        }
    }
}// end of class