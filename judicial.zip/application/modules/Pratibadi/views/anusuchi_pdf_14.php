dd

<!DOCTYPE html>

<html>

<head>

	<meta charset="UTF-8">

	<title><?php echo SITE_OFFICE?></title>

	<style type="text/css">

		/*table, th, td {

			border: 1px solid black;

		}*/



		/* Center tables for demo */

		table {

			margin: 0 auto;

		}



		/* Default Table Style */

		table {

			color: #333;

			background: white;

			border: 0;

			font-size: 12pt;

			border-collapse: collapse;

		}

		table thead th,

		table tfoot th {

			color: #000;

			background: rgba(0,0,0,.1);

		}

		table caption {

			padding:.5em;

		}

		table th,

		table td {

			padding: .5em;

			border: 0;

		}
    .signature{
    float: right;
    border-top: dotted 1px #000;
    width:180px;
}
.stamp{
    float: right; 
    margin-top:auto;
    border: 1px solid #555; 
    margin-left: 427px; 
    height: 140px; 
    margin-top:-102px; 
    width: 145px;
    margin-right: 40px;
}

	</style>

</head>
  <body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
    <div style="background-color: #fff;"> <!-- main content -->
      <div style="margin-left: 320px;">अनुसूची–१४</div>
      <div style="margin-left: 240px;">(दफा ७९ को उपदफा (४) सँग सम्बन्धित)</div>
      <div style="margin-left: 280px;top:-30px;">सम्पति रोक्का को अदेश</div>
      <div style="margin-left: 225px;"><?php echo SITE_OFFICE?> न्यायिक समिति</div>

      <div style="margin-left: 40px; margin-top: 50px;">
        संयोजक श्री: <?php echo $anusuchi_14['samyojak']?>
      </div>

       
        <?php
          if(!empty($anusuchi_14['members'])) :
            $mem = explode('+', $anusuchi_14['members']);
            foreach($mem as $m) : 
        ?>
        <div style="margin-left: 40px;">
          सदस्य श्री: <?php echo $m?>
        </div>
        <?php endforeach;endif?>
      </div>

      <div style="margin-left: 320px; margin-top: 50px">
       आदेश
      </div>

      <div style="margin-left: 250px;">
        संवत <?php echo  $this->mylibrary->convertedcit(substr($darta_detail['date'], 0,4))?> सालको निवेदन नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?>
      </div>

      <div style="margin-left: 280px; margin-top: 50px;">
        विषयः  <?php echo  $this->mylibrary->convertedcit($subject['subject'])?>
      </div>

      <?php if(!empty($badi)) : 
        foreach($badi as $key => $b) : 
          $byear = substr($b['b_dob'],0,4);
          $bcurrent_date = convertDate(date('Y-m-d'));
          $bcurrent_year = substr($bcurrent_date, 0,4);
          $bage = $bcurrent_year - $byear;
          ?>
          <div style="margin-left: 40px; margin-right: 40px; margin-top: 30px; text-align: justify;"><?php echo SITE_DISTRICT?> जिल्ला <?php echo SITE_OFFICE?> वडा नं. <?php echo $b['b_address']?>  बस्ने <?php echo $b['b_father']?> छोरा / छोरी / श्रीमति वर्ष <?php echo $bage?> को  <?php echo $b['b_name']?> निवेदक (प्रथम पक्ष)</div>
      <?php endforeach;endif;?>

      <div style="margin-left: 320px">विरुद्ध</div>
      <div style="margin-left: 40px; margin-right: 40px; margin-top: 30px; text-align: justify;">
        <?php if(!empty($pratibadi)) : 
          foreach($pratibadi as $key => $p) : 
            $pyear = substr($b['b_dob'],0,4);
            $pcurrent_date = convertDate(date('Y-m-d'));
            $pcurrent_year = substr($pcurrent_date, 0,4);
            $page = $pcurrent_year - $pyear;
        ?>
        <?php echo SITE_DISTRICT?> जिल्ला <?php echo SITE_OFFICE?> वडा नं. <?php echo $p['p_address']?> विपक्षी  (दोश्रो पक्ष) बस्ने <?php echo $page?> वर्ष  को  <?php echo $p['p_name']?> 
        <?php endforeach;endif;?>
         यसमा निवेदकको माग बमोजिम <?php echo SITE_DISTRICT?> जिल्ला <?php echo SITE_OFFICE?>, वडा नं. 
       
        <?php echo $this->mylibrary->convertedcit($anusuchi_14['ward_no'])?>

        क्षे.फ.  <?php echo $this->mylibrary->convertedcit($anusuchi_14['area'])?>

         कि.नं.<?php echo $this->mylibrary->convertedcit($anusuchi_14['kitta_no'])?>
          जग्गामा बनेको  <?php echo $this->mylibrary->convertedcit($anusuchi_14['type'])?>

           को नाममा रहेको अवण्डाको  <?php echo $this->mylibrary->convertedcit($anusuchi_14['sqm'])?>
           वर्ग फिटको चार तल्ले घर र लिग लगापात समेत विपक्षी <?php echo $anusuchi_14['detail']?>
           सम्पती निज विपक्षीबाट अन्य अंशियारहरुको मन्जुरी विना हक हस्तान्तरण हुन सक्ने आशंका गरी निवेदकले दिएको निवेदन उपर प्रारम्भिक रुपमा जाँचबुझ गर्दा व्यहोरा मनासिव देखिएको हुँदा हाललाई प्रत्यक्षको नाममा रहेको उल्लिखित घरजग्गाको हक हस्तान्तरण गर्न सिफारिस नदिन वडालाई र अर्को आदेश नभएसम्मका लागि उक्त घरजग्गाको हक हस्तान्तरण नगर्नु÷गर्न नदिनु भनी मालपोत कार्यालयको नाममा समेत स्थानीय सरकार सञ्चालन ऐन २०७४ को दफा ४९ (६) बमोजिम यो रोक्काको आदेश जारी गरिदिएका छौं । यो आदेश मिसिल सामेल राखी सम्बन्धित कार्यालयहरुमा पठाईदिनु । यो आदेश अनुसार रोक्का भएको जानकारी प्राप्त गरी मिसिल सामेल राख्नु र नियमानुसार पेश गर्नु ।

      </div>

      <div style="margin-left: 80px;margin-right: 40px;margin-top: 150px">इति सम्वत् <?php echo $this->mylibrary->convertedcit(substr($anusuchi_14['date'], 0,4));?> साल <?php echo getNepaliMonthName(substr($anusuchi_14['date'], 5,2))?> महिना <?php echo $this->mylibrary->convertedcit(substr($anusuchi_14['date'], 8,2));?> गते रोज ...... शुभम् .................।</div>
    </div>
  </body>
</html>

