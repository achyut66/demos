<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                  <?php echo form_open('BadiAnusuchi/save_anusuchi_3', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                    <div class="element-box-tp" >
                       <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                       <input type="hidden" name="anusuchi_3_id" value="<?php echo !empty($anusuchi_3)?$anusuchi_3['id']:''?>">

                      <div class="anusuchi" style="height: 550px">
                          <!-- <div class="text-left">
                           <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-left: 40px;margin-right: 40px;margin-top: 20px;"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</button>
                        </div> -->
                        <div class="text-center">
                          <p>अनुसूची–३</p>
                          <p style="margin-top:-20px;">(दफा ९ को उपदफा (२) सँग सम्बन्धित)</p>
                          <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE?></p>
                          <p style="margin-top:-20px;">न्यायिक समिति</p>
                        </div>
                        <div class="text-left" >
                          <p style="margin-left: 40px;"><?php echo $badi[0]['b_name'] ?></p>
                          <p style="float:right; margin-right: 100px;margin-top: -50px;"><?php echo !empty($pratibadi[0]['p_name'])?$pratibadi[0]['p_name']:'प्रतिवादीको विवरण दाखिला गरिएको छैन' ?></p>
                        </div>
                        
                         <p class="text-left" style="margin-left:40px;margin-right: 40px;">मिति  &nbsp;&nbsp;
                          <input type="text" name="mdate" id="mdate" style=" width:180px;outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_3)?$anusuchi_3['date_1']:convertDate(date('Y-m-d'))?>"> मा 
                          
                          <input type="text" name="sdate" id="" style="width:360px;outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_3)?$anusuchi_3['detail_1']:''?>" > हुने भएकाले / साधारण तारेख भएको 
                          <textarea style=" width:300px;outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" name="details"><?php echo !empty($anusuchi_3)?$anusuchi_3['details']:''?></textarea>&nbsp;&nbsp;उपस्थित हुन आउनुहोला ।

                          <div class="text-left">
                            <p style="margin-left:40px;">सम्बन्धित कर्मचारीको</p>
                            <p style="margin-left:40px;">नामः
                             <select class="" style="border: none; background: none;border-bottom: 1px solid #000" required="true" id="workers" name="staff_id">
                                <option value="">कर्मचारी छानुहोस</option>
                                <?php if(!empty($workers)) : 
                                  foreach($workers as $staff) : ?>
                                  <option value="<?php echo $staff['id']?>"
                                    <?php if(!empty($anusuchi_3)) : ?>
                                      <?php if($staff['name'] == $anusuchi_3['worker_name']){ echo 'selected';}?>
                                      <?php endif;?>
                                    ><?php echo $staff['name']?></option>
                              <?php endforeach; endif;?>
                            </select></p>
                            <input type="hidden" name="worker_name" value="<?php echo !empty($anusuchi_3)?$anusuchi_3['worker_name']:''?>" id="worker_name">
                            <p style="margin-left:40px;">पदः<span style="color:red">*</span> <input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" value="<?php echo !empty($anusuchi_3)?$anusuchi_3['designation']:''?>" required="true" id="post"></p>
                            </p>
                            <p style="margin-left:40px;">दस्तखतः</p>
                          </div>
                          <div class="text-center" style="margin-top: 60px;">
                            <hr>
                            <?php if(empty($anusuchi_3)) { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                            <?php } else { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                              <a href ="<?php echo base_url()?>BadiAnusuchi/printAnusuchi_3/<?php echo $darta_detail['darta_no']?>" class="btn btn-secondary" target ="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
                            <?php } ?>
                          <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
                        </div>
                      </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    var mainInput = $("#mdate");
    //var smainInput = $("#sdate");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

    // smainInput.nepaliDatePicker({
    //     ndpYear: true,
    //     ndpMonth: true,
    //     ndpYearCount: 100,
    //     disableAfter: GetCurrentBsDate
    // });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url:base_url+'BadiAnusuchi/getWorkers',
        method:"POST",
        data: {workers_id:workers_id},
        success:function(resp){
          if(resp.status == 'success' ) {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });
  });
</script>