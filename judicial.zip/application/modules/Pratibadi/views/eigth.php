<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp" >
                      <?php echo form_open('Anusuchi/save_anusuchi_6', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                      <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                      <input type="hidden" name="anusuchi_6_id" value="<?php echo !empty($anusuchi_6)? $anusuchi_6['id']:''?>">

                      <div class="anusuchi" style="height: 900px;">
                        
                        <div class="text-center">
                          <p>अनुसूची–८</p>
                          <p style="margin-top:-20px;">(दफा ४८ सँग सम्बन्धित)</p>
                          <p style="margin-top:-20px;">अन्तरिम संरक्षणात्मक आदेश </p>
                          <p style="margin-top:-20px;"><?php echo SITE_OFFICE?> न्यायिक समिति</p>
                        </div>

                        <p style="margin-left: 40px;">
                          संयोजक श्री <span style="color:red">*</span> <input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" id="post" value="" >
                        </p>
                        <div style="margin-left: 30px;">
                          <table class="table table-borderless" id="frm_tbl_wit">
                           <tbody>
                              <tr>
                               <td>सदस्य श्री <span style="color:red">*</span> <input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="" ><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td> 
                              </tr>
                              </tr>
                           </tbody>
                          </table>
                        </div>
                        <div class="text-center">
                          <h6>आदेश</h6>
                          <h6 style="margin-left: 40px;">संवत <?php echo  $this->mylibrary->convertedcit(substr($darta_detail['date'], 0,4))?> सालको निवेदन नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?></h6>
                        </div>

                        <div class="text-center" style="margin-top: 30px">
                          <h5>विषयः  <?php echo  $this->mylibrary->convertedcit($subject['subject'])?> </h5>
                        </div>
                         <?php if(!empty($badi)) : 
                          foreach($badi as $key => $b) : 
                            // $pyear = substr($b['b_dob'],0,4);
                            // $pcurrent_date = convertDate(date('Y-m-d'));
                            // $pcurrent_year = substr($pcurrent_date, 0,4);
                            // $page = $pcurrent_year - $pyear;
                          ?>
                        <p style="margin-left: 40px; margin-top: 30px;"><?php echo SITE_DISTRICT?> जिल्ला <?php echo SITE_OFFICE?> वडा नं. <?Php echo $b['b_address']?>  बस्ने <?php echo $b['b_name']?> प्रथम पक्ष</p>
                         <?php endforeach;endif;?>
                        <p style="margin-left: 40px;">विरुद्ध</p>
                        <?php if(!empty($pratibadi)) : 
                          foreach($pratibadi as $key => $p) : 
                            // $pyear = substr($b['b_dob'],0,4);
                            // $pcurrent_date = convertDate(date('Y-m-d'));
                            // $pcurrent_year = substr($pcurrent_date, 0,4);
                            // $page = $pcurrent_year - $pyear;
                          ?>
                        <p style="margin-left: 40px;"><?php echo SITE_DISTRICT?> जिल्ला <?php echo SITE_OFFICE?> वडा नं. <?Php echo $p['p_address']?>  बस्ने <?php echo $p['p_name']?> प्रथम पक्ष</p>
                        <?php endforeach;endif;?>
                        <p style="margin-left: 40px;margin-right: 40px;">
                          यसमा निवेदकको माग वमोजिम .......................... जिल्ला वडा नं............................ बस्ने ............... को नाति ....................... को छोरा / छोरी वर्ष ............... को ................ ले आफुलाई असाध्य रोग लागि नियमित रुपमा हप्ताको २ पटक मृगौला डायलोसिस गर्न चिकित्सकले शिफारिस गरेकोमा एकाघरका छोरा वर्ष .................. को ........................... ले नियमित रुपमा डाय लोसि स गर्न अटेर गरेको, घरि घरि रुपयाँ नभएको वहाना गर्ने गरेको, कहिले कहिले कार्यालयको कामको व्यस्तताले फुर्सद नमिलेको आदि कारण जनाई आफुले नियमित प्राप्त गर्नुपर्ने स्वास्थ्य सेवा प्राप्त गर्न नसकेको हुँदा आफ्नो जीवन झनझन खतरायुक्त वन्दै गएको भनि अस्पतालको चिकित्सकको पुर्जा र शिफारिस सहित पेश हुन आएको निवेदन उपर प्रारम्भिक रुपमा जाँचवुझ गर्दा व्यहोरा मनासिव देखिएको हुँदा हाललाई निवेदकको लागि चिकित्सकले शिफारिस गरे वमोजिम हरेक हप्ता २ पटक डायलोसिस गर्नु गराउनु तथा निजको स्वास्थ्य लाभका लागि आवश्यक अन्य प्रवन्ध समेत मिलाउनु भनि स्थानीय सरकार संचालन ऐन २०७४ को दफा ४९ (८) वमोजिम विपक्षी ........................ को नाममा यो अन्तरिम संरक्षणात्मक आदेश जारी गरिदिएका छौं । यो आदेश मिसिल सामेल राखी विपक्षीलाई लेखी पठाईदिनु । यो आदेश अनुसार उपचार भएको जानकारी प्राप्त गरी मिसिल सामेल राख्नु र नियमानुसार पेश गर्नु ।
                        </p>
                          <div class="text-center" style="margin-top: 60px;">
                            <hr>
                          <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                        </div>
                      </div>
                       <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    $('.dd_select').select2();
    var mainInput = $("#mdate");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url:base_url+'Anusuchi/getWorkers',
        method:"POST",
        data: {workers_id:workers_id},
        success:function(resp){
          if(resp.status == 'success' ) {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });

    $('.btnaddNewField').click(function(e) {
      var MaxInputs       = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length+1;
          <?php if(empty($anusuchi_1)) : ?>
          var new_row =  '<tr class="row_mem">'+
                            '<td>सदस्य श्री <span style="color:red">*</span><input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="" ><button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>'+
                            '<tr>';
            <?php else : ?>
              var new_row = '<tr class="row_mem">'+
                            '<td><input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="" ><button type="button" style="border: none;background: none"><i class="fa fa-times" style="color:red;"></i></button></td>'+
                            '<tr>';
            <?php endif;?>
          $("#frm_tbl_wit").append(new_row);
    });

    $("body").on("click",".remove-row", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

  });

</script>