<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp" >
                      <?php echo form_open('BadiAnusuchi/save_anusuchi_2', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal', 'target'=>'_blank'));?>
                      <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                      <input type="hidden" name="anusuchi_2_id" value="<?php echo !empty($anusuchi_2)? $anusuchi_2['id']:''?>">
                      <input type = "hidden" name = "badi_pratibadi" value ="<?php echo $badi_pratibadi?>">
                      <div class="anusuchi" style="height: 500px;">
                        <div class="text-center">
                          <p>अनुसूची–२</p>
                          <p style="margin-top:-20px;">(दफा ९ को उपदफा (१) सँग सम्बन्धित</p>
                          <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE?></p>
                          <p style="margin-top:-20px;">उजुरी दर्ता गरेको निस्सा को ढाँचा</p>
                        </div>
                         <p class="text-left" style="margin-left:40px;margin-right: 40px;">वादी श्री <?php echo $badi[0]['b_name']?> ले मिति <?php echo $this->mylibrary->convertedcit($darta_detail['date'])?> मा <?php echo $pratibadi[0]['p_name']?> को विरुद्धमा <?php echo $subject['subject']?> विषयमा दर्ता गरेको नालेस यस समितिको दर्ता नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?>  मा दर्ता भएकाले यो भर्पाई दिइएको छ ।
                          <div class="text-left">
                            <p style="margin-left:40px;"><b>भपाई गर्ने कर्मचारीको</b></p>
                            <p style="margin-left:40px;">दस्तखतः</p>
                            <p style="margin-left:40px;">नामः<span style="color:red">*</span> 
                              <select class="" style="border: none; background: none;border-bottom: 1px solid #000" required="true" id="workers" name="staff_id">
                                <option value="">कर्मचारी छानुहोस</option>
                                <?php if(!empty($workers)) : 
                                  foreach($workers as $staff) : ?>
                                  <option value="<?php echo $staff['id']?>"
                                    <?php if(!empty($anusuchi_2)) : ?>
                                      <?php if($staff['id'] == $anusuchi_2['staff_id']){ echo 'selected';}?>
                                      <?php endif;?>
                                    ><?php echo $staff['name']?></option>
                              <?php endforeach; endif;?>
                            </select></p>
                            <input type="hidden" name="worker_name" value="<?php echo !empty($anusuchi_2)?$anusuchi_2['worker_name']:''?>" id="worker_name">
                            <p style="margin-left:40px;">पदः<span style="color:red">*</span> <input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" id="post" value="<?php echo !empty($anusuchi_2)?$anusuchi_2['designation']:''?>" ></p>

                            <p style="margin-left:40px;">मितिः<span style="color:red">*</span> <input type="text" name="date" id="mdate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_2)?$anusuchi_2['date']:convertDate(date('Y-m-d'))?>"  name="date"></p>
                          </div>
                          <div class="stamp">
                            <p>पालिकाको छाप</p>
                          </div>

                          <div class="text-center" style="margin-top: 60px;">
                            <hr>
                            <?php if(empty($anusuchi_2)) { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                            <?php } else { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                              <a href ="<?php echo base_url()?>BadiAnusuchi/printAnusuchi_2/<?php echo $darta_detail['darta_no']?>" class="btn btn-secondary" target ="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
                            <?php } ?>
                          <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
                        </div>
                     
                       <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    $('.dd_select').select2();
    var mainInput = $("#mdate");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url:base_url+'BadiAnusuchi/getWorkers',
        method:"POST",
        data: {workers_id:workers_id},
        success:function(resp){
          if(resp.status == 'success' ) {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });
  });

</script>