dd

<!DOCTYPE html>

<html>

<head>

	<meta charset="UTF-8">

	<title><?php echo SITE_OFFICE?></title>

	<style type="text/css">

		/*table, th, td {

			border: 1px solid black;

		}*/



		/* Center tables for demo */

		table {

			margin: 0 auto;

		}



		/* Default Table Style */

		table {

			color: #333;

			background: white;

			border: 0;

			font-size: 12pt;

			border-collapse: collapse;

		}

		table thead th,

		table tfoot th {

			color: #000;

			background: rgba(0,0,0,.1);

		}

		table caption {

			padding:.5em;

		}

		table th,

		table td {

			padding: .5em;

			border: 0;

		}
    .signature{
    float: right;
    border-top: dotted 1px #000;
    width:220px;
}

	</style>

</head>
  <body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; margin-top: 8cm ">
    <div style="background-color: #fff;"> <!-- main content -->
      
      <div style="margin-left: 320px;">अनुसूची–१</div>
      <div style="margin-left: 240px;">(दफा ८ को उपदफा (२) सँग सम्बन्धित)</div>
      <div style="margin-left: 220px;top:-30px;">श्री <?php echo SITE_OFFICE?>मा दर्ता गरेको नालेस</div>
      <?php 
        $year           = substr($badi[0]['b_dob'],0,4);
        $d_year         = substr($darta_detail['date'], 0,4);
        $d_month        = substr($darta_detail['date'], 5,2);
        $d_day          = substr($darta_detail['date'], 8,2);
        $current_date   = convertDate(date('Y-m-d'));
        $current_year   = substr($current_date, 0,4);
        $age            = $current_year - $year;
        $pyear          = substr($badi[0]['b_dob'],0,4);
        $pcurrent_date  = convertDate(date('Y-m-d'));
        $pcurrent_year  = substr($pcurrent_date, 0,4);
        $page           = $pcurrent_year - $pyear;
      ?>
       <div style="margin-left:40px; margin-right: 40px; margin-top: 40px;">
           <?php if(!empty($pratibadi)) : 
          foreach($pratibadi as $key => $p) : 
            $pyear = substr($p['p_dob'],0,4);
            $pcurrent_date = convertDate(date('Y-m-d'));
            $pcurrent_year = substr($pcurrent_date, 0,4);
            $page = $pcurrent_year - $pyear;
          ?>
          <?php echo $p['p_grandfather']?> को नाती <?php echo $p['p_father']?> को छोरा/छोरी <?php echo $p['p_husband_wife']?> को पति/पत्नी, <?php echo $p['p_address']?> बस्ने वर्ष 
          <?php echo $this->mylibrary->convertedcit($page)?> <?php echo $p['p_name']?><b> 
          <?php endforeach;endif;?>
        </div>
         <p style="margin-left: 320px;"> को विरुद्ध</p>
      <div style="margin-left:40px; margin-right: 40px; text-align: justify;">
        <?php if(!empty($badi)) : 
        foreach($badi as $key => $b) : 
          $byear = substr($b['b_dob'],0,4);
          $bcurrent_date = convertDate(date('Y-m-d'));
          $bcurrent_year = substr($bcurrent_date, 0,4);
          $bage = $bcurrent_year - $byear;
        ?>
        <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
        <?php echo $this->mylibrary->convertedcit($bage)?> <?php echo $b['b_name']?>
        <?php endforeach;endif;?>
      </div> 

        <h4 class="text-center" style="margin-left:250px;text-align: justify;margin-top: 20px;">विवादको विषयः <span style="text-decoration: underline;"><?php echo $subject['subject']?></span></b></h4><br>
        <?php if(!empty($badi)) {
            $total_badi = count($badi);
            if($total_badi >= 1 ) {
              $sombodan = 'हामी';
            } else {
              $sombodan = 'म';
            }
        } ?>
        <div style="margin-left:40px; margin-right: 40px; margin-top:-20px;text-align: justify;">
          १) <?php echo $sombodan?> वादीहरुलाई माथि उल्लेख भए बमोजिमका विपक्षीहरुले अन्याय गर्नु भएको हुनाले उक्त विवादको विषय उपर मुद्दा हेर्न मिल्ने यस <?php echo SITE_OFFICE?>को न्यायिक समिति समक्ष कानुन बमोजिमको हद म्याद भित्र प्रस्तुत नालेस लिई आएको छु / आएका छौं । कानुन बमोजिम लाग्ने  दस्तुर रु  <?php echo $this->mylibrary->convertedcit($anusuchi_5['dastur'])?> यसै साथ संलग्न <?php if($total_badi > 1){ echo 'गरेको छौं';} else { echo ' गरेका छु';} ?><!-- गरेको छु / गरेका छौं --> । विपक्षीहरुले गर्नु भएको अन्यायको व्यहोरा देहाय बमोजिम रहेको छः-</div>

        <div style="margin-left:80px; margin-right: 40px;margin-top: 10px"><?php echo $anusuchi_5['details']?></div>

        <div style="margin-left:40px; margin-right: 40px;margin-top: 10px">२) यो नालेस दर्ता गर्न कानुन व्यवसायी राखेको छु/छैन ।</div>

        <div style="margin-left:40px; margin-right: 40px;margin-top: 10px">३) विपक्षीहरु  <?php echo $this->mylibrary->convertedcit(count($badi))?> जनाका लागि प्रति व्यक्ति एकजनाको दरले नालेसको नक्कल प्रति <?php echo $this->mylibrary->convertedcit(count($badi))?> यसैसाथ संलग्न छ ।</div>

        <div style="margin-left:40px; margin-right: 40px;margin-top: 10px">४) <?php if($total_badi > 1){ echo 'हाम्रो';} else { echo ' मेरो';} ?><!--  /  --> दावीको प्रमाण देहाय बमोजिम रहेको छः</div>

        <div style="margin-left:80px; margin-right: 40px;margin-top: 10px"><?php echo $anusuchi_5['proof']?></div>

        <div style="margin-left:40px; margin-right: 40px;margin-top: 10px">५) <?php if($total_badi > 1){ echo 'हाम्रो';} else { echo ' मेरो';} ?> देहाय बमोजिमका साक्षी बुझीपाऊँः-</div>

        <div style="margin-left:40px; margin-right: 40px;margin-top: 10px">
          <?php if(!empty($witness)) : 
           $i=1; foreach ($witness as $key => $w) : ?>
              <div style="margin-left:40px; margin-right: 40px;margin-top:0px"><?php echo $this->mylibrary->convertedcit($i++)?>) नाम थर- <?php echo $w['name']?>, ठेगाना- <?php echo $w['address']?>, उमेर- <?php echo $this->mylibrary->convertedcit($w['age'])?> वर्ष</div>
             <?php endforeach;endif;?>
        </div>

        <div style="margin-left:40px; margin-right: 40px;margin-top: 15px">६) यसमा लेखिएको व्यहोरा ठिक साँचो छ, झुठ्ठा ठहरे कानुन बमोजिम सहुँला बुझाउँला ।</div>

        <div class="signature" style="margin-right:0px;margin-top: 100px;">प्रतिवादीको दस्तखत वा सहिछाप</div>

        <p style="margin-top: 80px;margin-left: 100px;font-size: 14px;">इति सम्वत <?php echo $this->mylibrary->convertedcit($year)?> साल <?php echo getNepaliMonthName($d_month)?> महिना <?php echo $this->mylibrary->convertedcit($d_day)?> गते रोज ६ (वार) शुभम् । </p>

    </div> <!-- end of main content -->
  </body>
</html>

