<style>
  ::-webkit-input-placeholder { /* Edge */
    color: red;
  }
  :-ms-input-placeholder { /* Internet Explorer */
    color: red;
  }
  ::placeholder {
    color: red;
    font-style: italic;
    text-align: center;
  }
</style>
<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp" >
                      <?php echo form_open('BadiAnusuchi/save_anusuchi_10', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                      <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                      <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_10)? $anusuchi_10['id']:''?>">
                      <div class="anusuchi">
                        <div class="text-center">
                          <p>अनुसूची - १०</p>
                          <p style="margin-top:-20px;">(दफा ५३ को उपदफा (५) सँग सम्बन्धित)</p>
                          <p style="margin-top:-20px;"><?php echo SITE_OFFICE?></p>
                          <p style="margin-top:-20px;">न्यायिक समिति समक्ष भएको मिलापत्र</p>
                        </div>
                        <p style="margin-left: 40px; margin-top: 30px;"><?php echo SITE_OFFICE?> न्यायिक समिति समक्ष पेश गरेको मिलापत्रको संयुक्त निवेदन पत्र</p>

                        <div style="margin-left:40px; margin-right: 40px;">
                          <?php if(!empty($badi)) : 
                            foreach($badi as $key => $b) : 
                              $byear = substr($b['b_dob'],0,4);
                              $bcurrent_date = convertDate(date('Y-m-d'));
                              $bcurrent_year = substr($bcurrent_date, 0,4);
                              $bage = $bcurrent_year - $byear;
                              ?>
                              <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
                              <?php echo $this->mylibrary->convertedcit($bage)?> को  <?php echo $b['b_name']?> निवेदक (प्रथम पक्ष)
                            <?php endforeach;endif;?>
                          </div>
                          <div class="text-center"><p>विरुद्ध</p></div>
                          <div style="margin-left:40px; margin-right: 40px;">
                            <?php if(!empty($pratibadi)) : 
                              foreach($pratibadi as $key => $p) : 
                                $pyear = substr($p['p_dob'],0,4);
                                $pcurrent_date = convertDate(date('Y-m-d'));
                                $pcurrent_year = substr($pcurrent_date, 0,4);
                                $page = $pcurrent_year - $pyear;
                              ?>
                              <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
                              <?php echo $this->mylibrary->convertedcit($bage)?> को  <?php echo $b['b_name']?> (दोस्रो पक्ष)
                            <?php endforeach;endif;?>
                          </div>

                        <div class="text-center">
                          <p>मुद्दाको विषयः <?php echo $subject['subject']?> 
                        </div>
                       
                        <p style="margin-left:40px; margin-right: 40px;">
                         हामी निवेदक निम्न लिखित निवेदन गर्दछौः
                          <div style="margin-left: 40px;">
                            <table class="table table-borderless" id="frm_tbl_wit">
                              <tbody>
                              <?php if(!empty($anusuchi_10)) : ?>
                                <?php $decision = explode('<>', $anusuchi_10['details_decision']);
                                if(!empty($decision)) : 
                                  foreach($decision as $key => $des) : ?>
                                  <tr class="row_mem">
                                    <td><textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 90%;"  placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा क्रमशः बुँदागत रुपमा खुलाई लेख्ने* " required="true" id="post" value="" ><?php echo $des?></textarea><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td> 
                                  </tr>
                                <?php endforeach;endif;?>
                              <?php else : ?>
                                <tr class="row_mem">
                                  <td><textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 90%;"  placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा क्रमशः बुँदागत रुपमा खुलाई लेख्ने* " required="true" id="post" value="" ></textarea><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td> 
                                </tr>
                              <?php endif;?>
                                <!-- <tr class="row_mem">
                                 <td>1) <textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 90%;"  placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा* " required="true" id="post" value="" ></textarea><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td> 
                                </tr>
                                </tr> -->
                             </tbody>
                            </table>  
                          </div>
                        </p>

                        <p style="margin-left: 350px;">निवेदकहरुको नाम, थर तथा दस्तखत</p>
                        <p style="margin-left: 350px;">
                          <?php if(!empty($badi)) :
                            foreach($badi as $key => $b) : ?> 
                            <p  style="margin-left: 150px;">
                            वादी: <?php echo $b['b_name']?>
                            </p>
                            <p  style="margin-left: 150px; margin-top: -19px;">
                            दस्तखतः
                            </p>
                          <?php endforeach;endif;?>
                        </p>

                        <p style="margin-left: 550px;">
                          <?php if(!empty($pratibadi)) :
                            foreach($pratibadi as $key => $p) : ?> 
                            <p  style="margin-left: 618px; margin-top: -69px;">
                            प्रतिवादी: <?php echo $p['p_name']?>
                            </p>
                            <p  style="margin-left: 618px; margin-top: -19px;">
                            दस्तखतः
                            </p>
                          <?php endforeach;endif;?>
                        </p>

                        <div style="margin-left: 200px;margin-right: 40px;margin-top: 50px">इति सम्वत् <?php echo $this->mylibrary->convertedcit(substr(convertDate(date('Y-m-d')), 0,4));?> साल <?php echo getNepaliMonthName(substr(convertDate(date('Y-m-d')), 5,2))?> महिला <?php echo $this->mylibrary->convertedcit(substr(convertDate(date('Y-m-d')), 8,2));?> गते रोज ...... शुभम् .................।</div>

                        <div class="text-center" style="margin-top: 60px;">
                            <hr>
                            <?php if(empty($anusuchi_10)) { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                            <?php } else { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                              <a href ="<?php echo base_url()?>BadiAnusuchi/printAnusuchi_10/<?php echo $darta_detail['darta_no']?>" class="btn btn-secondary" target ="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
                            <?php } ?>
                          <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-top: -18px;"><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
                        </div>

                      </div> <!-- endof anusuchi -->
                       <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){

    $('.btnaddNewField').click(function(e) {
      var MaxInputs       = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length+1;
          <?php if(empty($anusuchi_10)) : ?>
          var new_row =  '<tr class="row_mem">'+
                            '<td>'+trOneNew+') <textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 90%;"  placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा क्रमशः बुँदागत रुपमा खुलाई लेख्ने* " required="true" id="post" value="" ></textarea><button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>'+
                            '<tr>';
            <?php else : ?>
              var new_row = '<tr class="row_mem">'+
                            '<td><input type="text" name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 90%; " required="true" id="post" value="" ><button type="button" style="border: none;background: none" class="remove-row"><i class="fa fa-times" style="color:red;"></i></button></td>'+
                            '<tr>';
            <?php endif;?>
          $("#frm_tbl_wit").append(new_row);
    });

    $("body").on("click",".remove-row", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

  });

</script>