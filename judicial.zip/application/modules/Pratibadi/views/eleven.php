<style>
  ::-webkit-input-placeholder { /* Edge */
    color: red;
  }
  :-ms-input-placeholder { /* Internet Explorer */
    color: red;
  }
  ::placeholder {
    color: red;
    font-style: italic;
    text-align: center;
  }
</style>
<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp" >
                      <?php echo form_open('BadiAnusuchi/save_anusuchi_11', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                      <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                      <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_11)? $anusuchi_11['id']:''?>">

                      <div class="anusuchi">
                        <div class="text-center">
                          <p>अनुसूची-११</p>
                          <p style="margin-top:-20px;">(दफा ६० को उपदफा (३)सँग सम्बन्धित)</p>
                          <p style="margin-top:-20px;">मेलमिलापकर्तामा सूचीकृत हुने निवेदन <?php echo SITE_OFFICE?></p>
                          <p style="margin-top:-20px;">न्यायिक समिति</p>
                          <p style="margin-top:-20px;"><?php echo SITE_OFFICE?> समक्ष पेश गरेको निवेदन</p>
                        </div>

                        <div class="text-center" style="margin-top: 100px">
                          <p>मुद्दाको विषयः <?php echo $subject['subject']?> 
                        </div>
                       
                        <p style="margin-left:40px; margin-right: 40px;">
                         प्रस्तुत विषयमा तपसिलमा उल्लेखित कागजातहरुको प्रतिलिपी साथै राखी गजुरी गाउँपालिकाको न्यायिक समिति अन्तर्गतका <input type="text" name="decision" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;"  placeholder="*" required="true" id="post" value="" > मेलमिलाप केन्द्रमा सूचीकृत भई मेलमिलाप गराउन अनुमती पाउँ भनी निवेदन गर्दछु ।
                          
                        </p>

                        <p style="margin-left: 40px;">तपसिल</p>
                        <p style="margin-left: 40px;">१) नागरिकता प्रमाण पत्रको छाँयाकपी,</p>
                        <p style="margin-left: 40px;">२) स्नातक तहसम्म उतिर्ण गरेको शैक्षिक प्रमाण पत्रको छाँयाकपी,</p>
                        <p style="margin-left: 40px;">३) मेलमिलापकर्ताको तालिम प्राप्त गरेको प्रमाण पत्रको छायाँकपी,</p>
                        <p style="margin-left: 40px;">४) मेलमिलाप सम्बन्धी अनुभव र</p>
                        <p style="margin-left: 40px;">५) व्यक्तिगत विवरण (Bio- data)</p>

                        <p style="margin-left: 40px; margin-top: 20px;">निवेदक</p>

                        <p style="margin-left: 40px;margin-top: -5px;">नाम थरः <input type="text" name="name" id="" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_11)?$anusuchi_11['name']:$badi[0]['b_name']?>" ></p>

                        <p style="margin-left: 40px;margin-top: -5px;">दस्तखतः .................................................</p>

                         <p style="margin-left:40px;margin-top: -5px;">मितिः<span style="color:red">*</span> <input type="text" name="date" id="mdate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" readonly value="<?php echo !empty($anusuchi_11)?$anusuchi_11['name']:convertDate(date('Y-m-d'))?>"></p>
                        <div class="text-center" style="margin-top: 60px;">
                          <hr>
                          <?php if(empty($anusuchi_11)) { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                            <?php } else { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                              <a href ="<?php echo base_url()?>BadiAnusuchi/printAnusuchi_11/<?php echo $darta_detail['darta_no']?>" class="btn btn-secondary" target ="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
                            <?php } ?>
                          <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-top: -18px;"><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
                        </div>

                      </div> <!-- endof anusuchi -->
                       <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    $('.dd_select').select2();
    var mainInput = $("#mdate");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

  });

</script>