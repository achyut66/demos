<style>
  ::-webkit-input-placeholder {
    /* Edge */
    color: red;
  }

  :-ms-input-placeholder {
    /* Internet Explorer */
    color: red;
  }

  ::placeholder {
    color: red;
    font-style: italic;
    text-align: center;
  }
</style>
<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('BadiAnusuchi/save_anusuchi_15', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_15) ? $anusuchi_15['id'] : '' ?>">

            <div class="anusuchi">
              <a href="<?php echo base_url() ?>BadiAnusuchi/printAnusuchi_15/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची - <?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
                <p style="margin-top: 20px;">न्यायिक समिति</p>
                <p style="margin-top:-20px;"><?php echo SITE_OFFICE ?> गाउँपालि कामा पेश गरेको</p>
                <p style="margin-top:-20px;">निवेदन पत्र</p>
              </div>

              <div class="text-center" style="margin-top: 50px">
                <h4>विषयः नक्कल उपलब्ध गराई पाऊँ ।</h4>
              </div>


              <p style="margin-left:40px; margin-right: 40px;margin-top: 30px;">
                <?php if (!empty($badi)) : $i = 1;
                  foreach ($badi as $key => $b) :

                ?>
                    <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?><br> वादी
                <?php endforeach;
                endif; ?>
              </p>
              <p style="margin-left:40px;"> विरुद्ध </p>
              <p style="margin-left:40px; margin-right: 40px;">
                <?php if (!empty($pratibadi)) : $i = 1;
                  foreach ($pratibadi as $key => $p) :

                ?>
                    <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?>
                <?php endforeach;
                endif; ?> प्रतिवादी
              </p>



              <h5 style="margin-left: 40px;">मुद्दा: <?php echo $darta_detail['case_title'] ?></h5>
              <p style="margin-left: 40px; margin-top:30px;">म निवेदक निवेदन वापत रु <input type="text" name="dastur" id="" style="outline: 0;border-width: 0 0 1px; border-color:#000;background: none;" placeholder="दस्तुर *" required="true" value="<?php echo !empty($anusuchi_15) ? $anusuchi_15['dastur'] : ''; ?>"> दस्तुर साथै राखी निम्न व्यहोरा निवेदन गर्दछु ।</p>

              <p style="margin-left: 40px;margin-right: 40px; margin-top: 30px;">१) उपरोक्त विपक्षीसँगको उल्लेखित मुद्दामा अध्ययनको लागि देहायका कागजातहरु आवश्यक परेको हुँदा प्रमाणित प्रतिलिपी पाउँ भनी यो निवेदन साथ उपस्थित भएको छु । अतः नक्कलको प्रमाणित प्रतिलिपी पाउँ । </p>


              <p style="margin-left: 40px; margin-top: 20px;">देहाय</p>

              <div style="margin-left: 40px; margin-top: 20px;">
                <table class="table table-borderless" id="frm_tbl_wit">
                  <tbody>
                    <?php if (empty($anusuchi_15)) : ?>
                      <tr class="row_mem">
                        <td>1. <span style="color:red">*</span> <input type="text" name="decision[]" style="outline: 0;border-width: 0 0 1px; border-color:#000;background: none;    width: 50%; " required="true" id="post" value=""><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title=" थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td>
                      </tr>
                      <?php else :
                      if (!empty($anusuchi_15['details_decision'])) :
                        $mem = explode('<>', $anusuchi_15['details_decision']);
                        foreach ($mem as  $mem) : ?>
                          <tr>
                            <td>सदस्य श्री <span style="color:red">*</span> <input type="text" name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="<?php echo $mem ?>">
                              <button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title="" data-original-title=" हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button>
                            </td>
                          </tr>
                      <?php endforeach;
                      endif;
                      ?>

                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
              <p style="margin-left: 40px;"> २) लेखिएको व्यहोरा ठिक साँचो छ, झुट्टा ठहरे कानून बमोजिम सहुँला बुझाउँला । </p>


              <p style="margin-left: 40px; margin-top: 100px;"> निवेदक </p>
              <p style="margin-left: 40px;margin-top: -5px;">निज <input type="text" name="name" id="" style="outline: 0;border-width: 0 0 1px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_15) ? $anusuchi_15['name'] : $badi[0]['b_name']; ?>"></p>

              <div style="margin-left: 200px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>

              <div class="text-center" style="margin-top: 60px;">
                <hr>
                <?php if (empty($anusuchi_15)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

                <?php } ?>
                <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-top: -18px;"><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
              </div>

            </div> <!-- endof anusuchi -->
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js">
  </script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
      $('.dd_select').select2();
      // var mainInput = $("#mdate");
      // mainInput.nepaliDatePicker({
      //     ndpYear: true,
      //     ndpMonth: true,
      //     ndpYearCount: 100,
      //     disableAfter: GetCurrentBsDate
      // });


      $('.btnaddNewField').click(function(e) {
        var MaxInputs = 2;
        e.preventDefault();
        var trOneNew = $('.row_mem').length + 1;
        <?php if (empty($anusuchi_15)) : ?>
          var new_row = '<tr class="row_mem">' +
            '<td>' + trOneNew + '. <span style="color:red">*</span><input type="text" name="decision[]" style="outline: 0;border-width: 0 0 1px; border-color:#000;background: none;    width: 50%; " required="true" id="post" value="" ><button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>' +
            '<tr>';
        <?php else : ?>
          var new_row = '<tr class="row_mem">' +
            '<td><input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 1px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="" ><button type="button" style="border: none;background: none"><i class="fa fa-times" style="color:red;"></i></button></td>' +
            '<tr>';
        <?php endif; ?>
        $("#frm_tbl_wit").append(new_row);
      });

      $("body").on("click", ".remove-row", function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
          $(this).parent().parent().remove();
        }
      });

    });
  </script>