<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <?php echo form_open('BadiAnusuchi/save_parcha', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
          <div class="element-box-tp">
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_4_id" value="<?php echo !empty($anusuchi_4) ? $anusuchi_4['id'] : '' ?>">

            <div class="anusuchi" style="height: 750px">

              <!-- <a href="<?php //echo base_url() ?>BadiAnusuchi/printAnusuchi_4/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a> -->

              <div class="text-center">
                <p>अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
                <p style="margin-top:-20px;">न्यायिक समिति</p>
                <p style="margin-top:-20px;"><?php echo SITE_OFFICE ?></span> <?php echo SITE_OFFICE_TYPE ?>बाट जारी भएको तारेखको पर्चा</p>
              </div>
              <div class="text-left" style="margin-top:70px;">
                <p style="margin-left: 40px;margin-top: -20px;"><?php echo $badi[0]['b_name'] ?> (वादी</p>
                <p style="float:right; margin-right: 100px;margin-top: -20px;"><?php echo !empty($pratibadi[0]['p_name']) ? $pratibadi[0]['p_name'] . ' (प्रतिवादी)' : 'प्रतिवादीको विवरण दाखिला गरिएको छैन' ?></p>
              </div>
              <div class="text-center" style="margin-top:80px;">
                <p>विषय: <?php echo $darta_detail['case_title'] ?></p>
              </div>
              <div class="form-border">
                प्रारम्भिक इस्लास/पेशी पछी समाधान हुन नसकी वादी तथा प्रतिवादीलाई तपशिल आनुसारको समयमा हाजिर हुन आउनुहोला
              </div>

              <div style="margin-top:40px;">
                <p>वादी: <?php echo $badi[0]['b_name'] ?></p>
                <p>तारिक मिति: <?php echo $this->mylibrary->convertedcit($badi_bharpai['date']) ?></p>
                <p>काम: <?php echo $badi_bharpai['work'] ?></p>
              </div>

              <div style="margin-top: -119px; margin-left: 351px;">
                <p>प्रतिवादी: <?php echo $pratibadi[0]['p_name'] ?></p>
                <p>तारिक मिति: <?php echo $this->mylibrary->convertedcit($pratibadi_bharpai['date']) ?></p>
                <p>काम: <?php echo $pratibadi_bharpai['work'] ?></p>
              </div>

              <div style="margin-top: -160px; margin-left: 651px;">
                <p style="margin-left:40px; margin-top: 60px;">फाँटवालाको दस्तखत</p>
                <p style="margin-left:40px;">मितिः</p>
              </div>
              <div class="text-center" style="margin-top: 60px;">
                <hr>
                <?php if (empty($anusuchi_4)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

                <?php } ?>
              </div>
            </div>
          </div>
          <?php echo form_close() ?>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
    var mainInput = $("#mdate");
    //var smainInput = $("#sdate");
    mainInput.nepaliDatePicker({
      ndpYear: true,
      ndpMonth: true,
      ndpYearCount: 100,
      disableAfter: GetCurrentBsDate
    });

    // smainInput.nepaliDatePicker({
    //     ndpYear: true,
    //     ndpMonth: true,
    //     ndpYearCount: 100,
    //     disableAfter: GetCurrentBsDate
    // });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url: base_url + 'Anusuchi/getWorkers',
        method: "POST",
        data: {
          workers_id: workers_id
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });
  });
</script>