dd

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title><?php echo SITE_OFFICE ?></title>

    <style type="text/css">
        /*table, th, td {

			border: 1px solid black;

		}*/



        /* Center tables for demo */

        table {

            margin: 0 auto;

        }



        /* Default Table Style */

        table {

            color: #333;

            background: white;

            border: 0;

            font-size: 12pt;

            border-collapse: collapse;

        }

        table thead th,

        table tfoot th {

            color: #000;

            background: rgba(0, 0, 0, .1);

        }

        table caption {

            padding: .5em;

        }

        table th,

        table td {

            padding: .5em;

            border: 0;

        }

        .signature {
            float: right;
            border-top: dotted 1px #000;
            width: 180px;
        }

        .stamp {
            float: right;
            margin-top: auto;
            border: 1px solid #555;
            margin-left: 427px;
            height: 140px;
            margin-top: -102px;
            width: 145px;
            margin-right: 40px;
        }
    </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
    <div style="background-color: #fff;">
        <!-- main content -->
        <div style="margin-left: 325px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></div>
        <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
        <div style="margin-left: 295px;top:-30px;"> <?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>
        <div style="margin-left: 260px;top:-30px;"><?php echo SITE_OFFICE ?> न्यायिक समिति</div>

        <div style=" margin-top: 50px;margin-left:40px; margin-right: 40px; text-align:justify">संयोजक श्री: <?php echo $anusuchi_8['cooridinator'] ?></div>
        <?php if (!empty($anusuchi_8)) :
            $decision = explode('<>', $anusuchi_8['member']);
            if (!empty($decision)) :
                $i = 1;
                foreach ($decision as $des) : ?>
                    <div style="margin-top:10px; margin-left:40px;">सदस्य श्री: <?php echo $des; ?></div>
            <?php endforeach;
            endif; ?>
        <?php endif; ?>
        <div style="margin-left:320px; margin-right: 40px; text-align:justify">आदेश</div>
        <div style="margin-left:220px; margin-right: 40px; text-align:justify">संवत <?php $year = explode('-', $darta_detail['date']);
                                                                                    echo $this->mylibrary->convertedcit($year[0]) ?> सालको निवेदन नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_id']) ?></div>
        <div style="margin-left:140px; margin-right: 40px; text-align:justify; margin-top: 70px;">विषयः <?php echo $this->mylibrary->convertedcit($darta_detail['case_title']) ?></div>
        <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 70px;">
            <?php if (!empty($badi)) :
                $i = 1;
                foreach ($badi as $key => $b) : ?>
                    <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
            <?php endforeach;
            endif; ?>
        </div>

        <div style="margin-left:40px; margin-right: 80px; text-align: justify; margin-top: 40px;">
            <?php if (!empty($pratibadi)) : $i = 1;
                foreach ($pratibadi as $key => $p) : ?>
                    <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
            <?php endforeach;
            endif; ?>
        </div>
        <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 40px;"><?php echo $anusuchi_8['details'] ?></div>
        <div style="margin-left: 80px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>
</body>

</html>