<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('BadiAnusuchi/save_anusuchi_14', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['id'] : '' ?>">

            <div class="anusuchi" style="height: 990px;">
              <a href="<?php echo base_url() ?>BadiAnusuchi/printAnusuchi_14/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
                <p style="margin-top:-20px;"><?php echo SITE_OFFICE ?> न्यायिक समिति</p>
              </div>

              <p style="margin-left: 40px;">
                संयोजक श्री <span style="color:red">*</span> <input type="text" name="samyojak" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" id="post" value="<?php echo $anusuchi_14['samyojak'] ?>">
              </p>
              <div style="margin-left: 30px;">
                <table class="table table-borderless" id="frm_tbl_wit">
                  <tbody>
                    <?php if (empty($anusuchi_14)) : ?>
                      <tr>
                        <td>सदस्य श्री <span style="color:red">*</span> <input type="text" name="member[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value=""><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td>
                      </tr>
                      <?php else :
                      if (!empty($anusuchi_14['members'])) :
                        $mem = explode('+', $anusuchi_14['members']);
                        foreach ($mem as  $mem) : ?>
                          <tr>
                            <td>सदस्य श्री <span style="color:red">*</span> <input type="text" name="member[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="<?php echo $mem ?>">
                              <button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title="" data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button>
                            </td>
                          </tr>
                      <?php endforeach;
                      endif;
                      ?>

                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
              <div class="text-center">
                <h6>आदेश</h6>
                <h6 style="margin-left: 40px;">संवत <?php echo  $this->mylibrary->convertedcit(substr($darta_detail['date'], 0, 4)) ?> सालको निवेदन नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no']) ?></h6>
              </div>

              <div class="text-center" style="margin-top: 30px">
                <h5>विषयः <?php echo  $this->mylibrary->convertedcit($darta_detail['case_title']) ?> </h5>
              </div>

              <p style="text-align: justify; margin-top: 40px">
                <?php if (!empty($badi)) :
                  $i = 1;
                  foreach ($badi as $key => $b) : ?>
                    <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
                <?php endforeach;
                endif; ?>
              </p>
              <p style="margin-left:291px; margin-right: 40px; text-align: justify; margin-top: 25px;"><b>विरुद्</b></p>
              <p style=" text-align: justify; margin-top: 25px">
                <?php if (!empty($pratibadi)) : $i = 1;
                  foreach ($pratibadi as $key => $p) : ?>
                    <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
                <?php endforeach;
                endif; ?>
              </p>

              <p style="margin-top:70px;">
                यसमा निवेदकको माग बमोजिम <?php echo SITE_DISTRICT ?> जिल्ला <?php echo SITE_OFFICE ?>, वडा नं.
                <input type="text" name="ward_no" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 105px; " required="true" id="post" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['ward_no'] : '' ?>">

                क्षे.फ. <input type="text" name="area" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 105px; " required="true" id="post" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['area'] : '' ?>">

                कि.नं. <input type="text" name="kitta_no" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 105px; " required="true" id="post" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['kitta_no'] : '' ?>">
                जग्गामा बनेको
                <input type="text" name="type" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 105px; " required="true" id="post" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['type'] : '' ?>">

                को नाममा रहेको अवण्डाको
                <input type="text" name="sqm" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 105px; " required="true" id="post" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['sqm'] : '' ?>">
                वर्ग फिटको चार तल्ले घर र लिग लगापात समेत विपक्षी

                <input type="text" name="detail" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 105px; " required="true" id="post" value="<?php echo !empty($anusuchi_14) ? $anusuchi_14['detail'] : '' ?>">

                सम्पती निज विपक्षीबाट अन्य अंशियारहरुको मन्जुरी विना हक हस्तान्तरण हुन सक्ने आशंका गरी निवेदकले दिएको निवेदन उपर प्रारम्भिक रुपमा जाँचबुझ गर्दा व्यहोरा मनासिव देखिएको हुँदा हाललाई प्रत्यक्षको नाममा रहेको उल्लिखित घरजग्गाको हक हस्तान्तरण गर्न सिफारिस नदिन वडालाई र अर्को आदेश नभएसम्मका लागि उक्त घरजग्गाको हक हस्तान्तरण नगर्नु÷गर्न नदिनु भनी मालपोत कार्यालयको नाममा समेत स्थानीय सरकार सञ्चालन ऐन २०७४ को दफा ४९ (६) बमोजिम यो रोक्काको आदेश जारी गरिदिएका छौं । यो आदेश मिसिल सामेल राखी सम्बन्धित कार्यालयहरुमा पठाईदिनु । यो आदेश अनुसार रोक्का भएको जानकारी प्राप्त गरी मिसिल सामेल राख्नु र नियमानुसार पेश गर्नु ।

              </p>
              <div class="text-center" style="margin-top: 60px;">
                <hr>
                <?php if (empty($anusuchi_14)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

                <?php } ?>
                <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
              </div>
            </div>
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
    $('.dd_select').select2();
    // var mainInput = $("#mdate");
    // mainInput.nepaliDatePicker({
    //     ndpYear: true,
    //     ndpMonth: true,
    //     ndpYearCount: 100,
    //     disableAfter: GetCurrentBsDate
    // });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url: base_url + 'Anusuchi/getWorkers',
        method: "POST",
        data: {
          workers_id: workers_id
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });

    $('.btnaddNewField').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      <?php if (empty($anusuchi_14)) : ?>
        var new_row = '<tr class="row_mem">' +
          '<td>सदस्य श्री <span style="color:red">*</span><input type="text" name="member[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="" ><button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>' +
          '<tr>';
      <?php else : ?>
        var new_row = '<tr class="row_mem">' +
          '<td><input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 205px; " required="true" id="post" value="" ><button type="button" style="border: none;background: none"><i class="fa fa-times" style="color:red;"></i></button></td>' +
          '<tr>';
      <?php endif; ?>
      $("#frm_tbl_wit").append(new_row);
    });

    $("body").on("click", ".remove-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

  });
</script>