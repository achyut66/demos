<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('BadiAnusuchi/save_anusuchi_2', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal', 'target' => '_blank')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_2_id" value="<?php echo !empty($anusuchi_2) ? $anusuchi_2['id'] : '' ?>">
            <input type="hidden" name="badi_pratibadi" value="<?php echo $badi_pratibadi ?>">
            <div class="anusuchi" style="height: 670px;">
              <a href="<?php echo base_url() ?>BadiAnusuchi/printAnusuchi_2/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
              </div>

              <div>
                श्री <span style="border-bottom:2px dotted"><?php echo $badi[0]['b_name'] ?></span>
              </div>

              <div class="text-center" style="margin-top: 65px;font-weight: bold;margin-left:151.18px;margin-right:40px;">
                <p style="font-weight: bold;">विषय : उजुरी दर्ताको निस्सापत्र सम्बन्धमा ।</p>
              </div>
              <div style="height:50px"></div>

              <div class="form-border">
                  <?php if(!empty($badi)) : foreach($badi as $badi) :?>
                <b> <?php echo $badi['b_gapa'] ?> <?php echo $this->mylibrary->convertedcit($badi['b_ward']) ?> बस्ने तपाई,
                <?php endforeach;endif;?>
                  ले <?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_ward']) ?> बस्ने
                  <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_name']) ?>
                  विरुद्ध
                  <?php echo $darta_detail['case_title'] ?>
                  भनि उजुरी दर्ता गर्न ल्याएकोमा आजको मितिमा दर्ता गरि दर्ता नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no']) ?> कायम भएकोले यो निस्सा जारी गरिदिएको छ । </b>
              </div>

              <div style="margin-left:790px;margin-top:40px;">
                <p>अधिकृत कर्मचारी:
                  <select class="borderless" id="workers" name="staff_id" required>
                    <option value="">--छान्नुहोस्--</option>
                    <?php if (!empty($workers)) :
                      foreach ($workers as $staff) : ?>
                        <option value="<?php echo $staff['id'] ?>" <?php if (!empty($anusuchi_2)) : ?> <?php if ($staff['id'] == $anusuchi_2['staff_id']) {
                                                                                                          echo 'selected';
                                                                                                        } ?> <?php endif; ?>><?php echo $staff['name'] ?></option>
                    <?php endforeach;
                    endif; ?>
                  </select>
                </p>
                <p>दस्तखत:</p>
                <p>मिति: <input type="text" name="date" id="mdate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_2) ? $anusuchi_2['date'] : convertDate(date('Y-m-d')) ?>" name="date"></p>
              </div>

              <div class="text-center" style="margin-top: 60px;">
                <hr>
                <?php if (empty($anusuchi_2)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                <?php } ?>
              </div>

              <?php echo form_close() ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
      $('.dd_select').select2();
      var mainInput = $("#mdate");
      mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
      });

      $('#workers').change(function() {
        var workers_id = $(this).val();
        $.ajax({
          url: base_url + 'BadiAnusuchi/getWorkers',
          method: "POST",
          data: {
            workers_id: workers_id
          },
          success: function(resp) {
            if (resp.status == 'success') {
              $('#post').val(resp.deg);
              $('#worker_name').val(resp.name);
            }
          }
        });
      });
    });
  </script>