dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->
    <div style="margin-left: 320px;">अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 295px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>

    <?php if (!empty($badi)) :
      foreach ($badi as $key => $b) : ?>
        <div style="margin-left: 40px; margin-top: 30px;"> <?php echo $b['b_name'] ?>, <?php echo SITE_DISTRICT ?> जिल्ला <?php echo SITE_OFFICE ?> <?Php echo $b['b_address'] ?></div>
    <?php endforeach;
    endif; ?>
    <?php if (!empty($pratibadi)) :
      foreach ($pratibadi as $key => $p) : ?>
        <div style="margin-left: 40px;"> <?php echo $p['p_name'] ?> <?Php echo $p['p_address'] ?>, <?php echo SITE_DISTRICT ?> <?php echo SITE_OFFICE ?> </div>
    <?php endforeach;
    endif; ?>

    <div style="margin-left: 40px; margin-top: 30px;">विवादको विषयः <?php echo  $this->mylibrary->convertedcit($darta_detail['case_title']) ?></div>
    <div style="margin-left: 40px;">नालेस दर्ता नम्बरः <?php echo  $this->mylibrary->convertedcit($darta_detail['darta_id']) ?></div>
    <div style="margin-left: 40px;margin-right: 40px; margin-top: 30px;">
      स्थानीय सरकार संचालन ऐन २०७४ को दफा ४७ (१) ञ वमोजिम निवेदन दर्ता भई सोही ऐनको दफा ४६ वमोजिम गठन भएको न्यायिक समिति समक्ष प्रस्तुत हुन आएको मुद्दाको संक्षिप्त तथ्य र निर्णय यस प्रकार छः
    </div>
    <?php if (!empty($anusuchi_7)) :
      $decision = explode('<>', $anusuchi_7['details_decision']);
      if (!empty($decision)) :
        $i = 1;
        foreach ($decision as $des) : ?>
          <div style="margin-left: 60px;margin-top:10px;"><?php echo $this->mylibrary->convertedcit($i++) ?>. <?php echo $des; ?></div>
      <?php endforeach;
      endif; ?>
    <?php endif; ?>
  </div> <!-- end of main content -->
  <div style="margin-left: 40px;margin-right: 40px; margin-top: 30px;">समितिको निर्णयः</div>
  <div style="margin-left: 60px;margin-right: 40px;"><?php echo $anusuchi_7['samiti_decision'] ?></div>

  <div style="margin-left: 40px;margin-right: 40px; margin-top: 30px;">तपसिल</div>
  <div style="margin-left: 80px;margin-right: 40px;">१. सरोकारवालाले नक्कल माग गर्न आएमा नियमानुसार दस्तुर लिई नक्कल दिनु ।</div>
  <div style="margin-left: 80px;margin-right: 40px;">२. यस न्यायिक समितिको निर्णयमा चित्त नबुझे ३५ दिनभित्र .<?php echo SITE_OFFICE ?> जिल्ला अदालतमा पुनरावेदन गर्न जानु भनि प्रत्यर्थीलाई सुनाईदिनु ।</div>
  <div style="margin-left: 80px;margin-right: 40px;">३. म्याद भित्र पुनरावेदन नपरेमा कानून वमोजिम निर्णय कार्यान्वयन गर्नु र गराउनु । </div>
  <div style="margin-left: 80px;margin-right: 40px;margin-top: 150px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>
</body>

</html>