dd

<!DOCTYPE html>

<html>

<head>

	<meta charset="UTF-8">

	<title><?php echo SITE_OFFICE?></title>

	<style type="text/css">

		/*table, th, td {

			border: 1px solid black;

		}*/



		/* Center tables for demo */

		table {

			margin: 0 auto;

		}



		/* Default Table Style */

		table {

			color: #333;

			background: white;

			border: 0;

			font-size: 12pt;

			border-collapse: collapse;

		}

		table thead th,

		table tfoot th {

			color: #000;

			background: rgba(0,0,0,.1);

		}

		table caption {

			padding:.5em;

		}

		table th,

		table td {

			padding: .5em;

			border: 0;

		}
    .signature{
    float: right;
    border-top: dotted 1px #000;
    width:180px;
}
.stamp{
    float: right; 
    margin-top:auto;
    border: 1px solid #555; 
    margin-left: 427px; 
    height: 140px; 
    margin-top:-102px; 
    width: 145px;
    margin-right: 40px;
}

	</style>

</head>
  <body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
    <div style="background-color: #fff;"> <!-- main content -->
      <div style="margin-left: 320px;">अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name'])?></div>
      <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa'])?></div>
      <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type'])?></div>
      <div style="margin-left: 320px;">न्यायिक समिति</div>
      <div style="margin-left: 225px;"><?php echo SITE_OFFICE?> समक्ष पेश गरेको निवेदन</div>

      <div style="margin-left: 220px; margin-top: 40px;">
        विषयः <?php echo $darta_detail['case_title']?>
      </div>

      <div style="margin-left:40px; margin-right: 40px;text-align: justify;margin-top:30px;">
        प्रस्तुत विषयमा तपसिलमा उल्लेखित कागजातहरुको प्रतिलिपी साथै राखी गजुरी गाउँपालिकाको न्यायिक समिति अन्तर्गतका <?php echo $anusuchi_11['details_decision']?> मेलमिलाप केन्द्रमा सूचीकृत भई मेलमिलाप गराउन अनुमती पाउँ भनी निवेदन गर्दछु ।
      </div>

      <div style="margin-left: 40px; margin-top: 20px;">तपसिल</div>
      <div style="margin-left: 40px;">१) नागरिकता प्रमाण पत्रको छाँयाकपी,</div>
      <div style="margin-left: 40px;">२) स्नातक तहसम्म उतिर्ण गरेको शैक्षिक प्रमाण पत्रको छाँयाकपी,</div>
      <div style="margin-left: 40px;">३) मेलमिलापकर्ताको तालिम प्राप्त गरेको प्रमाण पत्रको छायाँकपी,</div>
      <div style="margin-left: 40px;">४) मेलमिलाप सम्बन्धी अनुभव र</div>
      <div style="margin-left: 40px;">५) व्यक्तिगत विवरण (Bio- data)</div>
      <div style="margin-left: 60px; margin-top: 40px;">निवेदक</div>

      <div style="margin-left: 40px;">नाम थरः <?php echo !empty($anusuchi_11)?$anusuchi_11['name']:$badi[0]['b_name']?></div>

      <div style="margin-left: 40px;">दस्तखतः </div>

      <div style="margin-left:40px;">मितिः <?php echo !empty($anusuchi_11)?$this->mylibrary->convertedcit($anusuchi_11['date']):convertDate(date('Y-m-d'))?></div>
  </body>
</html>

