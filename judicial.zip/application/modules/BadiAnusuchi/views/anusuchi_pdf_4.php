dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->

    <div style="margin-left: 320px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?> </div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 315px;">न्यायिक समिति</div>
    <?php
    // $year           = substr($badi[0]['b_dob'], 0, 4);
    // $d_year         = substr($darta_detail['date'], 0, 4);
    // $d_month        = substr($darta_detail['date'], 5, 2);
    // $d_day          = substr($darta_detail['date'], 8, 2);
    // $current_date   = convertDate(date('Y-m-d'));
    // $current_year   = substr($current_date, 0, 4);
    // $age            = $current_year - $year;
    // $pyear          = substr($badi[0]['b_dob'], 0, 4);
    // $pcurrent_date  = convertDate(date('Y-m-d'));
    // $pcurrent_year  = substr($pcurrent_date, 0, 4);
    // $page           = $pcurrent_year - $pyear;
    ?>

    <div style="margin-left: 70px;margin-top: 40px;">वादी</div>
    <div style="margin-left: 40px;margin-top: 40px;margin-top: -2px;"><?php echo $badi[0]['b_name'] ?></div>

    <div style="margin-left: 510px; margin-top: -55px;">प्रतिवादी</div>
    <div style="margin-left: 490px; margin-top: 5px;"> <?php echo !empty($pratibadi[0]['p_name']) ? $pratibadi[0]['p_name'] : 'dad' ?></div>

    <div style="margin-left: 80px; margin-top: 70px;">विषय:<?php echo $darta_detail['case_title'] ?></div>
    <div style="margin-left: 40px; margin-top: 70px;">मिति <?php echo $this->mylibrary->convertedcit($anusuchi_4['date']) ?> मा <?php echo $anusuchi_4['work'] ?> काम गर्न <?php echo $this->mylibrary->convertedcit($anusuchi_4['time']) ?> बजे हाजिर हुन आउनुहोला ।</div>

    <div style="margin-left: 40px; margin-top: 50px;text-decoration: underline;"><b></b></div>

    <div style="margin-left: 40px;margin-top: 10px;">फाँटवालाको दस्तखत:</div>
    <div style="margin-left: 40px;margin-top: 10px;">मितिः <?php echo $this->mylibrary->convertedcit($anusuchi_4['date']) ?> </div>

  </div> <!-- end of main content -->
</body>

</html>