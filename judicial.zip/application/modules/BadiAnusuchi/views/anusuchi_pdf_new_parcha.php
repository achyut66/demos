dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->

    <div style="margin-left: 320px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?> </div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 315px;">न्यायिक समिति</div>

    <div style="margin-left: 70px;margin-top: 40px;">वादी</div>
    <div style="margin-left: 40px;margin-top: 40px;margin-top: -2px;"><?php echo $badi[0]['b_name'] ?></div>

    <div style="margin-left: 510px; margin-top: -55px;">प्रतिवादी</div>
    <div style="margin-left: 490px; margin-top: 5px;"> <?php echo !empty($pratibadi[0]['p_name']) ? $pratibadi[0]['p_name'] : 'dad' ?></div>

    <div style="margin-left: 80px; margin-top: 70px;">विषय:<?php echo $darta_detail['case_title'] ?></div>


    <div style="margin-left: 40px; margin-top: 70px;"> प्रारम्भिक इस्लास/पेशी पछी समाधान हुन नसकी वादी तथा प्रतिवादीलाई तपशिल आनुसारको समयमा हाजिर हुन आउनुहोला</div>

    <div style="margin-left: 40px; margin-top: 50px;text-decoration: underline;"><b></b></div>

    <div style="margin-left: 40px; margin-top:40px;">
      <p>वादी: <?php echo $badi[0]['b_name'] ?></p>
      <p>तारिक मिति: <?php echo $this->mylibrary->convertedcit($badi_bharpai['date']) ?></p>
      <p>काम: <?php echo $badi_bharpai['work'] ?></p>
    </div>

    <div style="margin-top: -138px; margin-left: 251px;">
      <p>प्रतिवादी: <?php echo $pratibadi[0]['p_name'] ?></p>
      <p>तारिक मिति: <?php echo $this->mylibrary->convertedcit($pratibadi_bharpai['date']) ?></p>
      <p>काम: <?php echo $pratibadi_bharpai['work'] ?></p>
    </div>

    <div style="margin-top: -185px; margin-left: 451px;">
      <p style="margin-left:40px; margin-top: 60px;">फाँटवालाको दस्तखत</p>
      <p style="margin-left:40px;">मितिः</p>
    </div>

  </div> <!-- end of main content -->
</body>

</html>