<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->
    <div style="margin-left: 320px;">अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 240px;"><?php echo SITE_OFFICE ?> गाउँपालिकामा पेश गरेको</div>
    <div style="margin-left: 320px;"> <?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>

    <div style="margin-left: 220px; margin-top: 80px;">
      विषयः <?php echo $darta_detail['case_title'] ?>
    </div>

    <div style="margin-left:40px; margin-right: 40px;margin-top: 30px;">
      <?php if (!empty($badi)) :
        foreach ($badi as $key => $b) :

      ?>
          <?php echo $b['b_address'] ?> बस्ने वर्ष <?php echo $b['b_name'] ?>
      <?php endforeach;
      endif; ?> वादी
    </div>
    <div style="margin-left:160px;"> विरुद्ध </div>
    <div style="margin-left:40px; margin-right: 40px;">
      <?php if (!empty($pratibadi)) :
        foreach ($pratibadi as $key => $p) :

      ?>
          <?php echo $p['p_address'] ?> बस्ने वर्ष <?php echo $p['p_name'] ?><b>
        <?php endforeach;
      endif; ?> प्रतिवादी
    </div>

    <div style="margin-left: 320px; margin-top: 50px;">मुद्दा</div>

    <div style="margin-left: 40px; margin-top: 30px;">म निवेदक निवेदन वापत रु <?php echo !empty($anusuchi_13) ? $this->mylibrary->convertedcit($anusuchi_13['dastur']) . '/' : '' ?> दस्तुर साथै राखी निम्न व्यहोरा निवेदन गर्दछु ।</div>

    <div style="margin-left: 40px;margin-right: 40px; margin-top: 10px; text-align: justify;">१) उपरोक्त विपक्षीसँगको उल्लेखित मुद्दा यस गाउँपालिकाको न्यायिक समितिबाट मिति निर्णय मिति मा निर्णय भई उक्त घर जग्गा वा <?php echo !empty($anusuchi_13) ? $anusuchi_13['details_decision'] : ''; ?> मेरो हक भोग र स्वामित्वको हुने ठहर भएकोमा श्री <?php echo SITE_DISTRICT ?> जिल्ला अदालतमा विपक्षीले पुनरावलोकन गरेकोमा सम्मानीत अदालतबाट समेत मिति <?php echo !empty($anusuchi_13) ? $this->mylibrary->convertedcit($anusuchi_13['date']) : ''; ?> मा निर्णय हुँदा न्यायिक समितिकै निर्णयलाई सदर गरी मेरै हक भोग कायम गरेको हुँदा सो मेरो हक भोगको कायम भएको सम्पत्ति रहेको हुँदा शिघ्रातिशिघ्र मलाई उक्त सम्पत्ति चलन चलाई पाउन यो निवेदन पेश गरेको छु ।</div>

    <div style="margin-left: 40px;margin-right: 40px;margin-top: 10px; text-align: justify;">२) यसै निवेदन साथ देहायका कागजातहरु संलग्न गरेको छु ।</div>
    <div style="margin-left: 80px;margin-top: 10px; text-align: justify;">क) न्यायिक समितिले मिति <?php echo !empty($anusuchi_13) ? $this->mylibrary->convertedcit($anusuchi_13['ndate']) : ''; ?> मा गरेको निर्णयको छाँयाँकपी ।</div>

    <div style="margin-left: 80px;margin-top: 10px; text-align: justify;">ख) श्री <?php echo SITE_DISTRICT ?> जिल्ला अदालतले गरेको मिति <?php echo !empty($anusuchi_13) ? $this->mylibrary->convertedcit($anusuchi_13['adate']) : ''; ?> को सदर फैसलाको छाँयाँकपी ।</div>

    <div style="margin-left: 80px;margin-top: 10px; text-align: justify;">ग) यस विवाद सम्वद्ध मिसिल यसै कार्यालयमा रहेको छ ।</div>

    <div style="margin-left: 80px;margin-top: 10px; text-align: justify;">घ) लेखिएको व्यहोरा ठिक साँचो छ, झुठा ठहरे कानून बमोजिम सहुँला बुझाउँला ।</div>


    <div style="margin-left: 40px; margin-top: 20px;">निवेदक</div>

    <p style="margin-left: 40px;margin-top: -5px;">निज <?php echo !empty($anusuchi_13) ? $anusuchi_13['name'] : $badi[0]['b_name']; ?></p>

    <div style="margin-left: 140px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>
</body>

</html>