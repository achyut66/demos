<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp">
                      <div class="anusuchi">
                        <?php if($this->session->flashdata('MSG_ERR')) { ?>
                          <div class="alert alert-danger"><?php echo $this->session->flashdata("MSG_ERR")?></div>
                        <?php } ?>
                        <h5 class="form-header"> <?php echo $subject['subject']?></h5>
                        <div class="form-desc">
                          <a href="<?php echo base_url()?>" target="_blank" class="btn btn-sm btn-primary"><i class="fa fa-info-circle"></i> दर्ता नं-<?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?></a>
                          <a href="<?php echo base_url()?>" target="_blank" class="btn btn-sm btn-warning"><i class="fa fa fa-calendar-check-o"></i> मिति-<?php echo $this->mylibrary->convertedcit($darta_detail['date'])?></a>
                        </div>
                        <div class="table-responsive">
                          <table  class="table table-lightborder">
                            <thead>
                              <tr>
                                <th class="text-right">#</th> 
                                <th>अनुसूची </th>
                                <th>दफा</th>
                                <th class="text-center">कार्य</th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php if(!empty($aanusuchi)) :
                              $i = 1;
                              foreach($aanusuchi as $key => $value) : ?>
                                <tr class="gradeX">
                                  <td class="text-right"><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                  <td>अनुसूची-<?php echo $this->mylibrary->convertedcit($value['letter_name'])?></td>
                                  <td><?php echo $this->mylibrary->convertedcit($value['dafa'])?></td>
                                  <td>
                                    <a href="<?php echo base_url()?>Anusuchi/view/<?php echo $darta_detail['darta_no']?>/<?php echo $value['letter_name']?>" target="_blank" class="btn btn-sm btn-outline-success"><i class="fa fa-eye"></i> पत्र हेर्नुहोस</a>
                                    <a href="<?php echo base_url()?>" target="_blank" class="btn btn-sm btn-outline-danger"><i class="fa fa-cloud-download"></i> डाउनलोड गर्नुहोस्</a></td>
                                </tr>
                              <?php endforeach;endif; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>