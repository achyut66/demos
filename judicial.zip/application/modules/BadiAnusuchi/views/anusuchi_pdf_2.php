dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: 70px;
      /* border: 1px solid #555; */
      margin-left: 327px;
      /* height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px; */
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->

    <div style="margin-left: 320px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 290px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>


    <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 40px;">
      श्री <span><?php echo $badi[0]['b_name'] ?></span>
    </div>

    <div class="text-center" style="margin-top: 65px;font-weight: bold;margin-left:220px;margin-right:40px;">
      <p style="font-weight: bold;">विषय : उजुरी दर्ताको निस्सापत्र सम्बन्धमा ।</p>
    </div>
   
    <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 60px;">
 <?php if(!empty($badi)) : foreach($badi as $badi) :?>
      <?php echo $badi['b_gapa'] ?> <?php echo $this->mylibrary->convertedcit($badi['b_ward']) ?> बस्ने तपाई,
      
     <?php endforeach;endif;?>
      ले <?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_ward']) ?> बस्ने
      <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_name']) ?>
      
      विरुद्ध
      <?php echo $darta_detail['case_title'] ?>
      भनि उजुरी दर्ता गर्न ल्याएकोमा आजको मितिमा दर्ता गरि दर्ता नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no']) ?> कायम भएकोले यो निस्सा जारी गरिदिएको छ ।

    </div>

    <div class="stamp">
      <div style="margin-left: 40px; margin-top: 50px;">अधिकृत कर्मचारी: <?php echo $staff['name'] ?></div>
      <div style="margin-left: 40px;margin-top: 5px;">दस्तखतः </div>
      <div style="margin-left: 40px;margin-top: 5px;">मितिः <?php echo $this->mylibrary->convertedcit($anusuchi_2['date']) ?></div>
    </div>


  </div> <!-- end of main content -->
</body>

</html>