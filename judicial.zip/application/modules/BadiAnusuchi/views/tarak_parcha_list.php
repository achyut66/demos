<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <!--------------------
              START - Controls Above Table
              -------------------->
              <div class="controls-above-table">
                <div class="row">
                  <div class="col-sm-6">
                    <a class="btn btn-outline-primary" href="<?php echo base_url() ?>BadiAnusuchi/newTarikParcha/<?php echo $darta_detail['darta_no'] ?>"><i class="os-icon os-icon-ui-22"></i><span>नयाँ थप्नुहोस</span></a>
                  </div>
                  <!--  <hr> -->
                </div>
              </div>
              <!--------------------
               END - Controls Above Table
              -------------------->
              <!--------------------
              START - Table with actions
              ------------------  -->
              <?php if ($this->session->flashdata('MSG_SUCCESS')) { ?>
                <div class="alert alert-success alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_SUCCESS') ?></div>
              <?php } ?>
              <?php if ($this->session->flashdata('MSG_ERR')) { ?>
                <div class="alert alert-danger alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_ERR') ?></div>
              <?php } ?>
              <?php if ($this->session->flashdata('MSG_WARNING')) { ?>
                <div class="alert alert-warning alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_WARNING') ?></div>
              <?php } ?>
              <div class="table-responsive">
                <div class="text-center"><strong>
                    <h2>तारेक पर्चा</h2>
                    <p>मुद्दा दर्ता नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no']) ?> </p>
                    <p>विषय: <?php echo $darta_detail['case_title'] ?></p>
                  </strong></div>
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>मिति</th>
                      <th>के काम गर्ने</th>
                      <th>उपस्थित हुने समय</th>
                      <th>किसिम</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($anusuchi_4)) :
                      $i = 1;
                      foreach ($anusuchi_4 as $key => $value) : ?>
                        <tr>
                          <td style="width:20px;"><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['date']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['work']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['time']) ?> बजे</td>
                          <td>
                            <?php
                            if ($value['type'] == 'badi') {
                              $type = 'वादी';
                            } else if ($value['type'] == 'pratibadi') {
                              $type = 'प्रतिवादी';
                            } else {
                              $type = "पहिलो पेशी पछाडी";
                            }
                            echo $this->mylibrary->convertedcit($type);
                            ?>
                          </td>
                        </tr>
                    <?php endforeach;
                    endif; ?>
                  </tbody>
                </table>
              </div>
              <!--------------------
                          END - Table with actions
                          -------------------->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>