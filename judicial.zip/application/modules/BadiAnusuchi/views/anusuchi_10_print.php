<html>
<title><?php echo !empty($title) ? $title : SITE_OFFICE ?></title>
<meta charset="utf-8">
<meta content="ie=edge" http-equiv="x-ua-compatible">
<meta content="template language" name="keywords">
<meta content="Tamerlan Soziev" name="author">
<meta content="Admin dashboard html template" name="description">
<meta content="width=device-width, initial-scale=1" name="viewport">
<link href="<?php echo base_url() ?>assets/img/nyaik_samiti.png" rel="shortcut icon">
<link href="apple-touch-icon.png" rel="apple-touch-icon">
<link href="<?php echo base_url() ?>assets/css/main.css?version=4.4.0" rel="stylesheet">
<style>
  body {
    font-size: 24px;
    margin: 0px;
    color: black;

  }

  @page {
    size: auto;
    /* margin: 25mm 25mm 25mm 25mm; */
  }

  .csstransforms {
    position: absolute;
    top: 390px;
    text-align: justify;
    transform-origin: 0 0;
    transform: rotate(-90deg);
    padding: 10px;
    /* margin-top: 350px; */
    width: 500px;
    margin-left: 150px;
  }

  .csstransforms-hakim {
    transform: rotate(-90deg);
  }

  .heading {
    margin-top: 520px;
  }
</style>

<body style="--bleeding: 0.5cm;--margin: 1cm;">
  <div class="row">
    <div class="col-md-12" style="margin-top: 10px;">
      <div class="csstransforms" style="margin-top: 102px;">
        <p style="text-align:center">श्री <?php echo SITE_OFFICE ?></p>
        <p><?php echo $tokaadesh['tok_aadesh'] ?></p>
        <p style="margin-left:205px; margin-top:270px;"><?php echo $staff['name'] ?></p>
        <p style="margin-left:155px;"><?php echo $staff['designation'] ?></p>
      </div>
    </div>

    <div class="col-md-12" style="height:auto;">
      <div class=" heading">
        <p class="text-center" style="">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
        <p class="text-center" style="margin-top:-10px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
        <p class="text-center">श्री <?php echo SITE_OFFICE ?></p>
        <p class="text-center"><?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
      </div>

      <div class="badi">
        <p style="margin-left:151.18px;text-align: justify; margin-top: 20px; margin-right:40px">
          <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div class="text-center" style="margin-top:20px;">
        <p style="font-weight: bold;">विरुद्</p>
      </div>
      <div class="pratibadi">
        <p style="margin-left:151.18px; text-align: justify; margin-top: 25px;margin-right:40px">
          <?php if (!empty($pratibadi)) : $i = 1;
            foreach ($pratibadi as $key => $p) : ?>
              <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div class="text-center" style="margin-left:151.18px;margin-top: 20px;margin-right:40px;font-weight: bold;">
        <p style="margin-top: 60px;font-weight: bold;">विषय : <?php echo $darta_detail['case_title'] ?></p>
      </div>

      <div style="margin-left:151.18px; margin-top: 120px;margin-right:20px;">
        हामी निवेदक निम्न लिखित निवेदन गर्दछौः
        <?php if (!empty($anusuchi_10)) :
          $decision = explode('<>', $anusuchi_10['details_decision']);
          if (!empty($decision)) :
            $i = 1;
            foreach ($decision as $des) : ?>
              <div style="margin-top:10px; text-align:justify"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $des; ?></div>
          <?php endforeach;
          endif; ?>
        <?php endif; ?>
      </div>
      <div style="margin-left:350px;margin-top:100px;">
        <?php if (!empty($pratibadi)) :
          foreach ($pratibadi as $key => $p) : ?>
            <div style="margin-left:218px; margin-top: -39px;">
              प्रतिवादी: <?php echo $p['p_name'] ?>
            </div>
            <div style="margin-left: 218px;">
              दस्तखतः
            </div>
        <?php endforeach;
        endif; ?>
      </div>

      <div style="text-align:center; margin-top: 185px;font-size:18px;">इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ............................... ।</div>
    </div>
  </div>
</body>
<script type="text/javascript">
  window.print();
</script>

</html>