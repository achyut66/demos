dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    table {
      margin: 0 auto;
    }

    table {
      color: #333;
      background: white;
      border: 0;
      font-size: 12pt;
      border-collapse: collapse;
    }

    table thead th,
    table tfoot th {
      color: #000;
      background: rgba(0, 0, 0, .1);
    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->
    <div style="margin-left: 320px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?> </div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 315px;">न्यायिक समिति</div>
    <div style="margin-left: 320px"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>
    <div style="margin-left: 40px;margin-top: 40px;"><?php echo $badi[0]['b_name'] ?> (वादी)</div>

    <div style="margin-left: 280px; margin-top:-25px;">मुद्दा नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no']) ?></div>
    <div style="margin-left: 490px; margin-top: -25px;"> <?php echo !empty($pratibadi[0]['p_name']) ? $pratibadi[0]['p_name'] . ' (प्रतिवादी)' : 'n/a' ?></div>

    <div class="text-center" style="margin-left: 40px;margin-top:80px;">
      <p>मुद्दा: <?php echo $darta_detail['case_title'] ?></p>
    </div>

    <div style="margin-left: 40px;margin-top:30px; margin-right:40px;">
      प्रारम्भिक छलफल पछी समाधान हुन नसकी वादी तथा प्रतिवादी लाई तपशिल आनुसार मितिमा <?php echo !empty($anusuchi_3) ? $this->mylibrary->convertedcit($anusuchi_3['date_1']) : '' ?>उपस्थित हुनेछु
    </div><br>
    <div style="margin-left:40px; margin-top:40px;">
      <p>वादी: <?php echo $badi[0]['b_name'] ?></p>
      <p style="margin-top:-40px;">तारिक मिति: <?php echo $badi_bharpai['date_1'] ?></p>
      <p>काम: <?php echo $badi_bharpai['details'] ?></p>
    </div>

    <div style="margin-left:400px;margin-top: -139px; ">
      <p>प्रतिवादी: <?php echo $pratibadi[0]['p_name'] ?></p>
      <p>तारिक मिति: <?php echo $pratibadi_bharpai['date_1'] ?></p>
      <p>काम: <?php echo $pratibadi_bharpai['details'] ?></p>
    </div>
  </div> <!-- end of main content -->
</body>

</html>