dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->
    <div style="margin-left: 320px;">अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></div>
    <!-- <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div> -->
    <div style="margin-left: 240px;"><?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>
    <div style="margin-left: 280px;">भरिभराऊको निवेदा पत्र</div>

    <div style="margin-left: 220px; margin-top: 80px;">
      विषयः <?php echo $darta_detail['case_title'] ?>
    </div>

    <!-- <div style="margin-left:40px; margin-right: 40px;text-align: justify;">
        प्रस्तुत विषयमा तपसिलमा उल्लेखित कागजातहरुको प्रतिलिपी साथै राखी गजुरी गाउँपालिकाको न्यायिक समिति अन्तर्गतका <?php echo $anusuchi_12['dastur'] ?> मेलमिलाप केन्द्रमा सूचीकृत भई मेलमिलाप गराउन अनुमती पाउँ भनी निवेदन गर्दछु ।
      </div> -->

    <div style="margin-left:40px; margin-right: 40px;margin-top: 30px;">
      <?php if (!empty($badi)) :
        foreach ($badi as $key => $b) :

      ?>
          <?php echo $b['b_address'] ?> बस्ने वर्ष <?php echo $b['b_name'] ?>
      <?php endforeach;
      endif; ?> वादी
    </div>
    <div style="margin-left:160px;"> विरुद्ध </div>
    <div style="margin-left:40px; margin-right: 40px;">
      <?php if (!empty($pratibadi)) :
        foreach ($pratibadi as $key => $p) :

      ?>
          <?php echo $p['p_address'] ?> बस्ने वर्ष <?php echo $p['p_name'] ?><b>
        <?php endforeach;
      endif; ?> प्रतिवादी
    </div>
    <div style="margin-left: 320px; margin-top: 50px;">मुद्दा</div>

    <div style="margin-left: 40px; margin-top: 30px;">म निवेदक निवेदन वापत रु <?php echo !empty($anusuchi_12) ? $this->mylibrary->convertedcit($anusuchi_12['dastur']) . '/' : '' ?> दस्तुर साथै राखी निम्न व्यहोरा निवेदन गर्दछु ।</div>

    <div style="margin-left: 40px;margin-right: 40px; margin-top: 10px; text-align: justify;">१) उपरोक्त विपक्षी संगको उल्लेखित मुद्दा यस गाउँपालिको न्यायिक समितिको मिति मुद्दाको निर्यण मिति को निर्णय बमोजिम मैले यस कार्यालयमा राखेको दस्तुर / रकम मिति <?php echo !empty($anusuchi_12) ? $this->mylibrary->convertedcit($anusuchi_12['date']) : convertDate(date('Y-m-d')) ?> को श्री <?php echo SITE_DISTRICT ?> जिल्ला अदालतको फैसला बमोजिम मैले भरी भराई पाउने ठहर भएको हुँदा उक्त रकम भरी भराई पाउन यो निवेदन पेश गरेको छु ।</div>

    <div style="margin-left: 40px;margin-right: 40px;margin-top: 10px; text-align: justify;">२) मैल यसै कार्यालयमा जम्मा गरेको दस्तुर / रकमको भरपाई र रसिदर भौचरको सक्कलै प्रति र सम्मानीत श्री <?php echo SITE_DISTRICT ?> जिल्ला अदालतको अन्तिम फैसलाको छायाँकपी यसै साथ संलग्न छ ।</div>
    <div style="margin-left: 40px;margin-top: 10px; text-align: justify;">३) यसमा लेखिएको व्यहोरा ठिक हो, झुठा ठहरे सहुँला बुझाउला ।</div>


    <div style="margin-left: 40px; margin-top: 20px;">निवेदक</div>

    <p style="margin-left: 40px;margin-top: -5px;">निज <?php echo !empty($anusuchi_12) ? $anusuchi_12['name'] : $badi[0]['b_name']; ?></p>

    <div style="margin-left: 140px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>
</body>

</html>