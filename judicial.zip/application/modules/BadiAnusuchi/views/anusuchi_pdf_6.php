dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>


</head>

<body style="background-color: #fff; padding: 10px; font-family: freeserif; font-size: 14px;">
  <div style="background-color: #fff;">
    <div style="margin-left: 320px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?>
    </div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 235px;">न्यायिक समितिबाट जारी भएको
      <?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>
    <div style="margin-left:40px; margin-right: 20px; margin-top:20px;text-align:justify">
      <p><?php echo SITE_DISTRICT ?>, जिल्ला <?php echo SITE_OFFICE ?> वडा नं.
        <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_ward']) ?>,
        <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_address']) ?> बस्ने बर्ष
        <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_dob']) ?> को <?php echo $pratibadi[0]['p_name'] ?>को
        नाउँमा <?php echo SITE_OFFICE ?>को कार्यालय बाट
        <?php echo !empty($anusuchi_6) ? $anusuchi_6['serial_no'] : '' ?> पटक जारी भएको
        <?php echo !empty($anusuchi_6) ? $this->mylibrary->convertedcit($anusuchi_6['days']) : '' ?> दिने सूचना</p>
    </div>
    <div style="margin-left:40px; margin-right: 20px;text-align:justify;margin-top:20px;">
      <p><?php echo SITE_DISTRICT ?>, जिल्ला <?php echo SITE_OFFICE ?> वडा नं.
        <?php echo $this->mylibrary->convertedcit($badi[0]['b_ward']) ?>,
        <?php echo $this->mylibrary->convertedcit($badi[0]['b_address']) ?> बस्ने <?php echo $badi[0]['b_name'] ?>ले
        तपाई विरुद्ध <?php echo $darta_detail['case_title'] ?> भनि निवेदन दर्ता गरेको हुँदा सो को प्रतिलिपि यसैसाथ
        पठाईएको छ । अत : तपाईले म्याद बुझेको वा रितपुर्वक तामेल भएको मितिले
        <?php echo !empty($anusuchi_6) ? $this->mylibrary->convertedcit($anusuchi_6['days']) : '' ?> दिन भित्रमा आफ्नो
        भनाई सहित आफै वा कानुन बंमोजिम वारेश मार्फत यस कार्यालयमा हाजिर हुन आउनु होला । अन्यथा कानुन बमोजिम हुने व्यहोरा
        जानकारी गराईन्छ ।</p>
    </div>

    <p style="text-align:center;margin-top:0px; text-decoration: underline;">म्याद जारी गर्ने अधिकारीको</p>
    <p style="margin-left: 40px;margin-top: 5px;">नामः <?php echo $anusuchi_6['worker_name'] ?>&nbsp; &nbsp; &nbsp;
      &nbsp;पदः <?php echo $anusuchi_6['designation'] ?>&nbsp; &nbsp; &nbsp; &nbsp;दस्तखतः..................&nbsp;
      &nbsp; मितिः <?php echo $this->mylibrary->convertedcit($anusuchi_6['date']) ?> </p>
    <!-- <div style="margin-left: 445px;margin-top: -285px;">पदः <?php echo $anusuchi_6['designation'] ?></div>
    <div style="margin-left: 445px;margin-top: 5px;">दस्तखतः </div>
    <div style="margin-left: 445px;margin-top: 5px;">मितिः <?php echo $this->mylibrary->convertedcit($anusuchi_6['date']) ?></div> -->

    <div class="text-center">
      <p style="text-decoration: underline; text-align:center">प्रतीवादी ले म्याद बुझी गरिदिने भरपाइ</p>
    </div>

    <div style="margin-left:40px;margin-right: 20px;text-align: justify;">मिति......................................मा
      यस न्यायिक समितिमा............................बस्ने .....................................................उपर
      निवेदन दर्ता गरेकोमा सो विवादमा प्रतिवादी/वारेस..............................................उपस्थित भई सो म्याद र
      सो साथ आवश्यक प्रति, निवेदन र अन्य कागजातका प्रमाणित प्रति बुझिलिएकोले यो भरपाई गरिएको छ ।</div>

    <p style="text-align:center;margin-left:40px; margin-top:20px;text-decoration:underline">न्यायिक समितिबाट म्याद
      बुझ्नेको</p>
    <div style="margin-left:40px;margin-left:100px;">दस्तखतः..................&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;
      &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
      &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; प्रतिवादी/वारेस नाम: <?php echo $pratibadi[0]['p_name'] ?></div>


    <div style="margin-left:40px;margin-right: 20px;margin-top:20px;">
      <p style="text-decoration: underline;text-align:center">गल्छी गाउँपालिका ......... नं. वडा कार्यालय बाट गल्छी
        गाउँपालिका न्यायिक समितिमा पठाईएको म्याद तामेलीको प्रतिवेदन</p>
    </div>
    <div style="margin-left:40px;margin-right: 20px;">
      <p style="text-align: justify;">मिति ............................. मा <?php echo SITE_OFFICE ?> न्यायिक समितिबाट
        ............................................ बस्ने .................................. को
        /छोरा/नाती/श्रीमान/श्रीमती/बुहारी ....................................... बस्ने बर्ष................. को नाउँमा
        जारी भएको ......... दिने म्याद सूचना निजको घर ठेगाना सम्पर्क गरि निजलाई नै/ एकाघरको परिवारको
        सदस्य.................................... लाई मिति......................... गते.......... बजे तपशिलमा लेखिएका
        प्रतिनिधिहरुको रोवारमा तामेल गरिएको व्यहोरा यसै प्रतिवेदन साथ पेश गरेको छु । </p>
    </div>
    <div style="margin-left:40px;margin-right: 20px;text-decoration: underline;margin-top:0px;">रोहवर :-</d>
    </div>
    <div style="margin-left:40px;margin-right: 40px;">
      <p>१. वडा नं .................. का वडा अध्यक्ष र सदस्य श्री ..........................................<br>२. ऐ.ऐ.
        वडा नं .................................. टोल बस्ने बर्ष ......... को श्री
        ..........................................<br>३. ऐ.ऐ. वडा नं .................................. टोल बस्ने बर्ष
        ......... को श्री ..........................................</p>

    </div>
    <div style="margin-left: 485px; margin-top: 10px;"><b>प्रतिवेदक</b></div>
    <div style="margin-left: 445px;margin-top: 5px;">(वडासचिवरतोकिएको कर्मचारी)</div>
</body>

</html>