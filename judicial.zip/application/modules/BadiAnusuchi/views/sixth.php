<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('BadiAnusuchi/save_anusuchi_6', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_6_id"
              value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['id'] : '' ?>">

            <div class="anusuchi" style="height:1490px;">
              <a href="<?php echo base_url() ?>BadiAnusuchi/printAnusuchi_6/<?php echo $darta_detail['darta_no'] ?>"
                class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?>
                </p>
              </div>

              <div class="form-border">
                <p><?php echo SITE_DISTRICT ?>, जिल्ला <?php echo SITE_OFFICE ?> वडा नं.
                  <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_ward']) ?>,
                  <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_address']) ?> बस्ने बर्ष
                  <?php echo $this->mylibrary->convertedcit($pratibadi[0]['p_dob']) ?> को
                  <?php echo $pratibadi[0]['p_name'] ?>को नाउँमा <?php echo SITE_OFFICE ?>को कार्यालय बाट <input
                    type="text" name="serial_no" class="borderlessinput" placeholder="पहिलो/दोस्रो*" required="true"
                    value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['serial_no'] : '' ?>"> पटक जारी भएको <input
                    type="text" name="days" value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['days'] : '' ?>"
                    class="borderlessinput" placeholder="दिन*" required="true"> दिने सूचना</p>
              </div>

              <div class="form-border">
                <p><?php echo SITE_DISTRICT ?>, जिल्ला <?php echo SITE_OFFICE ?> वडा नं.
                  <?php echo $this->mylibrary->convertedcit($badi[0]['b_ward']) ?>,
                  <?php echo $this->mylibrary->convertedcit($badi[0]['b_address']) ?> बस्ने
                  <?php echo $badi[0]['b_name'] ?>ले तपाई विरुद्ध <?php echo $darta_detail['case_title'] ?> भनि निवेदन
                  दर्ता गरेको हुँदा सो को प्रतिलिपि यसैसाथ पठाईएको छ । अत ः तपाईले म्याद बुझेको वा रितपुर्वक तामेल भएको
                  मितिले <input type="text" name="days"
                    value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['days'] : '' ?>" class="borderlessinput"
                    placeholder="दिन*" required="true"> दिन भित्रमा आफ्नो भनाई सहित आफै वा कानुन बंमोजिम वारेश मार्फत यस
                  कार्यालयमा हाजिर हुन आउनु होला । अन्यथा कानुन बमोजिम हुने व्यहोरा जानकारी गराईन्छ ।</p>
              </div>


              <div style="margin-left:645px">
                <p style="margin-left:40px; font-size: 18px;margin-top: 40px;"><b>म्याद जारी गर्ने अधिकारीको</b></p>
                <p style="margin-left:40px;">नामः<span style="color:red">*</span>
                  <select class="borderlessinput" required="true" id="workers" name="staff_id">
                    <option value="">कर्मचारी छानुहोस</option>
                    <?php if (!empty($workers)):
                      foreach ($workers as $staff): ?>
                        <option value="<?php echo $staff['id'] ?>" <?php if (!empty($anusuchi_6)): ?>       <?php if ($staff['id'] == $anusuchi_6['staff_id']) {
                                        echo 'selected';
                                      } ?>     <?php endif; ?>><?php echo $staff['name'] ?></option>
                      <?php endforeach;
                    endif; ?>
                  </select>
                </p>


                <input type="hidden" name="worker_name"
                  value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['worker_name'] : '' ?>" id="worker_name"
                  class="borderlessinput">
                <p style="margin-left:40px;">पदः<span style="color:red">*</span> <input type="text" name="worker_deg"
                    class="borderlessinput" required="true" id="post"
                    value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['designation'] : '' ?>"></p>
                <p style="margin-left:40px;">दस्तखतः</p>
                <p style="margin-left:40px;">मितिः<span style="color:red">*</span> <input type="text" name="date"
                    id="mdate" class="borderlessinput" required="true"
                    value="<?php echo !empty($anusuchi_6) ? $anusuchi_6['date'] : convertDate(date('Y-m-d')) ?>"
                    name="date"></p>
              </div>
              <hr>
              <div class="text-center">
                <p style="text-decoration: underline;">प्रतीवादी ले म्याद बुझी गरिदिने भरपाइ</p>
              </div>

              <div class="form-border">
                <p>मिति............................ मा यस न्यायिक समितिमा ............................ बस्ने
                  .....................................................उपर निवेदन दर्ता गरेकोमा सो विवादमा
                  प्रतिवादी/वारेस .............................................. उपस्थित भई सो म्याद र सो साथ आवश्यक
                  प्रति, निवेदन र अन्य कागजातका प्रमाणित प्रति बुझिलिएकोले यो भरपाई गरिएको छ ।</p>

              </div>

              <div style="margin-left:645px">
                <p style="margin-left:40px; font-size: 16px;margin-top:0px;"><b>न्यायिक समितिबाट म्याद बुझ्नेको</b></p>
                <p style="margin-left:40px;margin-top:-10px;">दस्तखतः</p>
                <p style="margin-left:40px;margin-top:-10px;">प्रतिवादी/वारेस नाम: <?php echo $pratibadi[0]['p_name'] ?>
                </p>
              </div>

              <div style="margin-top:30px;">
                <p style="text-decoration: underline;">गल्छी गाउँपालिका ......... नं. वडा कार्यालय बाट गल्छी गाउँपालिका
                  न्यायिक समितिमा पठाईएको म्याद तामेलीको प्रतिवेदन</p>
              </div>
              <div class="form-border">
                <p style="text-align:justify">मिति............................मा गल्छी गाउँपालिका न्यायिक समितिबाट
                  ...............................................बस्ने
                  ....................................................को/छोरा/नाती/श्रीमान/श्रीमती/बुहारी..................................बस्ने
                  बर्ष ........को नाउँमा जारी भएको .........दीने म्याद सुचना निजको घर ठेगानामा सम्पर्क गरी निजलाई नै /
                  एकाघरको परीवारको सदस्य ....................................................लाई मिति
                  .....................गते........बजे तपशिलमा लेखीएका प्रतिनिधीहरुको रोहवरमा तामेल गरीएको व्यहोरा यसै
                  प्रतिवेदन साथ पेश गरेको छु ।</p>
              </div>
              <div>
                <p style="text-decoration: underline;">रोहवर :-</p>
              </div>
              <div>
                <p>१. वडा नं .................. का वडा अध्यक्ष र सदस्य श्री ..........................................
                </p>
                <p>२. ऐ.ऐ. वडा नं .................. टोल बस्ने बर्ष ......... को श्री
                  ..........................................</p>
                <p>३. ऐ.ऐ. वडा नं .................. टोल बस्ने बर्ष ......... को श्री
                  ..........................................</p>
              </div>
              <div style="margin-left:645px">
                <p style="margin-left:40px; font-size: 16px;margin-top:0px;"><b>प्रतिवेदक</b></p>
                <select class="borderlessinput" required="true" name="pratibedak">
                  <option value="">कर्मचारी छानुहोस</option>
                  <?php if (!empty($workers)):
                    foreach ($workers as $staff): ?>
                      <option value="<?php echo $staff['id'] ?>" <?php if (!empty($anusuchi_6)): ?>       <?php if ($staff['id'] == $anusuchi_6['pratibedak']) {
                                      echo 'selected';
                                    } ?>     <?php endif; ?>><?php echo $staff['name'] ?></option>
                    <?php endforeach;
                  endif; ?>
                </select>
              </div>
              <div class="text-center" style="margin-top: 60px;">
                <hr>
                <?php if (empty($anusuchi_6)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i
                      class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i
                      class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

                <?php } ?>
              </div>
            </div>
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript"
  src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function () {
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
    $('.dd_select').select2();
    var mainInput = $("#mdate");
    mainInput.nepaliDatePicker({
      ndpYear: true,
      ndpMonth: true,
      ndpYearCount: 100,
      disableAfter: GetCurrentBsDate
    });

    $('#workers').change(function () {
      var workers_id = $(this).val();
      $.ajax({
        url: base_url + 'BadiAnusuchi/getWorkers',
        method: "POST",
        data: {
          workers_id: workers_id
        },
        success: function (resp) {
          if (resp.status == 'success') {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });
  });
</script>