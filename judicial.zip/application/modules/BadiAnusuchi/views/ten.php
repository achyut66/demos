<style>
  ::-webkit-input-placeholder {
    /* Edge */
    color: red;
  }

  :-ms-input-placeholder {
    /* Internet Explorer */
    color: red;
  }

  ::placeholder {
    color: red;
    font-style: italic;
    text-align: center;
  }
</style>
<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('BadiAnusuchi/save_anusuchi_10', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_10) ? $anusuchi_10['id'] : '' ?>">
            <div class="anusuchi">
              <a href="<?php echo base_url() ?>BadiAnusuchi/printAnusuchi_10/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची - <?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;"><?php echo SITE_OFFICE ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
              </div>
              <p style="margin-left: 308px; margin-top: 10px;"><?php echo SITE_OFFICE ?> न्यायिक समिति समक्ष पेश गरेको मिलापत्रको संयुक्त निवेदन पत्र</p>

              <div class="form-border">
                <?php if (!empty($badi)) :
                  $i = 1;
                  foreach ($badi as $key => $b) : ?>
                    <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
                <?php endforeach;
                endif; ?>
              </div>
              <div class="text-center">
                <p>विरुद्ध</p>
              </div>
              <div class="form-border">
                <?php if (!empty($pratibadi)) : $i = 1;
                  foreach ($pratibadi as $key => $p) : ?>
                    <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
                <?php endforeach;
                endif; ?>
              </div>

              <div class="text-center" style="margin-top:70px;">
                <h5><b>मुद्दाको विषयः <?php echo $darta_detail['case_title'] ?> </b></h5>
              </div>
              <hr>
              <div class="form-border">
                हामी निवेदक निम्न लिखित निवेदन गर्दछौः
                <div class="form-border">
                  <button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i> नया थप्नुहोस</button>
                  <table class="table table-borderless" id="frm_tbl_wit">
                    <tbody>
                      <?php if (!empty($anusuchi_10)) : ?>
                        <?php $decision = explode('<>', $anusuchi_10['details_decision']);
                        if (!empty($decision)) :
                          foreach ($decision as $key => $des) : ?>
                            <tr class="row_mem">
                              <td><textarea name="decision[]" class="form-control" rows="4" placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा क्रमशः बुँदागत रुपमा खुलाई लेख्ने* " required="true" id="post" value=""><?php echo $des ?></textarea></td>
                            </tr>
                        <?php endforeach;
                        endif; ?>
                      <?php else : ?>
                        <tr class="row_mem">
                          <td><textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width: 90%;" placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा क्रमशः बुँदागत रुपमा खुलाई लेख्ने* " required="true" id="post" value=""></textarea><button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td>
                        </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>

              <hr>
              <div class="col-md-12">
                <h5 style="text-decoration: underline;">तोक आदेश </h5>
                <textarea class="form-control content" rows="3" id="content" readonly required><?php echo $tokaadesh['tok_aadesh'] ?></textarea>
                <br>
                <select class="form-control" name="staff_id" required>
                  <option value="">तोक लगाउने कर्मचारी छान्नुहोस्</option>
                  <?php if (!empty($staffs)) :
                    foreach ($staffs as $key => $staff) : ?>
                      <option value="<?php echo $staff['id'] ?>" <?php if (!empty($anusuchi_10)) :
                                                                    if ($anusuchi_10['staff_id'] == $staff['id']) {
                                                                      echo 'selected';
                                                                    }
                                                                  endif; ?>><?php echo $staff['name'] ?><b>(<?php echo $staff['designation'] ?>)</b></option>
                  <?php endforeach;
                  endif; ?>
                </select>
              </div>
              <hr>

              <p style="margin-left: 350px;margin-top:70px;">निवेदकहरुको नाम, थर तथा दस्तखत</p>
              <p style="margin-left: 350px;">
                <?php if (!empty($badi)) :
                  foreach ($badi as $key => $b) : ?>
              <p style="margin-left: 150px;">
                वादी: <?php echo $b['b_name'] ?>
              </p>
              <p style="margin-left: 150px; margin-top: -19px;">
                दस्तखतः
              </p>
          <?php endforeach;
                endif; ?>
          </p>

          <p style="margin-left: 550px;">
            <?php if (!empty($pratibadi)) :
              foreach ($pratibadi as $key => $p) : ?>
          <p style="margin-left: 618px; margin-top: -69px;">
            प्रतिवादी: <?php echo $p['p_name'] ?>
          </p>
          <p style="margin-left: 618px; margin-top: -19px;">
            दस्तखतः
          </p>
      <?php endforeach;
            endif; ?>
      </p>

      <div style="margin-left: 200px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>

      <div class="text-center" style="margin-top: 60px;">
        <hr>
        <?php if (empty($anusuchi_10)) { ?>
          <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
        <?php } else { ?>
          <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

        <?php } ?>
        <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-top: -18px;"><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
      </div>

            </div> <!-- endof anusuchi -->
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {

    $('.btnaddNewField').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      <?php if (empty($anusuchi_10)) : ?>
        var new_row = '<tr class="row_mem">' +
          '<td>' + trOneNew + ') <textarea name="decision[]" class="form-control" rows="4" placeholder="कसले के गर्ने गरी मिलापत्र हुने सहमति भएको हो त्यो व्यहोरा क्रमशः बुँदागत रुपमा खुलाई लेख्ने* " required="true" id="post" value="" ></textarea><button type="button" style="border: none;background: none" class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>' +
          '<tr>';
      <?php else : ?>
        var new_row = '<tr class="row_mem">' +
          '<td><input type="text" name="decision[]" class="form-control" rows="4" required="true" id="post" value="" ><button type="button" style="border: none;background: none" class="remove-row"><i class="fa fa-times" style="color:red;"></i></button></td>' +
          '<tr>';
      <?php endif; ?>
      $("#frm_tbl_wit").append(new_row);
    });

    $("body").on("click", ".remove-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

  });
</script>