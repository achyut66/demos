<style>
  ::-webkit-input-placeholder {
    /* Edge */
    color: red;
  }

  :-ms-input-placeholder {
    /* Internet Explorer */
    color: red;
  }

  ::placeholder {
    color: red;
  }
</style>
<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('BadiAnusuchi/save_anusuchi_9', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_9) ? $anusuchi_9['id'] : '' ?>">

            <div class="anusuchi">
              <a href="<?php echo base_url() ?>BadiAnusuchi/printAnusuchi_9/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;"><?php echo SITE_OFFICE ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
              </div>

              <div class="text-center">
                <?php if (!empty($badi)) :
                  foreach ($badi as $key => $b) : ?>
                    <p>
                      वादी: <?php echo $b['b_name'] ?>
                    </p>
                <?php endforeach;
                endif; ?>
                <p>तथा</p>
                <?php if (!empty($pratibadi)) :
                  foreach ($pratibadi as $key => $p) : ?>
                    <p>
                      प्रतिवादी: <?php echo $p['p_name'] ?>
                    </p>
                <?php endforeach;
                endif; ?>
              </div>

              <div class="text-center">
                 <p>मुद्धा नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_id']) ?>
                <p>विवादको विषयः <?php echo $darta_detail['case_title'] ?> 
               
              </div>
              <div class="form-border">१. फिराद पत्र:<br> <textarea name="badi_dabi" id="borderless" placeholder="* " required="true"  value="" rows="4"><?php echo !empty($anusuchi_9) ? $anusuchi_9['badi_dabi'] : "" ?></textarea></div>
              <div class="form-border">२. प्रतिउत्तर पत्र <textarea name="pratibadi_dabi" id="borderless" rows="4" placeholder="* " required="true" id="post" value=""><?php echo !empty($anusuchi_9) ? $anusuchi_9['pratibadi_dabi'] : "" ?></textarea></div>
              <div class="form-border">
               ३. छलफलको क्रममा निवेदन दिनुपूर्व हामी पक्षहरु एकआपसमा छलफल गर्न सकेको भए अति उत्तम थियो भन्ने दुवै पक्षको ठहर ।
              </div>
              <div class="form-border">
                ४. मिलापत्र खण्ड: हामी केही समय विवाद गरी आयौ, गजुरी गाऊँपालिका न्यायिक समितिमा नियमानुसार
                  निवेदनपत्र र लिखित जवाफ बुझाईसके पछि न्यायिक समितीले दिएको समय २०७७ भाद्र२८ गतेको प्रारम्भिक
                  ईजलास तथा २०७७ असोज ११ र मिति ०७७ चैत्र २४ गतेको इजलासबाट हामीदुवै पक्ष विच मिलिआएको व्यहोरा
                  यो छ कि विगतमा जे जस्ता विषयमा असमझदारी तथा वेमेल भएता पनि हामि दुवै छिमेकि विच एक अर्का प्रति
                  विश्वास सद्भाव कायमै रहेकोले गाली बेइज्जती सम्बन्धमा भन्ने निवेदन जिकिर छाडी अब आईन्दा हामीदुवै
                  पक्षबाट भएका केहि कमजोरी र गल्तीलाई हामीदुवैले आत्मसाथपनि गर्यो । प्रस्तुत विवादमा हामिहरु विचमा
                  वीवाद गरी आएता पनि अव यस विषयमा विवाद नगरौ भनि मिलीआएको व्यहोरा यो छ की
                <table class="table table-borderless" id="frm_tbl_wit">
                  <tbody>
                    
                    <?php if (!empty($anusuchi_9)) : ?>
                      <?php $decision = explode('<>', $anusuchi_9['details_decision']);
                      if (!empty($decision)) :
                        foreach ($decision as $key => $des) : ?>
                          <tr class="row_mem">
                            <td>1. <textarea name="decision[]" id="borderless" placeholder="मिलापत्र खण्ड* खुलाई लेख्ने* " required="true" id="post" value=""><?php echo $des ?></textarea><button type="button" style="" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button></td>
                          </tr>
                      <?php endforeach;
                      endif; ?>
                    <?php else : ?>
                      <tr class="row_mem">
                        <td>1. <textarea name="decision[]" id="borderless" rows="4" placeholder="मिलापत्र खण्ड* " required="true" id="post" value=""></textarea><button type="button" style="" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="नया  थप्नुहोस"><i class="fa fa-plus-circle" ></i> नया थप्नुहोस</button></td>
                      </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
              <hr>
              <div class="col-md-12">
                <h5 style="text-decoration: underline;">तोक आदेश </h5>
                <textarea class="form-control content" rows="3" id="content" readonly required><?php echo $tokaadesh['tok_aadesh'] ?></textarea>
                <br>
                <select class="form-control" name="staff_id" required>
                  <option value="">तोक लगाउने कर्मचारी छान्नुहोस्</option>
                  <?php if (!empty($staffs)) :
                    foreach ($staffs as $key => $staff) : ?>
                      <option value="<?php echo $staff['id'] ?>" <?php if (!empty($anusuchi_9)) :
                                                                    if ($anusuchi_9['staff_id'] == $staff['id']) {
                                                                      echo 'selected';
                                                                    }
                                                                  endif; ?>><?php echo $staff['name'] ?><b>(<?php echo $staff['designation'] ?>)</b></option>
                  <?php endforeach;
                  endif; ?>
                </select>
              </div>
              <hr>
              <p style="margin-left: 350px;">निवेदकहरुको नाम, थर तथा दस्तखत</p>
              <p style="margin-left: 350px;">
                <?php if (!empty($badi)) :
                  foreach ($badi as $key => $b) : ?>
              <p style="margin-left: 150px;">
                वादी: <?php echo $b['b_name'] ?>
              </p>
              <p style="margin-left: 150px; margin-top: -19px;">
                दस्तखतः
              </p>
          <?php endforeach;
                endif; ?>
          </p>

          <p style="margin-left: 550px;">
            <?php if (!empty($pratibadi)) :
              foreach ($pratibadi as $key => $p) : ?>
          <p style="margin-left: 618px; margin-top: -69px;">
            प्रतिवादी: <?php echo $p['p_name'] ?>
          </p>
          <p style="margin-left: 618px; margin-top: -19px;">
            दस्तखतः
          </p>
      <?php endforeach;
            endif; ?>
      </p>

      <div style="margin-left: 200px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>

      <div class="text-center" style="margin-top: 60px;">
        <hr>
        <?php if (empty($anusuchi_9)) { ?>
          <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
        <?php } else { ?>
          <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

        <?php } ?>
        <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-top: -18px;"><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
      </div>

            </div> <!-- endof anusuchi -->
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {

    $('.btnaddNewField').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      <?php if (empty($anusuchi_9)) : ?>
        var new_row = '<tr class="row_mem">' +
          '<td>' + trOneNew + '. <textarea name="decision[]" id="borderless" rows="4"  required="true" id="post" value="" ></textarea><button type="button"  class=" btn btn-sm btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="सदस्य हटानुहोस"><i class="fa fa-times-circle" "></i> हटाउनुहोस</button></td>' +
          '<tr>';
      <?php else : ?>
        var new_row = '<tr class="row_mem">' +
          '<td><input type="text" name="decision[]" id="borderless" rows="4" required="true" id="post" value="" ><button type="button" ><i class="fa fa-times" style="color:red;"></i> हटाउनुहोस </button></td>' +
          '<tr>';
      <?php endif; ?>
      $("#frm_tbl_wit").append(new_row);
    });

    $("body").on("click", ".remove-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    $("textarea").focus(function() {
      var $minHeight = $(this).css('min-height');
      $(this).on('input', function(e) {
        $(this).css('height', $minHeight);
        var $newHeight = $(this)[0].scrollHeight;
        $(this).css('height', $newHeight);
      });
    });
  });
</script>