dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE ?></title>

  <style type="text/css">
    /*table, th, td {

			border: 1px solid black;

		}*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 15pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0, 0, 0, .1);

    }

    table caption {

      padding: .5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }

    .signature {
      float: right;
      border-top: dotted 1px #000;
      width: 180px;
    }

    .stamp {
      float: right;
      margin-top: auto;
      border: 1px solid #555;
      margin-left: 427px;
      height: 140px;
      margin-top: -102px;
      width: 145px;
      margin-right: 40px;
    }
  </style>

</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
  <div style="background-color: #fff;">
    <!-- main content -->
    <div style="margin-left: 320px;">अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></div>
    <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></div>
    <div style="margin-left: 280px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></div>
    <div style="margin-left: 320px; margin-top: 20px;">न्यायिक समिति</div>
    <div style="margin-left: 240px;"><?php echo SITE_OFFICE ?> <?php echo SITE_OFFICE_TYPE ?>मा पेश गरेको</div>
    <div style="margin-left: 320px;">निवेदन पत्र</div>

    <div style="margin-left: 280px; margin-top: 40px;">
      विषयः नक्कल उपलब्ध गराई पाऊँ ।
    </div>

    <!-- <div style="margin-left:40px; margin-right: 40px;text-align: justify;">
        प्रस्तुत विषयमा तपसिलमा उल्लेखित कागजातहरुको प्रतिलिपी साथै राखी गजुरी गाउँपालिकाको न्यायिक समिति अन्तर्गतका <?php echo $anusuchi_15['dastur'] ?> मेलमिलाप केन्द्रमा सूचीकृत भई मेलमिलाप गराउन अनुमती पाउँ भनी निवेदन गर्दछु ।
      </div> -->

    <div style="margin-left:40px; margin-right: 40px;margin-top: 30px; text-align:justify">
      <?php if (!empty($badi)) : $i = 1;
        foreach ($badi as $key => $b) :

      ?>
          <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?><br> वादी
      <?php endforeach;
      endif; ?> वादी
    </div>
    <div style="margin-left:160px;"> विरुद्ध </div>
    <div style="margin-left:40px; margin-right: 40px;text-align:justify">
      <?php if (!empty($pratibadi)) : $i = 1;
        foreach ($pratibadi as $key => $p) :

      ?>
          <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?>
          <?php endforeach;
      endif; ?>प्रतिवादी
    </div>
    <div style="margin-left: 40px; margin-top: 20px;">मुद्दा: <?php echo $darta_detail['case_title'] ?></div>
    <div style="margin-left: 40px; margin-top: 30px;">म निवेदक निवेदन वापत रु <?php echo !empty($anusuchi_15) ? $this->mylibrary->convertedcit($anusuchi_15['dastur']) . '/' : '' ?> दस्तुर साथै राखी निम्न व्यहोरा निवेदन गर्दछु ।</div>
    <div style="margin-left: 40px; margin-top: 30px;">१) उपरोक्त विपक्षीसँगको उल्लेखित मुद्दामा अध्ययनको लागि देहायका कागजातहरु आवश्यक परेको हुँदा प्रमाणित प्रतिलिपी पाउँ भनी यो निवेदन साथ उपस्थित भएको छु । अतः नक्कलको प्रमाणित प्रतिलिपी पाउँ ।</div>
    <div style="margin-left: 80px; margin-top: 10px;">देहाय</div>
    <?php if (!empty($anusuchi_15['details_decision'])) :
      $mem = explode('<>', $anusuchi_15['details_decision']);
      $i = 1;
      foreach ($mem as  $mem) : ?>
        <div style="margin-left: 80px;"><?php echo $this->mylibrary->convertedcit($i++) ?>. <?php echo $mem ?></div>
    <?php endforeach;
    endif;
    ?>

    <div style="margin-left: 40px; margin-top: 10px"> २) लेखिएको व्यहोरा ठिक साँचो छ, झुट्टा ठहरे कानून बमोजिम सहुँला बुझाउँला । </div>


    <div style="margin-left: 40px; margin-top: 40px;">निवेदक</div>

    <p style="margin-left: 40px;margin-top: -5px;">निज <?php echo !empty($anusuchi_15) ? $anusuchi_15['name'] : $badi[0]['b_name']; ?></p>

    <div style="margin-left: 140px;margin-right: 40px;margin-top: 50px">इति सम्वत् इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ........................ ।</div>
</body>

</html>