<html>
<title><?php echo !empty($title) ? $title : SITE_OFFICE ?></title>
<meta charset="utf-8">
<meta content="ie=edge" http-equiv="x-ua-compatible">
<meta content="template language" name="keywords">
<meta content="Tamerlan Soziev" name="author">
<meta content="Admin dashboard html template" name="description">
<meta content="width=device-width, initial-scale=1" name="viewport">
<link href="<?php echo base_url() ?>assets/img/nyaik_samiti.png" rel="shortcut icon">
<link href="apple-touch-icon.png" rel="apple-touch-icon">
<link href="<?php echo base_url() ?>assets/css/main.css?version=4.4.0" rel="stylesheet">
<style>
  body {
    font-size: 18px;
    margin: 0px;
    color: black;

  }

  @page {
    /* size: auto; */
    margin: 20mm 20mm 20mm 20mm;
  }

  .csstransforms {
    position: absolute;
    top: 250px;
    text-align: justify;
    transform-origin: 0 0;
    transform: rotate(-90deg);
    padding: 10px;
    /* margin-top: 350px; */
    width: 500px;
    margin-left: 150px;
  }

  .csstransforms-hakim {
    transform: rotate(-90deg);
  }

  .heading {
    margin-top: 510px;
  }
</style>

<body style="--bleeding: 0.5cm;--margin: 1cm;">
  <div class="row">
    <div class="col-md-12" style="margin-top: 10px;">
      <div class="csstransforms" style="margin-top: 252px;">
        <p style="text-align:center">श्री <?php echo SITE_OFFICE ?></p>
        <p><?php echo $tokaadesh['tok_aadesh'] ?></p>
        <p style="margin-left:205px; margin-top:270px;"><?php echo $staff['name'] ?></p>
        <p style="margin-left:155px;"><?php echo $staff['designation'] ?></p>
      </div>
    </div>

    <div class="col-md-12" style="height:auto;">
      <div class=" heading">
        <p class="text-center" style="">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
        <p class="text-center" style="margin-top:-10px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
        <p class="text-center" style="margin-top:-10px;"><b><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></b> </p>
        <p class="text-center" style="margin-top:-10px;"><b><?php echo SITE_OFFICE ?> न्यायिक समिति</b> </p>
      </div>

      <!-- <div class="text-center" style="margin-top: 20px;">
        <div class="text-center">
          <p style="margin-left:151.18px;text-align: justify; margin-top: 40px; margin-right:40px">
          <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
          <?php endforeach;
          endif; ?>
        </p>
        </div>
        <p class="text-center">तथा</p>
        <div class="text-center">
          <?php if (!empty($pratibadi)) :
            foreach ($pratibadi as $key => $p) : ?>
              <p style="margin-top:0px;"> प्रतिवादी: <?php echo $p['p_name'] ?></p>
          <?php endforeach;
          endif; ?>
        </div>

      </div> -->

       <div style="margin-left:151.18px;text-align: justify; margin-top: 40px; margin-right:40px">
          <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
          <?php endforeach;
          endif; ?>
        </div>

        <div style="margin-left:151.18px; text-align: justify; margin-top: 25px;margin-right:40px">
          <?php if (!empty($pratibadi)) : $i = 1;
            foreach ($pratibadi as $key => $p) : ?>
              <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
          <?php endforeach;
          endif; ?>
        </div>

      <div class="text-center" style="margin-top: 70px;font-weight: bold; margin-left:151.18px;">
        <p style="margin-top:25px;font-weight: bold;">मुद्धा नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_id']) ?></p>
        <p style="margin-top: 10px;font-weight: bold;">विषय : <?php echo $darta_detail['case_title'] ?></p>
      </div>
      <div style="margin-left:151px;text-align: justify; margin-top: 80px; margin-right:40px" class="first-page">१. फिराद पत्र: <?php echo $anusuchi_9['badi_dabi'] ?></div>
      <div style="margin-left:151px;text-align: justify; margin-top:10px; margin-right:40px" class="first-page">२. प्रतिउत्तर पत्र: <?php echo $anusuchi_9['pratibadi_dabi'] ?></div>
       <div style="margin-left:151px;text-align: justify; margin-top:10px; margin-right:40px" class="first-page">३. छलफलको क्रममा निवेदन दिनुपूर्व हामी पक्षहरु एकआपसमा छलफल गर्न सकेको भए अति उत्तम थियो भन्ने दुवै पक्षको ठहर । </div>
      <div style="margin-left:151px;margin-top: 70px;text-align:justify;margin-right:40px">
      ४. मिलापत्र खण्ड: हामी केही समय विवाद गरी आयौ, गजुरी गाऊँपालिका न्यायिक समितिमा नियमानुसार
                  निवेदनपत्र र लिखित जवाफ बुझाईसके पछि न्यायिक समितीले दिएको समय २०७७ भाद्र२८ गतेको प्रारम्भिक
                  ईजलास तथा २०७७ असोज ११ र मिति ०७७ चैत्र २४ गतेको इजलासबाट हामीदुवै पक्ष विच मिलिआएको व्यहोरा
                  यो छ कि विगतमा जे जस्ता विषयमा असमझदारी तथा वेमेल भएता पनि हामि दुवै छिमेकि विच एक अर्का प्रति
                  विश्वास सद्भाव कायमै रहेकोले गाली बेइज्जती सम्बन्धमा भन्ने निवेदन जिकिर छाडी अब आईन्दा हामीदुवै
                  पक्षबाट भएका केहि कमजोरी र गल्तीलाई हामीदुवैले आत्मसाथपनि गर्यो । प्रस्तुत विवादमा हामिहरु विचमा
                  वीवाद गरी आएता पनि अव यस विषयमा विवाद नगरौ भनि मिलीआएको व्यहोरा यो छ की
      </div>

      <div style="margin-left:150px;margin-top: 10px;text-align:justify; margin-right:40px">
        <?php if (!empty($anusuchi_9)) :
          $decision = explode('<>', $anusuchi_9['details_decision']);
          if (!empty($decision)) :
            $i = 1;
            foreach ($decision as $des) : ?>
              <div style="margin-top:30px;"><?php echo $this->mylibrary->convertedcit($i++) ?>. <?php echo $des; ?></div>
          <?php endforeach;
          endif; ?>
        <?php endif; ?>
      </div>

      <div style="margin-left: 150px; margin-top:70px;">निवेदकहरुको</div>
     <div style="margin-left:151.18px;text-align: justify; margin-top: 40px; margin-right:40px">
          १. <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
          <?php endforeach;
          endif; ?>
        </div>

        <div style="margin-left:151.18px; text-align: justify; margin-top: 25px;margin-right:40px">
          २. <?php if (!empty($pratibadi)) : $i = 1;
            foreach ($pratibadi as $key => $p) : ?>
              <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
          <?php endforeach;
          endif; ?>
        </div>

      <div style="text-align:center; margin-top: 185px;font-size:18px;">इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ............................... ।</div>
    </div>
  </div>
</body>
<script type="text/javascript">
  window.print();
</script>

</html>