<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                   <?php echo form_open('BadiAnusuchi/save_anusuchi_1', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                    <div class="element-box-tp">
                      <?php if($this->session->flashdata('MSG_ERR')) { ?>
                        <div class="alert alert-danger"><?php echo $this->session->flashdata("MSG_ERR")?></div>
                      <?php } ?>
                      <div class="anusuchi" style="height: 1250px;">
                        <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                        <input type="hidden" name="type" value="<?php echo $type?>">
                        <input type="hidden" name="anusuchi_id" value="<?php echo $anusuchi_1['id']?>">
                        <input type = "hidden" name = "badi_pratibadi" value ="<?php echo $badi_pratibadi?>">
                        <div class="text-center">
                          <p>अनुसूची–१</p>
                          <p style="margin-top:-20px;">(दफा ८ को उपदफा (२) सँग सम्बन्धित)</p>
                          <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE?>मा दर्ता गरेको नालेस</p>
                        </div>
                        <?php 
                          $year = substr($badi[0]['b_dob'],0,4);
                          $current_date = convertDate(date('Y-m-d'));
                          $current_year = substr($current_date, 0,4);
                          $age = $current_year - $year;
                        ?>
                        <?php 
                          $pyear = substr($badi[0]['b_dob'],0,4);
                          $pcurrent_date = convertDate(date('Y-m-d'));
                          $pcurrent_year = substr($pcurrent_date, 0,4);
                          $page = $pcurrent_year - $pyear;
                        ?>

                        <p style="margin-left:40px; margin-right: 40px;">
                          <?php if(!empty($badi)) : 
                          foreach($badi as $key => $b) : 
                            $byear          = substr($b['b_dob'],0,4);
                            $bcurrent_date  = convertDate(date('Y-m-d'));
                            $bcurrent_year  = substr($bcurrent_date, 0,4);
                            $bage = $bcurrent_year - $byear;
                          ?>
                          <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
                          <?php echo $this->mylibrary->convertedcit($bage)?> <?php echo $b['b_name']?><b>,</b> 
                        <?php endforeach;endif;?>
                        </p>
                        <p class="text-center"> को विरुद्ध</p>

                        <p style="margin-left:40px; margin-right: 40px;">
                           <?php if(!empty($pratibadi)) : 
                          foreach($pratibadi as $key => $p) : 
                            $pyear = substr($p['p_dob'],0,4);
                            $pcurrent_date = convertDate(date('Y-m-d'));
                            $pcurrent_year = substr($pcurrent_date, 0,4);
                            $page = $pcurrent_year - $pyear;
                          ?>
                          <?php echo $p['p_grandfather']?> को नाती <?php echo $p['p_father']?> को छोरा/छोरी <?php echo $p['p_husband_wife']?> को पति/पत्नी, <?php echo $p['p_address']?> बस्ने वर्ष 
                          <?php echo $this->mylibrary->convertedcit($page)?> <?php echo $p['p_name']?><b> 
                          <?php endforeach;endif;?>
                        </p>

                        <h4 class="text-center" ><b>विवादको विषयः <span style="text-decoration: underline;"><?php echo $subject['subject']?></span></b></h4><br>
                        <?php if(!empty($badi)) {
                            $total_badi = count($badi);
                            if($total_badi >= 1 ) {
                              $sombodan = 'हामी';
                            } else {
                              $sombodan = 'म';
                            }
                        } ?>
                        <p style="margin-left:40px; margin-right: 40px;">
                        १. <?php echo $sombodan?> वादीहरुलाई माथि उल्लेख भए बमोजिमका विपक्षीहरुले अन्याय गर्नु भएको हुनाले उक्त विवादको विषय उपर मुद्दा हेर्न मिल्ने यस <?php echo SITE_OFFICE?>को न्यायिक समिति समक्ष कानुन बमोजिमको हद म्याद भित्र प्रस्तुत नालेस लिई आएको छु / आएका छौं । कानुन बमोजिम लाग्ने  
                        <input type="text" name="dastur" style="outline: 0;border-width: 0 0 2px; border-color: dotted 1px #000;background: none;" required="true" placeholder="दस्तुर रु*" name="dastur" value="<?php echo !empty($anusuchi_1)?$anusuchi_1['dastur']:''?>"> यसै साथ संलग्न <?php if($total_badi > 1){ echo 'गरेको छौं';} else { echo ' गरेका छु';} ?><!-- गरेको छु / गरेका छौं --> । विपक्षीहरुले गर्नु भएको अन्यायको व्यहोरा देहाय बमोजिम रहेको छः-</p>
                        <p style="margin-left:40px; margin-right: 40px; margin-top: 60px;">
                          <textarea name ="case_details" placeholder= "मुद्दाको विवरण*" style="outline: 0;border-width: 0 0 2px; border-color: dotted 1px #000;background: none; width:100%" required="true"><?php echo !empty($anusuchi_1)?$darta_detail['case_details']:'';?></textarea>
                        </p>

                        <p style="margin-left:40px; margin-right: 40px;">२. यो नालेस दर्ता गर्न कानुन व्यवसायी राखेको छु/छैन ।
                          <div style="margin-left: 50px;">

                            <?php 
                              if(!empty($anusuchi_1)) { ?>
                                <div class="form-check-inline">
                                  <label class="form-check-label" for="radio2">
                                    <input type="radio" class="form-check-input" id="radio2" name="has_lawyer" value="1" <?php if($darta_detail['has_lawyer'] == 1){ echo 'checked';}?>>छु
                                  </label>
                                </div>
                                <div class="form-check-inline">
                                  <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="has_lawyer" value="2" <?php if($darta_detail['has_lawyer'] == 2){ echo 'checked';}?>>छैन
                                  </label>
                                </div>
                              <?php } else { ?>
                                <div class="form-check-inline">
                                  <label class="form-check-label" for="radio2">
                                    <input type="radio" class="form-check-input" id="radio2" name="has_lawyer" value="1" checked="true">छु
                                  </label>
                                </div>
                                <div class="form-check-inline">
                                  <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="has_lawyer" value="2">छैन
                                  </label>
                                </div>
                              <?php } ?>
                            
                          </div>
                          
                        </p>

                        <p style="margin-left:40px; margin-right: 40px;">३. विपक्षीहरु  <?php echo $this->mylibrary->convertedcit(count($pratibadi))?> जनाका लागि प्रति व्यक्ति एकजनाको दरले नालेसको नक्कल प्रति ..... यसैसाथ संलग्न छ ।</p>

                        <p style="margin-left:40px; margin-right: 40px;">४. <?php if($total_badi > 1){ echo 'हाम्रो';} else { echo ' मेरो';} ?><!--  /  --> दावीको प्रमाण देहाय बमोजिम रहेको छः</p>

                        <p style="margin-left:40px; margin-right: 40px;">
                          <textarea name ="proof" placeholder= "देहाय बमोजिम प्रमाण*" style="outline: 0;border-width: 0 0 2px; border-color: dotted 1px #000;background: none; width:100%" required="true"><?php echo !empty($anusuchi_1)?$darta_detail['proof']:'';?></textarea>
                        </p>

                        <p style="margin-left:40px; margin-right: 40px;">५. <?php if($total_badi > 1){ echo 'हाम्रो';} else { echo ' मेरो';} ?> देहाय बमोजिमका साक्षी बुझीपाऊँः-</p>

                       <!--  <p style="margin-left:40px; margin-right: 40px;">(सवै साक्षीको पुरा नाम, थर, ठेगाना, उमेर उल्लेख गर्ने)</p> -->
                       <p style="margin-left:40px; margin-right: 40px;">

                        <div style="margin-left: 40px;margin-right: 40px;">
                          <table class="table table-bordered" id="frm_tbl_wit">
                              <thead>
                                  <tr>
                                      <th>नाम</th>
                                      <th>ठेगाना</th>
                                      <th>उमेर</th>
                                      <th>सम्पर्क नं.</th>
                                      <th>
                                        <?php if(!empty($anusuchi_1)) :?>
                                          <button type="button" class="btn  btn-primary btnaddNewField" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button>
                                        <?php else : ?>
                                          #
                                        <?php endif;?>
                                      </th>
                                  </tr>
                              </thead>
                              <tbody>
                                <?php if(!empty($anusuchi_1)) : ?>
                                  <?php if(!empty($witness)) : 
                                    foreach($witness as $w ) : ?>
                                    <tr>
                                      <input type="hidden" name="w_id[]" value="<?php echo $w['id']?>">
                                      <td><input type="text" name="w_name[]" class="form-control" value="<?php echo $w['name']?>" required="true"></td>

                                      <td><input type="text" name="w_address[]" class="form-control" value="<?php echo $w['address']?>" required="true"></td>

                                      <td><input type="text" name="w_age[]" class="form-control" value="<?php echo $w['age']?>" required="true"></td>

                                      <td><input type="text" name="w_phone[]" class="form-control" value="<?php echo $w['phone']?>" required="true"></td>

                                      <td><button type="button" data-href="<?php echo base_url()?>Anusuchi/deleteWitness/" class="btn btn-outline-danger deleteWitness" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस" data-id ="<?php echo $w['id']?>"><i class="os-icon os-icon-ui-15" ></i></button></td>
                                  </tr>
                                  <?php  endforeach;endif;?>
                                <?php else : ?>
                                  <tr>
                                      <td><input type="text" name="w_name[]" class="form-control" value="" required="true"></td>
                                      <td><input type="text" name="w_address[]" class="form-control" value="" required="true"></td>
                                      <td><input type="text" name="w_age[]" class="form-control" value="" required="true"></td>
                                      <td><input type="text" name="w_phone[]" class="form-control" value="" required="true"></td>
                                      <td><button type="button" class="btn  btn-primary btnaddNewField" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button></td>
                                  </tr>
                                <?php endif;?>
                                  
                          </table>
                        </div>


                         <!--  <?php if(!empty($witness)) : 
                           $i=1; foreach ($witness as $key => $w) : ?>
                              <p style="margin-left:80px; margin-right: 40px;"><?php echo $this->mylibrary->convertedcit($i++)?>) नाम थर- <?php echo $w['name']?>, ठेगाना- <?php echo $w['address']?>, उमेर- <?php echo $this->mylibrary->convertedcit($w['age'])?></p>
                             <?php endforeach;endif;?> -->
                         </p>

                        <p class="signature" style="margin-right: 40px; margin-top: 30px;">वादीको दस्तखत वा सहिछाप</p>
                        <p class="text-center" style="margin-top: 70px;">इति सम्वत २०७८ साल वैशाख महिना २० गते रोज ६ (वार) शुभम् । (आवेदन मिति)</p>
                        <hr>
                        <div class="text-center">
                          <?php if(empty($anusuchi_1)) { ?>
                          <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                          <?php } else { ?>
                            <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                            <a href ="<?php echo base_url()?>BadiAnusuchi/printAnusuchi_1/<?php echo $darta_detail['darta_no']?>" class="btn btn-secondary" target ="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
                          <?php } ?>
                        </div>

                      </div>
                      <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('.btnaddNewField').click(function(e) {
      var MaxInputs       = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length+1;
          <?php if(empty($anusuchi_1)) : ?>
          var new_row =  '<tr class="row_mem">'+
                            '<td><input type="text" name="w_name[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="w_address[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="w_age[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="w_phone[]" class="form-control" value="" required="true"></td>'+
                            '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>'+
                            '<tr>';
            <?php else : ?>
              var new_row =  '<tr class="row_mem">'+
                            '<td><input type="text" name="w_name_new[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="w_address_new[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="w_age_new[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="w_phone_new[]" class="form-control" value="" required="true"></td>'+
                            '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>'+
                            '<tr>';
            <?php endif;?>
          $("#frm_tbl_wit").append(new_row);
      });
    //remove samati members.
    $("body").on("click",".remove-muddha-row", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });


    //remove witness
    $(document).on('click', '.deleteWitness', function(e) {
      e.preventDefault();
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        id = $(this).data('id');
        url = $(this).data('href');
        $.ajax({
          url:url,
          method:"POST",
          data:{
            id:id,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
          },
          beforeSend: function () {
            $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
          },
          success : function(resp){
            if(resp.status == 'success') {
              toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": true,
                "onclick": null,
                "showDuration": "1000",
                "hideDuration": "2000",
                "timeOut": "2000",
                "extendedTimeOut": "3000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
              }
              toastr.error(resp.data);
               location.reload();
            }
          }
        });
      }
    });

  });
</script>