<?php 

class AnuMdl extends CI_Model {

    public function GetMaxDartaNo()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`id`) AS `darta_no` FROM `darta`")->row();
        return $row;
    }

    //get list
    public function getDartaList() {
        $this->db->select('t1.*, t2.subject')->from('darta t1');
        $this->db->join('mudda_bisaye t2','t2.id = t1.mudda_bisaye','left');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function Totalprint($table, $darta_no) {
        $this->db->from($table);
        // $this->db->where('status', 1);
        $this->db->where('darta_no', $darta_no);
        return $this->db->count_all_results();
    }
    public function getAnusuchi($table, $darta_no) {
        $this->db->select('*')->from($table);
        $this->db->where('darta_no', $darta_no);
        $this->db->order_by('id','DESC');
        $query = $this->db->get();
        return $query->row_array();
    }
    public function getLatestTarakBharpai($darta_no) {
        $this->db->select('*')->from('anusuchi_3');
        $this->db->where('darta_no', $darta_no);
        $this->db->where('type', 'new');
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getNewTarakParch($darta_no) {
        $this->db->select('*')->from('anusuchi_4');
        $this->db->where('darta_no', $darta_no);
        $this->db->where('type', 'new');
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array();
    }

    //getMyadSuchana
    public function getMyadSuchana($darta_no) {
        $this->db->select('*')->from('anusuchi_4');
        $this->db->where('darta_no', $darta_no);
        $this->db->where('type', 'new');
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result_array(); 
    }

}