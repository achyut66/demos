<div class="content-i">
    <div class="content-box">
        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-content">
                        <table  class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th text-aligh="right">#</th> 
                                    <th>भूमिका</th>
                                    <th class="hidden-phone"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($groups)) :
                                    $i = 1;
                                    foreach($groups as $key => $value) : ?>
                                    <tr class="gradeX">
                                        <td><?php echo $i++?></td>
                                        <td><?php echo $value['group_name']?></td>
                                        <td class="center hidden-phone">
                                            <a href = "<?php echo base_url()?>Groups/EditGroupPerm/<?php echo $value['groupid']?>" class="btn btn-danger" data-toggle="tooltip" title="" >अनुमति प्रबन्ध गर्नुहोस्</a>
                                        </td>
                                    </tr>
                                <?php endforeach;endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>