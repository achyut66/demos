<div class="content-i">
    <div class="content-box">
        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-content">
                       <?php echo form_open('Groups/EditGroupPerm/'.$this->uri->segment(3), array('name'=>'EditGroupPerm', 'id'=>'EditGroupPerm', 'method'=>'post', 'class'=>'form-horizontal'));?>
                        <?php 
                            $group_id = $this->uri->segment(3);
                            $grouppermissions = '';
                            $checkCount = 0;
                            $moduleCount = 0;
                            if ($parentmodules) {                        
                                $grouppermissions .= '<table  class="display table table-bordered table-striped" id="dynamic-table">
                                <tbody>
                                <tr>
                                <td colspan="100%" align="right"><a href="javascript:void(0);" data-id="group-select-all" data-type="all">All</a>&nbsp;<a href="javascript:void(0);" data-id="group-select-all" data-type="none">None</a></td>
                                </tr>';
                                $qrymodules = $this->Groupsmodel->listmodule();
                                if ($qrymodules) {
                                  foreach ($qrymodules as $module_row):
                                    $grouppermissions .= '<tr>';
                                    $grouppermissions .= '<td>'. $module_row->menu_name . '</td>';
                                    $qryuseraction = $this->Groupsmodel->listuseraction();
                                    if($qryuseraction){                 
                                      foreach ($qryuseraction as $action_row):
                                        $permission = $this->Groupsmodel->checkgroup_permision($module_row->menuid,$action_row->user_action_id,$group_id);
                                        $checkbox_id = $module_row->menuid ."_". $action_row->user_action_id;
                                        if($permission)
                                          $checked = "checked";
                                        else
                                          $checked = "";
                                        $class = 'group-select-all group-select-'.$checkCount.' module-select-'.$moduleCount;
                                        $checkbox = form_input(array('type'=>'checkbox','name'=>'chk_permission[]', 'id'=>'chk_permission', 'value'=> $checkbox_id, $checked=>$checked,  'class'=>$class));
                                        $grouppermissions .= '<td>'.  $action_row->user_action_name. '&nbsp;&nbsp;' . $checkbox . '</td>';
                                      endforeach;
                                    }
                                    $mk = 'module-select-'.$moduleCount;
                                    $grouppermissions .= '<td align="right"><a data-id="'.$mk.'" data-type="all" href="javascript:void(0);">All</a>&nbsp;<a data-id="'.$mk.'" href="javascript:void(0);" data-type="none">None</a></td>';
                                    $moduleCount++;
                                  endforeach; 
                                }
                                $checkCount++;
                                $grouppermissions .='</tbody>';
                              }
                              $grouppermissions .="</table>";
                              echo $grouppermissions;
                              ?>

                              <?php $groupid = (isset($query->groupid) && $query->groupid!='')?$query->groupid:''?>
                              <?php echo form_input(array('type'=>'hidden','name'=>'ID', 'id'=>'ID','value'=>$groupid, 'class'=>'form-control', 'required'=>'required'));?>
                              <?php echo form_input(array('type'=>'hidden','name'=>'Submit', 'id'=>'Submit','value'=>'Submit', 'class'=>'form-control', 'required'=>'required'));?>

                              <td>
                                  <span class="tools pull-right">
                                    <a href="javascript:;" id="savegroupperm_button" class="btn btn-info " style="color:#fff"><i class="fa fa-save"></i> Save</a>
                                    <a href="javascript:;" id="cancelgroup_button" class="btn btn-danger" style="color: #fff"><i class="fa fa-remove"></i> Cancel</a>
                                </span>
                              </td>
                              <?php echo form_close();?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>