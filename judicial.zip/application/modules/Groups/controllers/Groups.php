<?php

/**

* Created By: Balram Upadhyay

*/

class Groups extends MX_Controller

{

    public function __construct()

    {

        parent::__construct();

        $this->load->model('Groupsmodel');
        $this->load->model('CommonModel');

        $this->module_code = 'MANAGE-GROUP';

    }



    public function Index()

    {

        if ($this->authlibrary->IsLoggedIn() && $this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {

            redirect('Groups/ListAll', 'location');

        } else {

            $this->session->set_flashdata('error', 'Please login with your username and password');

            $this->session->set_userdata('return_url', current_url());

            redirect('Login', 'location');

        }

    }



    public function ListAll()

    {

        if ($this->authlibrary->IsLoggedIn()) {

            if (!$this->authlibrary->HasModulePermission($this->module_code, 'VIEW')) {

                $this->session->set_flashdata("MSG_ERR_ACCESS", "Unauthorized Access to Restricted Module!");

                redirect('Dashboard');

            }

            $query                  = $this->Groupsmodel->listGroup();

            $data['pageTitle']      = 'Manage User Group';

            $data['title']          = 'Manage Groups';

            $data['groups']         = $query;

            $data['script']         = 'listscript';

            $data['page']           = 'listgroup';

            $this->breadcrumb->populate(array(

                'ड्यासबोर्ड'              => '',

                'भूमिका'            => 'Groups/ListAll',

                'सुची'

                ));

            $data['breadcrumb']     = $this->breadcrumb->output();

            $this->load->vars($data);

            $this->load->view('main');

        } else {

            $this->session->set_flashdata('error', 'Please login with your username and password');

            $this->session->set_userdata('return_url', current_url());

            redirect('Login', 'location');

        }

    }

    public function AddGroup()

    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {

            $this->session->set_flashdata("MSG_ERR_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            $data['pageTitle'] = 'भूमिका';

            $id = $this->input->post('id');



            $this->load->view('addgroup',$data);

        }

    }



    public function saveGroup() {

        if(!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            if($this->input->post('Submit'))

            {

                $value['details']['group_name'] = $this->input->post('groupname');

               

                $this->Groupsmodel->addGroup($value['details']);



                $this->session->set_flashdata('MSG_SUC_ADD','A new group has been added with name: '.$this->input->post('groupname'));

                redirect('Groups/ListAll');

            }

        }

    }



    public function EditGroup() {

        $id             = $this->input->post('id');

        $query          = $this->Groupsmodel->getGroup($id);

        $data['query']  = $query;

        $data['page']   = 'editgroup';

        $this->load->vars($data);

        $this->load->view('editgroup');

    }



    public function UpdateGroup(){

        if($this->authlibrary->IsLoggedIn()){

            if(!$this->authlibrary->HasModulePermission($this->module_code, 'EDIT')){

                $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

                redirect('Home');

            }

            if($this->input->post('Submit'))

            {

                $id = $this->input->post('ID');

                $value['details']['group_name'] = $this->input->post('groupname');

                $this->Groupsmodel->editGroup($value['details'],$id);



                $this->session->set_flashdata('MSG_SUC_ADD','A group information with the name '.$this->input->post('groupname').' has been modified.');

                redirect('Groups/ListAll');

            }

        } else {

            $this->session->set_flashdata('error', 'Please login with your username and password');

            $this->session->set_userdata('return_url', current_url());

            redirect('Login', 'location');

        }

    }



    public function EditGroupPerm()

    {

        if ($this->authlibrary->IsLoggedIn()) {

            if (!$this->authlibrary->HasModulePermission($this->module_code, 'EDIT')) {

                $this->session->set_flashdata("MSG_ERR_ACCESS", "Unauthorized Access to Restricted Module!");

                redirect('Dashboard');

            }

            if ($this->input->post('Submit')) {

                $chk_permission         = $this->input->post('chk_permission');

                $login_id               = $this->session->userdata('EM_USER_ID');

                $group_id               = $this->uri->segment(3);

                $this->Groupsmodel->updategroup_permision($chk_permission, $group_id, $login_id);

                $this->session->set_flashdata('MSG_SUC_ADD', 'Group Permission Saved Successfully.');

                redirect('Groups/EditGroupPerm/'.$group_id, 'location');

            }

            $id                         = $this->uri->segment(3);

            $parentmodules              = $this->Groupsmodel->listmodule();

            $this->breadcrumb->populate(array(

                'Dashboard'             => '',

                'Groups'                => 'Groups/ListAll',

                'Edit Group Permission' => 'EditGroupPerm'

                ));

            $data['breadcrumb']         = $this->breadcrumb->output();

            $data['parentmodules']      = $parentmodules;

            $data['pagetitle']          = 'Edit Group Permission for '.$this->Groupsmodel->getgroupname($id);

            $data['title']              = 'Edit Group Permission';

            $data['script']             = 'editgrouppermscript';

            $data['page']               = 'editgroupperm';

            $this->load->vars($data);

            $this->load->view('main');

        } else {

            $this->session->set_flashdata('error', 'Please login with your username and password');

            $this->session->set_userdata('return_url', current_url());

            redirect('Login', 'location');

        }

    }

}

