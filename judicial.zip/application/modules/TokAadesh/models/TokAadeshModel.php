<?php 

class TokAadeshModel extends CI_Model {

	/*
        * this funcrtion get all main topic list 
        @param null
        @ return array main topic list.
    */
	public function getList() {
		$this->db->select('t1.*,t2.letter_type')->from('tok_aadesh t1');
        $this->db->join('letters t2', 't2.id = t1.letter_type', 'left');
        $query = $this->db->get();
        return $query->result_array();
	}

}