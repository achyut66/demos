<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    तोक-आदेश सम्पादन गर्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>

  <form action="<?php echo base_url() ?>TokAadesh/Update" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="row">
      <div class="col-sm-12">
       
          <input class="form-control" type="hidden" name="id" required="true" value="<?php echo $row['id'] ?>">
       
        <table class="table table table-padded" id="frm_tbl_mem">
          <tbody>
            <tr class="row_mem">
              <td>
                <select class="form-control" name="letter_type">
                  <option value="">--पत्रको किसिम छान्नुहोस्--</option>
                  <?php if (!empty($letters)) :
                    foreach ($letters as $key => $letter) : ?>
                      <option value="<?php echo $letter['id'] ?>" <?php if($letter['id'] == $row['letter_type']){ echo 'selected'; }?>><?php echo $letter['letter_type'] ?></option>
                  <?php endforeach;
                  endif; ?>
                </select>
              </td>
            </tr>
            <tr class="row_mem">
              <td><textarea class="form-control" name="tok_aadesh" rows="4"><?php echo $row['tok_aadesh'] ?></textarea></td>
            </tr>
          </tbody>
        </table>

      </div>
      <div class="col-sm-12">
        <button class="btn btn-primary btn-xs btn-block save_btn" data-toggle="tooltip" title="सेभ गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
      </div>
    </div>
  </form>
</div>