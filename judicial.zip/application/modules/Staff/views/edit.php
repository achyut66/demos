<div class="content-i">
    <div class="content-box">
        <div class="element-wrapper">
            <div class="element-box-tp">
                <div class="anusuchi">
                    <div class="text-center"><strong><h2>न्यायिक समिति पदाधिकारीको विवरण सम्पादन गर्नुहोस</h2></strong></div>
                    <?php echo form_open('Staff/Update', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
                        <div class="form-desc">
                          <span class="text-danger">[ कृपया &nbsp;*चिन्न भएको ठाउँ खाली नछोड्नु होला ]</span>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-2" for="">नाम<span
                                class="text-danger">&nbsp;*</span></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="name" required="true" value="<?php echo $row['name']?>">
                                <input type="hidden" class="form-control" name="id" required="true" value="<?php echo $row['id']?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-2" for="">पद<span
                                class="text-danger">&nbsp;*</span></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="designation" required="true" value="<?php echo $row['designation']?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-2" for="">मोबाइल नं<span
                                class="text-danger">&nbsp;*</span></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="mobile" required="true" value="<?php echo $row['mobile']?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-sm-2" for="">इ-मेल<span
                                class="text-danger">&nbsp;*</span></label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="email" required="true" value="<?php echo $row['email']?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-form-label col-sm-2" for="">अवस्था<span
                                class="text-danger">&nbsp;*</span></label>
                            <div class="col-sm-8">
                                <div class="form-check">
                                    <label class="form-check-label"><input class="form-check-input" name="status" type="radio" value="1" <?php if($row['status'] == 1){echo 'checked';}?>>Active</label>
                                    <label class="form-check-label" style="margin-left: 50px;"><input class="form-check-input" name="status" type="radio" value="2" <?php if($row['status'] !=1){echo 'checked';}?>>Inactive</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-form-label col-sm-2" for="">कैफियत</label>
                            <div class="col-sm-8">
                                <textarea class="form-control" name="remarks"><?php echo $row['remarks']?></textarea>
                            </div>
                        </div>

                        <div class="form-buttons-w">
                            <button type="submit" class='btn btn-submit btn-primary btn-block save_btn' name="submit">सम्पादन गर्नुहोस्</button>
                        </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
