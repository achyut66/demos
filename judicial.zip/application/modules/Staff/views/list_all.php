<div class="content-i">
  <div class="content-box">
    <div class="row">
        <div class="col-sm-12">
            <div class="element-wrapper">
              <div class="element-box-tp">
                <div class="anusuchi">
                  <?php if($this->authlibrary->HasModulePermission('STAFF', "ADD")) { ?>
                  <div class="controls-above-table">
                      <div class="row">
                          <div class="col-sm-6">
                              <a class="btn btn-outline-primary" href="<?php echo base_url()?>Staff/Add" ><i class="os-icon os-icon-ui-22" ></i><span>न्यायिक समिति पदाधिकारी / कर्मचारी थप्नुहोस</span></a>
                          </div>
                      </div>
                  </div>
                  <?php } ?>
                  <div class="table-responsive">
                    <table  class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th class="text-right">#</th> 
                          <th>नाम</th>
                          <th>पद</th>
                          <th>मोबाइल नं</th>
                          <th>इ-मेल</th>
                          <th>अवस्था</th>
                          <?php if($this->authlibrary->HasModulePermission('STAFF', "EDIT") || $this->authlibrary->HasModulePermission('STAFF', "DELETE") ) { ?>
                            <th>कार्य</th>
                          <?php } ?>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if(!empty($staffs)) :
                          $i = 1;
                          foreach($staffs as $key => $value) : ?>
                          <tr>
                            <td class="text-right"><?php echo $this->mylibrary->convertedcit($i++)?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['name'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['designation'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['mobile'])?></td>
                            <td><?php echo $this->mylibrary->convertedcit($value['email'])?></td>
                            <td>
                              <?php if($value['status'] == 1) { ?>
                                <a href="<?php echo base_url()?>STAFF/ChangeStatus/<?php echo $value['id']?>" class=" btn btn-outline-success btn-sm"><i class="fa fa-check-circle"></i> Active</a>
                              <?php } else { ?>
                               <a href="<?php echo base_url()?>STAFF/ChangeStatus/<?php echo $value['id']?>" class=" btn btn-outline-danger btn-sm"><i class="fa fa-times-circle"></i> Inactive</a>
                             <?php  } ?>
                             </td>
                            <?php if($this->authlibrary->HasModulePermission('STAFF', "EDIT") || $this->authlibrary->HasModulePermission('STAFF', "DELETE") ) { ?>
                              <td class="">
                                <?php if($this->authlibrary->HasModulePermission('STAFF', "EDIT")) { ?>
                                <a href="<?php echo base_url()?>Staff/Edit/<?php echo $value['id']?>" class="btn btn-outline-info btn-sm" data-placement="bottom" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्"><i class="fa fa-pencil"></i> </a>
                                <?php } ?>
                                <?php if($this->authlibrary->HasModulePermission('STAFF', "DELETE") ) { ?>
                                <a class="btn btn-outline-danger btn-sm" data-placement="bottom" data-toggle="tooltip" title="" data-original-title=" विवरण हटानुहोस" href="<?php echo base_url()?>Staff/Delete/<?php echo $value['id']?>"><i class="os-icon os-icon-ui-15"></i></a>
                                <?php } ?>
                              </td>
                            <?php } ?>
                          </tr>
                        <?php endforeach;endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>