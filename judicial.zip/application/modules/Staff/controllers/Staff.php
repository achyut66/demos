<?php
class Staff extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        //$this->load->model("StaffModel");
        $this->module_code = 'Staff';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page'] = 'list_all';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'न्यायिक समिति पदाधिकारी / कर्मचारी'         => 'Staff',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['staffs']     = $this->CommonModel->getData('staff');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function add() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page']   = 'add';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'न्यायिक समिति पदाधिकारी / कर्मचारी'      => 'Staff',
                'नयाँ थप्नुहोस'      
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();

            $data['position'] = $this->CommonModel->getData('position','ASC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function Save() {
        if($this->input->is_ajax_request()) {
            
            $this->form_validation->set_rules('name', 'पदाधिकारीको पद', 'required|trim');
            $this->form_validation->set_rules('designation', 'पदाधिकारीको नाम', 'required|trim');
            $this->form_validation->set_rules('mobile', 'पदाधिकारीको मोवाइल नं.', 'required|trim');
            $this->form_validation->set_rules('email', 'पदाधिकारीको ई-मेल', 'required|trim');
            $this->form_validation->set_rules('status', 'Status', 'required|trim');
            if($this->form_validation->run() == false) {
              $errors = array();
                // Loop through $_POST and get the keys
                foreach ($this->input->post() as $key => $value)
                {
                    // Add the error message for this field
                    $errors[$key]   = form_error($key);
                }
                $err['errors']      = array_filter($errors); // Some might be empty
                $response           = array(
                    'status'                => 'v_errors',
                    'validation_errors'     => $err['errors'],
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $name                   = $this->input->post('name');
            $designation            = $this->input->post('designation');
            $mobile_no              = $this->input->post('mobile');
            $email                  = $this->input->post('email');
            $status                 = $this->input->post('status');
            $remarks                = $this->input->post('remarks');
            $post_data              = array(
                'name'              => $name,
                'designation'       => $designation,
                'mobile'            => $mobile_no,
                'email'             => $email,
                'status'            => $status,
                'remarks'           => $remarks
            );
            $result = $this->CommonModel->insertData('staff',$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'Staff',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "fail to insert data",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function Edit() {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page']       = 'edit';
            $data['script']     = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'न्यायिक समिति पदाधिकारी'     => 'Staff',
                'सम्पादन गर्नुहोस'  
            ));
            $id                 = $this->uri->segment(3);
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['row']        = $this->CommonModel->getDataByID('staff',$id);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->form_validation->set_rules('name', 'पदाधिकारीको पद', 'required|trim');
            $this->form_validation->set_rules('designation', 'पदाधिकारीको नाम', 'required|trim');
            $this->form_validation->set_rules('mobile', 'पदाधिकारीको मोवाइल नं.', 'required|trim');
            $this->form_validation->set_rules('email', 'पदाधिकारीको ई-मेल', 'required|trim');
            $this->form_validation->set_rules('status', 'Status', 'required|trim');
            if($this->form_validation->run() == false) {
              $errors = array();
                // Loop through $_POST and get the keys
                foreach ($this->input->post() as $key => $value)
                {
                    // Add the error message for this field
                    $errors[$key]   = form_error($key);
                }
                $err['errors']      = array_filter($errors); // Some might be empty
                $response           = array(
                    'status'                => 'v_errors',
                    'validation_errors'     => $err['errors'],
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $name                   = $this->input->post('name');
            $designation            = $this->input->post('designation');
            $mobile_no              = $this->input->post('mobile');
            $email                  = $this->input->post('email');
            $status                 = $this->input->post('status');
            $remarks                = $this->input->post('remarks');
            $post_data              = array(
                'name'              => $name,
                'designation'       => $designation,
                'mobile'            => $mobile_no,
                'email'             => $email,
                'status'            => $status,
                'remarks'           => $remarks
            );
            $result = $this->CommonModel->updateData('staff',$id,$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'Staff',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "fail to insert data",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    //remove members
    public function Delete() {
        $id = $this->uri->segment(3);
        if(empty($id)) {
            $this->session->set_flashdata('MSG_ERR', "Invalid Process");
            redirect('Staff');
        }
        $result = $this->CommonModel->deleteData('staff', $id);
        if($result) {
            $this->session->set_flashdata('MSG_SUCCESS', "Removed Successfully");
            redirect('Staff');
        }
    }
}