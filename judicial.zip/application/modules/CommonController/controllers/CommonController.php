<?php
class CommonController extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {}

    //get district by state

    public function getDistrictByState() {

        if($this->input->is_ajax_request()) {

            $state = $this->input->post('state');

            get_district_dropdown($state);

        } else {

          exit('no direct script allowed');

      }

    }



    //get Gapanapa By Districts

    public function getGapanapaByDistricts() {

        if($this->input->is_ajax_request()) {
            $district = $this->input->post('district');
            get_ganapa_dropdown($district);
        } else {

          exit('no direct script allowed');

        }

    }

    public function getSamitiNameByPost() {
        if($this->input->is_ajax_request()) {
            $post               = $this->input->post('sa_post');
            $selected_samiti    = $this->input->post('selected_samiti');
            $data               = $this->CommonModel->getRowByMultipleCondition('meeting_members',array('designation' => $post, 'samiti_id' => $selected_samiti, 'row'));
            if(empty($data)) {
                $response           = array(
                    'status'        => 'null',
                    'data'          => 'पदकारी दाखिला गरिएको छैन ',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response           = array(
                'status'        => 'success',
                'data'          => $data['name'],
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
         } else {
          exit('no direct script allowed');
        }
    }

    public function deleteDocuments() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $result = $this->CommonModel->deleteData('documents', $id);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'  => 'successfully removed' 
                );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
            }
        }
    }
}