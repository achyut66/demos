<html>
<title><?php echo !empty($title) ? $title : SITE_OFFICE ?></title>
<meta charset="utf-8">
<meta content="ie=edge" http-equiv="x-ua-compatible">
<meta content="template language" name="keywords">
<meta content="Tamerlan Soziev" name="author">
<meta content="Admin dashboard html template" name="description">
<meta content="width=device-width, initial-scale=1" name="viewport">
<link href="<?php echo base_url() ?>assets/img/nyaik_samiti.png" rel="shortcut icon">
<link href="apple-touch-icon.png" rel="apple-touch-icon">
<link href="<?php echo base_url() ?>assets/css/main.css?version=4.4.0" rel="stylesheet">
<style>
  body {
    font-size: 22px;
    margin-bottom: 10px;
    color:#000;
  }

  /* @page {
    size: auto;
    margin: 25mm 25mm 25mm 25mm;
  } */
  
 

  .csstransforms {
    position: absolute;
    top: 290px;
    text-align: justify;
    transform-origin: 0 0;
    transform: rotate(-90deg);
    padding: 20px;
    /* margin-top: 350px; */
    width: 500px;
    margin-left: 150px;
  }

  .csstransforms-hakim {
    transform: rotate(-90deg);
  }

  .heading {
    margin-top: 570px;
  }

  @media print {
    .content {
      clear: both;
      page-break-after: always;
    }
  }
</style>

<body style="--bleeding: 0.5cm;--margin: 1cm;">
  <div class="row">
    <div class="col-md-12" style="margin-top: 20px;">
      <div class="csstransforms" style="margin-top: 212px;">
        <p style="text-align:center">श्री <?php echo SITE_OFFICE ?></p>
        <p><?php echo $tokaadesh['tok_aadesh'] ?></p>
        <p style="margin-left:205px; margin-top:120px;"><?php echo $aadesh_staff['name'] ?></p>
        <p style="margin-left:155px;"><?php echo $aadesh_staff['designation'] ?></p>
      </div>
    </div>
    <!-- first page  -->
    <div class="col-md-12" style="height:auto;">
      <div class=" heading">
        <p class="text-center" style="">श्री <?php echo SITE_OFFICE ?></p>
        <p class="text-center" style="margin-top:-10px;">न्यायिक समिती समक्ष पेश गरेको</p>
        <p class="text-center" style="margin-top:-10px;"><b>निवेदन पत्र</b> </p>
      </div>
      <div class="badi">
        <p style="margin-left:151.18px;text-align: justify; margin-top: 120px; margin-right:40px">
          <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo $b['b_gapa'] ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div class="text-center" style="margin-top:80px;">
        <p style="font-weight: bold;">विरुद्</p>
      </div>
      <div class="pratibadi">
        <p style="margin-left:151.18px; text-align: justify; margin-top: 80px;margin-right:40px">
          <?php if (!empty($pratibadi)) : $i = 1;
            foreach ($pratibadi as $key => $p) : ?>
              <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo $p['p_gapa'] ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पति<?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div class="text-center" style="margin-top: 120px;font-weight: bold;margin-left:151.18px;margin-right:40px;">
        <p style="font-weight: bold;">विषय : <?php echo $darta_detail['case_title'] ?></p>
      </div>
      <div style="margin-left:151.18px;text-align: justify; margin-right:40px; margin-top:80px;">१. म निम्न लिखित बुदाहरुमा लेखिए बमोजिम निवेदन गर्दछ ।</div>
    </div>
    <!-- content -->

    <div class="content">
      <div class="col-md-12">
        <div style="height:5cm;"></div>
        <div style="margin-left:151.18px;text-align: justify;margin-right:40px">
          <?php if (!empty($muddhadetails['muddha_details'])) :
            $decision = explode('<>', $muddhadetails['muddha_details']);
            if (!empty($decision)) :
              $i = 1;
              foreach ($decision as $key=> $des) : ?>
                <p style="margin-top: 20px;"><?php echo $des; ?></p>
            <?php endforeach;
            endif; ?>
          <?php endif; ?>
        </div>
        <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;line-height:2em; margin-right:40px">
          २.यस गाउँपालिका बाट जारी भएको <?php echo $this->mylibrary->convertedcit($local_dafa['details']) ?> बमोजिम
          निवेदन दस्तुर रु <?php echo $this->mylibrary->convertedcit($muddhadetails['nibedan_dastur']) ?> दोस्रो पक्ष एक जनालाई म्याद सुचना दस्तुर रु.<?php echo $this->mylibrary->convertedcit($muddhadetails['suchana_dastur']) ?>,पाना <?php echo $this->mylibrary->convertedcit($muddhadetails['pana']) ?> को प्रतिलिपि दस्तुर रु. <?php echo $this->mylibrary->convertedcit($muddhadetails['pratilipi_dastur']) ?>
          जम्मा रु <?php echo $this->mylibrary->convertedcit($muddhadetails['jamma']) ?> तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छु ।
        </div>
        <div style="margin-left:151.18px;text-align: justify; margin-top: 20px;margin-right:40px">३. यो निवेदन
          <?php echo $this->mylibrary->convertedcit($subject['dafa']) ?> <?php echo $this->mylibrary->convertedcit($subject['upa_dafa']) ?> <?php echo $this->mylibrary->convertedcit($subject['remarks']) ?>
          अनुसार यसै समितिको अधिकारक्षेत्र भित्र पर्दछ ।</div>
        <div style="margin-left:151.18px;text-align: justify; margin-top: 20px;margin-right:20px">४. यो निवेदन हदम्याद भित्रै छ र म निवेदकलाई यस बिषयमा निवेदनदिने हकदैया प्राप्त छ।</div>
        <div style="margin-left:151.18px;text-align: justify; margin-top: 20px;margin-right:40px">५. साक्षीहरु :
          <?php $i = 1;
          if (!empty($witness)) : foreach ($witness as $key => $wit) : ?>
              <div style="margin-left:20px;  text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $wit['address'] . ', बस्ने ' . $this->mylibrary->convertedcit($wit['age']) . ' ' . $wit['name'] ?></div>
          <?php endforeach;
          endif; ?>
        </div>
        <div style="margin-left:151.18px;text-align: justify; margin-top: 20px;margin-right:40px">६. संलग्न कागजातहरु :
          <?php $i = 1;
          if (!empty($documents)) : foreach ($documents as $key => $docs) : ?>
              <p style="margin-left:20px;  text-align: justify; margin-top:2px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $docs['doc_type'] ?></p>
          <?php endforeach;
          endif; ?>
        </div>
        <div style="margin-left:151.18px;text-align: justify; margin-top: 20px;margin-right:40px">७. यसमा लेखिएको व्यहोरा ठिक साँचो सत्य हुन झुठा ठहरे कानून बमोजिम सजाय भोग्नतयार छु ।</div>
        <div style="margin-left:790px;margin-top:10px;">निवेदक</div>
        <?php if (!empty($badi)) :
          $i = 1;
          foreach ($badi as $key => $b) :
        ?>
            <div style="margin-left:776px;margin-top:10px;"><?php echo $b['b_name'] ?></div>
            <div style="margin-left:723px;margin-top:-5px;"><?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($b['b_ward']) . ' ' . $b['b_address'] ?></div>
        <?php endforeach;
        endif; ?>
        <div style="margin-left:250px;margin-top: 33px;font-size:18px;position:absolute;">इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ............................... ।</div>
      </div>
    </div>

  </div>
</body>
<script type="text/javascript">
  window.print();
</script>

</html>