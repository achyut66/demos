<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <?php if ($this->authlibrary->HasModulePermission('STAFF', "ADD")) { ?>
                <div class="controls-above-table">
                  <div class="row">
                    <div class="col-sm-6">
                      <!-- <a class="btn btn-primary" href="<?php echo base_url() ?>Letters/add"><i class="os-icon os-icon-ui-22"></i><span></span></a> -->
                      <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-primary btn-sm" title="" data-url="<?php echo base_url() ?>Letters/add"><i class="os-icon os-icon-ui-22"></i> नयाँ थप्नुहोस</button>
                    </div>
                  </div>
                </div>
              <?php } ?>
              <div class="table-responsive">
                <table class="table table-bordered table-striped" id="">
                  <thead>
                    <tr>
                      <th class="text-right">#</th>
                      <th>अनुसूची</th>
                      <th>विवरण</th>
                      <th>पत्रको नाम </th>
                      <th>तोक आदेश ?</th>
                      <th class="text-center">कार्य</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($sections)) :
                      $i = 1;
                      foreach ($sections as $key => $value) : ?>
                        <tr class="gradeX">
                          <td><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                          <td>अनुसूची-<?php echo $this->mylibrary->convertedcit($value['letter_name']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['dafa']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['letter_type']) ?></td>
                          <td><?php if($value['has_tok'] == 1 ) {
                            echo 'छ';
                          } else {
                            echo 'छैन';
                          } ?></td>
                          <?php if ($this->authlibrary->HasModulePermission('LETTER', "EDIT") || $this->authlibrary->HasModulePermission('LETTER', "DELETE")) { ?>
                            <td class="center hidden-phone">
                              <?php if ($this->authlibrary->HasModulePermission('LETTER', "EDIT")) { ?>
                                <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-primary btn-sm" title="" data-url="<?php echo base_url() ?>Letters/edit" data-id="<?php echo $value['id'] ?>"><i class="fa fa-pencil"></i></button>
                              <?php } ?>
                              <?php if ($this->authlibrary->HasModulePermission('LETTER', "EDIT")) { ?>
                                <a href="<?php echo base_url() ?>uploads/anu_<?php echo $value['letter_name'] ?>.pdf" class="btn btn-outline-info btn-sm" title="" target="_blank" data-placement="bottom" data-toggle="tooltip" title="" type="button" data-original-title="view sample format"><i class="fa fa-file"></i></a>
                              <?php } ?>
                            </td>
                          <?php } ?>
                        </tr>
                    <?php endforeach;
                    endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>