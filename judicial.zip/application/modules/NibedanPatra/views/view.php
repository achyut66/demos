<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('NibedanPatra/updateNibedanPatra', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data')); ?>

            <input type="hidden" name="data_id" value="<?php echo $row['id'] ?>">
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <div class="anusuchi">
                
                <a href="<?php echo base_url() ?>NibedanPatra/printFirstPage/<?php echo $darta_detail['id'] ?>" class='btn btn-submit btn-info'><i class="fa fa-print"></i> पहिलो पेज प्रिन्ट गर्नुहोस </a>
                
              <a href="<?php echo base_url() ?>NibedanPatra/generateFiradPatra/<?php echo $darta_detail['id'] ?>" class='btn btn-submit btn-primary'><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </a>
               
               
              <div class="col-md-12" style="height:auto;">
                <div class=" heading">
                  <p class="text-center" style="">श्री <?php echo SITE_OFFICE ?></p>
                  <p class="text-center" style="margin-top:-10px;">न्यायिक समिती समक्ष पेश गरेको</p>
                  <p class="text-center" style="margin-top:-10px;"><b>निवेदन पत्र</b> </p>
                </div>
                <div class="col-md-12">
                  <div class="form-border">
                    <?php if (!empty($badis)) :
                      $i = 1;
                      foreach ($badis as $key => $b) : ?>
                        <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo $b['b_gapa'] ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक
                    <?php endforeach;
                    endif; ?>
                  </div>
                  <div class="text-center" style="margin-top:20px;">
                    <p style="font-weight: bold;">विरुद्</p>
                  </div>
                  <div class="form-border">
                    <?php if (!empty($pratibadis)) : $i = 1;
                      foreach ($pratibadis as $key => $p) : ?>
                        <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo $p['p_gapa'] ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
                    <?php endforeach;
                    endif; ?>
                  </div>

                  <div class=" form-border description">१. म निम्न लिखित बुदाहरुमा लेखिए बमोजिम निवेदन गर्दछ ।
                    <table class="table table-bordered" id="tbl_wiwaran" style="border:color:#000">
                      <thead>
                        <tr>
                          <th>विवरण लेख्नुहोस</th>
                          <th>
                            <button type="button" class="btn  btn-outline-primary btnwiwaran" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> थप्नुहोस </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php if (!empty($row['muddha_details'])) :
                          $decision = explode('<>', $row['muddha_details']);
                          if (!empty($decision)) :
                            $i = 1;
                            foreach ($decision as $des) : ?>
                              <tr>
                                <td style="width: 100%"><textarea class="form-control content" rows="4" id="content" name="muddha_details[]" placeholder="विवरण लेख्नुहोस"><?php echo $des ?></textarea></td>
                                <td><button type="button" class="btn btn-outline-danger" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="हटानुहोस"><i class="os-icon os-icon-ui-15"></i> हटानुहोस</button></td>
                              </tr>
                          <?php endforeach;
                          endif; ?>
                        <?php endif; ?>
                    </table>
                  </div>
                  <div class="form-border">

                    २.यस गाउँपालिका बाट जारी भएको &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    <select class="" id="borderless" name="local_dafa">
                      <option value="">--कार्यविधिको दफा छान्नुहोस्--</option>
                      <?php if (!empty($local_dafa)) :
                        foreach ($local_dafa as $dafa) : ?>
                          <option value="<?php echo $dafa['id'] ?>" <?php if ($dafa['id'] == $row['local_dafa']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $dafa['details'] ?></option>
                      <?php endforeach;
                      endif; ?>
                    </select> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    <!-- स्थानिय न्यायिक कार्यविधिको दफा १४ बमोजिम -->
                    निवेदन दस्तुर रु &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                    <input type="text" name="nibedan_dastur" id="nibedan_dastur" placeholder="*" required="true" value="<?php echo $row['nibedan_dastur'] ?>" class="borderlessinput">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;दोस्रो पक्ष एक जनालाई म्याद
                    <hr> सुचना दस्तुर रु.
                    <input type="text" name="suchana_dastur" id="suchana_dastur" placeholder="*" required="true" value="<?php echo $row['suchana_dastur'] ?>" class="borderlessinput">,पाना
                    <input type="text" name="pana" id="pana" placeholder="*" required="true" value="<?php echo $row['pana'] ?>" class="borderlessinput"> को प्रतिलिपि दस्तुर रु.
                    <input type="text" name="pratilipi_dastur" id="pratilipi_dastur" placeholder="*" required="true" value="<?php echo $row['pratilipi_dastur'] ?>" class="borderlessinput">
                    जम्मा रु
                    <input type="text" name="jamma" class="borderlessinput" value="<?php echo $row['jamma'] ?>">
                    <hr>
                    तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छु ।

                  </div>

                  <div class="form-border">३. यो निवेदन
                    <?php echo $this->mylibrary->convertedcit($subject['dafa']) ?> उपदफा <?php echo $this->mylibrary->convertedcit($subject['upa_dafa']) ?> <?php echo $this->mylibrary->convertedcit($subject['remarks']) ?>
                    अनुसार यसै समितिको अधिकारक्षेत्र भित्र पर्दछ ।
                  </div>

                  <div class="form-border">४. यो निवेदन हदम्याद भित्रै छ र म निवेदकलाई यस बिषयमा निवेदनदिने हकदैया प्राप्त छ।</div>

                  <div class="form-border">
                    <p> ५. संलग्नकागजातहरु </p>
                    <table class="table table-bordered" id="frm_tbl_upload">
                      <thead>
                        <tr>
                          <th>पेश गरेको कागजातको नाम </th>
                          <!-- <th>कागजात</th> -->
                          <th>
                            #
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if (!empty($documents)) :
                          foreach ($documents as $doc) : ?>
                            <tr>
                              <td><input type="text" name="doc_name" class="form-control" value="<?php echo $doc['doc_type'] ?>" readonly></td>
                              <!-- <td><input type="file" name="userfile" class="form-control" required></td> -->
                              <td>
                                <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-success btn-sm" title="" data-url="<?php echo base_url() ?>Darta/viewDocs" data-id="<?php echo $doc['id'] ?>"><i class="fa fa-eye"></i></button>
                                <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-primary btn-sm" title="" data-url="<?php echo base_url() ?>Darta/editDocs" data-id="<?php echo $doc['id'] ?>"><i class="fa fa-pencil"></i></button>
                                <button type="button" data-href="<?php echo base_url() ?>BadiAnusuchi/nebidanDocs/" class="btn btn-outline-danger btn-sm deleteWitness" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="हटानुहोस" data-id="<?php echo $doc['id'] ?>"><i class="os-icon os-icon-ui-15"></i></button>
                              </td>
                            </tr>
                        <?php endforeach;
                        endif; ?>
                      </tbody>
                    </table>
                  </div>

                  <div class="form-border">
                    <p>५. साक्षीहरु :</p>
                    <table class="table table-bordered" id="frm_tbl_wit" style="border:color:#000">
                      <thead>
                        <tr>
                          <th>नाम</th>
                          <th>ठेगाना</th>
                          <th>उमेर</th>
                          <th>सम्पर्क नं.</th>
                          <th>

                            <!--<button type="button" class="btn  btn-outline-primary" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button>-->

                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if (!empty($witness)) :
                          foreach ($witness as $w) : ?>
                            <tr>
                              <input type="hidden" name="w_id[]" value="<?php echo $w['id'] ?>">
                              <td><input type="text" name="w_name[]" class="form-control" value="<?php echo $w['name'] ?>" required="true"></td>
                              <td><input type="text" name="w_address[]" class="form-control" value="<?php echo $w['address'] ?>" required="true"></td>
                              <td><input type="text" name="w_age[]" class="form-control" value="<?php echo $w['age'] ?>" required="true"></td>
                              <td><input type="text" name="w_phone[]" class="form-control" value="<?php echo $w['phone'] ?>" required="true"></td>
                              <td><a href="<?php echo base_url()?>NibedanPatra/view/<?php echo $w['id']?>" class="btn btn-danger"><i class="fa fa-times"></i> </a></td>
                            </tr>
                        <?php endforeach;
                        endif; ?>

                    </table>
                  </div>

                  <div class="form-border">६. यस विषयमा अन्यत्र कहीं कतै कुनै निकायमा कुनै प्रकारको निवेदन दिईएको छैन ।</div>
                  <div class="form-border">७. यसमा लेखिएको व्यहोरा ठिक साँचो सत्य हुन झुठा ठहरे कानून बमोजिम सजाय भोग्नतयार छु ।</div>
                </div>
                <hr>
                <div class="col-md-12">
                  <h5 style="text-decoration: underline;">तोक आदेश </h5>
                  <textarea class="form-control content" rows="3" id="content" readonly required><?php echo $tokaadesh['tok_aadesh'] ?></textarea>
                  <br>
                  <select class="form-control" name="staff_id" required>
                    <option value="">तोक लगाउने कर्मचारी छान्नुहोस्</option>
                    <?php if (!empty($staffs)) :
                      foreach ($staffs as $key => $staff) : ?>
                        <option value="<?php echo $staff['id'] ?>" <?php if ($staff['id'] == $row['staff_id']) {
                                                                      echo 'selected';
                                                                    } ?>><?php echo $staff['name'] ?><b>(<?php echo $staff['designation'] ?>)</b></option>
                    <?php endforeach;
                    endif; ?>
                  </select>
                </div>

                <hr>
                <div class="text-center">
                  <?php if (!empty($row)) : ?>
                    <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="">सम्पादन गर्नुहोस</button>
                  <?php endif; ?>
                </div>

              </div>
              <?php echo form_close() ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
    <script>
      $(document).ready(function() {

        $('.btnwiwaran').click(function(e) {
          var MaxInputs = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length + 1;
          var new_row = '<tr><td><textarea class="form-control content" rows="4" name="muddha_details[]" id="content" placeholder="विवरण लेख्नुहोस"></textarea></td>' +
            '<td><button type="button" class="btn btn-outline-danger remove-wiwaran-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="हटाउनुहोस"><i class="os-icon os-icon-ui-15" ></i> हटाउनुहोस</button></td>' +
            '<tr>';
          $("#tbl_wiwaran").append(new_row);
        });
        //remove samati members.
        $("body").on("click", ".remove-wiwaran-row", function(e) {
          e.preventDefault();
          var id = $(this).data('id');
          if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
            $(this).parent().parent().remove();
          }
        });

        //upload files
        $('.btnUpload').click(function(e) {
          var MaxInputs = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length + 1;
          var new_row = '<tr class="row_mem">' +
            '<td><input type = "text" name = "doc_name[]" class="form-control"></td>' +
            '<td><input type = "file" name = "userfile[]" class="form-control" required></td>' +
            '<td><button type="button" class="btn btn-outline-danger remove-file-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title=" हटानुहोस"><i class="os-icon os-icon-ui-15" ></i> हटानुहोस</button></td>' +
            '<tr>';
          $("#frm_tbl_upload").append(new_row);
        });

        $("body").on("click", ".remove-file-row", function(e) {
          e.preventDefault();
          var id = $(this).data('id');
          if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
            $(this).parent().parent().remove();
          }
        });

        $('.btnaddNewField').click(function(e) {
          var MaxInputs = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length + 1;
          <?php if (empty($row)) : ?>
            var new_row = '<tr class="row_mem">' +
              '<td><input type="text" name="w_name[]" class="form-control" value="" required="true"></td>' +
              '<td><input type="text" name="w_address[]" class="form-control" value="" required="true"></td>' +
              '<td><input type="text" name="w_age[]" class="form-control" value="" required="true"></td>' +
              '<td><input type="text" name="w_phone[]" class="form-control" value="" required="true"></td>' +
              '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i> हटानुहोस</button></td>' +
              '<tr>';
          <?php else : ?>
            var new_row = '<tr class="row_mem">' +
              '<td><input type="text" name="w_name_new[]" class="form-control" value="" required="true"></td>' +
              '<td><input type="text" name="w_address_new[]" class="form-control" value="" required="true"></td>' +
              '<td><input type="text" name="w_age_new[]" class="form-control" value="" required="true"></td>' +
              '<td><input type="text" name="w_phone_new[]" class="form-control" value="" required="true"></td>' +
              '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i> हटानुहोस</button></td>' +
              '<tr>';
          <?php endif; ?>
          $("#frm_tbl_wit").append(new_row);
        });

        $("body").on("click", ".remove-muddha-row", function(e) {
          e.preventDefault();
          var id = $(this).data('id');
          if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
            $(this).parent().parent().remove();
          }
        });

      });
    </script>