<html>
<title><?php echo !empty($title) ? $title : SITE_OFFICE ?></title>
<meta charset="utf-8">
<meta content="ie=edge" http-equiv="x-ua-compatible">
<meta content="template language" name="keywords">
<meta content="Tamerlan Soziev" name="author">
<meta content="Admin dashboard html template" name="description">
<meta content="width=device-width, initial-scale=1" name="viewport">
<link href="<?php echo base_url() ?>assets/img/nyaik_samiti.png" rel="shortcut icon">
<link href="apple-touch-icon.png" rel="apple-touch-icon">
<link href="<?php echo base_url() ?>assets/css/main.css?version=4.4.0" rel="stylesheet">
<style>
  body {
    font-size: 22px;
    margin-bottom: 10px;
    color:#000;
  }

  /* @page {
    size: auto;
    margin: 25mm 25mm 25mm 25mm;
  } */
  
 

  .csstransforms {
    position: absolute;
    top: 290px;
    text-align: justify;
    transform-origin: 0 0;
    transform: rotate(-90deg);
    padding: 20px;
    /* margin-top: 350px; */
    width: 500px;
    margin-left: 150px;
  }

  .csstransforms-hakim {
    transform: rotate(-90deg);
  }

  .heading {
    margin-top: 570px;
  }
  
  @page {
    margin: 2cm;

    @top-center {
        content: element(pageHeader);
    }

    @bottom-center {
        content: element(pageFooter);
    }
}
@media print 
{
    @page {
      size: A4; /* DIN A4 standard, Europe */
      margin:5cm;
    }
    html, body {
        width: 210mm;
        /* height: 297mm; */
        height: 282mm;
        /*font-size: 11px;*/
        /*background: #FFF;*/
        overflow:visible;
    }
    body {
        padding-top:15mm;
    }
    
    .content {
      clear: both;
      page-break-after: always;
    }
}
  /*@media print {*/
    
  /*}*/
</style>

<body style="--bleeding: 0.5cm;--margin: 1cm;">
  <div class="row">
    <div class="col-md-12" style="margin-top: 20px;">
      <div class="csstransforms" style="margin-top: 212px;">
        <p style="text-align:center">श्री <?php echo SITE_OFFICE ?></p>
        <p><?php echo $tokaadesh['tok_aadesh'] ?></p>
        <p style="margin-left:205px; margin-top:120px;"><?php echo $aadesh_staff['name'] ?></p>
        <p style="margin-left:155px;"><?php echo $aadesh_staff['designation'] ?></p>
      </div>
    </div>
    <!-- first page  -->
    <div class="col-md-12" style="height:auto;">
      <div class=" heading">
        <p class="text-center" style="">श्री <?php echo SITE_OFFICE ?></p>
        <p class="text-center" style="margin-top:-10px;">न्यायिक समिती समक्ष पेश गरेको</p>
        <p class="text-center" style="margin-top:-10px;"><b>निवेदन पत्र</b> </p>
      </div>
      <div class="badi">
        <p style="margin-left:151.18px;text-align: justify; margin-top: 120px; margin-right:40px">
          <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo $b['b_gapa'] ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div class="text-center" style="margin-top:40px;">
        <p style="font-weight: bold;">विरुद्</p>
      </div>
      <div class="pratibadi">
        <p style="margin-left:151.18px; text-align: justify; margin-top: 80px;margin-right:40px">
          <?php if (!empty($pratibadi)) : $i = 1;
            foreach ($pratibadi as $key => $p) : ?>
              <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo $p['p_gapa'] ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div class="text-center" style="margin-top: 40px;font-weight: bold;margin-left:151.18px;margin-right:40px;">
        <p style="font-weight: bold;">विषय : <?php echo $darta_detail['case_title'] ?></p>
      </div>
      
  </div>
</body>
<script type="text/javascript">
  window.print();
</script>

</html>