<?php
class NibedanPatra extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->module_code = 'LETTER';
        $this->load->helper('text');
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function add($darta_no) {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']       = 'add';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'      => '',
                'निबेदन पत्र '    => 'Letters',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['sections']   = $this->CommonModel->getData('letters', 'DESC');

            $data['breadcrumb']             = $this->breadcrumb->output();
            $data['aanusuchi']              = $this->CommonModel->getData('letters', 'ASC');
            $data['staffs']              = $this->CommonModel->getData('staff', 'ASC');
           
            $data['darta_detail']           = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            //muddha darta details dafa 
            //$data['sarkar_dafa']            = $this->CommonModel->getWhere('muddha')
            $data['badis']                  = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['tokaadesh']              = $this->CommonModel->getWhere('tok_aadesh', array('letter_type' => 1));
            //dafas
            $data['local_dafa']             = $this->CommonModel->getData('local_dafa','DESC');
            $data['sarkar_yain']             = $this->CommonModel->getData('sarkar_yain', 'DESC');
            //pp($data['badis']);
            $data['pratibadis']             = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['anusuchis']              = $this->CommonModel->getData('letters', 'ASC');
            //वादी को विवरण 
            $data['firadpatra']             = $this->CommonModel->getAllDataByField('badi_firad_patra', 'darta_no', $darta_no);
            $data['nisa_patra']             = $this->CommonModel->getResultByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['tarik_patra']            = $this->CommonModel->getResultByMultipleCondition('anusuchi_3', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['tarik_bharpai']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_4', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['mayad_suchana']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_6', array('darta_no' => $darta_no, 'type' => 'badi'));
            //प्रतिवादी को विवरण
            $data['likhit_jawaf']           = $this->CommonModel->getAllDataByField('likhit_jawaf', 'darta_no', $darta_no);
            $data['nisa_patra_p']           = $this->CommonModel->getResultByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['tarik_patra_p']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_3', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['tarik_bharpai_p']        = $this->CommonModel->getResultByMultipleCondition('anusuchi_4', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    public function saveNibedanPatra()
    {
        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        if ($this->input->post('submit')) {
            $darta_no               = $this->input->post('darta_no');
            $nibedan_dastur         = $this->input->post('nibedan_dastur');
            $suchana_dastur         = $this->input->post('suchana_dastur');
            $pratilipi_dastur       = $this->input->post('pratilipi_dastur');
            $jamma                  = $this->input->post('jamma');
            $pana                   = $this->input->post('pana');
            $local_dafa             = $this->input->post('local_dafa');
            //$sarkar_yain            = $this->input->post('sarkar_yain');
            $staff_id               = $this->input->post('staff_id');
            $muddha_details         = $this->input->post('muddha_details');
            $details                = implode('<>', $muddha_details);
            $total_print            = $this->CommonModel->Totalprint('badi_firad_patra', $darta_no);
            $data = array(
                'darta_no'          => $darta_no,
                'muddha_id'         => $darta_no,
                'muddha_details'    => $details,
                'nibedan_dastur'    => $nibedan_dastur,
                'suchana_dastur'    => $suchana_dastur,
                'pratilipi_dastur'  => $pratilipi_dastur,
                'jamma'             => $jamma,
                'pana'              => $pana,
                'local_dafa'        => $local_dafa,
                'sarkar_yain'       => '',
                'staff_id'          => $staff_id,
                'created_on'        => convertDate(date('Y-m-d')),
                'created_by'        => $this->session->userdata('EM_USER_ID'),
                'print_count'       => $total_print + 1,
            );
            $result = $this->CommonModel->insertData('badi_firad_patra', $data);
            if ($result) {
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi              = array();
                if (!empty($w_name)) {
                    foreach ($w_name as $key => $wit) {
                        $sachi[]      = array(
                            'name'      => $w_name[$key],
                            'age'       => $w_age[$key],
                            'phone'     => $w_phone[$key],
                            'address'   => $w_address[$key],
                            'darta_no'  => $darta_no,
                            'type'      => '1',
                        );
                    }
                    $this->CommonModel->batchInsert($sachi, 'witness');
                }

                //upload
                $document_title = $this->input->post('doc_name');
                $postupload = $this->input->post('userfile');
                if (!empty($document_title)) {
                    if (!empty($_FILES['userfile']['name'])) {
                        $mypath = realpath(APPPATH . '../uploads');
                        foreach ($_FILES['userfile']['name'] as $key => $value) {
                            if ($document_title[$key] != '') {
                                $extionpart                     = pathinfo($value);
                                $user_filename                  = str_replace(' ', '_', trim($document_title[$key]) . '.' . $extionpart['extension']);
                                $system_filename                = $result . '_' . time() . '_' . $user_filename;
                            } else {
                                $user_filename                  = str_replace(' ', '_', $value);
                                $system_filename                = $result . '_' . '_' . time() . $user_filename;
                            }
                            $_FILES['uploadDocuments']              = array();
                            $_FILES['uploadDocuments']['name']      = $system_filename;
                            $_FILES['uploadDocuments']['type']      = $_FILES['userfile']['type'][$key];
                            $_FILES['uploadDocuments']['tmp_name']  = $_FILES['userfile']['tmp_name'][$key];
                            $_FILES['uploadDocuments']['error']     = $_FILES['userfile']['error'][$key];
                            $_FILES['uploadDocuments']['size']      = $_FILES['userfile']['size'][$key];
                            // Initialize the document config
                            $config['upload_path']                  = $mypath;
                            $config['allowed_types']                = 'pdf|jpg|png';
                            $config['file_name']                    = $system_filename;
                            $config['file_ext_tolower']             = TRUE;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            // Upload the document
                            if (!$this->upload->do_upload('uploadDocuments')) {
                                $docerros[$key] = array('error' => $this->upload->display_errors());
                                redirect('Darta/add' . $darta_no);
                            } else {
                                if ($document_title[$key] != '') {
                                    $doctitle = $document_title[$key];
                                } else {
                                    $extionpart = pathinfo($value);
                                    $doctitle = str_replace('_', ' ', str_replace('.' . $extionpart['extension'], '', $user_filename));
                                }
                                // set the values in the db
                                $data['documents']['darta_no']             = $darta_no;
                                $data['documents']['doc_type']             = $document_title[$key];
                                $data['documents']['doc_name']             = $system_filename;
                                $data['documents']['type']                 = 1;
                                $this->CommonModel->insertData('documents', $data['documents']);
                            }
                        }
                    }
                }
                redirect('NibedanPatra/generateFiradPatra/' . $darta_no);
            }
        }
    }
    
    //generate first page 
    public function printFirstPage() {
        $darta_no                           = $this->uri->segment(3);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
       
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
        $data['muddhadetails']              = $this->CommonModel->getDataBySelectedFields('badi_firad_patra', 'darta_no', $darta_no);
        $data['officer']                    = $this->CommonModel->getDataByID('staff', $data['muddhadetails']['officer']);
        
        $data['local_dafa']                    = $this->CommonModel->getDataByID('local_dafa', $data['muddhadetails']['local_dafa']);
        $data['sarkar_yain']                    = $this->CommonModel->getDataByID('sarkar_yain', $data['muddhadetails']['sarkar_yain']);
        $data['aadesh_staff']                    = $this->CommonModel->getDataByID('staff', $data['muddhadetails']['staff_id']);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
        $data['tokaadesh']                  = $this->CommonModel->getDataByID('tok_aadesh', 1);

        $data['witness']                    = $this->CommonModel->getResultByMultipleCondition('witness', array('darta_no' => $darta_no, 'type' => 1));
        $data['documents']                  = $this->CommonModel->getResultByMultipleCondition('documents', array('darta_no' => $darta_no, 'type' => 1));
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters', 'ASC');
        $data['workers']                    = $this->CommonModel->getData('staff', 'ASC');

        $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
        $this->load->view('firad_patra_first_page', $data);
    }
    public function generateFiradPatra()
    {
        $darta_no                           = $this->uri->segment(3);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
       
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
        $data['muddhadetails']              = $this->CommonModel->getDataBySelectedFields('badi_firad_patra', 'darta_no', $darta_no);
        $data['officer']                    = $this->CommonModel->getDataByID('staff', $data['muddhadetails']['officer']);
        
        $data['local_dafa']                    = $this->CommonModel->getDataByID('local_dafa', $data['muddhadetails']['local_dafa']);
        $data['sarkar_yain']                    = $this->CommonModel->getDataByID('sarkar_yain', $data['muddhadetails']['sarkar_yain']);
        $data['aadesh_staff']                    = $this->CommonModel->getDataByID('staff', $data['muddhadetails']['staff_id']);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
        $data['tokaadesh']                  = $this->CommonModel->getDataByID('tok_aadesh', 1);

        $data['witness']                    = $this->CommonModel->getResultByMultipleCondition('witness', array('darta_no' => $darta_no, 'type' => 1));
        $data['documents']                  = $this->CommonModel->getResultByMultipleCondition('documents', array('darta_no' => $darta_no, 'type' => 1));
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters', 'ASC');
        $data['workers']                    = $this->CommonModel->getData('staff', 'ASC');

        $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
        $this->load->view('firad_patra', $data);
    }

    //view nibedan patra
    public function view($darta_no) {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            
            $muddha_darta_no = $this->uri->segment(4);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'view';
           
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'निवेदन पत्र'
            ));
            $data['breadcrumb']             = $this->breadcrumb->output();
            $data['staffs']              = $this->CommonModel->getData('staff', 'ASC');
            $data['darta_detail']           = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badis']                  = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
           
            $data['tokaadesh']              = $this->CommonModel->getWhere('tok_aadesh', array('letter_type' => 1));
            //dafas
            $data['local_dafa']             = $this->CommonModel->getData('local_dafa', 'DESC');
            $data['sarkar_yain']             = $this->CommonModel->getData('sarkar_yain', 'DESC');
            //pp($data['badis']);
            $data['pratibadis']             = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
           
            $data['anusuchis']              = $this->CommonModel->getData('letters', 'ASC');
            //वादी को विवरण 
            $data['firadpatra']             = $this->CommonModel->getAllDataByField('badi_firad_patra', 'darta_no', $darta_no);
            $data['nisa_patra']             = $this->CommonModel->getResultByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['tarik_patra']            = $this->CommonModel->getResultByMultipleCondition('anusuchi_3', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['tarik_bharpai']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_4', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['mayad_suchana']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_6', array('darta_no' => $darta_no, 'type' => 'badi'));
            //प्रतिवादी को विवरण
            $data['likhit_jawaf']           = $this->CommonModel->getAllDataByField('likhit_jawaf', 'darta_no', $darta_no);
            $data['nisa_patra_p']           = $this->CommonModel->getResultByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['tarik_patra_p']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_3', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['tarik_bharpai_p']        = $this->CommonModel->getResultByMultipleCondition('anusuchi_4', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);

            $data['witness']                = $this->CommonModel->getResultByMultipleCondition('witness', array('darta_no' => $darta_no, 'type' => 1));
            $data['documents']              = $this->CommonModel->getResultByMultipleCondition('documents', array('darta_no' => $darta_no, 'type' => 1));

            $data['row']                    = $this->CommonModel->getWhere('badi_firad_patra', array('darta_no' => $darta_no));

            $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function updateNibedanPatra()
    {
        if ($this->input->post('submit')) {
            $data_id = $this->input->post('data_id');
            $darta_no = $this->input->post('darta_no');
            $nibedan_dastur       = $this->input->post('nibedan_dastur');
            $suchana_dastur       = $this->input->post('suchana_dastur');
            $pratilipi_dastur     = $this->input->post('pratilipi_dastur');
            $jamma                = $this->input->post('jamma');
            $pana                 = $this->input->post('pana');
            $muddha_details       = $this->input->post('muddha_details');
            $details              = implode('<>', $muddha_details);

            $local_dafa             = $this->input->post('local_dafa');
            $sarkar_yain            = $this->input->post('sarkar_yain');
            $staff_id               = $this->input->post('staff_id');

            $total_print = $this->CommonModel->Totalprint('badi_firad_patra', $darta_no);
            $data = array(
                'muddha_details'    => $details,
                'nibedan_dastur'    => $nibedan_dastur,
                'suchana_dastur'    => $suchana_dastur,
                'pratilipi_dastur'  => $pratilipi_dastur,
                'jamma'             => $jamma,
                'pana'              => $pana,
                'local_dafa'        => $local_dafa,
                'sarkar_yain'       => $sarkar_yain,
                'staff_id'          => $staff_id,
            );
            $result = $this->CommonModel->updateData('badi_firad_patra', $data_id, $data);
            if ($result) {
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi              = array();
                if (!empty($w_name)) {
                    foreach ($w_name as $key => $wit) {
                        $sachi[]      = array(
                            'id'        => $w_id[$key],
                            'name'      => $w_name[$key],
                            'age'       => $w_age[$key],
                            'phone'     => $w_phone[$key],
                            'address'   => $w_address[$key],
                        );
                    }
                    $this->CommonModel->batchUpdate('witness', $w_id, $sachi);
                }
                $w_name_new             = $this->input->post('w_name_new');
                $w_phone_new            = $this->input->post('w_phone_new');
                $w_age_new              = $this->input->post('w_age_new');
                $w_address_new          = $this->input->post('w_address_new');
                $sachi_new            = array();
                if (!empty($w_name_new)) {
                    foreach ($w_name_new as $key => $wit) {
                        $sachi_new[]      = array(
                            'name'      => $w_name_new[$key],
                            'age'       => $w_age_new[$key],
                            'phone'     => $w_phone_new[$key],
                            'address'   => $w_address_new[$key],
                            'darta_no'  => $darta_no,
                            'type'      => 1,
                        );
                    }
                    $this->CommonModel->batchInsert($sachi_new, 'witness');
                }
                redirect('NibedanPatra/view/' . $darta_no);
            }
        }
    }
   
   public function deleteWitness($id) {
        $id         = $this->uri->segment(3);
        $darta_no   = $this->uri->segment(4);
        if (empty($id)) {
            $this->session->set_flashdata('MSG_ERR', "Invalid Process");
            redirect('Darta');
        }
        $result = $this->CommonModel->deleteData('witness', $id);
        if ($result) {
            $this->session->set_flashdata('MSG_SUCCESS', "Removed Successfully");
            redirect('NibedanPatra/view/' . $darta_no);
        }
   }
}