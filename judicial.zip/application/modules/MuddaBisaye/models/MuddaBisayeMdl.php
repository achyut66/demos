<?php 

class MuddaBisayeMdl extends CI_Model {
    public function getDistinctDafa()
    {
        $this->db->select('DISTINCT(name)');
        $query = $this->db->get('dafa');
        return $query->result_array();
    }
}