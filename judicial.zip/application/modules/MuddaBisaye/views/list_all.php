<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <?php if ($this->authlibrary->HasModulePermission('MUDDHA-BISAYE', "ADD")) { ?>
                <div class="controls-above-table">
                  <div class="row">
                    <div class="col-sm-6">
                      <a class="btn btn-outline-primary" href="#onboardingFormModal" data-toggle="modal" data-url="<?php echo base_url() ?>MuddaBisaye/add" data-id=""><i class="os-icon os-icon-ui-22"></i> नयाँ प्रकार थप्नुहोस</a>
                    </div>
                  </div>
                </div>
              <?php } ?>
              <?php $success_message = $this->session->flashdata("MSG_SUCCESS");
              if (!empty($success_message)) { ?>
                <div class="alert alert-success">
                  <button class="close" data-close="alert"></button>
                  <span> <?php echo $success_message; ?> </span>
                </div>
              <?php } ?>
              <table class="table table-bordered table-striped" id="">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>दफा </th>
                    <th>उप दफा</th>
                    <th>क्र.स.</th>
                    <th>मुद्दाका प्रकार</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!empty($sections)) :
                    $i = 1;
                    foreach ($sections as $key => $value) : ?>
                      <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['dafa']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['upa_dafa']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['remarks']) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['subject']) ?></td>
                        <?php if ($this->authlibrary->HasModulePermission('MUDDHA-BISAYE', "EDIT") || $this->authlibrary->HasModulePermission('MUDDHA-BISAYE', "DELETE")) { ?>
                          <td style="width:200px">
                            <?php if ($this->authlibrary->HasModulePermission('MUDDHA-BISAYE', "EDIT")) { ?>
                              <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-info btn-sm" title="विवरण सम्पादन गर्नुहोस " data-url="<?php echo base_url() ?>MuddaBisaye/edit" data-id="<?php echo $value['id'] ?>"><i class="fa fa-pencil"></i></button>

                              <a class="btn btn-outline-danger btn-sm" data-placement="bottom" data-toggle="tooltip" title="" data-original-title=" विवरण हटानुहोस" href="<?php echo base_url() ?>MuddaBisaye/Delete/<?php echo $value['id'] ?>" onclick=" return confirm('कृपया सुनिस्चित गर्नुहोस')"><i class="os-icon os-icon-ui-15"></i></a>
                              
                            <?php } ?>

                          </td>
                        <?php } ?>
                      </tr>
                  <?php endforeach;
                  endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>