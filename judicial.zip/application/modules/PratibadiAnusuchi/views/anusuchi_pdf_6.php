dd

<!DOCTYPE html>

<html>

<head>

	<meta charset="UTF-8">

	<title><?php echo SITE_OFFICE?></title>

	<style type="text/css">

		/*table, th, td {

			border: 1px solid black;

		}*/



		/* Center tables for demo */

		table {

			margin: 0 auto;

		}



		/* Default Table Style */

		table {

			color: #333;

			background: white;

			border: 0;

			font-size: 12pt;

			border-collapse: collapse;

		}

		table thead th,

		table tfoot th {

			color: #000;

			background: rgba(0,0,0,.1);

		}

		table caption {

			padding:.5em;

		}

		table th,

		table td {

			padding: .5em;

			border: 0;

		}
    .signature{
    float: right;
    border-top: dotted 1px #000;
    width:180px;
}
.stamp{
    float: right; 
    margin-top:auto;
    border: 1px solid #555; 
    margin-left: 427px; 
    height: 140px; 
    margin-top:-102px; 
    width: 145px;
    margin-right: 40px;
}

	</style>

</head>
  <body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
    <div style="background-color: #fff;"> <!-- main content -->
      
      <div style="margin-left: 320px;">अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name'])?></div>
      <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa'])?></div>
      <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE?></div>
      <div style="margin-left: 235px;">न्यायिक समितिबाट जारी भएको <?php echo $this->mylibrary->convertedcit($letter_name['letter_type'])?></div>
      <?php 
        $year           = substr($badi[0]['b_dob'],0,4);
        $d_year         = substr($darta_detail['date'], 0,4);
        $d_month        = substr($darta_detail['date'], 5,2);
        $d_day          = substr($darta_detail['date'], 8,2);
        $current_date   = convertDate(date('Y-m-d'));
        $current_year   = substr($current_date, 0,4);
        $age            = $current_year - $year;
        $pyear          = substr($badi[0]['b_dob'],0,4);
        $pcurrent_date  = convertDate(date('Y-m-d'));
        $pcurrent_year  = substr($pcurrent_date, 0,4);
        $page           = $pcurrent_year - $pyear;
      ?>
     <?php 
        $year = substr($badi[0]['b_dob'],0,4);
        $current_date = convertDate(date('Y-m-d'));
        $current_year = substr($current_date, 0,4);
        $age = $current_year - $year;
      ?>

      <?php 
        $pyear = substr($badi[0]['b_dob'],0,4);
        $pcurrent_date = convertDate(date('Y-m-d'));
        $pcurrent_year = substr($pcurrent_date, 0,4);
        $page = $pcurrent_year - $pyear;
      ?>

      <div style="margin-left:40px; margin-right: 40px; margin-top:40px">
         <?php if(!empty($pratibadi)) : 
        foreach($pratibadi as $key => $p) : 
          $pyear = substr($p['p_dob'],0,4);
          $pcurrent_date = convertDate(date('Y-m-d'));
          $pcurrent_year = substr($pcurrent_date, 0,4);
          $page = $pcurrent_year - $pyear;
        ?>
        <?php echo $p['p_grandfather']?> को नाती <?php echo $p['p_father']?> को छोरा/छोरी <?php echo $p['p_husband_wife']?> को पति/पत्नी, <?php echo $p['p_address']?> बस्ने वर्ष 
        <?php echo $this->mylibrary->convertedcit($page)?> <?php echo $p['p_name']?><b> 
        <?php endforeach;endif;?>
      </div>

      <div style="margin-left:320px; margin-right: 40px;"> लाई </div>

      <div style="margin-left:40px; margin-right: 40px;">
        <?php if(!empty($badi)) : 
          foreach($badi as $key => $b) : 
            $byear = substr($b['b_dob'],0,4);
            $bcurrent_date = convertDate(date('Y-m-d'));
            $bcurrent_year = substr($bcurrent_date, 0,4);
            $bage = $bcurrent_year - $byear;
          ?>
          <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
          <?php echo $this->mylibrary->convertedcit($bage)?> <?php echo $b['b_name']?><b>,</b> 
        <?php endforeach;endif;?>
      </div>
         

      <div style="margin-left:40px; margin-right: 40px; margin-top: 20px;">
            
            ले यस समिति समक्ष मिति <?php echo $this->mylibrary->convertedcit($darta_detail['date'])?> मा <?php echo $this->mylibrary->convertedcit($subject['subject'])?> विषयको विवादमा नालेस दर्ता गरेको हुनाले सो नालेसको नक्कल साथै राखी यो म्याद पठाइएको छ । यो म्याद प्राप्त भएको वा तपाईंको घरमा टाँस भएको मितिले १५ (पन्ध्र) दिन भित्र यस समिति समक्ष आफ्नो भएको व्यहोरा खुलाई प्रतिवाद तयार गरी हाजिर हुन आउनुहोला वा वारेस वा कानुन व्यवसायी पठाउनुहोला । सो बमोजिम नगरी म्याद गुजारी बसेमा नालेसमा कानुन बमोजिम कारवाही हुने व्यहोरा समेत जानकारी गराइन्छ ।
      </div>

        <div style="margin-left: 40px; margin-top: 50px;"><b>म्याद जारी गर्नेको</b></div>
        <div style="margin-left: 40px;margin-top: 5px;">नामः <?php echo $anusuchi_6['worker_name']?></div>
        <div style="margin-left: 40px;margin-top: 5px;">पदः <?php echo $anusuchi_6['designation']?></div>
        <div style="margin-left: 40px;margin-top: 5px;">दस्तखतः </div>
        <div style="margin-left: 40px;margin-top: 5px;">मितिः <?php echo $this->mylibrary->convertedcit($anusuchi_6['date'])?></div>
      <!-- <div class="stamp">
        <p>पालिकाको छाप</p>
      </div> -->
    </div> <!-- end of main content -->
  </body>
</html>

