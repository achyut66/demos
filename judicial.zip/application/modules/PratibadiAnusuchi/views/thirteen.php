<style>
  ::-webkit-input-placeholder { /* Edge */
    color: red;
  }
  :-ms-input-placeholder { /* Internet Explorer */
    color: red;
  }
  ::placeholder {
    color: red;
    font-style: italic;
    text-align: center;
  }
</style>
<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp" >
                      <?php echo form_open('PratibadiAnusuchi/save_anusuchi_13', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                      <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                      <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_13)? $anusuchi_13['id']:''?>">

                      <div class="anusuchi">
                        <div class="text-center">
                          <p>अनुसूची - १३</p>
                          <p style="margin-top:-20px;">(दफा ७७ को उपदफा (१) सँग सम्बन्धित)</p>
                          <p style="margin-top:-20px;">चलन चलाउने निवेदन</p>
                          <p style="margin-top:-20px;"><?php echo SITE_OFFICE?> गाउँपालिकामा पेश गरेको</p>
                          <p style="margin-top:-20px;"> निवेदन पत्र </p>
                        </div>

                        <div class="text-center" style="margin-top: 30px">
                          <h4>मुद्दाको विषयः <?php echo $subject['subject']?></h4>
                        </div>
                        

                        <p style="margin-left:40px; margin-right: 40px;margin-top: 30px;">
                           <?php if(!empty($badi)) : 
                          foreach($badi as $key => $b) : 
                            $byear = substr($b['b_dob'],0,4);
                            $bcurrent_date = convertDate(date('Y-m-d'));
                            $bcurrent_year = substr($bcurrent_date, 0,4);
                            $bage = $bcurrent_year - $byear;
                          ?>
                          <?php echo $b['b_address']?> बस्ने वर्ष <?php echo $b['b_name']?>
                        <?php endforeach;endif;?> वादी 
                        </p>
                        <p style="margin-left:40px;"> विरुद्ध </p>
                        <p style="margin-left:40px; margin-right: 40px;">
                           <?php if(!empty($pratibadi)) : 
                          foreach($pratibadi as $key => $p) : 
                            $pyear = substr($p['p_dob'],0,4);
                            $pcurrent_date = convertDate(date('Y-m-d'));
                            $pcurrent_year = substr($pcurrent_date, 0,4);
                            $page = $pcurrent_year - $pyear;
                          ?>
                          <?php echo $p['p_address']?> बस्ने वर्ष  <?php echo $p['p_name']?><b> 
                          <?php endforeach;endif;?> प्रतिवादी
                        </p>

                        

                        <div class="text-center"><h4>मुद्दा</h4></div>

                       <!--  <p style="margin-left:40px; margin-right: 40px;">
                         प्रस्तुत विषयमा तपसिलमा उल्लेखित कागजातहरुको प्रतिलिपी साथै राखी गजुरी गाउँपालिकाको न्यायिक समिति अन्तर्गतका <input type="text" name="decision" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;"  placeholder="*" required="true" id="post" value="" > मेलमिलाप केन्द्रमा सूचीकृत भई मेलमिलाप गराउन अनुमती पाउँ भनी निवेदन गर्दछु ।
                          
                        </p> -->

                        <p style="margin-left: 40px;">म निवेदक निवेदन वापत रु <input type="text" name="dastur" id="" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" placeholder="दस्तुर *" required="true" value="<?php echo !empty($anusuchi_13)?$anusuchi_13['dastur']:'';?>" > दस्तुर साथै राखी निम्न व्यहोरा निवेदन गर्दछु ।</p>

                        <p style="margin-left: 40px;margin-right: 40px; margin-top: 30px; text-align: justify;">१) उपरोक्त विपक्षीसँगको उल्लेखित मुद्दा यस गाउँपालिकाको न्यायिक समितिबाट मिति निर्णय मिति  मा निर्णय भई उक्त घर जग्गा वा
                         <input type="text" name="details" id="" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_13)?$anusuchi_13['name']:'';?>" > 

                         मेरो हक भोग र स्वामित्वको हुने ठहर भएकोमा श्री <?php echo SITE_DISTRICT?> जिल्ला अदालतमा विपक्षीले पुनरावलोकन गरेकोमा सम्मानीत अदालतबाट समेत मिति 

                        <input type="text" name="date" id="mdate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_13)?$anusuchi_13['date']:'';?>" > 

                        मा निर्णय हुँदा न्यायिक समितिकै निर्णयलाई सदर गरी मेरै हक भोग कायम गरेको हुँदा सो मेरो हक भोगको कायम भएको सम्पत्ति रहेको हुँदा शिघ्रातिशिघ्र मलाई उक्त सम्पत्ति चलन चलाई पाउन यो निवेदन पेश गरेको छु ।</p>

                        <p style="margin-left: 40px;margin-right: 40px;">२) यसै निवेदन साथ देहायका कागजातहरु संलग्न गरेको छु ।</p>

                        <p style="margin-left: 80px;margin-right: 40px;">क) न्यायिक समितिले मिति <input type="text" name="ndate" id="ndate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_13)?$anusuchi_13['date']:'';?>" > मा गरेको निर्णयको छाँयाँकपी ।</p>

                        <p style="margin-left: 80px;margin-right: 40px;">ख) श्री <?php echo SITE_DISTRICT?> जिल्ला अदालतले गरेको मिति <input type="text" name="adate" id="adate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_13)?$anusuchi_13['date']:'';?>" > को सदर फैसलाको छाँयाँकपी ।</p>

                        <p style="margin-left: 80px;margin-right: 40px;">ग) यस विवाद सम्वद्ध मिसिल यसै कार्यालयमा रहेको छ </p>

                        <p style="margin-left: 80px;margin-right: 40px;">घ) लेखिएको व्यहोरा ठिक साँचो छ, झुठा ठहरे कानून बमोजिम सहुँला बुझाउँला ।</p>


                        <p style="margin-left: 40px; margin-top: 30px;">निवेदक</p>

                        <p style="margin-left: 40px;margin-top: -5px;">निज  <input type="text" name="name" id="" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_12)?$anusuchi_12['name']:$badi[0]['b_name'];?>" ></p>

                        <div style="margin-left: 200px;margin-right: 40px;margin-top: 50px">इति सम्वत् <?php echo $this->mylibrary->convertedcit(substr(convertDate(date('Y-m-d')), 0,4));?> साल <?php echo getNepaliMonthName(substr(convertDate(date('Y-m-d')), 5,2))?> महिला <?php echo $this->mylibrary->convertedcit(substr(convertDate(date('Y-m-d')), 8,2));?> गते रोज ...... शुभम् .................।</div>

                        <div class="text-center" style="margin-top: 60px;">
                          <hr>
                          <?php if(empty($anusuchi_13)) { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                            <?php } else { ?>
                              <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>
                              <a href ="<?php echo base_url()?>PratibadiAnusuchi/printAnusuchi_11/<?php echo $darta_detail['darta_no']?>" class="btn btn-secondary" target ="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
                            <?php } ?>
                          <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style="margin-top: -18px;"><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
                        </div>

                      </div> <!-- endof anusuchi -->
                       <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    $('.dd_select').select2();
    var mainInput = $("#mdate");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });
    var nInput = $("#ndate");
    nInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });
    var aInput = $("#adate");
    aInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

  });

</script>