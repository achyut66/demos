<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <?php echo form_open('PratibadiAnusuchi/save_anusuchi_7', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_id" value="<?php echo !empty($anusuchi_7) ? $anusuchi_7['id'] : '' ?>">

            <div class="anusuchi">
              <a href="<?php echo base_url() ?>PratibadiAnusuchi/printAnusuchi_7/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>
              <div class="text-center">
                <p>अनुसूची-७</p>
                <p style="margin-top:-20px;">(दफा ४२ को उपदफा (१) सँग सम्बन्धित)</p>
                <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE ?></p>
                <p style="margin-top:-20px;">न्यायिक समितिबाट भएको निर्णय</p>
              </div>

              <?php if (!empty($badi)) :
                foreach ($badi as $key => $b) :
              ?>
                  <p style="margin-left: 40px; margin-top: 30px;"> <?php echo $b['b_name'] ?>,<?php echo SITE_DISTRICT ?> जिल्ला <?php echo SITE_OFFICE ?> <?Php echo $b['b_address'] ?></p>
              <?php endforeach;
              endif; ?>
              <?php if (!empty($pratibadi)) :
                foreach ($pratibadi as $key => $p) :
              ?>
                  <p style="margin-left: 40px;"> <?Php echo $p['p_address'] ?>, <?php echo SITE_DISTRICT ?> <?php echo SITE_OFFICE ?> <?php echo $p['p_name'] ?> </p>
              <?php endforeach;
              endif; ?>

              <p style="margin-left: 40px;">
                विवादको विषयः <?php echo  $this->mylibrary->convertedcit($subject['subject']) ?>
              </p>

              <p style="margin-left: 40px;">
                नालेस दर्ता नम्बरः <?php echo  $this->mylibrary->convertedcit($darta_detail['darta_no']) ?>
              </p>

              <p style="margin-left: 40px;margin-right: 40px;">
                स्थानीय सरकार संचालन ऐन २०७४ को दफा ४७ (१) ञ वमोजिम निवेदन दर्ता भई सोही ऐनको दफा ४६ वमोजिम गठन भएको न्यायिक समिति समक्ष प्रस्तुत हुन आएको मुद्दाको संक्षिप्त तथ्य र निर्णय यस प्रकार छः

              <table class="table table-borderless" id="frm_tbl_wit" style="margin-left: 30px;">
                <tbody>
                  <?php if (!empty($anusuchi_7)) : ?>
                    <?php $decision = explode('<>', $anusuchi_7['details_decision']);
                    if (!empty($decision)) :
                      foreach ($decision as $key => $des) : ?>
                        <tr>
                          <td>
                            <p>संक्षिप्त तथ्य र निर्णय <span style="color:red">*</span>
                              <textarea style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 500px; " required="true" name="decision[]" value=""><?php echo $des ?></textarea>
                              <button type="button" style="border: none;background: none" class=" btn btn-danger remove-row" data-placement="top" data-toggle="tooltip" title="" data-original-title="संक्षिप्त तथ्य र निर्णय हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button>

                              <?php if ($key == 0) : ?>
                                <button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="संक्षिप्त तथ्य र निर्णय थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button>
                              <?php endif; ?>

                            </p>
                          </td>
                        </tr>
                    <?php endforeach;
                    endif; ?>
                  <?php else : ?>
                    <tr>
                      <td>
                        <p>संक्षिप्त तथ्य र निर्णय <span style="color:red">*</span>
                          <textarea style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 500px; " required="true" name="decision[]" value=""></textarea>
                          <button type="button" style="border: none;background: none" class=" btn btn-outline-success btnaddNewField" data-placement="top" data-toggle="tooltip" title="" data-original-title="सदस्य थप्नुहोस"><i class="fa fa-plus-circle" style="color:#000;"></i></button>
                        </p>
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              </p>
              <p style="margin-left: 40px;margin-right: 40px;">समितिको निर्णयः<span style="color:red">*</span>

                <textarea name="samiti_decision" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;width: 530px; " required="true" id="post" value=""><?php echo $anusuchi_7['samiti_decision'] ?></textarea>
              </p>

              <p style="margin-left: 40px;margin-right: 40px;">तपसिल</p>
              <p style="margin-left: 80px;margin-right: 40px;">१. सरोकारवालाले नक्कल माग गर्न आएमा नियमानुसार दस्तुर लिई नक्कल दिनु ।</p>
              <p style="margin-left: 80px;margin-right: 40px;">२. यस न्यायिक समितिको निर्णयमा चित्त नबुझे ३५ दिनभित्र .<?php echo SITE_OFFICE ?> जिल्ला अदालतमा पुनरावेदन गर्न जानु भनि प्रत्यर्थीलाई सुनाईदिनु ।</p>
              <p style="margin-left: 80px;margin-right: 40px;">३. म्याद भित्र पुनरावेदन नपरेमा कानून वमोजिम निर्णय कार्यान्वयन गर्नु र गराउनु । </p>

              <div class="text-center" style="margin-top: 60px;">
                <hr>

                <?php if (empty($anusuchi_7)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

                <?php } ?>

                <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
              </div>
            </div>
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
    $('.dd_select').select2();
    // var mainInput = $("#mdate");
    // mainInput.nepaliDatePicker({
    //     ndpYear: true,
    //     ndpMonth: true,
    //     ndpYearCount: 100,
    //     disableAfter: GetCurrentBsDate
    // });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url: base_url + 'Anusuchi/getWorkers',
        method: "POST",
        data: {
          workers_id: workers_id
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });

    $('.btnaddNewField').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      <?php if (empty($anusuchi_7)) : ?>
        var new_row = '<tr class="row_mem">' +
          '<td>मुद्दाको संक्षिप्त तथ्य र निर्णय <span style="color:red">*</span><textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 500px; " required="true" id="post" value="" ></textarea><button type="button" style="border: none;background: none" class=" btn btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="संक्षिप्त तथ्य र निर्णय हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>' +
          '<tr>';
      <?php else : ?>
        var new_row = '<tr class="row_mem">' +
          '<td>मुद्दाको संक्षिप्त तथ्य र निर्णय <span style="color:red">*</span><textarea name="decision[]" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;    width: 500px; " required="true" id="post" value="" ></textarea><button type="button" style="border: none;background: none" class=" btn btn-danger remove-row" data-placement="top" data-toggle="tooltip" title=""data-original-title="संक्षिप्त तथ्य र निर्णय हटानुहोस"><i class="fa fa-times-circle" style="color:red;"></i></button></td>' +
          '<tr>';
      <?php endif; ?>
      $("#frm_tbl_wit").append(new_row);
    });

    $("body").on("click", ".remove-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

  });
</script>