<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <?php echo form_open('PratibadiAnusuchi/save_anusuchi_3', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal')); ?>
          <div class="element-box-tp">
            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
            <input type="hidden" name="anusuchi_3_id" value="<?php echo !empty($anusuchi_3) ? $anusuchi_3['id'] : '' ?>">

            <div class="anusuchi">
              <a href="<?php echo base_url() ?>PratibadiAnusuchi/printAnusuchi_3/<?php echo $darta_detail['darta_no'] ?>" class="btn btn-secondary" target="_blank"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</a>

              <div class="text-center">
                <p>अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa']) ?></p>
                <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type']) ?></p>
                <p style="margin-top:-20px;">न्यायिक समिति</p>
              </div>

              <div class="text-center" style="margin-top:50px;">
                <p><?php echo $this->mylibrary->convertedcit(SITE_OFFICE) ?>मा </p>
                <p style="margin-top:-20px;">खडा गरिएको तारक भरपाई</p>
              </div>

              <div class="form-border">
                <p style="margin-left: 40px; margin-top:70px;"><?php echo $badi[0]['b_name'] ?> (वादी)</p>
                <p style="margin-left: 480px; margin-top:-50px;">मुद्दा नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no']) ?></p>

                <p style="float:right; margin-right: 100px;margin-top: -44px;"><?php echo !empty($pratibadi[0]['p_name']) ? $pratibadi[0]['p_name'] . ' (प्रतिवादी)' : 'प्रतिवादीको विवरण दाखिला गरिएको छैन' ?></p>
              </div>

              <div class="text-center" style="margin-top:80px;">
                <p>मुद्दा: <?php echo $darta_detail['case_title'] ?></p>
              </div>

              <div class="form-border ">
                मिति <?php echo $this->mylibrary->convertedcit($likhit_jawaf['miti']) ?> मा प्रतिउत्तर दर्ता हुदाँ मिति <input type="text" name="mdate" id="mdate" class="borderlessinput" required="true" value="<?php echo !empty($anusuchi_3) ? $anusuchi_3['date_1'] : convertDate(date('Y-m-d')) ?>">
                <input type="text" name="details" id="details" class="borderlessinput" required="true" value="<?php echo !empty($anusuchi_3) ? $anusuchi_3['details'] : '' ?>" style="width:400px;" placeholder="क काम गर्ने उल्लेख गर्नुहोस*" required>
                को काम हुने भएकोले सोहि दिन<br><br>
                <input type="text" name="sdate" id="sdate" class="borderlessinput" required="true" value="<?php echo !empty($anusuchi_3) ? $anusuchi_3['detail_1'] : ''; ?>" placeholder="समय*"> बजे यस न्यायिक समिति कार्यालयमा उपस्थित हुनेछु भनिसहिछाप गर्ने
              </div><br>
              <div>
                प्रतिवादी: <?php echo $pratibadi[0]['p_name'] ?>
              </div>

              <div class="text-center" style="margin-top: 60px;">
                <hr>
                <?php if (empty($anusuchi_3)) { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php } else { ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सम्पादन गर्नुहोस </button>

                <?php } ?>
                <!-- <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button> -->
              </div>

            </div>
          </div>
          <?php echo form_close() ?>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
    var mainInput = $("#mdate");
    //var smainInput = $("#sdate");
    mainInput.nepaliDatePicker({
      ndpYear: true,
      ndpMonth: true,
      ndpYearCount: 100,
      disableAfter: GetCurrentBsDate
    });

    // smainInput.nepaliDatePicker({
    //     ndpYear: true,
    //     ndpMonth: true,
    //     ndpYearCount: 100,
    //     disableAfter: GetCurrentBsDate
    // });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url: base_url + 'BadiAnusuchi/getWorkers',
        method: "POST",
        data: {
          workers_id: workers_id
        },
        success: function(resp) {
          if (resp.status == 'success') {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });
  });
</script>