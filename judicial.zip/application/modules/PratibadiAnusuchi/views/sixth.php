<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp" >
                      <?php echo form_open('PratibadiAnusuchi/save_anusuchi_6', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal'));?>
                      <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no']?>">
                      <input type="hidden" name="anusuchi_6_id" value="<?php echo !empty($anusuchi_6)? $anusuchi_6['id']:''?>">

                      <div class="anusuchi" style="height: 900px;">
                        
                        <div class="text-center">
                          <p>अनुसूची–<?php echo $this->mylibrary->convertedcit($letter_name['letter_name'])?></p>
                          <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa'])?></p>
                          <p style="margin-top:-20px;">श्री <?php echo SITE_OFFICE?></p>
                          <p style="margin-top:-20px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type'])?></p>
                        </div>


                        <?php 
                          $year = substr($badi[0]['b_dob'],0,4);
                          $current_date = convertDate(date('Y-m-d'));
                          $current_year = substr($current_date, 0,4);
                          $age = $current_year - $year;
                        ?>

                         <?php 
                          $pyear = substr($badi[0]['b_dob'],0,4);
                          $pcurrent_date = convertDate(date('Y-m-d'));
                          $pcurrent_year = substr($pcurrent_date, 0,4);
                          $page = $pcurrent_year - $pyear;
                        ?>

                        <p style="margin-left:40px; margin-right: 40px;">
                           <?php if(!empty($pratibadi)) : 
                          foreach($pratibadi as $key => $p) : 
                            $pyear = substr($p['p_dob'],0,4);
                            $pcurrent_date = convertDate(date('Y-m-d'));
                            $pcurrent_year = substr($pcurrent_date, 0,4);
                            $page = $pcurrent_year - $pyear;
                          ?>
                          <?php echo $p['p_grandfather']?> को नाती <?php echo $p['p_father']?> को छोरा/छोरी <?php echo $p['p_husband_wife']?> को पति/पत्नी, <?php echo $p['p_address']?> बस्ने वर्ष 
                          <?php echo $this->mylibrary->convertedcit($page)?> <?php echo $p['p_name']?><b> 
                          <?php endforeach;endif;?>
                        </p>

                        <p class="text-center"> लाई </p>

                        <p style="margin-left:40px; margin-right: 40px;">
                           <?php if(!empty($badi)) : 
                          foreach($badi as $key => $b) : 
                            $byear = substr($b['b_dob'],0,4);
                            $bcurrent_date = convertDate(date('Y-m-d'));
                            $bcurrent_year = substr($bcurrent_date, 0,4);
                            $bage = $bcurrent_year - $byear;
                          ?>
                          <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
                          <?php echo $this->mylibrary->convertedcit($bage)?> <?php echo $b['b_name']?><b>,</b> 
                        <?php endforeach;endif;?>
                        </p>
                       

                        <p style="margin-left:40px; margin-right: 40px;">
                          
                          ले यस समिति समक्ष मिति <?php echo $this->mylibrary->convertedcit($darta_detail['date'])?> मा <?php echo $this->mylibrary->convertedcit($subject['subject'])?> विषयको विवादमा नालेस दर्ता गरेको हुनाले सो नालेसको नक्कल साथै राखी यो म्याद पठाइएको छ । यो म्याद प्राप्त भएको वा तपाईंको घरमा टाँस भएको मितिले १५ (पन्ध्र) दिन भित्र यस समिति समक्ष आफ्नो भएको व्यहोरा खुलाई प्रतिवाद तयार गरी हाजिर हुन आउनुहोला वा वारेस वा कानुन व्यवसायी पठाउनुहोला । सो बमोजिम नगरी म्याद गुजारी बसेमा नालेसमा कानुन बमोजिम कारवाही हुने व्यहोरा समेत जानकारी गराइन्छ ।
                        </p>

                        <!-- <h4 class="text-center" ><b>विवादको विषयः <span style="text-decoration: underline;"><?php echo $subject['subject']?></span></b></h4><br>
                        <?php if(!empty($badi)) {
                            $total_badi = count($badi);
                            if($total_badi >= 1 ) {
                              $sombodan = 'हामी';
                            } else {
                              $sombodan = 'म';
                            }
                        } ?>
                        <p style="margin-left:40px; margin-right: 40px;">
                        १. <?php echo $sombodan?> वादीहरुलाई माथि उल्लेख भए बमोजिमका विपक्षीहरुले अन्याय गर्नु भएको हुनाले उक्त विवादको विषय उपर मुद्दा हेर्न मिल्ने यस <?php echo SITE_OFFICE?>को न्यायिक समिति समक्ष कानुन बमोजिमको हद म्याद भित्र प्रस्तुत नालेस लिई आएको छु / आएका छौं । कानुन बमोजिम लाग्ने 

                         <p class="text-left" style="margin-left:40px;margin-right: 40px;">वादी श्री <?php echo $badi[0]['b_name']?> ले मिति <?php echo $this->mylibrary->convertedcit($darta_detail['date'])?> मा <?php echo $pratibadi[0]['p_name']?> को विरुद्धमा <?php echo $subject['subject']?> विषयमा दर्ता गरेको नालेस यस समितिको दर्ता नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?>  मा दर्ता भएकाले यो भर्पाई दिइएको छ । -->


                          <div class="text-left">

                            <p style="margin-left:40px; font-size: 18px;margin-top: 40px;"><b>म्याद जारी गर्नेको</b></p>
                            <p style="margin-left:40px;">नामः<span style="color:red">*</span> 
                              <select class="" style="border: none; background: none;border-bottom: 1px solid #000" required="true" id="workers" name="staff_id">
                                <option value="">कर्मचारी छानुहोस</option>
                                <?php if(!empty($workers)) : 
                                  foreach($workers as $staff) : ?>
                                  <option value="<?php echo $staff['id']?>"
                                    <?php if(!empty($anusuchi_6)) : ?>
                                      <?php if($staff['id'] == $anusuchi_6['staff_id']){ echo 'selected';}?>
                                      <?php endif;?>
                                    ><?php echo $staff['name']?></option>
                              <?php endforeach; endif;?>
                            </select></p>


                            <input type="hidden" name="worker_name" value="<?php echo !empty($anusuchi_6)?$anusuchi_6['worker_name']:''?>" id="worker_name">
                            <p style="margin-left:40px;">पदः<span style="color:red">*</span> <input type="text" name="worker_deg" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" id="post" value="<?php echo !empty($anusuchi_6)?$anusuchi_6['designation']:''?>" ></p>
                            <p style="margin-left:40px;">दस्तखतः</p>
                            <p style="margin-left:40px;">मितिः<span style="color:red">*</span> <input type="text" name="date" id="mdate" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;" required="true" value="<?php echo !empty($anusuchi_6)?$anusuchi_6['date']:convertDate(date('Y-m-d'))?>"  name="date"></p>
                          </div>
                        <!--   <div class="stamp">
                            <p>पालिकाको छाप</p>
                          </div> -->

                          <div class="text-center" style="margin-top: 60px;">
                            <hr>
                            <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                        </div>
                      </div>
                       <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    $('.dd_select').select2();
    var mainInput = $("#mdate");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

    $('#workers').change(function() {
      var workers_id = $(this).val();
      $.ajax({
        url:base_url+'BadiAnusuchi/getWorkers',
        method:"POST",
        data: {workers_id:workers_id},
        success:function(resp){
          if(resp.status == 'success' ) {
            $('#post').val(resp.deg);
            $('#worker_name').val(resp.name);
          }
        }
      });
    });
  });

</script>