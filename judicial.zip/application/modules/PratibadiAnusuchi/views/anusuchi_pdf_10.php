dd

<!DOCTYPE html>

<html>

<head>

	<meta charset="UTF-8">

	<title><?php echo SITE_OFFICE?></title>

	<style type="text/css">

		/*table, th, td {

			border: 1px solid black;

		}*/



		/* Center tables for demo */

		table {

			margin: 0 auto;

		}



		/* Default Table Style */

		table {

			color: #333;

			background: white;

			border: 0;

			font-size: 12pt;

			border-collapse: collapse;

		}

		table thead th,

		table tfoot th {

			color: #000;

			background: rgba(0,0,0,.1);

		}

		table caption {

			padding:.5em;

		}

		table th,

		table td {

			padding: .5em;

			border: 0;

		}
    .signature{
    float: right;
    border-top: dotted 1px #000;
    width:180px;
}
.stamp{
    float: right; 
    margin-top:auto;
    border: 1px solid #555; 
    margin-left: 427px; 
    height: 140px; 
    margin-top:-102px; 
    width: 145px;
    margin-right: 40px;
}

	</style>

</head>
  <body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
    <div style="background-color: #fff;"> <!-- main content -->
      <div style="margin-left: 320px;">अनुसूची-<?php echo $this->mylibrary->convertedcit($letter_name['letter_name'])?></div>
      <div style="margin-left: 240px;"><?php echo $this->mylibrary->convertedcit($letter_name['dafa'])?></div>
      <div style="margin-left: 280px;top:-30px;">श्री <?php echo SITE_OFFICE?></div>
      <div style="margin-left: 225px;"><?php echo $this->mylibrary->convertedcit($letter_name['letter_type'])?></div>

      <div style="margin-left: 40px; margin-top: 30px;"><?php echo SITE_OFFICE?> <?php echo $this->mylibrary->convertedcit($letter_name['letter_type'])?></div>
      
      <div style="margin-left:40px; margin-right: 40px;">
        <?php if(!empty($badi)) : 
          foreach($badi as $key => $b) : 
            $byear = substr($b['b_dob'],0,4);
            $bcurrent_date = convertDate(date('Y-m-d'));
            $bcurrent_year = substr($bcurrent_date, 0,4);
            $bage = $bcurrent_year - $byear;
            ?>
            <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
            <?php echo $this->mylibrary->convertedcit($bage)?> को  <?php echo $b['b_name']?> निवेदक (प्रथम पक्ष)
          <?php endforeach;endif;?>
        </div>
        <div style="margin-left: 320px;"><p>विरुद्ध</p></div>
        <div style="margin-left:40px; margin-right: 40px;">
          <?php if(!empty($pratibadi)) : 
            foreach($pratibadi as $key => $p) : 
              $pyear = substr($p['p_dob'],0,4);
              $pcurrent_date = convertDate(date('Y-m-d'));
              $pcurrent_year = substr($pcurrent_date, 0,4);
              $page = $pcurrent_year - $pyear;
              ?>
              <?php echo $b['b_grandfather']?> को नाती <?php echo $b['b_father']?> को छोरा/छोरी <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
              <?php echo $this->mylibrary->convertedcit($bage)?> को  <?php echo $b['b_name']?> (दोस्रो पक्ष)
            <?php endforeach;endif;?>
          </div>
          <div style="margin-left: 252px;">
            <p>विवादको विषयः <?php echo $subject['subject']?> </p>
          </div>

      <div style="margin-left:40px; margin-right: 40px; margin-top: 30px;">
     हामी निवेदक निम्न लिखित निवेदन गर्दछौः
      <?php if(!empty($anusuchi_10)) :
        $decision = explode('<>', $anusuchi_10['details_decision']);
        if(!empty($decision)) :
          $i = 1; 
          foreach($decision as $des) : ?>
          <div style="margin-top:10px;"><?php echo $this->mylibrary->convertedcit($i++)?>) <?php echo $des;?></div>
      <?php endforeach;endif;?>
    <?php endif;?>
   </div>
    <div style="margin-left: 250px; margin-top: 50px;">निवेदकहरुको नाम, थर तथा दस्तखत</div>
    <div style="margin-left: 50px; margin-top:30px;">
      <?php if(!empty($badi)) :
        foreach($badi as $key => $b) : ?> 
          <div  style="margin-left:50px;">
            वादी: <?php echo $b['b_name']?>
          </div>
          <div  style="margin-left: 50px;">
            दस्तखतः
          </div>
        <?php endforeach;endif;?>
      </div>

    <div style="margin-left:250px;">
      <?php if(!empty($pratibadi)) :
        foreach($pratibadi as $key => $p) : ?> 
        <div  style="margin-left:218px; margin-top: -39px;">
        प्रतिवादी: <?php echo $p['p_name']?>
        </div>
        <div  style="margin-left: 218px;">
        दस्तखतः
        </div>
      <?php endforeach;endif;?>
    </div>

    <div style="margin-left: 80px;margin-right: 40px;margin-top: 150px">इति सम्वत् <?php echo $this->mylibrary->convertedcit(substr($anusuchi_10['date'], 0,4));?> साल <?php echo substr($anusuchi_10['date'], 5,2)?> महिना <?php echo $this->mylibrary->convertedcit(substr($anusuchi_10['date'], 8,2));?> गते रोज ...... शुभम् .................।</div>
  </body>
</html>

