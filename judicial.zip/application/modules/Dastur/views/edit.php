<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    नयाँ मुद्दाको विषय थप्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>
  
   <form action="<?php echo base_url()?>Dastur/Update" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <input type="hidden" name="id" value="<?php echo $row['id']?>">
    <table class="table table table-padded" id="frm_tbl_mem">
        <tbody>
          <tr class="row_mem">
            <td>1.</td>
            <td><textarea class="form-control" placeholder="बापत" name="bapat"><?php echo $row['bapat']?></textarea></td>
            <td><input class="form-control" placeholder="दस्तुर/रकम" type="text" name="rate" required="true" value="<?php echo $row['rate']?>"></td>
            <td><textarea class="form-control" placeholder="कैफियत" name="remarks"><?php echo $row['remarks']?></textarea></td>
          </tr>
        </tbody>
    </table>
      <button class="btn btn-primary btn-block btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
  </form>
</div>