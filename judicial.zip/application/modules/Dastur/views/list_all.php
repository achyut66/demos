<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <?php if($this->authlibrary->HasModulePermission('DASTUR', "ADD")) { ?>
                <div class="controls-above-table">
                    <div class="row">
                        <div class="col-sm-6">
                            <a class="btn btn-outline-primary" href="#onboardingFormModal" data-toggle="modal" data-url="<?php echo base_url()?>Dastur/add" data-id = ""><i class="os-icon os-icon-ui-22" ></i> नयाँ विषय थप्नुहोस</a>
                        </div>
                    </div>
                </div>
              <?php } ?>
              <table  class="table table-bordered table-stripe">
                <thead>
                  <tr>
                    <th text-aligh="right">क्र.स.</th> 
                    <th>बापत</th>
                    <th>दस्तुर/रकम</th>
                    <th>कैफियत</th>
                    <th>#</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(!empty($sections)) :
                    $i = 1;
                    foreach($sections as $key => $value) : ?>
                      <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['bapat'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['rate'])?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['remarks'])?></td>
                        <?php if($this->authlibrary->HasModulePermission('DASTUR', "EDIT") || $this->authlibrary->HasModulePermission('DASTUR', "DELETE") ) { ?>
                          <td class="center hidden-phone">
                            <?php if($this->authlibrary->HasModulePermission('DASTUR', "EDIT")) { ?>
                              <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-info btn-sm" title="" data-url="<?php echo base_url()?>Dastur/edit" data-id = "<?php echo $value['id']?>"><i class="fa fa-pencil"></i></button>
                            <?php } ?>

                            <?php if($this->authlibrary->HasModulePermission('DASTUR', "EDIT")) { ?>
                              <a href="<?php echo base_url()?>Dastur/Delete/<?php echo $value['id']?>" class="btn btn-outline-danger btn-sm" onclick ="return Confirm('Are you sure? Data connot be recovered.')"><i class="os-icon os-icon-ui-15"></i></a>
                            <?php } ?>
                            
                         </td>
                       <?php } ?>
                     </tr>
                    <?php endforeach;endif; ?>
                 </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>