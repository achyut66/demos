<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box">
                        <?php echo form_open('Users/EditUserPerm/'.$this->uri->segment(3), array('name'=>'EditUserPerm', 'id'=>'EditUserPerm', 'method'=>'post', 'class'=>'form-horizontal'));?>
                        <div class="controls-above-table">
                          <div class="row">
                            <div class="col-sm-6">EDIT USER PERMISSION</div>
                              <div class="col-sm-6">
                               <span class="tools pull-right">
                                <button type="submit" class="btn btn-success" name="Submit" value="Submit"><i class="fa fa-check-circle"></i> Save</button>
                                <a href="<?php echo base_url()?>Users" id="cancelgroup_button" class="btn btn-danger" style="color: #fff"><i class="fa fa-times-circle"></i> Cancel</a>
                              </span>
                              </div>
                          </div>
                        </div>
                            <?php 
                            $user_id = $this->uri->segment(3);
                            $userpermissions = '';
                            $checkCount = 0;
                            $moduleCount = 0;
                            if ($parentmodules) {
                            //---------------------Start Parent Menu Access---------------------------------    
                              $userpermissions .= '<table cellpadding="5" cellspacing="0" border="0" width="100%" class="table table-striped table-bordered table-hover">
                              <tbody>
                              <tr>
                              <td colspan="100%" align="right"><a href="javascript:void(0);" data-id="group-select-all" data-type="all" class="btn btn-info btn-sm green"><i class="fa fa-check-circle"></i> All</a>&nbsp;<a href="javascript:void(0);" data-id="group-select-all" data-type="none" class="btn btn-danger btn-sm red"><i class="fa fa-times-circle"></i> None</a></td>
                              </tr>';

                              foreach ($parentmodules as $parent_module_rows => $parent_module_row ):
                                if($parent_module_rows>0){
                                  break;
                                }
                                $userpermissions .= '<tr>';
                                $userpermission = $this->Usersmodel->checkuser_perm($parent_module_row->menuid, 1, $user_id);
                                $checkbox_id = $parent_module_row->menuid ."_1";
                                if($userpermission)
                                  $checked = "checked";
                                else
                                  $checked = "";

                                $grouppermission = $this->Usersmodel->checkgroup_permision($parent_module_row->menuid, 1, $group_id);
                                if($grouppermission)
                                  $permitted = '<span class="glyphicon glyphicon-ok-sign" data-toggle="tooltip" title="Published"></span>';
                                else
                                  $permitted = '<span class="glyphicon glyphicon-remove-sign" data-toggle="tooltip" title="Unpublished"></span>';
                                $class = 'group-select-all group-select-'.$checkCount.'';
                                $checkbox = form_input(array('type'=>'checkbox','name'=>'chk_permission[]', 'id'=>'chk_permission', 'value'=> $checkbox_id, $checked=>$checked, 'class'=>$class));
                                $ck = 'group-select-'.$checkCount;

                                $qrymodules = $this->Usersmodel->listmodule($parent_module_row->menuid);
                                if ($qrymodules) {
                                  $countval = 1;
                                  $userpermissions .= '<tr>';
                                  foreach ($qrymodules as $module_row):
                                    $userpermissions .= '
                                    <td>'. $module_row->menu_name . '</td>';
                                    $qryuseraction = $this->Usersmodel->listuseraction();
                                    if($qryuseraction){
                                      foreach ($qryuseraction as $action_row):
                                        $userpermission = $this->Usersmodel->checkuser_perm($module_row->menuid, $action_row->user_action_id, $user_id);
                                        $checkbox_id = $module_row->menuid ."_". $action_row->user_action_id;
                                        if($userpermission)
                                          $checked = "checked";
                                        else
                                          $checked = "";

                                        $grouppermission = $this->Usersmodel->checkgroup_permision($module_row->menuid, $action_row->user_action_id, $group_id);
                                        if($grouppermission)
                                          $permitted = '<span class=""> <i class="fa fa-check" style="color:green"></i> </span>';
                                        else
                                          $permitted = '<span class=""> <i class="fa fa-times" style="color:red"></i> </span>';
                                        $class = 'group-select-all group-select-'.$checkCount.' module-select-'.$moduleCount;
                                        $checkbox = form_input(array('type'=>'checkbox','name'=>'chk_permission[]', 'id'=>'chk_permission', 'value'=> $checkbox_id, $checked=>$checked , 'class'=>$class));

                                        $userpermissions .= '<td>'. $permitted . '&nbsp;&nbsp;' .  $action_row->user_action_name. '&nbsp;&nbsp;' .$checkbox .'</td>';
                                      endforeach;
                                    }
                                    $mk = 'module-select-'.$moduleCount;
                                    $userpermissions .= '<td align="right"><a data-id="'.$mk.'" data-type="all" href="javascript:void(0);" class="btn btn-sm btn-warning"><i class="fa fa-check-circle"></i> All</a>&nbsp;<a data-id="'.$mk.'" data-type="none" href="javascript:void(0);" class="btn btn-circle btn-sm btn-danger"><i class="fa fa-times-circle"></i> None</a></td>';
                                    $userpermissions .= '</tr>';
                                    $moduleCount++;
                                  endforeach;
                                }
                                $countval++;
                                $checkCount++;
                                $userpermissions .="</tbody>";
                              endforeach;
                              $userpermissions .="</table>";
                            }
                            echo $userpermissions;
                            ?>

                            <?php echo form_close();?>
                          
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>