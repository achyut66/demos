<div class="content-i">

    <div class="content-box">

        <div class="element-wrapper">

            <div class="element-box-tp">

                <?php echo form_open('Users/SaveUsers', array('name'=>'SaveUsers', 'id'=>'SaveUsers', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>

                <div class="form-desc">

                  कृपया <span class="text-danger">&nbsp;*</span> चिन्न भएको ठाउँ खाली नछोड्नु होला |

                </div>


                <div class="form-group row">

                    <label class="col-form-label col-sm-4" for=""><span

                        class="text-danger">&nbsp;*</span>भूमिका</label>

                    <div class="col-sm-8">

                        <select class="form-control" name="group" id="role">

                            <option value="">छानुहोस</option>

                            <?php if(!empty($groups)) :

                                foreach($groups as $group) : ?>

                                    <option value="<?php echo $group->groupid?>"><?php echo $group->group_name?></option>

                            <?php endforeach;endif?>

                        </select>

                    </div>
                </div>
                

                <div class="samiti_row">
                   
                </div>
                

                </form>

            </div>

        </div>

    </div>

</div>

<script type="text/javascript">
    $(document).ready(function() {
         $(".select2").select2({             
            placeholder: "छान्नुहोस्"               
        });
        $('#role').change( function() {
            var role = $(this).val();
            $.ajax({
                url:base_url+'Users/getUserForm',
                method:"POST",
                data:{role:role},
                beforeSend: function () {
                  $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
                },
                success : function(resp) {
                    $('.samiti_row').html(resp);
                }
            });
        });

       

    });
</script>

<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>