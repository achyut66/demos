<div class="content-i">

    <div class="content-box">

         <div class="row">

            <div class="col-sm-12">

                <div class="element-wrapper">

                    <div class="element-box">

                        <!--------------------

                          START - Controls Above Table

                          -------------------->

                        <div class="controls-above-table">

                          <div class="row">

                              <div class="col-sm-6">

                                  <a class="btn btn-primary btn-sm" href="<?php echo base_url()?>Users/Add"><i class="os-icon os-icon-ui-22"></i><span>नयाँ प्रोयोगकर्ता थप्नुहोस</span></a>

                              </div>

                          </div>

                        </div>

                        <!--------------------

                          END - Controls Above Table

                          ------------------          -->

                        <!--------------------

                          START - Table with actions

                          ------------------  -->

                        <div class="table-responsive">

                         <table id="dataTable1" class="table table-lightbordered">
                            <thead>
                              <tr>
                                <th> # </th>
                                <th> नाम </th>
                                <th> पद </th>
                                <th> इमेल </th>
                                <th> सम्पर्क नं </th>
                                <th> भूमिका </th>
                                <th>ID</th>
                                <th>आवस्था</th>
                                <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT', 'EDIT') && $this->authlibrary->HasModulePermission($this->module_code,'DELETE')){?>
                                  <th>Action</th>
                                <?php }?>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $i=1; 
                              if ($users) {
                                foreach ($users as $user) { ?>
                                  <tr>
                                    <td><?php echo $i++;?></td>
                                    <td><?php echo $user->FullName; ?></td>
                                    <td><?php echo $user->designation; ?></td>
                                    <td><?php echo $user->Email; ?></td>
                                    <td><?php echo $user->contact_no; ?></td>
                                    <td><?php echo $user->group_name; ?></td>
                                    <td><?php echo $user->UserName; ?></td>
                                    <td><a href="<?php echo base_url()?>Users/ChangeStatus/<?php echo $user->ID?>" onclick="return confirm('Are you sure?')" class="btn <?php if($user->Status== 'Active'){echo 'btn-success';} else{echo 'btn-danger';} ?> btn-sm"><?php echo $user->Status;?></a></td>
                                    <?php if($this->authlibrary->HasModulePermission($this->module_code, 'EDIT') || $this->authlibrary->HasModulePermission($this->module_code,'DELETE')){?>
                                    <td class="row-actions">
                                            <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT','EDIT')){ ?>
                                              <a href="<?php echo base_url();?>Users/EditUser/<?php echo $user->ID;?>"  class="" data-placement="bottom" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्"><i class="fa fa-edit"></i> </a>
                                          <?php } ?>
                                          <?php if($this->authlibrary->HasModulePermission('USER-MANAGEMENT','DELETE')){ ?>
                                             <a href="<?php echo base_url()?>Users/EditUserPerm/<?php echo $user->ID?>"  class="" data-placement="bottom" data-toggle="tooltip" title="" type="button" data-original-title="अनुमति सम्पादन गर्नुहोस्"><i class="fa fa-file"></i> </a>
                                          <?php } ?>
                                      </td>
                                      <?php } ?>
                                  </tr>
                              <?php } } ?>
                            </tbody>
                          </table>
                        </div>
                        <!--------------------
                          END - Table with actions
                          -------------------->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>