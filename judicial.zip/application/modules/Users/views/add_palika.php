<?php if($role == 3 ) { ?>
<div class="form-group row">
    <label class="col-form-label col-sm-4" for="samiti_name">समितिको नाम<span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
        <select class="form-control select2" name="samiti_name" id="samiti_name" >
            <option value="">select</option>
            <?php if(!empty($samiti)) : 
                foreach($samiti as $sami) : ?>
                    <option value="<?php echo $sami['id']?>"><?php echo $sami['name']?></option>
            <?php endforeach;endif;?>
        </select>
    </div>
</div>

<div class="form-group row">
    <label class="col-form-label col-sm-4" for="">पधकारीको नाम <span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
        <select class="form-control select2" name="member_name" id="member_name" >
            <option value="">select</option>
        </select>
    </div>
</div>
<div class="form-group row">
    <label class="col-sm-4 col-form-label">नाम<span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
        <input type="text" class="form-control" name="name" required="true" id="mem_name"> 
    </div>
</div>
<?php } ?>

<?php if($role != 3) { ?>
<div class="form-group row">
    <label class="col-sm-4 col-form-label">नाम<span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
        <input type="text" class="form-control" name="name" required="true"> 
    </div>
</div>
<?php } ?>


<div class="form-group row">
    <label class="col-sm-4 col-form-label">पद<span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
        <input type="text" class="form-control" name="designation" required="true" id="pad"> 
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-4 col-form-label">सम्पर्क नं<span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
        <input type="text" class="form-control" name="contact_no" required="true" id="contact_no">
    </div>
</div>

<div class="form-group row">
    <label class="col-form-label col-sm-4" for=""><span class="text-danger">&nbsp;*</span>इमेल</label>
    <div class="col-sm-8">
        <input type="text" id="email" class="form-control" name="email" required="true">
    </div>
</div>

<div class="form-group row">
    <label class="col-form-label col-sm-4" for="">प्रयोगकर्ता इड(username)<span class="text-danger">&nbsp;*</span></label>
    <div class="col-sm-8">
       <input type="text" class="form-control" name="username" required="true">
    </div>
</div>

<div class="form-group row">
    <label class="col-sm-4 col-form-label">पासवोर्ड<span class="text-danger">&nbsp;*</span> </label>
    <div class="col-sm-8">
        <input type="password" class="form-control" name="password" required="true">
    </div>
</div>
<div class="form-group row">
    <label class="col-sm-4 col-form-label">पासवोर्ड सुनिश्चित</label>
    <div class="col-sm-8">
        <div class="input-group">
            <input type="password" class="form-control" name="cpassword" required="true">
        </div>
    </div>
</div>

<div class="form-buttons-w text-center">
    <button type="submit" class='btn btn-submit btn-primary btn-block  save_btn' name="submit">सम्पादन गर्नुहोस्</button>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $(".select2").select2({             
            placeholder: "छान्नुहोस्"               
        });
        
        $('#samiti_name').change( function() {
            var samiti_name = $(this).val();
            $.ajax({
                url:base_url+'Users/getSamitiMember',
                method:"POST",
                data:{samiti_name:samiti_name},
                beforeSend: function () {
                  $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
                },
                success : function(resp) {
                    if(resp.status == 'success') {
                        $('#member_name').html(resp.option);
                    }
                }
            });
        });


        //member_name 
        $('#member_name').change( function() {
            var member_name = $(this).val();
            $.ajax({
                url:base_url+'Users/getsamitiMemberDetail',
                method:"POST",
                data:{member_name:member_name},
                beforeSend: function () {
                  $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
                },
                success : function(resp) {
                    if(resp.status == 'success') {
                        $('#mem_name').val(resp.name);
                        $('#pad').val(resp.pad);
                        $('#contact_no').val(resp.mobile);
                        $('#email').val(resp.email);
                    }
                }
            });
        });

    });
</script>