<div class="content-i">

    <div class="content-box">

        <div class="element-wrapper">

            <div class="element-box">

                <?php echo form_open('Users/updateUser', array('name'=>'EditUserPerm', 'id'=>'EditUserPerm', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>

                    <input type="hidden" name="id" value="<?php echo $query->ID?>">

                <div class="form-desc">

                  कृपया <span class="text-danger">&nbsp;*</span> चिन्न भएको ठाउँ खाली नछोड्नु होला |

                </div>

                <div class="form-group row">
                    <label class="col-form-label col-sm-4" for=""><span

                        class="text-danger">&nbsp;*</span>भूमिका</label>

                        <div class="col-sm-8">

                            <select class="form-control" name="group">

                                <option value="">छानुहोस</option>

                                <?php if(!empty($groups)) :

                                    foreach($groups as $group) : ?>

                                        <option value="<?php echo $group->groupid?>" <?php if($group->groupid = $query->UserGroup){ echo 'selected';}?>><?php echo $group->group_name?></option>

                                <?php endforeach;endif?>

                            </select>

                        </div>

                </div>
                <div class="form-group row">

                    <label class="col-form-label col-sm-4" for=""> नाम<span

                        class="text-danger">&nbsp;*</span></label>

                    <div class="col-sm-8">

                        <input type="text" class="form-control" name="name" required="true" value="<?php echo $query->FullName?>">

                    </div>

                </div>

                <div class="form-group row">

                    <label class="col-sm-4 col-form-label">पद<span

                        class="text-danger">&nbsp;*</span></label>

                    <div class="col-sm-8">

                        <input type="text" class="form-control" name="designation" required="true" value="<?php echo $query->designation?>">

                    </div>

                </div>
                 


                    <div class="form-group row">

                        <label class="col-sm-4 col-form-label">सम्पर्क नं<span

                        class="text-danger">&nbsp;*</span></label>

                        <div class="col-sm-8">

                            <input type="text" class="form-control" name="contact_no" required="true" value="<?php echo $query->contact_no?>">

                        </div>

                    </div>



                    <div class="form-group row">

                        <label class="col-form-label col-sm-4" for=""><span

                        class="text-danger">&nbsp;*</span>इमेल</label>

                        <div class="col-sm-8">

                            <input type="text" id="email" class="form-control" name="email" required="true" value="<?php echo $query->Email?>">

                        </div>

                    </div>
                    <div class="form-group row">

                        <label class="col-form-label col-sm-4" for="">प्रयोगकर्ता इड(username)<span

                        class="text-danger">&nbsp;*</span></label>

                        <div class="col-sm-8">

                            <input type="text" class="form-control" name="username" required="true" value="<?php echo $query->UserName?>">

                        </div>

                    </div>



                    <div class="form-group row">

                        <label class="col-form-label col-sm-6" for=""><input class="form-check-input show_change_password" name="change_password" type="checkbox" id="autoSizingCheck" value="1"> पासवोर्ड परिवर्तन  <br></label>

                        

                    </div>



                    <div id="change_password">

                        <div class="row">

                          <div class="col-md-6">

                            <div class="form-group">

                              <label class="control-label">पासवोर्ड</label>

                              <input type="password" class="form-control" name="password">

                          </div>

                      </div>

                      <div class="col-md-6">

                        <div class="form-group">

                          <label class="control-label">पासवोर्ड सुनिश्चित </label>

                          <input type="password" class="form-control" name="cpassword">

                      </div>

                  </div>

              </div>

              

          </div>



                <div class="form-buttons-w">

                    <button type="submit" class='btn btn-submit btn-primary save_btn' name="submit">सम्पादन गर्नुहोस्</button>

                </div>

                </form>

            </div>

        </div>

    </div>

</div>

<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>

<script type="text/javascript">

  $(document).ready(function(){

    $('#change_password').hide();



    $('.show_change_password').click(function(){

      //var change_password = $(this).val();

      if ($(this).prop('checked')) {

        $('#change_password').show();

      } else {

        $('#change_password').hide();

      }

    });

  });

</script>