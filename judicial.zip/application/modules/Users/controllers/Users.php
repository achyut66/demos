<?php
/**
 * Created By: Binod sunar
 */
class Users extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Usersmodel');
        $this->load->model('CommonModel');
        $this->module_code = 'MANAGE-USERS';
        if ($this->authlibrary->IsLoggedIn() == false) {
            $this->session->set_flashdata('MSG_ERR_LOGIN', 'You have to Login First');
            redirect('Login');
        }
    }
    public function Index()
    {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'VIEW')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            redirect('Users/ListAll', 'location');
        }
    }
    public function ListAll()
    {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'VIEW')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $data['users']      = $this->Usersmodel->listUser();
            $data['title']      = 'प्रोयोगकर्ता';
            $data['pageTitle']  = 'प्रोयोगकर्ता';
            $data['page']       = 'list';
            $data['script']     = 'listscript';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'प्रोयोगकर्ताको सुची'         => 'Users/ListAll',
                'सुची'
                ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $this->load->vars($data);
            $this->load->view('main');
        }
    }

    public function Add()
    {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'ADD')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        }   else {
                $data['title']                          = 'Add New User';
                $data['subtitle']                       = '';
                $data['pageTitle']                      = 'Add New User';
                $data['script']                         =  'addscript';
                $this->breadcrumb->populate(array(
                  'ड्यासबोर्ड'                                => '',
                  'प्रोयोगकर्ता'                               => 'Users/ListAll',
                  'नयाँ थप्नुहोस'
                ));
                $data['groups']                         = $this->Usersmodel->listgroup();
                $data['samiti']                         = $this->CommonModel->getData('samati_name');
                $data['provinces']                      = $this->CommonModel->getData('provinces', 'DESC');
                $data['districts']                      = getDistricts();
                $data['breadcrumb']                     = $this->breadcrumb->output();
                $data['page']                           = 'add';
                $this->load->vars($data);
                $this->load->view('main');
        }
    }

    public function SaveUsers() {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('name',       'नाम', 'trim|required');
            $this->form_validation->set_rules('designation','पद', 'trim|required');
            $this->form_validation->set_rules('email',      'इमेल', 'trim|required|valid_email');
            $this->form_validation->set_rules('contact_no', 'सम्पर्क नं', 'trim|required');
            $this->form_validation->set_rules('username',   'प्रयोगकर्ता इड(username)', 'trim|required');
            $this->form_validation->set_rules('password',   'पासवोर्ड', 'trim|required');
            if($this->form_validation->run() == false) {
                $errors = array();
                // Loop through $_POST and get the keys
                foreach ($this->input->post() as $key => $value)
                {
                    // Add the error message for this field
                    $errors[$key]   = form_error($key);
                }
                $err['errors']      = array_filter($errors); // Some might be empty
                $response           = array(
                    'status'                => 'v_errors',
                    'validation_errors'     => $err['errors'],
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $userexits = checkUserExits($this->input->post('username'));
            if($userexits == 1 ) {
                $response = array(
                    'status'      => 'error',
                    'data'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग .गरिएको छ.[user name must be unique]',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            if($this->input->post('password') != $this->input->post('cpassword')) {
                $response = array(
                    'status'      => 'error',
                    'data'     => 'password do not match. [Confirm password should match with password]',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $value['details']['UserGroup']            = $this->input->post('group');
            $value['details']['FullName']             = $this->input->post('name');
            $value['details']['UserType']             = $this->input->post('group');
            $value['details']['UserName']             = $this->input->post('username');
            $value['details']['Email']                = $this->input->post('email');
            $value['details']['Status']               = '1';
            $value['details']['TPID']                 = !empty($this->input->post('samiti_name'))?$this->input->post('samiti_name'):'su';
            $value['details']['Password']             = md5($this->input->post('password'));
            $value['details']['designation']          = $this->input->post('designation');
            $value['details']['contact_no']           = $this->input->post('contact_no');
            $value['details']['created_at']           = date('Y-m-d');
            $value['details']['created_by']           = $this->session->userdata('EM_USER_ID');
            $value['details']['created_ip']           = $this->input->ip_address();
           
            $result                                   = $this->Usersmodel->insertuser($value['details']);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'Users/ListAll',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('NO DIRECT SCRIPT ALLOWED!!!');
        }

    }

    public function EditUser()
    {
        if (!$this->authlibrary->HasModulePermission($this->module_code, 'EDIT')) {
            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");
            redirect('Dashboard');
        } else {
            $id = $this->uri->segment(3);
            $data['query']      = $this->Usersmodel->getUserData($id);
           // pp($data['query']);
            $data['groups']     = $this->Usersmodel->listgroup();
            //$data['samiti']     = $this->CommonModel->getData('samati_name');
            $this->breadcrumb->populate(array(
                'Home'          => '',
                'Users'         => 'Users/ListAll',
                'Edit'
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['title']      = 'Edit User Details';
            $data['pageTitle']  = 'Edit User Details';
            $data['page']       = 'edit';
            $data['script']     = 'editscript';
            $this->load->vars($data);
            $this->load->view('main');
        }
    }
    public function updateUser() {
        if ($this->input->is_ajax_request()) {
            $role = $this->input->post('group');
            $this->form_validation->set_rules('group',       'भूमिका', 'trim|required');
            if($role != 3 ) {
                $this->form_validation->set_rules('name',       'नाम', 'trim|required');
                $this->form_validation->set_rules('designation','पद', 'trim|required');
                $this->form_validation->set_rules('email',      'इमेल', 'trim|required|valid_email');
                $this->form_validation->set_rules('contact_no', 'सम्पर्क नं', 'trim|required');
               
                if($this->input->post('change_password') == 1) {
                    $this->form_validation->set_rules('password',   'पासवोर्ड', 'trim|required');
                }
            }
            $this->form_validation->set_rules('username',   'प्रयोगकर्ता इड(username)', 'trim|required');
            if($this->form_validation->run() == false) {
                $errors = array();
                // Loop through $_POST and get the keys
                foreach ($this->input->post() as $key => $value)
                {
                    // Add the error message for this field
                    $errors[$key]   = form_error($key);
                }
                $err['errors']      = array_filter($errors); // Some might be empty
                $response           = array(
                    'status'                => 'v_errors',
                    'validation_errors'     => $err['errors'],
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $userdetails = $this->Usersmodel->getUserData($this->input->post('id'));
            if($this->input->post('username') != $userdetails->UserName ) {
                $userexits = checkUserExits($this->input->post('username'));
                if($userexits == 1 ) {
                    $response = array(
                        'status'      => 'error',
                        'message'     => 'प्रयोगकर्ता इड(username) पहिलेनै प्रोयोग गरिएको छ',
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            }

            if($this->input->post('change_password') == 1){
                if($this->input->post('password') != $this->input->post('cpassword')) {
                    $response = array(
                        'status'      => 'error',
                        'message'     => 'password do not match. [Confirm password should match with password]',
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            }
            $value['details']['UserGroup']            = $this->input->post('group');
            if($role != 3) {
                $value['details']['FullName']             = $this->input->post('name');
                $value['details']['UserType']             = $this->input->post('group');
                $value['details']['UserName']             = $this->input->post('username');
                $value['details']['Email']                = $this->input->post('email');
                $value['details']['designation']          = $this->input->post('designation');
                $value['details']['contact_no']           = $this->input->post('contact_no');

            }
            if(!empty($this->input->post('password'))) { 
                $value['details']['Password']         = md5($this->input->post('password'));
            }
            $value['details']['modified_at']          = date('Y-m-d');
            $value['details']['modified_by']          = $this->session->userdata('EM_USER_ID');
            $value['details']['modified_ip']          = $this->input->ip_address();
            $result                                   = $this->Usersmodel->updateuser($this->input->post('id'), $value['details']);
            if($result) {
                $response = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url().'Users/ListAll',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('NO DIRECT SCRIPT ALLOWED!!!');
        }
    }
    public function EditUserPerm()
    {

        if (!$this->authlibrary->HasModulePermission($this->module_code, 'EDIT')) {

            $this->session->set_flashdata("MSG_ERR_AUTH_ACCESS", "Unauthorized Access to Restricted Module!");

            redirect('Dashboard');

        } else {

            if ($this->input->post('Submit')) {

                $chk_permission             = $this->input->post('chk_permission');

                $login_id                   = $this->session->userdata('EM_USER_ID');

                $user_id                    = $this->uri->segment(3);

                $this->Usersmodel->updateuser_perm($chk_permission, $user_id, $login_id);

                $this->session->set_flashdata('MSG_SUC_ADD', 'User Permission Saved Successfully.');

                redirect('Users/EditUserPerm/'.$user_id, 'location');

            } else {

                $user_id                    = $this->uri->segment(3);

                $group_id                   = $this->Usersmodel->getgroupid($user_id);

                $parentmodules              = $this->Usersmodel->listmodule();

                $this->breadcrumb->populate(array(

                'Home'                      => '',

                'Users'                     => 'Users/ListAll',

                'Edit User Permission'      => 'EditUserPerm'

              ));

                $data['breadcrumb']         = $this->breadcrumb->output();

                $data['group_id']           = $group_id;

                $data['parentmodules']      = $parentmodules;

                $data['pageTitle']          = 'Edit User Permission';

                $data['title']              = 'Edit User Permission';

                $data['script']             = 'editpermscript';

                $data['page']               = 'edituserperm';

                $this->load->vars($data);

                $this->load->view('main');

            }

        }

    }

    public function generateStrongPassword($length = 9, $add_dashes = false, $available_sets = 'luds')
    {

        $sets = array();

        if (strpos($available_sets, 'l') !== false) {

            $sets[] = 'abcdefghjkmnpqrstuvwxyz';

        }

        if (strpos($available_sets, 'u') !== false) {

            $sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';

        }

        if (strpos($available_sets, 'd') !== false) {

            $sets[] = '23456789';

        }

        if (strpos($available_sets, 's') !== false) {

            $sets[] = '!@#$%&*?';

        }

        $all = '';

        $password = '';

        foreach ($sets as $set) {

            $password .= $set[array_rand(str_split($set))];

            $all .= $set;

        }

        $all = str_split($all);

        for ($i = 0; $i < $length - count($sets); $i++) {

            $password .= $all[array_rand($all)];

        }

        $password = str_shuffle($password);

        if (!$add_dashes) {

            return $password;

        }

        $dash_len = floor(sqrt($length));

        $dash_str = '';

        while (strlen($password) > $dash_len) {

            $dash_str .= substr($password, 0, $dash_len) . '-';

            $password = substr($password, $dash_len);

        }

        $dash_str .= $password;

        return $dash_str;

    }

    public function getUserForm() {
        if($this->input->is_ajax_request()) {
            $role           = $this->input->post('role');
            $data['role']   = $role;
            $data['samiti'] = $this->CommonModel->getData('samati_name');
            $view           = $this->load->view('add_palika', $data);
        }
    }

    public function getSamitiMember() {
        if($this->input->is_ajax_request()) {
            $samiti_id = $this->input->post('samiti_name');
            $data = $this->CommonModel->getAllDataByField('meeting_members','samiti_id',$samiti_id);
            if(!empty($data)){
                $option = '';
                $option .= '<option value="">छान्नुहोस्</option>';
                foreach ($data as $key => $value) :
                  $option .= "<option value = '".$value['id']."'>".$value['name']."</option>";
                endforeach;
                $response = array(
                  'status'      => 'success',
                  'option' => $option,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        }
    }

    //getsamitiMemberDetail
    public function getsamitiMemberDetail() {
        if($this->input->is_ajax_request()) {
            $member_name = $this->input->post('member_name');
            $data = $this->CommonModel->getDataByID('meeting_members',$member_name);
           // pp($data);
            if(!empty($data)){
                $pad        = $data['designation'];
                $name       = $data['name'];
                $email      = $data['email'];
                $mobile     = $data['mobile'];
                $response   = array(
                  'status'  => 'success',
                  'name'    => $name,
                  'pad'     => $pad,
                  'email'   => $email,
                  'mobile'  => $mobile,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        }
    }

    public function ChangeStatus() {
        $userid = $this->uri->segment(3);
        $userdata = $this->Usersmodel->getUserData($userid);
        if($userdata->Status == 'Active') {
            $status ="Inactive";
        } else {
            $status = 'Active';
        }
        $value['details']['Status'] = $status;
        $result                     = $this->Usersmodel->updateuser($userid, $value['details']);
        if($result) {
            $this->session->set_flashdata('MSG_SUC','Status has been changed Successfully');
            redirect('Users');
        }
    }

}

