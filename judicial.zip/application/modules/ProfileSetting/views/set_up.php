<div class="content-i">
    <div class="content-box">
        <div class="element-wrapper">
            <div class="element-box-tp">
                <form class="save_post" action="<?php echo base_url()?>ProfileSetting/save" method="post">
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                <div class="form-desc">
                  कृपया <span class="text-danger">&nbsp;*</span> चिन्न भएको ठाउँ खाली नछोड्नु होला |
                </div>
                <input type="hidden" name="id" value="<?php echo !empty($profile['id'])?$profile['id']:''?>">
                <div class="form-group row">
                    <label class="col-form-label col-sm-4" for=""> प्रदेश<span
                        class="text-danger">&nbsp;*</span></label>
                    <div class="col-sm-8">
                     <select class="form-control select2" name="state_np">
                        <?php if(!empty($states)) :
                            foreach($states as $state) : ?>
                                <option value="<?php echo $state['Title']?>" <?php if($profile['state_np'] == $state['Title']){echo 'selected';}?>><?php echo $state['Title']?></option>
                            <?php endforeach;endif;?>
                            <option></option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">जिल्ला<span
                        class="text-danger">&nbsp;*</span></label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <select class="form-control select2" name="district_np">
                                <?php if(!empty($districts)) :
                                    foreach($districts as $d) : ?>
                                        <option value="<?php echo $d['name']?>" <?php if($d['name'] == $profile['district_np']){ echo 'selected';}?>><?php echo $d['name']?></option>
                                    <?php endforeach;endif;?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">पालिकाको नाम<span
                        class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                             <select class="form-control select2" name="palika_name_np">
                                <?php if(!empty($locals)) :
                                    foreach($locals as $l) : ?>
                                        <option value="<?php echo $l['name']?>" <?php if($profile['palika_name'] == $l['name']){ echo 'selected';}?>><?php echo $l['name']?></option>
                                    <?php endforeach;endif;?>
                                    <option></option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-sm-4" for=""><span
                        class="text-danger">&nbsp;*</span>कार्यालयको ठेगाना</label>
                        <div class="col-sm-8">
                          <input type="text" name="office_address" class="form-control" required value="<?php echo !empty($profile['office_address'])?$profile['office_address']:''?>" />
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-sm-4" for="">गाउँ/नगर  कार्यपालिका<span
                        class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                          <input type="text" name="karay_palika_np" class="form-control" required value="<?php echo !empty($profile['karay_palika_np'])?$profile['karay_palika_np']:''?>" />
                        </div>
                    </div>
                  <div class="form-group row">
                    <label class="col-sm-4 col-form-label">नेपाल सरकारको  लोगो<span
                        class="text-danger">&nbsp;*</span> </label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="file" name="sarkar_logo" class="form-control" <?php if(empty($profile['id'])){echo 'required';}?> />
                        </div>
                        <input type="hidden" name="old_sarkar_logo" value="<?php echo $profile['sarkar_logo']?>">

                        <?php if(!empty($profile['id'])):?>
                            <img src="<?php echo base_url()?>uploads/<?php echo $profile['sarkar_logo']?>" style="height:50px;width:50px;">
                        <?php endif;?>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">पालिकाको लोगो</label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="file" name="palika_logo" class="form-control" <?php if(empty($profile['palika_logo'])){echo 'required';}?>/>
                        </div>
                        <input type="hidden" name="old_palika_logo" value="<?php echo $profile['palika_logo']?>">
                        <?php if(!empty($profile['palika_logo'])):?>
                            <img src="<?php echo base_url()?>uploads/<?php echo $profile['palika_logo']?>" style="height:50px;width:50px;"><br>
                            <a href="<?php echo base_url()?>ProfileSetting/RemovePalikaLogo" style="color:red" onclick="return confirm('Are you sure?')"><i class="fa fa-trash" ></i> REMOVE</a>
                        <?php endif;?>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">पालिकाको नारा(slogan)</label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="text" name="palika_slogan" class="form-control" required  value="<?php echo $profile['palika_slogan']?>" />
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">website</label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="text" name="website" class="form-control" value="<?php echo $profile['website']?>" required />
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">phone no<span
                                class="text-danger">&nbsp;*</span></label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="number" name="phone_no" class="form-control" required value="<?php echo $profile['phone_no']?>" />
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Email<span
                                class="text-danger">&nbsp;*</span></label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="email" name="email" class="form-control" value="<?php echo $profile['email']?>" required />
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Facebook</label>
                    <div class="col-sm-8">
                        <div class="input-group">
                            <input type="text" name="facebook" class="form-control" value="<?php echo $profile['facebook']?>" required />
                        </div>
                    </div>
                </div>

                <div class="form-buttons-w">
                     <button type="submit" class='btn btn-block btn-submit btn-primary save_btn' name="submit">सम्पादन
                                    गर्नुहोस्
                                </button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>