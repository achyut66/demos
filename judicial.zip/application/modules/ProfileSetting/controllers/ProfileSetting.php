<?php
class ProfileSetting extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("ProfileSetupModel");
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
       // if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
        $data['page'] = 'set_up';
        $this->breadcrumb->populate(array(
            'ड्यासबोर्ड'      => '',
            'पलिकाको प्रोफाइल'       => 'ProfileSetting',
        ));
        $data['breadcrumb'] = $this->breadcrumb->output();
        $data['page_title'] = 'पलिकाको प्रोफाइल ';
        $data['states']     = $this->CommonModel->getData('provinces','DESC');
        $data['districts']  = $this->CommonModel->getData('settings_district','DESC');
        $data['locals']     = $this->CommonModel->getData('settings_vdc_municipality','DESC');
        $data['profile']    = $this->CommonModel->getDataBySelectedFields('set_up','id',1);
        $this->load->view('main', $data);
        // } else {
        //     $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
        //     redirect('Dashboard');
        // }
    }
    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function save() {
        if($this->input->is_ajax_request()) {

            $id                     = $this->input->post('id');
            $palika_logo            = $_FILES['palika_logo']['name'];
            $sarkar_logo            = $_FILES['sarkar_logo']['name'];
            $old_palika_logo        = $this->input->post('old_palika_logo');
            $old_sarkar_logo        = $this->input->post('old_sarkar_logo');
            $upload_path            = "uploads/";

            if(!empty($_FILES['palika_logo']['name'])) {
                $p_logo = $palika_logo;
            } else {
                $p_logo = $old_palika_logo;
            }

            if(!empty($_FILES['sarkar_logo']['name'])) {
                $s_logo = $sarkar_logo;
            } else {
                $s_logo = $old_sarkar_logo;
            }
            if(!empty($_FILES['palika_logo']['name'])) {
                $config = array(
                    'upload_path'=>$upload_path,
                    'allowed_types'=> "jpg|png|gif|PNG|png",
                    'overwrite' => TRUE,
                    'file_name' => $p_logo,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if(!$this->upload->do_upload('palika_logo')) {
                    $error =  'Could Not upload'.$this->upload->display_errors();
                    $this->session->set_flashdata('ERR_UPLOAD',$error);
                    redirect('SiteSetting/editSiteSetting');
                } else{
                    $this->upload->do_upload();
                }
            }

            if(!empty($_FILES['sarkar_logo']['name'])) {
                $config = array(
                    'upload_path'=>$upload_path,
                    'allowed_types'=> "jpg|png|gif|PNG|png",
                    'overwrite' => TRUE,
                    'file_name' => $s_logo,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if(!$this->upload->do_upload('sarkar_logo')) {
                    $error =  'Could Not upload'.$this->upload->display_errors();
                    $this->session->set_flashdata('ERR_UPLOAD',$error);
                    redirect('SiteSetting/editSiteSetting');
                } else{
                    $this->upload->do_upload();
                }
            }

            $this->form_validation->set_rules('palika_name_np',     'palika_name_np', 'required');
            $this->form_validation->set_rules('karay_palika_np',    'karay_palika_np', 'required');
            $this->form_validation->set_rules('state_np',           'state_np', 'required');
            $this->form_validation->set_rules('karay_palika_np',    'karay_palika_np', 'required');
            $this->form_validation->set_rules('district_np',        'district_np', 'required');
            $this->form_validation->set_rules('palika_slogan',      'palika_slogan', 'required');
            $this->form_validation->set_rules('phone_no',           'phone_no', 'required');
            $this->form_validation->set_rules('email',              'email', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => validation_errors(),
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $data = array(
                'palika_name'           => $this->input->post('palika_name_np'),
                'karay_palika_np'       => $this->input->post('karay_palika_np'),
                'state_np'              => $this->input->post('state_np'),
                'district_np'           => $this->input->post('district_np'),
                'office_address'        => $this->input->post('office_address'),
                'sarkar_logo'           => $s_logo,
                'palika_logo'           => $p_logo,
                'palika_slogan'         => $this->input->post('palika_slogan'),
                'website'               => $this->input->post('website'),
                'phone_no'              => $this->input->post('phone_no'),
                'email'                 => $this->input->post('email'),
                'facebook'              => $this->input->post('facebook'),
                'created_at'            => date('Y-m-d h:i:sa')
            );
            if(empty($id)) {
                $result = $this->CommonModel->insertData('set_up',$data);
                if($result) {
                    $response = array(
                        'status'      => 'success',
                        'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'     => 'success'
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }  
            } else {
                $result = $this->CommonModel->UpdateData('set_up',$id, $data);
                if($result) {
                    $response = array(
                        'status'      => 'success',
                        'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'     => 'success'
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            }
        }
    }

    public function RemovePalikaLogo() {
        $result = $this->ProfileSetupModel->update_palika_logo();
        if($result == 1) {
            $this->session->set_flashdata('MSG_SUC_ADD', 'updated Successfully');
            redirect('ProfileSetting');
        } else {
            $this->session->set_flashdata('MSG_SUC_ADD', 'Error');
            redirect('ProfileSetting');
        }
    }
}