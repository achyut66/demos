<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <?php if ($this->authlibrary->HasModulePermission('LOCAL-DAFA', "ADD")) { ?>
                <div class="controls-above-table">
                  <div class="row">
                    <div class="col-sm-6">
                      <a class="btn btn-outline-primary" href="#onboardingFormModal" data-toggle="modal" data-url="<?php echo base_url() ?>LocalDafa/add" data-id=""><i class="os-icon os-icon-ui-22"></i> नयाँ थप्नुहोस</a>
                    </div>
                  </div>
                </div>
              <?php } ?>
              <?php if (!empty($this->session->flashdata('MSG_SUCCESS'))) { ?>
                <div class="alert alert-warning alert-dismissible fade showr">
                  <?php echo $this->session->flashdata('MSG_SUCCESS') ?>
                </div>
              <?php } ?>
              <table class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th text-aligh="right">#</th>
                    <th>कार्यविधिको दफा</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!empty($sections)) :
                    $i = 1;
                    foreach ($sections as $key => $value) : ?>
                      <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['details']) ?></td>
                        <?php if ($this->authlibrary->HasModulePermission('LOCAL-DAFA', "EDIT") || $this->authlibrary->HasModulePermission('MUDDHA-BISAYE', "DELETE")) { ?>
                          <td style="width:200px;">
                            <?php if ($this->authlibrary->HasModulePermission('LOCAL-DAFA', "EDIT")) { ?>
                              <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-info btn-sm" title="" data-url="<?php echo base_url() ?>localDafa/edit" data-id="<?php echo $value['id'] ?>"><i class="fa fa-pencil"></i> </button>
                            <?php } ?>

                            <?php if ($this->authlibrary->HasModulePermission('LOCAL-DAFA', "EDIT")) { ?>
                              <a class="btn btn-outline-danger btn-sm" title="" href="<?php echo base_url() ?>localDafa/Delete/<?php echo $value['id'] ?>"><i class="fa fa-trash"></i> </a>
                            <?php } ?>

                          </td>
                        <?php } ?>
                      </tr>
                  <?php endforeach;
                  endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>