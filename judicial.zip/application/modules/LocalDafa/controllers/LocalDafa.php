<?php
class LocalDafa extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->module_code = 'DAFA';
        if(!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login','location');
        }
    }

    /**
        * This function list all the land minimun rate
        * @param NULL
        * @return void

     */
    public function Index()
    {
        if($this->authlibrary->HasModulePermission($this->module_code, "VIEW")){
            $data['page']       = 'list_all';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'      => '',
                'स्थानिय न्यायिक कार्यविधिको दफा'   => 'LocalDafa',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['sections']   = $this->CommonModel->getData('local_dafa','DESC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS','तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
        * On ajax call load view
        * @param  NULL
        * @return void
     */
    public function add() {
        $data['pageTitle'] = "बैठक समितिको पद थप्नुहोस";
        $this->load->view('add', $data);
    }

    /**
        * Call on ajax request
        * save fiscal year
        * @return NULL
     */
    public function save() {
        if($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('dafa[]', 'dafa', 'required');
            if($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'validation_errors'     => 'कृपया * चिन्न लागेको ठाउँ खाली भएको हुनाले सभ हुन असफल भयो',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $dafa       = $this->input->post('dafa');
            $post       = array();
            if(!empty($dafa)) {
                foreach ($dafa as $key => $indexv) {
                    $post[]    = array(
                        'details'     => $dafa[$key],                         
                    );
                }
               $result = $this->CommonModel->batchInsert($post, 'local_dafa');
                if($result) {
                    $response = array(
                        'status'        => 'success',
                        'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url().'LocalDafa',
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "Fail",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            } 
        } else {
            exit('no direct script allowed');
        }
    }

     /**
        * On ajax call load view
        * @param  $id $_POST['id']
        * @return void
     */
    public function edit() {
        $id             = $this->input->post('id');
        $data['row']    = $this->CommonModel->getDataByID('local_dafa',$id);
        $this->load->view('edit',$data);
    }

    /**
        * This function on ajaxcall update land area type data
        * @param  $_POST
        * @return json response
     */
    public function Update() {
        if($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->form_validation->set_rules('dafa', 'name', 'required');
            if($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => '<div class="alert alert-danger">'.validation_errors().'</div>',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data = array(
                'details'    => $this->input->post('dafa'),
            );
            $result = $this->CommonModel->UpdateData('local_dafa',$id,$post_data);
            if($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } 
        } else {
                exit('no direct script allowed');
        }
    }

    /**
        * This function delete data from database.
        * check proper id is in format of not.
        * @param $id int pk
        * @return boolean.
     */
    public function Delete($id) {
        $result = $this->CommonModel->deleteData('local_dafa',$id);
        if($result) {
            $this->session->set_flashdata('MSG_SUCCESS', 'successfully deleted');
            redirect('LocalDafa');
        }
            

        //     if($result) {
        //         $response = array(
        //             'status'      => 'success',
        //             'data'         => "सफलतापूर्वक हटाइयो",
        //             'message'     => 'success'
        //         );
        //         header("Content-type: application/json");
        //         echo json_encode($response);
        //         exit;
        //     } else {
        //         $response = array(
        //             'status'      => 'error',
        //             'data'         => "Oops something goes worng!!! Please try again",
        //             'message'     => 'success'
        //         );
        //         header("Content-type: application/json");
        //         echo json_encode($response);
        //         exit;
        //     }
        // } else {
        //     exit('no direct script allowed!!!');
        // }
    }

}