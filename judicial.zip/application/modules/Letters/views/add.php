<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    अनुसूची
  </h4>
  <!-- <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div> -->

  <form action="<?php echo base_url() ?>Letters/save" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <table class="table table table-padded" id="frm_tbl_mem">
      <tbody>
        <tr class="row_mem">
          <td><input type="text" name="anusuchi[]" class="form-control" placeholder="अनुसूची"></td>
        </tr>
        <tr>
          <td><input class="form-control" placeholder="विवरण" type="text" name="dafa[]" required="true" value=""></td>
        <tr>
        <tr>
          <td><input class="form-control" placeholder="पत्रको नाम " type="text" name="letter_name[]" required="true" value=""></td>
        </tr>
        <tr>
          <td>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="1" id="flexCheckDefault" name="has_tok">
              <label class="form-check-label" for="flexCheckDefault">
               तोक आदेश
              </label>
            </div>
          </td>
        </tr>
      </tbody>
    </table>

    <button class="btn btn-primary btn-block btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
  </form>
</div>
<script type="text/javascript">
  $(document).ready(function() {
    $('.btnNewPrastab').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      var new_row = '<tr class="row_mem">' +
        '<td>' + trOneNew + '.</td>' +
        '<td><input type="text" name="anusuchi[]" class="form-control" placeholder="अनुसूची"></td>' +
        '<td><input class="form-control" placeholder="विवरण" type="text" name="dafa[]" required="true" value=""></td>' +
        '<td><input class="form-control" placeholder="पत्रको नाम " type="text" name="letter_name[]" required="true" value=""></td>' +
        '<td><button type="button" class="btn btn-outline-danger remove-prastab-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
        '<tr>';
      $("#frm_tbl_mem").append(new_row);
    });
    //remove samati members.
    $("body").on("click", ".remove-prastab-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });
  });
</script>