<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    नयाँ मुद्दाको विषय थप्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>

  <form action="<?php echo base_url() ?>Letters/Update" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
    <table class="table table table-padded" id="frm_tbl_mem">
      <tbody>
        <tr class="row_mem">

          <td style="width:100px;"> <label for="" class="form-label">अनुसूची</label><input type="text" name="anusuchi" class="form-control" placeholder="अनुसूची" value="<?php echo $row['letter_name'] ?>"></td>
        </tr>
        <tr>

          <td> <label for="exampleFormControlInput1" class="form-label">विवरण</label><input class="form-control" placeholder="विवरण" type="text" name="dafa" required="true" value="<?php echo $row['dafa'] ?>"></td>
        </tr>

        <tr>

          <td> <label for="exampleFormControlInput1" class="form-label">पत्रको नाम</label><input class="form-control" placeholder="पत्रको नाम" type="text" name="letter_type" required="true" value="<?php echo $row['letter_type'] ?>"></td>
        </tr>
        <tr>
          <td>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="1" id="flexCheckDefault" name="has_tok" <?php if($row['has_tok'] == 1){ echo "checked=checked";}?>>
              <label class="form-check-label" for="flexCheckDefault">
                तोक आदेश
              </label>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <button class="btn btn-primary btn-block btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
  </form>
</div>