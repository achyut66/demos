<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*This class load model for dashboard*/

class Dashboardmodel extends CI_Model
{
	public function TotalCases() {
        $this->db->from("darta");
        if($this->session->userdata('EM_USER_TPID') != 'su' ) {
            $this->db->where('created_by', $this->session->userdata('EM_USER_TPID'));
        }
        return $this->db->count_all_results();
    }

    public function TotalDarta() {
        $this->db->where('darta_id !=',null);
        if($this->session->userdata('EM_USER_TPID') != 'su' ) {
            $this->db->where('created_by', $this->session->userdata('EM_USER_TPID'));
        }
        $this->db->from("darta");
        return $this->db->count_all_results();
    }

    public function TotalSubmittedMudda() {
        $this->db->where('darta_id',null);
        if($this->session->userdata('EM_USER_TPID') != 'su' ) {
            $this->db->where('created_by', $this->session->userdata('EM_USER_TPID'));
        }
        $this->db->from("darta");
        return $this->db->count_all_results();
    }

    public function getDartaDetails() {
        $this->db->select('t1.*, t2.subject')->from('darta t1');
        $this->db->join('mudda_bisaye t2','t2.id = t1.mudda_bisaye','inner');
        $this->db->where('t1.darta_id !=',null);
        $this->db->order_by('t1.darta_id','desc');
        $this->db->limit(5);
        $query = $this->db->get();
        return $query->result_array();
    }

    //count data
    public function getCount($table) {
        $this->db->from($table);
        return $this->db->count_all_results();
    }

    public function getPeshiDetails() {
        $this->db->select('t1.*')->from('peshi_darta t1');
        // $this->db->join('darta t2','t2.darta_id = t1.darta_no','inner');
        // $this->db->join('badi_detail t3','t1.darta_no = t3.darta_no','inner');
        // $this->db->join('pratibadi_detail t4','t1.darta_no = t4.darta_no','inner');
        $this->db->where('t1.peshi_miti',convertDate(date('Y-m-d')));
        $this->db->order_by('t1.darta_no','desc');
        //$this->db->limit(5);
        $query = $this->db->get();
        return $query->result_array();
    }
}