<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends MX_Controller
{	
	public function __construct()
	{
		parent:: __construct();
        $this->load->model('DashboardModel');
        $this->load->model('CommonModel');
        
        if(!$this->authlibrary->IsLoggedIn()){
            $this->session->set_userdata('return_url', current_url());
            redirect('Login');
        }
		$this->container='main';
	}

	public function Index()
	{
        $data['page']   = 'user_dashboard';
        $this->breadcrumb->populate(array(
            'ड्यासबोर्ड' => ''
        ));
        $data['mudda']              = $this->DashboardModel->TotalCases();
        $data['darta']              = $this->DashboardModel->TotalDarta();
        $data['ndarta']             = $this->DashboardModel->TotalSubmittedMudda();
        $data['dartas']             = $this->DashboardModel->getDartaDetails();
        $data['samitiDecision']     = $this->DashboardModel->getCount('anusuchi_7');
        $data['aadesh']             = $this->DashboardModel->getCount('anusuchi_8');
        $data['melmilapnibedan']    = $this->DashboardModel->getCount('anusuchi_9');
        $data['anusuchi10']         = $this->DashboardModel->getCount('anusuchi_10');
        $data['anusuchi11']         = $this->DashboardModel->getCount('anusuchi_11');
        $data['anusuchi12']         = $this->DashboardModel->getCount('anusuchi_12');
        $data['anusuchi13']         = $this->DashboardModel->getCount('anusuchi_13');
        $data['anusuchi14']         = $this->DashboardModel->getCount('anusuchi_14');
        $data['anusuchi15']         = $this->DashboardModel->getCount('anusuchi_15');
        $data['peshis']             = $this->DashboardModel->getPeshiDetails();
        $data['breadcrumb']         = $this->breadcrumb->output();
        $this->load->view('main', $data);
	}
   
    public function dbbackup(){
        $this->load->dbutil();
        $config = array( 
            'format'      => 'zip',
            'filename'    => 'db_nyik.sql'
        );
        $backup =  $this->dbutil->backup($config);
        $db_name = 'backup-on-'. date("Y-m-d-H-i-s") .'.zip';
        $save = FCPATH.'assets/dbbackup/'.$db_name;
        $this->load->helper('file');
        write_file($save, $backup); 
    }

}