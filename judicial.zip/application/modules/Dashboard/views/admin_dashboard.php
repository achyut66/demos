 <div class="row">
    <aside class="profile-nav col-lg-12">
        <section class="card">
            <div class="user-heading round">
                <a href="#">
                    <img src="<?php echo base_url()?>assets/img/nepal-govt.png" alt="">
                </a>
                <h1><?php echo !empty($admin_details)? $admin_details['ganapa']:'';?></h1>
                <p><?php echo !empty($admin_details)? $admin_details['name']:'';?>,<?php echo !empty($admin_details)? $admin_details['Title']:'';?></p>
            </div>
        </section>
    </aside>
</div>
<!-- Start of nepali patro badge -->

<!-- End of nepali patro badge -->