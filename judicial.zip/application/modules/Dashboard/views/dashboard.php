<div class="content-i">
    <div class="content-box">
        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-content">
                        <div class="row">
                            <div class="col-sm-<?php if($this->session->userdata('EM_USER_TPID') == 'su'){echo '4';} else { echo '6';}?> col-xxxl-3">
                                <a class="element-box el-tablo" href="#">
                                    <div class="label">
                                        जम्मा सम्पन्न गरिएका बैठक
                                    </div>
                                    <div class="value">
                                       <?php echo $this->mylibrary->convertedcit($totalc)?>
                                    </div>
                                </a>
                            </div>
                            <div class="col-sm-<?php if($this->session->userdata('EM_USER_TPID') == 'su'){echo '4';} else { echo '6';}?> col-xxxl-3">
                                <a class="element-box el-tablo" href="#">
                                    <div class="label">
                                        जम्मा संचालन गर्नुपर्ने बैठक
                                    </div>
                                    <div class="value">
                                        <?php echo $this->mylibrary->convertedcit($totals)?>
                                    </div>
                                </a>
                            </div>
                            <?php if($this->session->userdata('EM_USER_TPID') == 'su') : ?>
                            <div class="col-sm-4 col-xxxl-3">
                                <a class="element-box el-tablo" href="#">
                                    <div class="label">
                                        जम्मा बैठक समिति
                                    </div>
                                    <div class="value">
                                       <?php echo $this->mylibrary->convertedcit($samiti)?>
                                    </div>
                                </a>
                            </div>
                            <?php endif;?>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-actions">
                         <a class="btn btn-primary btn-sm" href="<?php echo base_url()?>Meeting/add" target="_blank"><i class="os-icon os-icon-ui-22"></i><span>नयाँ बैठक
                                थप्नुहोस</span></a>
                    </div>
                    <h6 class="element-header">
                       बैठक संचालन गर्नुहोस
                    </h6>

                    <div class="element-box">
                        <!--------------------
                          START - Controls Above Table
                          -------------------->
                            <div class="controls-above-table">
                                संचालन गर्नुपर्न बैठकहरुको सुची
                            </div>
                        <!--------------------
                          END - Controls Above Table
                          -------------------->
                        <!--------------------
                          START - Table with actions
                          ------------------  -->
                        <div class="table-responsive">
                            <?php if(!empty($meetings)) :?>
                            <table  class="table table-lightborder">
                                <thead>
                                    <tr>
                                        <th>क्र.स.</th>
                                        <th>बिषय</th>
                                        <th>समिति</th>
                                        <th></th>
                                        <th></th>

                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $i = 1;
                                    foreach($meetings as $key => $value) : ?>
                                        <tr class="gradeX">
                                          <td class=""><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                          <td><a href="#onboardingWideFeaturesModal" data-toggle="modal" data-url="<?php echo base_url()?>Meeting/viewAganda" data-id = "<?php echo $value['id']?>"><?php echo $this->mylibrary->convertedcit($value['subject'])?></a></td>
                                          <td><?php echo $this->mylibrary->convertedcit($value['sn'])?></td>
                                          <td>  
                                            <?php if($value['status'] == 1) : ?>
                                           <a href="<?php echo base_url()?>Meeting/OperateMeeting/<?php echo $value['id']?>" class="btn btn-success" onclick ="return confirm('कृपया संचालन सुनिस्चित गर्नुहोस')"><i class="os-icon os-icon-mail-18"></i> संचालन गर्नुहोस</a>
                                            <?php else : ?>
                                              <?php if($value['status'] == 2) : ?>
                                               <a href="<?php echo base_url()?>Meeting/AddDecision/<?php echo $value['id']?>" class="btn btn-warning"> निर्णय थप्नुहोस</a>
                                              <?php else :?>
                                                 <div class="btn btn-success"><i class="fa fa-check-circle" style="color:green"></i> सम्पन्न गरियो </div>
                                              <?php endif;?>
                                            <?php endif;?>
                                          </td>
                                          
                                          <?php if($this->authlibrary->HasModulePermission('MEETING', "EDIT") || $this->authlibrary->HasModulePermission('MEETING', "DELETE") ) { ?>
                                            <td class="row-actions">
                                              <?php if($value['status'] == 1) : ?>
                                              <?php if($this->authlibrary->HasModulePermission('MEETING', "EDIT")) { ?>
                                                <a href="<?php echo base_url()?>Meeting/Edit/<?php echo $value['id']?>" class="btn btn-primary" data-placement="bottom" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्" style="color:#fff"><i class="fa fa-pencil" style="color:#fff"></i> विवरण सच्यानुहोस</a>
                                              <?php } ?>
                                            
                                              <?php else : ?>
                                                <a href="<?php echo base_url()?>Meeting/MeetingMinute/<?php echo $value['id']?>" class="btn btn-warning" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="Meeting Minute"><i class="fa fa-eye"></i> View Minute</a>
                                            <?php endif;?>
                                            </td>
                                          <?php } ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php else : ?>

                                <div class="alert alert-info alert-dismissible" role="alert">
                                    <button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button>
                                    <h4 class="alert-heading">
                                        <i class="fa fa-info-circle"></i>  सबै समितको बैठक सम्पन भएको.
                                     
                                  </h4>
                                  <p>
                                      
                                  </p>

                              </div>
                            <?php endif;?>
                        </div>
                        <!--------------------
                          END - Table with actions
                          -------------------->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>