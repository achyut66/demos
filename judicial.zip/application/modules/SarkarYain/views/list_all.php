<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <?php if ($this->authlibrary->HasModulePermission('SARKAR-YAIN', "ADD")) { ?>
                <div class="controls-above-table">
                  <div class="row">
                    <div class="col-sm-6">
                      <a class="btn btn-primary" href="#onboardingFormModal" data-toggle="modal" data-url="<?php echo base_url() ?>SarkarYain/add" data-id=""><i class="os-icon os-icon-ui-22"></i> नयाँ थप्नुहोस</a>
                    </div>
                  </div>
                </div>
              <?php } ?>
              <table class="table table-lightbordered table-striped" id="dataTable1">
                <thead>
                  <tr>
                    <th text-aligh="right">#</th>
                    <th>ऐन</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!empty($sections)) :
                    $i = 1;
                    foreach ($sections as $key => $value) : ?>
                      <tr class="gradeX">
                        <td><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                        <td><?php echo $this->mylibrary->convertedcit($value['name']) ?></td>
                        <?php if ($this->authlibrary->HasModulePermission('SARKAR-YAIN', "EDIT") || $this->authlibrary->HasModulePermission('MUDDHA-BISAYE', "DELETE")) { ?>
                          <td class="center hidden-phone">
                            <?php if ($this->authlibrary->HasModulePermission('SARKAR-YAIN', "EDIT")) { ?>
                              <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-primary btn-sm" title="" data-url="<?php echo base_url() ?>SarkarYain/edit" data-id="<?php echo $value['id'] ?>"><i class="fa fa-pencil"></i> </button>
                            <?php } ?>

                          </td>
                        <?php } ?>
                      </tr>
                  <?php endforeach;
                  endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>