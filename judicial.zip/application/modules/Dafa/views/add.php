<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    नयाँ मुद्दाको विषय थप्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>
  <form action="<?php echo base_url() ?>Dafa/save" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <table class="table table-bordered" id="frm_tbl_mem">
      <thead>
        <tr>
          <th>दफा</th>
          <th>उप दफा</th>
        </tr>
      </thead>
      <tbody>
        <tr class="row_mem">
          <td><input class="form-control" type="text" name="dafa[]" required="true" value=""></td>
          <td><input class="form-control" type="text" name="upa_dafa[]" required="true" value=""></td>
          <td><button type="button" class="btn  btn-primary btnNewMuddha" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button></td>
        </tr>
      </tbody>
    </table>
    <button class="btn btn-primary btn-block btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
  </form>
</div>
<script type="text/javascript">
  $(document).ready(function() {
    $('.btnNewMuddha').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      var new_row = '<tr class="row_mem">' +
        '<td><input class="form-control" placeholder="" type="text" name="dafa[]" required="true" value=""></td>' +
        '<td><input class="form-control" placeholder="" type="text" name="upa_dafa[]" required="true" value=""></td>' +
        '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
        '<tr>';
      $("#frm_tbl_mem").append(new_row);
    });
    //remove samati members.
    $("body").on("click", ".remove-muddha-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });
  });
</script>