<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    नयाँ मुद्दाको विषय थप्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>

  <form action="<?php echo base_url() ?>Dafa/Update" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="row">
      <div class="col-sm-12">
        <div class="form-group">
          <label for="">दफा<span class="text-danger"> * </span></label>
          <input class="form-control" type="text" name="dafa" required="true" value="<?php echo $row['name'] ?>">
          <input class="form-control" type="hidden" name="id" required="true" value="<?php echo $row['id'] ?>">
        </div>

        <div class="form-group">
          <label for="">उप दफा<span class="text-danger"> * </span></label>
          <input class="form-control" type="text" name="upa_dafa" required="true" value="<?php echo $row['upa_dafa'] ?>">
        </div>
      </div>
      <div class="col-sm-12">
        <button class="btn btn-primary btn-xs btn-block save_btn" data-toggle="tooltip" title="सेभ गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
      </div>
    </div>
  </form>
</div>