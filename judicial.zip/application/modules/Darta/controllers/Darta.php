<?php
class Darta extends MX_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("CommonModel");
        $this->load->model("DartaMdl");
        $this->module_code = 'DARTA';
        if (!$this->authlibrary->IsLoggedIn()) {
            $this->session->set_userdata('return_url', current_url());
            redirect('Login', 'location');
        }
    }

    /**
     * This function list all the land minimun rate
     * @param NULL
     * @return void

     */
    public function Index()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page'] = 'list_all';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'          => '',
                'मुद्दाहरुको सुचि'    => 'Darta',
            ));
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['dartas']     = $this->DartaMdl->getDartaList();
            // pp($data['dartas']);
            // $data['anusuchi']   = $this->CommonModel->getResultByMultipleCondition('letters', array('status' => 1));
            $data['anusuchi']   = $this->CommonModel->getData('letters','DESC');
            // pp($data['anusuchi']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    /*--------------------------------darta process------------------------------------------------------*/

    //get parkar by dafa 
    public function getPrakarByDafa()
    {
        if ($this->input->is_ajax_request()) {
            $dafa = $this->input->post('dafa');
            $upadafa = $this->input->post('updafa');
            $data = $this->CommonModel->getWhereAll('mudda_bisaye', array('dafa' => $dafa,'upa_dafa' =>$upadafa));
            $parkar = '<option value="">मुद्दाको प्रकार छान्नुहोस्</option>';
            if (!empty($data)) {
                $i = 1;
                foreach ($data as $key => $value) {
                    $parkar .= "<option value = '" . $value['id'] . "''>" . $this->mylibrary->convertedcit($i++) . ') ' . $value['subject'] . "</option>";
                }
            }
            $response = array(
                'status'        => 'success',
                'data'          => $parkar,
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        }
    }
    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function add()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']   = 'add';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'मुद्दा दर्ता फाराम'
            ));
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['dafa']           = $this->DartaMdl->getDistinctDafa();
            $data['updafa']         = $this->CommonModel->getData('dafa', 'ASC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * Call on ajax request
     * save fiscal year
     * @return NULL
     */
    public function darta_save()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('date', 'पदाधिकारीको पद', 'required|trim');
            $this->form_validation->set_rules('type', 'पदाधिकारीको नाम', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $date                   = $this->input->post('date');
            $type                   = $this->input->post('type');
            $dafa                   = $this->input->post('dafa');
            $upa_dafa                   = $this->input->post('upa_dafa');
            $bisaye                 = $this->input->post('bisaye');
            $darta                  = $this->DartaMdl->GetMaxDartaNo();
            $darta_no               = !empty($darta) ? $darta->darta_no + 1 : '';
            if (empty($darta_no)) {
                $response           = array(
                    'status'        => 'error',
                    'data'          => "oops ! something goes worng",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data              = array(
                'darta_no'          => $darta_no,
                'date'              => $date,
                'dafa'              => $dafa,
                'upa_dafa'          => $upa_dafa,
                'case_title'        => $bisaye,
                'mudda_bisaye'      => $type,
                'status'            => 1,
                'created_at'        => $date,
                'created_ip'        => $this->generalsettings->get_real_ipaddr(),
                'created_by'        => $this->session->userdata('EM_USER_ID'),
                'refid'             => $this->generalsettings->get_Mac_Address()
            );
            $result = $this->CommonModel->insertData('darta', $post_data);
            if ($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Darta/addBadi/' . $darta_no,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "fail to insert data",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function Edit()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']       = 'edit';
            $data['script']     = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचिमा जानुहोस'     => 'Staff',
                'मुद्दाहरुको सम्पादन गर्नुहोस'
            ));
            $id                 = $this->uri->segment(3);
            $data['breadcrumb'] = $this->breadcrumb->output();
            $data['row']        = $this->CommonModel->getDataByID('darta', $id);
            $data['dafa']           = $this->DartaMdl->getDistinctDafa();
            $data['updafa']         = $this->CommonModel->getData('dafa', 'ASC');
            $data['types']      = $this->CommonModel->getData('mudda_bisaye', 'ASC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * This function on ajaxcall update land area type data
     * @param  $_POST
     * @return json response
     */
    public function darta_update()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('date', 'पदाधिकारीको पद', 'required|trim');
            $this->form_validation->set_rules('type', 'पदाधिकारीको नाम', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id                     = $this->input->post('id');
            $date                   = $this->input->post('date');
            $type                   = $this->input->post('type');
            $dafa                   = $this->input->post('dafa');
            $bisaye                 = $this->input->post('bisaye');
            $darta                  = $this->DartaMdl->GetMaxDartaNo();
            $darta_no               = !empty($darta) ? $darta->darta_no + 1 : '';
            if (empty($darta_no)) {
                $response           = array(
                    'status'        => 'error',
                    'data'          => "oops ! something goes worng",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data              = array(
                // 'darta_no'          => $darta_no,
                'date'              => $date,
                'dafa'              => $dafa,
                'case_title'        => $bisaye,
                'mudda_bisaye'      => $type,
                'status'            => 1,
                'modified_at'       => $date,
                'modified_by'       => $this->generalsettings->get_real_ipaddr(),
                'modified_ip'       => $this->session->userdata('EM_USER_ID'),
                'refid'             => $this->generalsettings->get_Mac_Address()
            );
            // $date                   = $this->input->post('date');
            // $type                   = $this->input->post('type');
            // $post_data              = array(
            //     'date'              => $date,
            //     'mudda_bisaye'      => $type,
            //     'modified_at'       => $date,
            //     'modified_by'       => $this->generalsettings->get_real_ipaddr(),
            //     'modified_ip'       => $this->session->userdata('EM_USER_ID'),
            // );
            $result = $this->CommonModel->updateData('darta', $id, $post_data);
            if ($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Darta',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "fail to insert data",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }
    //remove members
    public function delete_darta()
    {
        $id = $this->uri->segment(3);
        if (empty($id)) {
            $this->session->set_flashdata('MSG_ERR', "Invalid Process");
            redirect('Darta');
        }
        $result = $this->CommonModel->deleteData('darta', $id);
        if ($result) {
            $this->session->set_flashdata('MSG_SUCCESS', "Removed Successfully");
            redirect('Darta');
        }
    }

    //darta rasid wiwarn
    public function RasidDetails()
    {
        $data['pageTitle']          = "";
        $data['id']                 = $this->input->post('id');
        $data['muddha_wiwaran']     = $this->CommonModel->getDataById('darta', $data['id']);
        $data['badi_nibedan']       = $this->CommonModel->getDataBySelectedFields('badi_firad_patra', 'darta_no', $data['id']);
        $this->load->view('darta_rasid_wiwaran', $data);
    }
    //save rasid wiwaran
    public function saveDartaRasidWiwaran()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('date', '', 'required|trim');
            $this->form_validation->set_rules('rasid_no', '', 'required|trim');
            $this->form_validation->set_rules('dastur', '', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $date                   = $this->input->post('date');
            $rasid_no               = $this->input->post('rasid_no');
            $dastur                 = $this->input->post('dastur');
            $muddha_darta_no        = $this->input->post('muddha_darta_no');
            $darta                  = $this->DartaMdl->GetMaxDartaID();
            $darta_id               = !empty($darta) ? $darta->darta_no + 1 : '';
            if (empty($darta_id)) {
                $response           = array(
                    'status'        => 'error',
                    'data'          => "oops ! something goes worng",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $post_data              = array(
                'darta_no'          => $muddha_darta_no,
                'rasid_no'          => $rasid_no,
                'darta_id'          => $darta_id,
                'created_at'        => convertdate(date('Y-m-d')),
                'created_by'        => $this->session->userdata('EM_USER_ID'),

            );
            //pp($post_data);
            $result = $this->CommonModel->insertData('darta_dastur_wiwaran', $post_data);
            if ($result) {
                $data_array = array('date' => convertdate(date('Y-m-d')), 'darta_id' => $darta_id);
                $this->CommonModel->updateData('darta', $muddha_darta_no, $data_array);
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Darta/badiDetails/' . $muddha_darta_no,
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "fail to insert data",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }
    /*-------------------------------- badi ko wiwaran ------------------------------------------------------*/

    /**
     * This function list all.
     * @param NULL
     * @return void

     */
    public function badiDetails()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            $data['page'] = 'list_badis'; //view muddha content detals
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचि'   => 'Darta',
                'वादीको विवरण'
            ));
            $data['breadcrumb']             = $this->breadcrumb->output();
            $data['aanusuchi']              = $this->CommonModel->getData('letters', 'ASC');
            $data['darta_detail']           = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badis']                  = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
           
            $data['pratibadis']             = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['anusuchis']              = $this->CommonModel->getData('letters', 'ASC');
            //वादी को विवरण 
            $data['firadpatra']             = $this->CommonModel->getAllDataByField('badi_firad_patra', 'darta_no', $darta_no);
            $data['nisa_patra']             = $this->CommonModel->getResultByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['tarik_patra']            = $this->CommonModel->getResultByMultipleCondition('anusuchi_3', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['tarik_bharpai']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_4', array('darta_no' => $darta_no, 'type' => 'badi'));
            $data['mayad_suchana']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_6', array('darta_no' => $darta_no, 'type' => 'badi'));
            //प्रतिवादी को विवरण
            $data['likhit_jawaf']           = $this->CommonModel->getAllDataByField('likhit_jawaf', 'darta_no', $darta_no);
            $data['nisa_patra_p']           = $this->CommonModel->getResultByMultipleCondition('anusuchi_2', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['tarik_patra_p']          = $this->CommonModel->getResultByMultipleCondition('anusuchi_3', array('darta_no' => $darta_no, 'type' => 'pratibadi'));
            $data['tarik_bharpai_p']        = $this->CommonModel->getResultByMultipleCondition('anusuchi_4', array('darta_no' => $darta_no, 'type' => 'pratibadi'));

            $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function addBadi()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'add_badi';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'मुद्दा दर्ता फाराम'
            ));
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['state']          = $this->CommonModel->getData('provinces', 'DESC');
            $data['districts']      = $this->CommonModel->getData('settings_district', 'ASC');
            $data['gapa']           = $this->CommonModel->getData('settings_vdc_municipality', 'ASC');
            $data['wards']          = $this->CommonModel->getData('settings_ward', 'ASC');
            $data['relations']      = $this->CommonModel->getData('settings_relation', 'ASC');
            $data['darta_detail']   = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['firad_details']  = $this->CommonModel->getDataBySelectedFields('badi_firad_patra', 'darta_no', $darta_no);
            if (empty($data['darta_detail'])) {
                $this->session->set_flashdata('MSG_ERR', 'Invalid Darta Details');
                redirect('Darta');
            }
            $data['subject'] = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * Call on ajax request
     * save fiscal year
     * @return NULL
     */
    public function badi_save()
    {
        if ($this->input->is_ajax_request()) {
            $darta_no                   = $this->input->post('darta_no');
            if (empty($darta_no)) {
                $response = array(
                    'status'      => 'error',
                    'data'         => "दर्ता नं. भेटिएन",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;

                // $this->session->set_flashdata('MSG_ERR','दर्ता नं भेटिएन.');
                // redirect('Darta');
            }
            $this->form_validation->set_rules('darta_no', 'darta_no', 'required|trim');
            $this->form_validation->set_rules('b_name[]', 'b_name', 'required|trim');
            $this->form_validation->set_rules('b_dob[]', 'b_dob', 'required|trim');
            $this->form_validation->set_rules('b_cznno[]', 'b_cznno', 'required|trim');
            $this->form_validation->set_rules('b_czn_date[]', 'b_czn_date', 'required|trim');
            $this->form_validation->set_rules('b_czn_district[]', 'b_czn_district', 'required|trim');
            $this->form_validation->set_rules('b_address[]', 'b_address', 'required|trim');
            $this->form_validation->set_rules('b_grandfather[]', 'b_grandfather', 'required|trim');
            $this->form_validation->set_rules('b_father[]', 'b_father', 'required|trim');
            $this->form_validation->set_rules('b_mother[]', 'b_mother', 'required|trim');
            $this->form_validation->set_rules('b_husband_wife[]', 'b_husband_father', 'required|trim');
            $this->form_validation->set_rules('b_phone[]', 'b_phone', 'required|trim');
            $this->form_validation->set_rules('b_ward[]', 'b_ward', 'required|trim');
            $this->form_validation->set_rules('b_relation[]', 'b_relation', 'required|trim');


            // $this->form_validation->set_rules('case_details', 'case_details', 'required|trim');
            // $this->form_validation->set_rules('proof', 'proof', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $gender                     = $this->input->post('gender');
            $b_name                     = $this->input->post('b_name');
            $b_dob                      = $this->input->post('b_dob');
            $b_cznno                    = $this->input->post('b_cznno');
            $b_czn_date                 = $this->input->post('b_czn_date');
            $b_czn_district             = $this->input->post('b_czn_district');
            $b_address                  = $this->input->post('b_address');
            $b_gapa                 = $this->input->post('b_gapa');
            $b_grandfather              = $this->input->post('b_grandfather');
            $b_father                   = $this->input->post('b_father');
            $b_mother                   = $this->input->post('b_mother');
            $b_husband_wife             = $this->input->post('b_husband_wife');
            $b_phone                    = $this->input->post('b_phone');
            $b_ward                     = $this->input->post('b_ward');
            $b_relation                 = $this->input->post('b_relation');

            if (empty($darta_no)) {
                $response           = array(
                    'status'      => 'error',
                    'data'         => "oops ! something goes worng",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $badi                 = array();
            if (!empty($b_name)) {
                foreach ($b_name as $key => $indexv) {
                    $badi[]              = array(
                        'darta_no'          => $darta_no,
                        'gender'            => $gender[$key],
                        'b_name'            => $b_name[$key],
                        'b_dob'             => $b_dob[$key],
                        'b_cznno'           => $b_cznno[$key],
                        'b_czn_date'        => $b_czn_date[$key],
                        'b_czn_district'    => $b_czn_district[$key],
                        'b_address'         => $b_address[$key],
                        'b_gapa'            => $b_gapa[$key],
                        'b_grandfather'     => $b_grandfather[$key],
                        'b_father'          => $b_father[$key],
                        'b_mother'          => $b_mother[$key],
                        'b_husband_wife'    => $b_husband_wife[$key],
                        'b_phone'           => $b_phone[$key],
                        'b_ward'            => $b_ward[$key],
                        'b_relation'        => $b_relation[$key],
                        'created_at'        => '',
                        'created_ip'        => $this->generalsettings->get_real_ipaddr(),
                        'created_by'        => $this->session->userdata('EM_USER_ID'),
                    );
                }
                $result = $this->CommonModel->batchInsert($badi, 'badi_detail');
                if ($result) {
                    $response = array(
                        'status'      => 'success',
                        'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url() . 'Darta/addPratiBadi/' . $darta_no,
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "fail to insert data",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function badiEdit()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $data['page']       = 'edit_badi';
            $data['script']     = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'बढीको विवरण सम्पादन गर्नुहोस'
            ));
            $id                     = $this->uri->segment(3);
            if (empty($id)) {
                $this->session->set_flashdata('MSG_ERR', 'Invalid Response');
                redirect('Darta');
            }
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['districts']      = $this->CommonModel->getData('settings_district', 'ASC');
            $data['relations']      = $this->CommonModel->getData('settings_relation', 'ASC');
            $data['wards']          = $this->CommonModel->getData('settings_ward', 'ASC');
            $data['gapa']           = $this->CommonModel->getData('settings_vdc_municipality', 'ASC');
            $data['rows']           = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $id);
            $data['darta']          = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $id);
            $data['witness']        = $this->CommonModel->getAllDataByField('witness', 'darta_no', $id);
            $data['subject']        = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta']['mudda_bisaye']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * This function on ajaxcall update land area type data
     * @param  $_POST
     * @return json response
     */
    public function badi_update()
    {
        if ($this->input->is_ajax_request()) {
            //$this->form_validation->set_rules('darta_no', 'darta_no', 'required|trim');
            $this->form_validation->set_rules('b_name[]', 'b_name', 'required|trim');
            $this->form_validation->set_rules('b_dob[]', 'b_dob', 'required|trim');
            $this->form_validation->set_rules('b_cznno[]', 'b_cznno', 'required|trim');
            $this->form_validation->set_rules('b_czn_date[]', 'b_czn_date', 'required|trim');
            $this->form_validation->set_rules('b_czn_district[]', 'b_czn_district', 'required|trim');
            $this->form_validation->set_rules('b_address[]', 'b_address', 'required|trim');
            $this->form_validation->set_rules('b_grandfather[]', 'b_grandfather', 'required|trim');
            $this->form_validation->set_rules('b_father[]', 'b_father', 'required|trim');
            $this->form_validation->set_rules('b_mother[]', 'b_mother', 'required|trim');
            $this->form_validation->set_rules('b_husband_wife[]', 'b_husband_father', 'required|trim');
            $this->form_validation->set_rules('b_phone[]', 'b_phone', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id                     = $this->input->post('row_id');
            $gender                 = $this->input->post('gender');
            $b_name                 = $this->input->post('b_name');
            $b_dob                  = $this->input->post('b_dob');
            $b_cznno                = $this->input->post('b_cznno');
            $b_czn_date             = $this->input->post('b_czn_date');
            $b_czn_district         = $this->input->post('b_czn_district');
            $b_address              = $this->input->post('b_address');
            $b_grandfather          = $this->input->post('b_grandfather');
            $b_father               = $this->input->post('b_father');
            $b_mother               = $this->input->post('b_mother');
            $b_husband_wife         = $this->input->post('b_husband_wife');
            $b_phone                = $this->input->post('b_phone');
            $darta_no               = $this->input->post('darta_no');
            $b_ward                 = $this->input->post('b_ward');
            $b_gapa                 = $this->input->post('b_gapa');
            $b_relation             = $this->input->post('b_relation');
            $post_data              = array();
            if (!empty($b_name)) {
                foreach ($b_name as $key => $indexv) {
                    $post_data[]              = array(
                        'id'                => $id[$key],
                        'gender'            => $gender[$key],
                        'b_name'            => $b_name[$key],
                        'b_dob'             => $b_dob[$key],
                        'b_cznno'           => $b_cznno[$key],
                        'b_czn_date'        => $b_czn_date[$key],
                        'b_czn_district'    => $b_czn_district[$key],
                        'b_address'         => $b_address[$key],
                        'b_gapa'            => $b_gapa[$key],
                        'b_grandfather'     => $b_grandfather[$key],
                        'b_father'          => $b_father[$key],
                        'b_mother'          => $b_mother[$key],
                        'b_husband_wife'    => $b_husband_wife[$key],
                        'b_phone'           => $b_phone[$key],
                        'b_ward'            => $b_ward[$key],
                        'b_relation'        => $b_relation[$key],
                        'modified_at'       => convertDate(date('Y-m-d')),
                        'modified_ip'       => $this->generalsettings->get_real_ipaddr(),
                        'modified_by'       => $this->session->userdata('EM_USER_ID'),
                    );
                }
                $result = $this->CommonModel->batchUpdate('badi_detail', $id, $post_data);
                if ($result) {
                    $b_name_new                 = $this->input->post('b_name_new');
                    $b_dob_new                  = $this->input->post('b_dob_new');
                    $b_cznno_new                = $this->input->post('b_cznno_new');
                    $b_czn_date_new             = $this->input->post('b_czn_date_new');
                    $b_czn_district_new         = $this->input->post('b_czn_district_new');
                    $b_address_new              = $this->input->post('b_address_new');
                    $b_grandfather_new          = $this->input->post('b_grandfather_new');
                    $b_father_new               = $this->input->post('b_father_new');
                    $b_mother_new               = $this->input->post('b_mother_new');
                    $b_husband_wife_new         = $this->input->post('b_husband_wife_new');
                    $b_phone_new                = $this->input->post('b_phone_new');
                    $b_ward_new                 = $this->input->post('b_ward_new');
                    $b_relation_new             = $this->input->post('b_relation_new');
                    $badi = array();
                    if (!empty($b_name_new)) {
                        foreach ($b_name_new as $key => $indexv) {
                            $badi[]              = array(
                                'darta_no'          => $darta_no,
                                'b_name'            => $b_name_new[$key],
                                'b_dob'             => $b_dob_new[$key],
                                'b_cznno'           => $b_cznno_new[$key],
                                'b_czn_date'        => $b_czn_date_new[$key],
                                'b_czn_district'    => $b_czn_district_new[$key],
                                'b_address'         => $b_address_new[$key],
                                'b_grandfather'     => $b_grandfather_new[$key],
                                'b_father'          => $b_father_new[$key],
                                'b_mother'          => $b_mother_new[$key],
                                'b_husband_wife'    => $b_husband_wife_new[$key],
                                'b_phone'           => $b_phone_new[$key],
                                'b_ward'            => $b_ward_new[$key],
                                'b_relation'        => $b_relation_new[$key],
                                'created_at'        => convertDate(date('Y-m-d')),
                                'created_ip'        => $this->generalsettings->get_real_ipaddr(),
                                'created_by'        => $this->session->userdata('EM_USER_ID'),

                            );
                        }
                        $this->CommonModel->batchInsert($badi, 'badi_detail');
                    }

                    $case_details               = $this->input->post('case_details');
                    $proof                      = $this->input->post('proof');
                    $has_lawyer                 = $this->input->post('has_lawyer');

                    $darta_updates      = array(
                        'case_details'  => $case_details,
                        'has_lawyer'    => $has_lawyer,
                        'proof'  => $proof,
                    );
                    $this->CommonModel->updateDataByField('darta', 'darta_no', $darta_no, $darta_updates);
                    $w_id               = $this->input->post('w_id');
                    $w_name             = $this->input->post('w_name');
                    $w_phone            = $this->input->post('w_phone');
                    $w_age              = $this->input->post('w_age');
                    $w_address          = $this->input->post('w_address');
                    $sachi              = array();
                    if (!empty($w_name)) {
                        foreach ($w_name as $key => $wit) {
                            $sachi[]      = array(
                                'id'        => $w_id[$key],
                                'name'      => $w_name[$key],
                                'age'       => $w_age[$key],
                                'phone'     => $w_phone[$key],
                                'address'   => $w_address[$key],
                                'darta_no'  => $darta_no
                            );
                        }
                        $this->CommonModel->batchUpdate('witness', $w_id, $sachi);
                    }
                    $response = array(
                        'status'        => 'success',
                        'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url() . 'Darta/badiDetails/' . $darta_no
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "Failed to update",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Invalid response",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    //remove members
    public function badi_delete()
    {
        $id         = $this->uri->segment(3);
        $darta_no   = $this->uri->segment(4);
        if (empty($id)) {
            $this->session->set_flashdata('MSG_ERR', "Invalid Process");
            redirect('Darta');
        }
        $result = $this->CommonModel->deleteData('badi_detail', $id);
        if ($result) {
            $this->session->set_flashdata('MSG_SUCCESS', "Removed Successfully");
            redirect('Darta/badiEdit/' . $darta_no);
        }
    }

    /*-------------------------------- pratibadi ko wiwaran ------------------------------------------------------*/

    /**
     * This function list all.
     * @param NULL
     * @return void

     */
    public function pratiBadiDetails()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            $data['page'] = 'list_pratibadis';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचि'   => 'Darta',
                'वादीको विवरण'
            ));
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['aanusuchi']      = $this->CommonModel->getData('letters', 'ASC');
            $data['darta_detail']   = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['pratibadis']     = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['likhit_jawaf']   = $this->CommonModel->getAllDataByField('likhit_jawaf', 'darta_no', $darta_no);
            $data['anusuchis']      = $this->CommonModel->getData('letters', 'ASC');
            $data['subject']        = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function addPratiBadi()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'add_pratibadi';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'प्रतिवादीको विवरण'
            ));
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['badi_details']   = $this->DartaMdl->checkIfBadiExits($darta_no);
            if ($data['badi_detail'] = false) {
                $this->session->set_flashdata('MSG_ERR', 'वादीको विवरण भेटिएन. वादीको विवरण थप्नुहोस');
                redirect('Darta/addBadi/' . $darta_no);
            }
            $data['districts']      = $this->CommonModel->getData('settings_district', 'ASC');
            $data['wards']          = $this->CommonModel->getData('settings_ward', 'ASC');
            $data['gapa']           = $this->CommonModel->getData('settings_vdc_municipality', 'ASC');
            $data['relations']      = $this->CommonModel->getData('settings_relation', 'ASC');
            $data['darta_detail']   = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['subject']        = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * Call on ajax request
     * save fiscal year
     * @return NULL
     */
    public function pratibadi_save()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('darta_no', 'darta_no', 'required|trim');
            $this->form_validation->set_rules('b_name[]', 'b_name', 'required|trim');
            $this->form_validation->set_rules('b_dob[]', 'b_dob', 'required|trim');
            //$this->form_validation->set_rules('b_cznno[]', 'b_cznno', 'required|trim');
            //$this->form_validation->set_rules('b_czn_date[]', 'b_czn_date', 'required|trim');
            //$this->form_validation->set_rules('b_czn_district[]', 'b_czn_district', 'required|trim');
            $this->form_validation->set_rules('b_address[]', 'b_address', 'required|trim');
            //$this->form_validation->set_rules('b_grandfather[]', 'b_grandfather', 'required|trim');
            //$this->form_validation->set_rules('b_father[]', 'b_father', 'required|trim');
            //$this->form_validation->set_rules('b_mother[]', 'b_mother', 'required|trim');
            //$this->form_validation->set_rules('b_husband_wife[]', 'b_husband_father', 'required|trim');
            //$this->form_validation->set_rules('b_phone[]', 'b_phone', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $darta_no                   = $this->input->post('darta_no');
            $b_name                     = $this->input->post('b_name');
            $b_dob                      = $this->input->post('b_dob');
            $b_cznno                    = $this->input->post('b_cznno');
            $b_czn_date                 = $this->input->post('b_czn_date');
            $b_czn_district             = $this->input->post('b_czn_district');
            $b_gapa                     = $this->input->post('b_gapa');
            $b_address                  = $this->input->post('b_address');
            $b_grandfather              = $this->input->post('b_grandfather');
            $b_father                   = $this->input->post('b_father');
            $b_mother                   = $this->input->post('b_mother');
            $b_husband_wife             = $this->input->post('b_husband_wife');
            $b_phone                    = $this->input->post('b_phone');
            $gender                     = $this->input->post('gender');
            $b_ward                     = $this->input->post('b_ward');
            $b_relation                 = $this->input->post('b_relation');
            if (empty($darta_no)) {
                $response           = array(
                    'status'      => 'error',
                    'data'         => "oops ! something goes worng",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }

            $pratibadi                 = array();
            if (!empty($b_name)) {
                foreach ($b_name as $key => $indexv) {
                    $pratibadi[]              = array(
                        'darta_no'          => $darta_no,
                        'gender'            => $gender[$key],
                        'p_name'            => $b_name[$key],
                        'p_dob'             => $b_dob[$key],
                        'p_cznno'           => $b_cznno[$key],
                        'p_czn_date'        => $b_czn_date[$key],
                        'p_czn_district'    => $b_czn_district[$key],
                        'p_gapa'            => $b_gapa[$key],
                        'p_address'         => $b_address[$key],
                        'p_grandfather'     => $b_grandfather[$key],
                        'p_father'          => $b_father[$key],
                        'p_mother'          => $b_mother[$key],
                        'p_husband_wife'    => $b_husband_wife[$key],
                        'p_phone'           => $b_phone[$key],
                        'p_ward'            => $b_ward[$key],
                        'p_relation'        => $b_relation[$key],
                        'created_at'        => convertDate(date('Y-m-d')),
                        'created_ip'        => $this->generalsettings->get_real_ipaddr(),
                        'created_by'        => $this->session->userdata('EM_USER_ID'),

                    );
                }
                $result = $this->CommonModel->batchInsert($pratibadi, 'pratibadi_detail');
                if ($result) {
                    $response = array(
                        'status'      => 'success',
                        'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url() . 'NibedanPatra/add/' . $darta_no,
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "fail to insert data",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            }
        } else {
            exit('no direct script allowed');
        }
    }

    /**
     * On ajax call load view
     * @param  NULL
     * @return void
     */
    public function pratibadiEdit()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $id = $this->uri->segment(3);
            $data['page']       = 'edit_pratibadi';
            $data['script']     = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'       => '',
                'मुद्दाहरुको सुचिमा जानुहोस '     => 'Darta',
                'प्रतिवादीको विवरण सम्पादन गर्नुहोस'
            ));
            $id                 = $this->uri->segment(3);
            if (empty($id)) {
                $this->session->set_flashdata('MSG_ERR', 'Invalid Response');
                redirect('Darta');
            }
            $data['breadcrumb']     = $this->breadcrumb->output();
            $data['districts']      = $this->CommonModel->getData('settings_district', 'ASC');
            $data['wards']          = $this->CommonModel->getData('settings_ward', 'ASC');
            $data['gapa']           = $this->CommonModel->getData('settings_vdc_municipality', 'ASC');
            $data['relations']      = $this->CommonModel->getData('settings_relation', 'ASC');
            $data['rows']           = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $id);
            $data['darta']          = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $id);
            $data['subject']        = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['rows'][0]['darta_no']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    /**
     * This function on ajaxcall update land area type data
     * @param  $_POST
     * @return json response
     */
    public function pratibadi_update()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('b_name[]', 'b_name', 'required|trim');
            $this->form_validation->set_rules('b_dob[]', 'b_dob', 'required|trim');
            $this->form_validation->set_rules('b_cznno[]', 'b_cznno', 'required|trim');
            $this->form_validation->set_rules('b_czn_date[]', 'b_czn_date', 'required|trim');
            $this->form_validation->set_rules('b_czn_district[]', 'b_czn_district', 'required|trim');
            $this->form_validation->set_rules('b_address[]', 'b_address', 'required|trim');
            $this->form_validation->set_rules('b_grandfather[]', 'b_grandfather', 'required|trim');
            $this->form_validation->set_rules('b_father[]', 'b_father', 'required|trim');
            $this->form_validation->set_rules('b_mother[]', 'b_mother', 'required|trim');
            $this->form_validation->set_rules('b_husband_wife[]', 'b_husband_father', 'required|trim');
            $this->form_validation->set_rules('b_phone[]', 'b_phone', 'required|trim');
            if ($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया * चिन्न भएको ठाउँ खाली नछोड्नु होला.',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $id                     = $this->input->post('row_id');
            $b_name                 = $this->input->post('b_name');
            $b_dob                  = $this->input->post('b_dob');
            $b_cznno                = $this->input->post('b_cznno');
            $b_czn_date             = $this->input->post('b_czn_date');
            $b_czn_district         = $this->input->post('b_czn_district');
            $b_address              = $this->input->post('b_address');
            $b_gapa                 = $this->input->post('b_gapa');
            $b_grandfather          = $this->input->post('b_grandfather');
            $b_father               = $this->input->post('b_father');
            $b_mother               = $this->input->post('b_mother');
            $b_husband_wife         = $this->input->post('b_husband_wife');
            $b_phone                = $this->input->post('b_phone');
            $darta_no               = $this->input->post('darta_no');
            $gender                 = $this->input->post('gender');
            $b_ward                 = $this->input->post('b_ward');
            $b_relation             = $this->input->post('b_relation');
            //$darta_no               = $this->input->post('darta_no');
            $post_data                 = array();
            if (!empty($b_name)) {
                foreach ($b_name as $key => $indexv) {
                    $post_data[]              = array(
                        'id'                => $id[$key],
                        'gender'            => $gender[$key],
                        'p_name'            => $b_name[$key],
                        'p_dob'             => $b_dob[$key],
                        'p_cznno'           => $b_cznno[$key],
                        'p_czn_date'        => $b_czn_date[$key],
                        'p_czn_district'    => $b_czn_district[$key],
                        'p_address'         => $b_address[$key],
                        'p_gapa'            => $b_gapa[$key],
                        'p_grandfather'     => $b_grandfather[$key],
                        'p_father'          => $b_father[$key],
                        'p_mother'          => $b_mother[$key],
                        'p_husband_wife'    => $b_husband_wife[$key],
                        'p_phone'           => $b_phone[$key],
                        'p_ward'            => $b_ward[$key],
                        'p_relation'        => $b_relation[$key],
                        'modified_at'       => convertDate(date('Y-m-d')),
                        'modified_ip'       => $this->generalsettings->get_real_ipaddr(),
                        'modified_by'       => $this->session->userdata('EM_USER_ID'),
                    );
                }
                $result = $this->CommonModel->batchUpdate('pratibadi_detail', $id, $post_data);
                if ($result) {
                    $b_name_new                 = $this->input->post('b_name_new');
                    $b_dob_new                  = $this->input->post('b_dob_new');
                    $b_cznno_new                = $this->input->post('b_cznno_new');
                    $b_czn_date_new             = $this->input->post('b_czn_date_new');
                    $b_czn_district_new         = $this->input->post('b_czn_district_new');
                    $b_address_new              = $this->input->post('b_address_new');
                    $b_grandfather_new          = $this->input->post('b_grandfather_new');
                    $b_father_new               = $this->input->post('b_father_new');
                    $b_mother_new               = $this->input->post('b_mother_new');
                    $b_husband_wife_new         = $this->input->post('b_husband_wife_new');
                    $b_phone_new                = $this->input->post('b_phone_new');
                    $b_ward_new                 = $this->input->post('b_ward_new');
                    $b_relation_new             = $this->input->post('b_relation_new');
                    $badi = array();
                    if (!empty($b_name_new)) {
                        foreach ($b_name_new as $key => $indexv) {
                            $badi[]              = array(
                                'darta_no'          => $darta_no,
                                'p_name'            => $b_name_new[$key],
                                'p_dob'             => $b_dob_new[$key],
                                'p_cznno'           => $b_cznno_new[$key],
                                'p_czn_date'        => $b_czn_date_new[$key],
                                'p_czn_district'    => $b_czn_district_new[$key],
                                'p_address'         => $b_address_new[$key],
                                'p_grandfather'     => $b_grandfather_new[$key],
                                'p_father'          => $b_father_new[$key],
                                'p_mother'          => $b_mother_new[$key],
                                'p_husband_wife'    => $b_husband_wife_new[$key],
                                'p_phone'           => $b_phone_new[$key],
                                'p_ward'            => $b_ward_new[$key],
                                'p_relation'        => $b_relation_new[$key],
                                'created_at'        => convertDate(date('Y-m-d')),
                                'created_ip'        => $this->generalsettings->get_real_ipaddr(),
                                'created_by'        => $this->session->userdata('EM_USER_ID'),

                            );
                        }
                        $this->CommonModel->batchInsert($badi, 'pratibadi_detail');
                    }

                    $response = array(
                        'status'      => 'success',
                        'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url() . 'Darta/badiDetails/' . $darta_no
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "Failed to update",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "Invalid response",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    //remove members
    public function pratibadi_delete()
    {
        $id         = $this->uri->segment(3);
        $darta_no   = $this->uri->segment(4);
        if (empty($id)) {
            $this->session->set_flashdata('MSG_ERR', "Invalid Process");
            redirect('Darta');
        }
        $result = $this->CommonModel->deleteData('pratibadi_detail', $id);
        if ($result) {
            $this->session->set_flashdata('MSG_SUCCESS', "Removed Successfully");
            redirect('Darta/pratibadiEdit/' . $darta_no);
        }
    }

    /*-------------------------------- वादीको निबेदन पत्र 
    -----------------------------------------------------------------------------*/
    public function addDetails()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            $muddha_darta_no = $this->uri->segment(4);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'addnebedan_patra';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'प्रतिवादीको विवरण'
            ));
            $data['breadcrumb']             = $this->breadcrumb->output();
            $data['darta_detail']           = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badi']                   = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['pratibadi']              = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            if (empty($data['badi'])) {
                $this->session->set_flashdata('MSG_ERROR', "कृपया वादीको विवरण दाखिला गर्नुहोस");
                redirect('Darta/addBadi/' . $darta_no);
            }
            if (empty($data['pratibadi'])) {
                $this->session->set_flashdata('MSG_ERROR', "कृपया प्रतिवादीको विवरण दाखिला गर्नुहोस");
                redirect('Darta/addPratiBadi/' . $darta_no);
            }
            $data['workers']                = $this->CommonModel->getData('staff', 'ASC');
            $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            if (!empty($muddha_darta_no)) {
                $data['mudda_darta_details'] =  $this->CommonModel->getDataByID('badi_firad_patra', $muddha_darta_no);
            }
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
    //edit nibedan patra
    public function editNibedanPatra($id)
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            $muddha_darta_no = $this->uri->segment(4);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'view';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'प्रतिवादीको विवरण'
            ));
            $data['breadcrumb']             = $this->breadcrumb->output();
            $data['darta_detail']           = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['workers']                = $this->CommonModel->getData('staff', 'ASC');
            $data['subject']                = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            $data['badi']                   = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['pratibadi']              = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['witness']                = $this->CommonModel->getResultByMultipleCondition('witness', array('darta_no' => $darta_no, 'type' => 1));
            $data['documents']              = $this->CommonModel->getResultByMultipleCondition('documents', array('darta_no' => $darta_no, 'type' => 1));
            //pp($data['documents']);
            $data['row']                    = $this->CommonModel->getDataByID('badi_firad_patra', $id);
            //pp($data['row']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    //save nibedan patra
    public function saveNibedanPatra()
    {
        if ($this->input->post('submit')) {
            $darta_no = $this->input->post('darta_no');
            $nibedan_dastur       = $this->input->post('nibedan_dastur');
            $suchana_dastur       = $this->input->post('suchana_dastur');
            $pratilipi_dastur     = $this->input->post('pratilipi_dastur');
            $jamma                = $this->input->post('jamma');
            $pana                 = $this->input->post('pana');
            $muddha_details       = $this->input->post('muddha_details');
            $details              = implode('<>', $muddha_details);
            $total_print = $this->CommonModel->Totalprint('badi_firad_patra', $darta_no);
            $data = array(
                'darta_no'          => $darta_no,
                'muddha_id'         => $darta_no,
                'muddha_details'    => $details,
                'nibedan_dastur'    => $nibedan_dastur,
                'suchana_dastur'    => $suchana_dastur,
                'pratilipi_dastur'  => $pratilipi_dastur,
                'jamma'             => $jamma,
                'pana'              => $pana,
                'created_on'        => convertDate(date('Y-m-d')),
                'created_by'        => $this->session->userdata('EM_USER_ID'),
                'print_count'       => $total_print + 1,
            );
            $result = $this->CommonModel->insertData('badi_firad_patra', $data);
            if ($result) {
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi            = array();
                if (!empty($w_name)) {
                    foreach ($w_name as $key => $wit) {
                        $sachi[]      = array(
                            'name'      => $w_name[$key],
                            'age'       => $w_age[$key],
                            'phone'     => $w_phone[$key],
                            'address'   => $w_address[$key],
                            'darta_no'  => $darta_no,
                            'type'      => '1',
                        );
                    }
                    $this->CommonModel->batchInsert($sachi, 'witness');
                }

                //upload
                $document_title = $this->input->post('doc_name');
                $postupload = $this->input->post('userfile');
                if(!empty($document_title)) {
                    if (!empty($_FILES['userfile']['name'])) {
                        $mypath = realpath(APPPATH . '../uploads');
                        foreach ($_FILES['userfile']['name'] as $key => $value) {
                            if ($document_title[$key] != '') {
                                $extionpart                     = pathinfo($value);
                                $user_filename                  = str_replace(' ', '_', trim($document_title[$key]) . '.' . $extionpart['extension']);
                                $system_filename                = $result . '_' . time() . '_' . $user_filename;
                            } else {
                                $user_filename                  = str_replace(' ', '_', $value);
                                $system_filename                = $result . '_' . '_' . time() . $user_filename;
                            }
                            $_FILES['uploadDocuments']              = array();
                            $_FILES['uploadDocuments']['name']      = $system_filename;
                            $_FILES['uploadDocuments']['type']      = $_FILES['userfile']['type'][$key];
                            $_FILES['uploadDocuments']['tmp_name']  = $_FILES['userfile']['tmp_name'][$key];
                            $_FILES['uploadDocuments']['error']     = $_FILES['userfile']['error'][$key];
                            $_FILES['uploadDocuments']['size']      = $_FILES['userfile']['size'][$key];
                            // Initialize the document config
                            $config['upload_path']                  = $mypath;
                            $config['allowed_types']                = 'pdf|jpg|png';
                            $config['file_name']                    = $system_filename;
                            $config['file_ext_tolower']             = TRUE;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            // Upload the document
                            if (!$this->upload->do_upload('uploadDocuments')) {
                                $docerros[$key] = array('error' => $this->upload->display_errors());
                                redirect('Darta/addDetails'.$darta_no);
                            } else {
                                if ($document_title[$key] != '') {
                                    $doctitle = $document_title[$key];
                                } else {
                                    $extionpart = pathinfo($value);
                                    $doctitle = str_replace('_', ' ', str_replace('.' . $extionpart['extension'], '', $user_filename));
                                }
                                // set the values in the db
                                $data['documents']['darta_no']             = $darta_no;
                                $data['documents']['doc_type']             = $document_title[$key];
                                $data['documents']['doc_name']             = $system_filename;
                                $data['documents']['type']                 = 1;
                                $this->CommonModel->insertData('documents', $data['documents']);
                            }
                        }
                    }
                }
               
                redirect('Darta/generateFiradPatra/' . $darta_no);
            }
        }
    }

    public function updateNibedanPatra()
    {
        if ($this->input->post('submit')) {
            $data_id = $this->input->post('data_id');
            $darta_no = $this->input->post('darta_no');
            $nibedan_dastur       = $this->input->post('nibedan_dastur');
            $suchana_dastur       = $this->input->post('suchana_dastur');
            $pratilipi_dastur     = $this->input->post('pratilipi_dastur');
            $jamma                = $this->input->post('jamma');
            $pana                 = $this->input->post('pana');
            $muddha_details       = $this->input->post('muddha_details');
            $details              = implode('<>', $muddha_details);
            $total_print = $this->CommonModel->Totalprint('badi_firad_patra', $darta_no);
            $data = array(
                'muddha_details'    => $details,
                'nibedan_dastur'    => $nibedan_dastur,
                'suchana_dastur'    => $suchana_dastur,
                'pratilipi_dastur'  => $pratilipi_dastur,
                'jamma'             => $jamma,
                'pana'              => $pana,
            );
            $result = $this->CommonModel->updateData('badi_firad_patra', $data_id, $data);
            if ($result) {
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi              = array();
                if (!empty($w_name)) {
                    foreach ($w_name as $key => $wit) {
                        $sachi[]      = array(
                            'id'        => $w_id[$key],
                            'name'      => $w_name[$key],
                            'age'       => $w_age[$key],
                            'phone'     => $w_phone[$key],
                            'address'   => $w_address[$key],
                        );
                    }
                    $this->CommonModel->batchUpdate('witness', $w_id, $sachi);
                }
                $w_name_new             = $this->input->post('w_name_new');
                $w_phone_new            = $this->input->post('w_phone_new');
                $w_age_new              = $this->input->post('w_age_new');
                $w_address_new          = $this->input->post('w_address_new');
                $sachi_new            = array();
                if (!empty($w_name_new)) {
                    foreach ($w_name_new as $key => $wit) {
                        $sachi_new[]      = array(
                            'name'      => $w_name_new[$key],
                            'age'       => $w_age_new[$key],
                            'phone'     => $w_phone_new[$key],
                            'address'   => $w_address_new[$key],
                            'darta_no'  => $darta_no,
                            'type'      => 1,
                        );
                    }
                    $this->CommonModel->batchInsert($sachi_new, 'witness');
                }
                redirect('Darta/editNibedanPatra/' . $darta_no);
            }
        }
    }
    //edit nibedan patra details
    public function editCaseDetails()
    {
        if ($this->input->is_ajax_request()) {
            $id                   = $this->input->post('detail_id');
            $details              = $this->CommonModel->getDataByID('badi_firad_patra', $id);
            $case1                = $this->input->post('case1');
            $case2                = $this->input->post('case2');
            $laywer_details       = $this->input->post('laywer_details');
            $subject              = $this->input->post('subject');
            $officer              = $this->input->post('officer');
            if (empty($id)) {
                $response         = array(
                    'status'      => 'error',
                    'data'        => "oops ! something goes worng",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            if (!empty($_FILES['userfile']['name'])) {
                $mypath = realpath(APPPATH . '../uploads');
                $user_filename      = str_replace(' ', '_', $_FILES['userfile']['name']);
                $nibedan            = $details['darta_no'] . '_' . time() . '_' . $user_filename;
                $config             = array(
                    'upload_path'   => $mypath,
                    'allowed_types' => "jpg|png|gif|PNG",
                    'overwrite'     => TRUE,
                    'file_name'     => $nibedan,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) {
                    $error =  $this->upload->display_errors();
                    $response = array(
                        'status'      => 'error',
                        'data'         => "upload file not supported",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $this->upload->do_upload();
                }
            } else {
                $nibedan = $this->input->post('old_file');
            }
            $data = array(
                'official_stamp'    => $case1,
                'muddha_details'    => $case2,
                'has_file'          => $nibedan,
                'has_layer'         => $laywer_details,
                'officer'           => $officer,
                'status'            => 1,
            );
            $result = $this->CommonModel->updateData('badi_firad_patra', $id, $data);
            if ($result) {
                $response           = array(
                    'status'        => 'success',
                    'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'       => 'redirect',
                    'redirect_url'  => base_url() . 'Darta/generateFiradPatra/' . $details['darta_no'],
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            } else {
                $response = array(
                    'status'      => 'error',
                    'data'         => "fail to insert data",
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }

    //generate firad patra
    public function generateFiradPatra()
    {
        $darta_no                           = $this->uri->segment(3);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
        $data['muddhadetails']              = $this->CommonModel->getDataBySelectedFields('badi_firad_patra', 'darta_no', $darta_no);
        $data['officer']                    = $this->CommonModel->getDataByID('staff', $data['muddhadetails']['officer']);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
        $data['tokaadesh']                  = $this->CommonModel->getDataByID('tok_aadesh', 1);
        $data['staff']                      = $this->CommonModel->getDataByID('staff', 1);
        $data['witness']                    = $this->CommonModel->getResultByMultipleCondition('witness', array('darta_no' => $darta_no, 'type' => 1));
        $data['documents']                  = $this->CommonModel->getResultByMultipleCondition('documents', array('darta_no' => $darta_no, 'type' => 1));
        $darta_no                           = $this->uri->segment(3);
        $data['aanusuchi']                  = $this->CommonModel->getData('letters', 'ASC');
        $data['workers']                    = $this->CommonModel->getData('staff', 'ASC');

        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
        $this->load->view('firad_patra', $data);
    }

    /*-------------------------------- लिखित जवाफ प्रतिवादी 
    -----------------------------------------------------------------------------*/
    public function addLikhitJawaf($darta_no)
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            $muddha_darta_no = $this->uri->segment(4);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'likhit_jawaf';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'प्रतिवादीको विवरण'
            ));
            $data['breadcrumb']                 = $this->breadcrumb->output();
            $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['row']                        = $this->CommonModel->getDataBySelectedFields('likhit_jawaf', 'darta_no', $darta_no);
            $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
            $data['tokaadesh']                  = $this->CommonModel->getWhere('tok_aadesh', array('letter_type' => 5));
            $data['local_dafa']                 = $this->CommonModel->getData('local_dafa','DESC');
            $data['sarkar_yain']                = $this->CommonModel->getData('sarkar_yain', 'DESC');
            $data['staffs']                     = $this->CommonModel->getData('staff', 'ASC');
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    //save likhit jawaf.
    public function saveLikhitJawaf()
    {
        if ($this->input->post('submit')) {
            $darta_no = $this->input->post('darta_no');
            $this->form_validation->set_rules('dastur', 'dastur', 'required|trim');
            $this->form_validation->set_rules('case_details[]', 'case_details', 'required|trim');
            if ($this->form_validation->run() == false) {
                $this->session->set_flashdata('MSG_ERR', 'Please fill all required fields');
                redirect('Darta/addLikhitJawaf/' . $darta_no);
            }
            $total_print = $this->DartaMdl->Totalprint('likhit_jawaf', $darta_no);
            $case_details       = $this->input->post('case_details');
            $details              = implode('<>', $case_details);
            $data = array(
                'darta_no'      => $darta_no,
                'status'        => 1,
                'dastur'        => $this->input->post('dastur'),
                'case_details'  => $details,
                'type'          => 'pratibadi',
                'local_dafa'    => $this->input->post('local_dafa'),
                'staff_id'      => $this->input->post('staff_id'),
                'miti'          => $this->input->post('miti'),
                'created_on'    => convertDate(date('Y-m-d')),
                'created_by'    => $this->session->userdata('EM_USER_ID'),
                'print_count'   => $total_print + 1,
            );
            $result = $this->CommonModel->insertData('likhit_jawaf', $data);
            if ($result) {
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi            = array();
                //save witness.
                if (!empty($w_name)) {
                    foreach ($w_name as $key => $wit) {
                        $sachi[]      = array(
                            'name'      => $w_name[$key],
                            'age'       => $w_age[$key],
                            'phone'     => $w_phone[$key],
                            'address'   => $w_address[$key],
                            'darta_no'  => $darta_no,
                            'type'      => '2',
                        );
                    }
                    $this->CommonModel->batchInsert($sachi, 'witness');
                }
                //upload
                $document_title = $this->input->post('doc_name');
                if(!empty($document_title)) {
                    if (!empty($_FILES['userfile']['name'])) {
                        $mypath = realpath(APPPATH . '../uploads');
                        foreach ($_FILES['userfile']['name'] as $key => $value) {
                            if ($document_title[$key] != '') {
                                $extionpart                     = pathinfo($value);
                                $user_filename                  = str_replace(' ', '_', trim($document_title[$key]) . '.' . $extionpart['extension']);
                                $system_filename                = $result . '_' . time() . '_' . $user_filename;
                            } else {
                                $user_filename                  = str_replace(' ', '_', $value);
                                $system_filename                = $result . '_' . '_' . time() . $user_filename;
                            }
                            $_FILES['uploadDocuments']              = array();
                            $_FILES['uploadDocuments']['name']      = $system_filename;
                            $_FILES['uploadDocuments']['type']      = $_FILES['userfile']['type'][$key];
                            $_FILES['uploadDocuments']['tmp_name']  = $_FILES['userfile']['tmp_name'][$key];
                            $_FILES['uploadDocuments']['error']     = $_FILES['userfile']['error'][$key];
                            $_FILES['uploadDocuments']['size']      = $_FILES['userfile']['size'][$key];
                            // Initialize the document config
                            $config['upload_path']                  = $mypath;
                            $config['allowed_types']                = 'pdf|jpg|png';
                            $config['file_name']                    = $system_filename;
                            $config['file_ext_tolower']             = TRUE;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            // Upload the document
                            if (!$this->upload->do_upload('uploadDocuments')) {
                                $docerros[$key] = array('error' => $this->upload->display_errors());
                               
                            } else {
                                if ($document_title[$key] != '') {
                                    $doctitle = $document_title[$key];
                                } else {
                                    $extionpart = pathinfo($value);
                                    $doctitle = str_replace('_', ' ', str_replace('.' . $extionpart['extension'], '', $user_filename));
                                }
                                // set the values in the db
                                $data['documents']['darta_no']             = $darta_no;
                                $data['documents']['doc_type']             = $document_title[$key];
                                $data['documents']['doc_name']             = $system_filename;
                                $data['documents']['type']                 = 2;
                                // pp($data['documents']);
                                $this->CommonModel->insertData('documents', $data['documents']);
                            }
                        }
                    }
                }
                redirect('Darta/generateLikhitPatra/' . $darta_no);
            }
        }
    }

    //generate likhit parta
    public function generateLikhitPatra()
    {
        $darta_no                           = $this->uri->segment(3);
        $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
        $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
        $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
        $data['likhitjawaf']                = $this->CommonModel->getDataBySelectedFields('likhit_jawaf', 'darta_no', $darta_no);
        if(empty($data['likhitjawaf'])) {
            $this->session->set_flashdata('MSG_ERR', 'विवरण भर्नुहोस्');
            redirect('Darta/addLikhitJawaf/'.$darta_no);
        }
        $data['officer']                    = $this->CommonModel->getDataByID('staff', $data['muddhadetails']['officer']);
        $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
        $data['witness']                    = $this->CommonModel->getResultByMultipleCondition('witness', array('darta_no' => $darta_no, 'type' => 2));
        $data['documents']                  = $this->CommonModel->getResultByMultipleCondition('documents', array('darta_no' => $darta_no, 'type' => 2));
        $data['tokaadesh']                  = $this->CommonModel->getWhere('tok_aadesh', array('letter_type' => 5));
        $data['local_dafa']                    = $this->CommonModel->getDataByID('local_dafa', $data['likhitjawaf']['local_dafa']);
        $data['sarkar_yain']                    = $this->CommonModel->getDataByID('sarkar_yain', $data['likhitjawaf']['sarkar_yain']);
        $data['staff']                    = $this->CommonModel->getDataByID('staff', $data['likhitjawaf']['staff_id']);
        $this->load->view('pratibadi_patra', $data);
    }

    //edit likhit jawaf
    public function viewLikhitJawaf()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            $muddha_darta_no = $this->uri->segment(4);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'edit_likhit';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'प्रतिवादीको विवरण'
            ));
            $data['breadcrumb']                 = $this->breadcrumb->output();
            
            $data['row']                        = $this->CommonModel->getDataBySelectedFields('likhit_jawaf', 'darta_no', $darta_no);
            //pp($data['row']);
            $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['row']                        = $this->CommonModel->getDataBySelectedFields('likhit_jawaf', 'darta_no', $darta_no);
            $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
            $data['tokaadesh']                  = $this->CommonModel->getWhere('tok_aadesh', array('letter_type' => 5));
            $data['local_dafa']                 = $this->CommonModel->getData('local_dafa', 'DESC');
            $data['sarkar_yain']                = $this->CommonModel->getData('sarkar_yain', 'DESC');
            $data['staffs']                     = $this->CommonModel->getData('staff', 'ASC');
            $data['documents']                  = $this->CommonModel->getWhereAll('documents', array('type' =>2, 'darta_no' => $darta_no ));
            $data['witness']                    = $this->CommonModel->getWhereAll('witness', array('type' => 2, 'darta_no' => $darta_no));
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    //update likhit jawaf
    public function updateLikhitJawaf()
    {
        if ($this->input->post('submit')) {
            $darta_no = $this->input->post('darta_no');
            $data_id  = $this->input->post('data_id');
            $this->form_validation->set_rules('dastur', 'dastur', 'required|trim');
            $this->form_validation->set_rules('case_details[]', 'case_details', 'required|trim');
            if ($this->form_validation->run() == false) {
                $this->session->set_flashdata('MSG_ERR', 'Please fill all required fields');
                redirect('Darta/viewLikhitJawaf/' . $darta_no);
            }
            $case_details       = $this->input->post('case_details');
            $details              = implode('<>', $case_details);
            $data = array(
                'dastur'        => $this->input->post('dastur'),
                'case_details'  => $details,
                'local_dafa'    => $this->input->post('local_dafa'),
                'staff_id'      => $this->input->post('staff_id'),
                'miti'          => $this->input->post('miti'),
            );
            $result = $this->CommonModel->updateData('likhit_jawaf', $data_id, $data);
            if ($result) {
                // $document_title = $this->input->post('doc_name');
                // if (!empty($_FILES['userfile']['name'])) {
                //     $mypath = realpath(APPPATH . '../uploads');
                //     foreach ($_FILES['userfile']['name'] as $key => $value) {
                //         if ($document_title[$key] != '') {
                //             $extionpart                     = pathinfo($value);
                //             $user_filename                  = str_replace(' ', '_', trim($document_title[$key]) . '.' . $extionpart['extension']);
                //             $system_filename                = $result . '_' . time() . '_' . $user_filename;
                //         } else {
                //             $user_filename                  = str_replace(' ', '_', $value);
                //             $system_filename                = $result . '_' . time() . $user_filename;
                //         }
                //         $_FILES['uploadDocuments']              = array();
                //         $_FILES['uploadDocuments']['name']      = $system_filename;
                //         $_FILES['uploadDocuments']['type']      = $_FILES['userfile']['type'][$key];
                //         $_FILES['uploadDocuments']['tmp_name']  = $_FILES['userfile']['tmp_name'][$key];
                //         $_FILES['uploadDocuments']['error']     = $_FILES['userfile']['error'][$key];
                //         $_FILES['uploadDocuments']['size']      = $_FILES['userfile']['size'][$key];
                //         // Initialize the document config
                //         $config['upload_path']                  = $mypath;
                //         $config['allowed_types']                = 'pdf|jpg|png';
                //         $config['file_name']                    = $system_filename;
                //         $config['file_ext_tolower']             = TRUE;
                //         $this->load->library('upload', $config);
                //         $this->upload->initialize($config);
                //         // Upload the document
                //         if (!$this->upload->do_upload('uploadDocuments')) {
                //             $docerros[$key] = array('error' => $this->upload->display_errors());
                //             redirect('Darta/addDetails' . $darta_no);
                //         } else {
                //             if ($document_title[$key] != '') {
                //                 $doctitle = $document_title[$key];
                //             } else {
                //                 $extionpart = pathinfo($value);
                //                 $doctitle = str_replace('_', ' ', str_replace('.' . $extionpart['extension'], '', $user_filename));
                //             }
                //             // set the values in the db
                //             $data['documents']['darta_no']             = $darta_no;
                //             $data['documents']['doc_type']             = $document_title[$key];
                //             $data['documents']['doc_name']             = $system_filename;
                //             $this->CommonModel->insertData('documents', $data['documents']);
                //         }
                //     }
                // }
                $w_name             = $this->input->post('w_name');
                $w_phone            = $this->input->post('w_phone');
                $w_age              = $this->input->post('w_age');
                $w_address          = $this->input->post('w_address');
                $w_id               = $this->input->post('w_id');
                $sachi            = array();
                if (!empty($w_name)) {
                    foreach ($w_name as $key => $wit) {
                        $sachi[]      = array(
                            'id'        => $w_id[$key],
                            'name'      => $w_name[$key],
                            'age'       => $w_age[$key],
                            'phone'     => $w_phone[$key],
                            'address'   => $w_address[$key],
                        );
                    }
                    $this->CommonModel->batchUpdate('witness', $w_id, $sachi);
                }
                $w_name_new             = $this->input->post('w_name_new');
                $w_phone_new            = $this->input->post('w_phone_new');
                $w_age_new              = $this->input->post('w_age_new');
                $w_address_new          = $this->input->post('w_address_new');
                $sachi_new            = array();
                if (!empty($w_name_new)) {
                    foreach ($w_name_new as $key => $wit) {
                        $sachi_new[]      = array(
                            'name'      => $w_name_new[$key],
                            'age'       => $w_age_new[$key],
                            'phone'     => $w_phone_new[$key],
                            'address'   => $w_address_new[$key],
                            'darta_no'  => $darta_no,
                            'type'      => 2,
                        );
                    }
                    $this->CommonModel->batchInsert($sachi_new, 'witness');
                }
                redirect('Darta/generateLikhitPatra/' . $darta_no);
            }
        }
    }
    public function viewDocs() {
        $id             = $this->input->post('id');
        $data['doc']    = $this->CommonModel->getDataByID('documents', $id);
        $this->load->view('viewdocs', $data);
    }
    //edit documents
    public function editDocs()
    {
        $id             = $this->input->post('id');
        $data['doc']    = $this->CommonModel->getDataByID('documents', $id);
        $this->load->view('editdocs', $data);
    }
    
    //update likhit jawaf docs
    public function UpdateDocs()
    {
        if ($this->input->is_ajax_request()) {
            $doc_id = $this->input->post('doc_id');
            $darta_no = $this->input->post('darta_no');
            //$document_title = $this->input->post('document_title');
            $this->form_validation->set_rules('doc_name', 'doc_name', 'required');
            if ($this->form_validation->run() == false) {
                $response = array(
                    'status'      => 'validation_error',
                    'message'     => '<div class="alert alert-danger">' . validation_errors() . '</div>',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $document_title = $this->input->post('doc_name');
            if (!empty($_FILES['userfile']['name'])) {
                $mypath = realpath(APPPATH . '../uploads');
                $extionpart                     = pathinfo($_FILES['userfile']['name']);
                $user_filename                  = str_replace(' ', '_', trim($document_title) . '.' . $extionpart['extension']);
                $nibedan                        = $darta_no     . '_' . time() . '_' . $user_filename;
                // $user_filename      = str_replace(' ','_',$_FILES['userfile']['name']);
                // $nibedan            = $darta_no.'_'.time().'_'.str_replace(' ','_',$document_title);
                $config             = array(
                    'upload_path'   => $mypath,
                    'allowed_types' => "jpg|png|gif|PNG",
                    'overwrite'     => TRUE,
                    'file_name'     => $nibedan,
                );
                $this->load->library('upload');
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) {
                    $error =  $this->upload->display_errors();
                    $response = array(
                        'status'      => 'error',
                        'data'         => "upload file not supported",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $this->upload->do_upload();
                }
            } else {
                $nibedan = $this->input->post('old_file');
            }
            $doc_type       = $this->input->post('doc_type');
            $post_data      = array(
                'doc_type'      => $document_title,
                'doc_name'      => $nibedan,
            );
            //pp($post_data);
            $result = $this->CommonModel->UpdateData('documents', $doc_id, $post_data);
            if ($result) {
                $response = array(
                    'status'      => 'success',
                    'data'         => "सफलतापूर्वक सम्मिलित गरियो",
                    'message'     => 'success'
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
        } else {
            exit('no direct script allowed');
        }
    }
    /*--------------------------------------------------------------------*/
    // public function 
    /*--------------------------------------------------------------------*/
    //details
    public function viewDetails()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'detail';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'मुद्दा दर्ता विवरण'
            ));
            $data['breadcrumb']                 = $this->breadcrumb->output();
            $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['witness']                    = $this->CommonModel->getAllDataByField('witness', 'darta_no', $darta_no);
            $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['mudda_bisaye']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }

    public function viewAnusuchi()
    {
        if ($this->authlibrary->HasModulePermission($this->module_code, "VIEW")) {
            $darta_no = $this->uri->segment(3);
            if (empty($darta_no)) {
                $this->session->set_flashdata('MSG_ERR', 'दर्ता नं भेटिएन.');
                redirect('Darta');
            }
            $data['page']   = 'letters';
            $data['script'] = 'script';
            $this->breadcrumb->populate(array(
                'ड्यासबोर्ड'                    => '',
                'मुद्दाहरुको सुचिमा जानुहोस '      => 'Darta',
                'मुद्दा आनुसुची विवरण'
            ));
            $data['breadcrumb']                 = $this->breadcrumb->output();
            $data['aanusuchi']                  = $this->CommonModel->getData('letters', 'ASC');
            $data['darta_detail']               = $this->CommonModel->getDataBySelectedFields('darta', 'darta_no', $darta_no);
            $data['badi']                       = $this->CommonModel->getAllDataByField('badi_detail', 'darta_no', $darta_no);
            $data['pratibadi']                  = $this->CommonModel->getAllDataByField('pratibadi_detail', 'darta_no', $darta_no);
            $data['witness']                    = $this->CommonModel->getAllDataByField('witness', 'darta_no', $darta_no);
            $data['subject']                    = $this->CommonModel->getDataBySelectedFields('mudda_bisaye', 'id', $data['darta_detail']['id']);
            $this->load->view('main', $data);
        } else {
            $this->session->set_flashdata('MSG_ACCESS', 'तपाईंको अनुमति अस्वीकृत गरिएको छ');
            redirect('Dashboard');
        }
    }
}// end of class