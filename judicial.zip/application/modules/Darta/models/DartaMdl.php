<?php 

class DartaMdl extends CI_Model {

    public function GetMaxDartaNo()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`id`) AS `darta_no` FROM `darta`")->row();
        return $row;
    }

    public function GetMaxDartaID()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`darta_id`) AS `darta_no` FROM `darta`")->row();
        return $row;
    }

    public function GetMuddhaMaxDartaNo()
    {
        $maxid = 0;
        $row = $this->db->query("SELECT MAX(`darta_id`) AS `darta_no` FROM `badi_firad_patra`")->row();
        return $row;
    }

    //get list
    public function getDartaList() {
        $this->db->select('t1.*, t2.subject,t2.remarks')->from('darta t1');
        $this->db->join('mudda_bisaye t2','t2.id = t1.mudda_bisaye','left');
        $this->db->order_by("id", "desc");;
        
        $query = $this->db->get();
        return $query->result_array();
    }

    public function checkIfBadiExits($darta_no) {
        $this->db->select('*')->from('badi_detail');
        $this->db->where('darta_no', $darta_no);
        $query = $this->db->get();
        if($query->num_rows() > 0 ) {
            return true;
        } else {
            return false;
        }
    }

    public function getDistinctDafa() {
        $this->db->select('DISTINCT(name)');
        $query = $this->db->get('dafa');
        return $query->result_array();
    }

    //get total likhit jawaf by darta no
    public function Totalprint($table, $darta_no)
    {
        $this->db->from($table);
        $this->db->where('darta_no', $darta_no);
        return $this->db->count_all_results();
    }
}