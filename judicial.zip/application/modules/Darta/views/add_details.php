<div class="content-i">
    <div class="content-box">
       <!--  <div class="alert alert-info alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <strong>प्रतिवादीको विवरण भर्नुहोस्</strong></div> -->
        <div class="element-wrapper">
            <div class="element-box-tp">
                <div class="anusuchi">
                    <?php echo form_open_multipart('Darta/saveCaseDetails', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
                        <div class="form-desc">
                          <span class="text-danger"> कृपया &nbsp;* चिन्न भएको ठाउँ खाली नछोड्नु होला |</span>
                        </div>

                        <div class="row">
                            <input type="hidden" name="darta_no" class="form-control" value="<?php echo $darta_detail['darta_no']?>" readonly>
                            <input type="hidden" name="mudda_darta_id" value="<?php echo !empty($mudda_darta_details)?$mudda_darta_details['id']:''?>">
                            <?php if(!empty($mudda_darta_details)) : ?>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label for="">दर्ता मिति </label>
                                    <div class="date-input">
                                        <input type="text" name="" class="form-control" value="<?php echo !empty($mudda_darta_details)?$mudda_darta_details['darta_no']:''?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <?php endif;?>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label for="">मिति </label>
                                    <div class="date-input">
                                        <input type="text" name="date" class="form-control" value="<?php echo !empty($mudda_darta_details)?$mudda_darta_details['darta_date']:convertDate(date('Y-m-d'))?>" readonly>
                                    </div>
                                </div>
                            </div>
                             <div class="col-sm-1">
                                <div class="form-group">
                                    <label for="">दफा</label>
                                    <div class="">
                                        <input type="text" name="dafa" class="form-control" value="<?php echo $darta_detail['dafa']?>" readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="form-group">
                                  <label for="">मुद्दाको प्रकार </label><input class="form-control" type="text" readonly="" value="<?php echo $subject['subject']?>">
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="form-group">
                                  <label for="">मुद्दाको विषय</label><input class="form-control" type="text" name = "subject" readonly="" value="<?php echo $darta_detail['case_title']?>">
                                </div>
                            </div>

                        </div>
                        
                        <!-- <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for=""> पालिकाको तर्फ बाट <span class="text-danger">*</span> </label><textarea class="form-control" name="case1" rows="5"> <?php echo !empty($mudda_darta_details)?$mudda_darta_details['official_stamp']:''?></textarea>
                                </div>
                            </div>
                        </div> -->

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for=""> निवेदनको विवरण<span class="text-danger">*</span> </label><textarea cols="30" id="ckeditor2" name="case2" rows="5"> <?php echo !empty($mudda_darta_details)?$mudda_darta_details['muddha_details']:''?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">निवेदन भएमा अपलोड गर्नुहोस्</label>
                                    <input type = "file" name="userfile" class="form-control userfile">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">कानुन व्यवसायी राखेको भएमा विवरण राख्नुहोस </label>
                                    <textarea class="form-control" name="laywer_details"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">रुजु गर्नेको नाम </label>
                                    <select class="form-control" name="officer">
                                        <option value="">छानुहोस</option>
                                        <?php if(!empty($workers)) :
                                            foreach($workers as $worker) : ?>
                                            <option value="<?php echo $worker['id']?>"><?php echo $worker['name']?></option>
                                        <?php endforeach;endif;?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-12">
                                 <div class="form-buttons-w text-center">
                                    <button type="submit" class='btn btn-submit btn-primary btn-block save_btn' name="submit">सेभ गर्नुहोस <i class="fa fa-arrow-circle-right"></i></button>
                                </div>
                            </div>
                        </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>