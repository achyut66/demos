<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <?php echo form_open('Darta/saveLikhitJawaf', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data')); ?>
          <div class="element-box-tp">
            <?php if ($this->session->flashdata('MSG_ERR')) { ?>
              <div class="alert alert-danger"><?php echo $this->session->flashdata("MSG_ERR") ?></div>
            <?php } ?>
            <div class="anusuchi">
              <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
              <div class="text-center">
                <p style="margin-top:20px;">श्री <?php echo SITE_OFFICE ?></p>
                <p style="margin-top:-20px;">न्यायिक समितीसमक्ष पेश गरेको</p>
                <p style="margin-top:-20px;"><b>लिखित जवाफ</b> </p>
              </div>

              <div class="form-border">
                <?php if (!empty($pratibadi)) : $i = 1;
                  foreach ($pratibadi as $key => $p) : ?>
                    <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
                <?php endforeach;
                endif; ?>
              </div>
              <div class="text-center" style="margin-top:20px;">
                <p style="font-weight: bold;">विरुद्</p>
              </div>
              <div class="form-border">
                <?php if (!empty($badi)) :
                  $i = 1;
                  foreach ($badi as $key => $b) : ?>
                    <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
                <?php endforeach;
                endif; ?>
              </div>
              <!-- --------------------------------------------------------------------------------------------------------------------------------------------------------- -->
              <div style="margin-left:260px; margin-right: 40px; text-align: justify; margin-top: 70px;"><b>विषयः <span style="text-decoration: underline;"><?php echo $darta_detail['case_title'] ?></span></b></div><br>
              <?php if (!empty($badi)) {
                $total_badi = count($badi);
                if ($total_badi >= 1) {
                  $sombodan = 'हामी';
                } else {
                  $sombodan = 'म';
                }
              } ?>
              <div class="form-border">उल्लिखित विपक्षी भएको उक्त विवादमा यस न्यायिक समितिबाट मेरा नाममा जारी भएको म्याद सुचना न्यायिक समितिबाट मिति
                <input type="text" name="miti" class="borderlessinput" required="true" id="post" value="">
                मा प्राप्त भएकोले सो निवेदन बमोजिमको आरोपका सम्बन्धमा देहायको व्यहोराको प्रतिउत्तर पत्र लीई उपस्थित भएको छु ।
              </div>
              <div class="form-border">
                १. निवेदकले मलाइ लगाएका आरोपका बिषयहरुका सम्बन्धमा मेरो भएको यथार्थ व्यहोरा निम्न लिखित बुदाहरुमा लेखिए बमोजिम, खुलाएको छु ।</div>
              <div class="form-border">
                <table class="table table-bordered" id="tbl_wiwaran" style="border:color:#000">
                  <thead>
                    <tr>
                      <th>मुद्दाको विवरण </th>
                      <th>
                        <button type="button" class="btn  btn-primary btnwiwaran" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><textarea class="form-control content" style="width:100%; height100px;" id="content" name="case_details[]"></textarea></td>
                      <td style="width:50px;"><button type="button" class="btn  btn-danger" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-15"></i> </button></td>
                    </tr>
                </table>
              </div>
              <div class="form-border">२. यस गाउँपालिका बाट जारी भएको स्थानिय न्यायिक कार्यविधिको

                <select class="" id="borderless" name="local_dafa">
                  <option value="">--कार्यविधिको दफा छान्नुहोस्--</option>
                  <?php if (!empty($local_dafa)) :
                    foreach ($local_dafa as $dafa) : ?>
                      <option value="<?php echo $dafa['id'] ?>"><?php echo $dafa['details'] ?></option>
                  <?php endforeach;
                  endif; ?>
                </select>

                बमोजिम प्रतिउत्तर दस्तुर रु.


                <input type="text" name="dastur" class="borderlessinput" placeholder="*" required="true" id="" value="">, तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छ
                ।
              </div>

              <div class="form-border">३. यो लिखित जवाफ म्याद भित्रै लिई म आफै उपस्थित भएको छु ।</div>

              <div class="form-border">
                <p>४. प्रमाण सम्बन्धि संलग्न कागजातहरु :</p>
                <table class="table table-bordered" id="frm_tbl_upload">
                  <thead>
                    <tr>
                      <th>पेश गरेको कागजातको नाम </th>
                      <th>कागजात</th>
                      <th>
                        #
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><input type="text" name="doc_name[]" class="form-control"></td>
                      <td><input type="file" name="userfile[]" class="form-control uploadfiles"></td>
                      <td><button type="button" class="btn  btn-primary btnUpload" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div class="form-border">
                <p>५. साक्षीहरु :</p>
                <table class="table table-bordered" id="frm_tbl_wit" style="border:color:#000">
                  <thead>
                    <tr>
                      <th>नाम</th>
                      <th>ठेगाना</th>
                      <th>उमेर</th>
                      <th>सम्पर्क नं.</th>
                      <th>
                        <?php if (!empty($anusuchi_5)) : ?>
                          <button type="button" class="btn  btn-primary btnaddNewField" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button>
                        <?php else : ?>
                          #
                        <?php endif; ?>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($row)) : ?>
                      <?php if (!empty($witness)) :
                        foreach ($witness as $w) : ?>
                          <tr>
                            <input type="hidden" name="w_id[]" value="<?php echo $w['id'] ?>">
                            <td><input type="text" name="w_name[]" class="form-control" value="<?php echo $w['name'] ?>" required="true"></td>
                            <td><input type="text" name="w_address[]" class="form-control" value="<?php echo $w['address'] ?>" required="true"></td>
                            <td><input type="text" name="w_age[]" class="form-control" value="<?php echo $w['age'] ?>" required="true"></td>
                            <td><input type="text" name="w_phone[]" class="form-control" value="<?php echo $w['phone'] ?>" required="true"></td>
                            <td><button type="button" data-href="<?php echo base_url() ?>BadiAnusuchi/deleteWitness/" class="btn btn-outline-danger deleteWitness" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस" data-id="<?php echo $w['id'] ?>"><i class="os-icon os-icon-ui-15"></i></button></td>
                          </tr>
                      <?php endforeach;
                      endif; ?>
                    <?php else : ?>
                      <tr>
                        <td><input type="text" name="w_name[]" class="form-control" value="" required="true"></td>
                        <td><input type="text" name="w_address[]" class="form-control" value="" required="true"></td>
                        <td><input type="text" name="w_age[]" class="form-control" value="" required="true"></td>
                        <td><input type="text" name="w_phone[]" class="form-control" value="" required="true"></td>
                        <td><button type="button" class="btn  btn-primary btnaddNewField" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button></td>
                      </tr>
                    <?php endif; ?>
                </table>
              </div>
              <!-- <div class="form-border">६. यस विषयमा अन्यत्र कहीं कतै कुनै निकायमा कुनै प्रकारको निवेदन दिईएको छैन ।</div> -->
              <div class="form-border">६. यसमा लेखिएको व्यहोरा ठिक साँचो सत्य हुन झुठा ठहरे कानून बमोजिम सजाय भोग्नतयार छु ।</div>

              <hr>
              <div class="col-md-12">
                <h5 style="text-decoration: underline;">तोक आदेश </h5>
                <textarea class="form-control content" rows="3" id="content" readonly required><?php echo $tokaadesh['tok_aadesh'] ?></textarea>
                <br>
                <select class="form-control" name="staff_id" required>
                  <option value="">तोक लगाउने कर्मचारी छान्नुहोस्</option>
                  <?php if (!empty($staffs)) :
                    foreach ($staffs as $key => $staff) : ?>
                      <option value="<?php echo $staff['id'] ?>"><?php echo $staff['name'] ?><b>(<?php echo $staff['designation'] ?>)</b></option>
                  <?php endforeach;
                  endif; ?>
                </select>
              </div>

              <hr>
              <div class="text-center">
                <?php if (empty($row)) : ?>
                  <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit" style=""><i class="fa fa-print"></i> सेभ र प्रिन्ट गर्नुहोस</button>
                <?php endif; ?>
              </div>

            </div>
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    //add new wiwaran field btanwiwaran
    $('.btnwiwaran').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      var new_row = '<tr><td><textarea class="form-control content" style="width:100%; height100px;" name="case_details[]" id="content"></textarea></td>' +
        '<td><button type="button" class="btn btn-outline-danger remove-wiwaran-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
        '<tr>';
      $("#tbl_wiwaran").append(new_row);
    });
    //remove samati members.
    $("body").on("click", ".remove-wiwaran-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    $('.btnaddNewField').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      <?php if (empty($anusuchi_5)) : ?>
        var new_row = '<tr class="row_mem">' +
          '<td><input type="text" name="w_name[]" class="form-control" value="" required="true"></td>' +
          '<td><input type="text" name="w_address[]" class="form-control" value="" required="true"></td>' +
          '<td><input type="text" name="w_age[]" class="form-control" value="" required="true"></td>' +
          '<td><input type="text" name="w_phone[]" class="form-control" value="" required="true"></td>' +
          '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
          '<tr>';
      <?php else : ?>
        var new_row = '<tr class="row_mem">' +
          '<td><input type="text" name="w_name_new[]" class="form-control" value="" required="true"></td>' +
          '<td><input type="text" name="w_address_new[]" class="form-control" value="" required="true"></td>' +
          '<td><input type="text" name="w_age_new[]" class="form-control" value="" required="true"></td>' +
          '<td><input type="text" name="w_phone_new[]" class="form-control" value="" required="true"></td>' +
          '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
          '<tr>';
      <?php endif; ?>
      $("#frm_tbl_wit").append(new_row);
    });
    //remove samati members.
    $("body").on("click", ".remove-muddha-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    //upload files
    $('.btnUpload').click(function(e) {
      var MaxInputs = 2;
      e.preventDefault();
      var trOneNew = $('.row_mem').length + 1;
      var new_row = '<tr class="row_mem">' +
        '<td><input type = "text" name = "doc_name[]" class="form-control"></td>' +
        '<td><input type = "file" name = "userfile[]" class="form-control uploadfiles" id="userfile" required></td>' +
        '<td><button type="button" class="btn btn-outline-danger remove-file-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
        '<tr>';
      $("#frm_tbl_upload").append(new_row);
    });

    $("body").on("click", ".remove-file-row", function(e) {
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });

    //remove witness
    $(document).on('click', '.deleteWitness', function(e) {
      e.preventDefault();
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        id = $(this).data('id');
        url = $(this).data('href');
        $.ajax({
          url: url,
          method: "POST",
          data: {
            id: id,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
          },
          beforeSend: function() {
            $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
          },
          success: function(resp) {
            if (resp.status == 'success') {
              toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": true,
                "onclick": null,
                "showDuration": "1000",
                "hideDuration": "2000",
                "timeOut": "2000",
                "extendedTimeOut": "3000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
              }
              toastr.error(resp.data);
              location.reload();
            }
          }
        });
      }
    });

    var cznInput = $("#post");
    cznInput.nepaliDatePicker({
      ndpYear: true,
      ndpMonth: true,
      ndpYearCount: 100,
    });

    $(document).on('change', '.uploadfiles', function(e) {
      var ext = $(this).val().split('.').pop().toLowerCase();
      if ($.inArray(ext, ['png', 'jpeg','jpg','pdf']) == -1) {
        alert('supports only png,jpeg,jpg,pdf');
        $(this).val('');
        $(this).css("border-color", "#FF0000");
        $(this).attr('required', true);
        return false;
      } else {
        $(this).css("border-color", "green");
        $('.save_btn').attr('disabled', false);
      }
    });
  });
</script>