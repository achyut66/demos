<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>निबेदन पत्र</title>

  <style>
    @page {
      margin: 10px;
    }

    body {
      margin: 20;
      font-size: 18px;
      color: #000;
    }

    .sheet {
      margin: 0;
      overflow: hidden;
      position: relative;
      box-sizing: border-box;
      page-break-after: always;
    }


    body.A4 .sheet {
      width: 210mm;
      height: auto;
    }


    body.letter .sheet {
      width: 216mm;
      height: 279mm
    }

    body.letter.landscape .sheet {
      width: 280mm;
      height: 215mm
    }

    body.legal .sheet {
      width: 216mm;
      height: 356mm
    }

    body.legal.landscape .sheet {
      width: 357mm;
      height: 215mm
    }

    /** Padding area **/
    .sheet.padding-10mm {
      padding: 10mm
    }

    .sheet.padding-15mm {
      padding: 15mm
    }

    .sheet.padding-20mm {
      padding: 20mm
    }

    .sheet.padding-25mm {
      padding: 25mm
    }

    /** For screen preview **/
    @media screen {
      body {
        background: #e0e0e0
      }

      .sheet {
        background: white;
        box-shadow: 0 .5mm 2mm rgba(0, 0, 0, .3);
        margin: 5mm auto;
      }
    }

    /** Fix for Chrome issue #273306 **/

    @page {
      size: A4 portrait;
      /* margin: 2cm 3cm; */
    }


    /* body {
      background-color: red;
    } */

    .page-break {
      page-break-before: always;
    }

    .avoid-break {
      page-break-inside: avoid;
    }

    .csstransforms {
      /* Abs positioning makes it not take up vert space */
      position: relative;
      top: 250px;
      text-align: justify;
      transform-origin: 0 0;
      transform: rotate(-90deg);
      padding: 10px;

    }

    .csstransforms-hakim {
      top: -40px;
      text-align: justify;

      transform: rotate(-90deg);
      padding: 10px;

    }

    .csstransforms-position {
      position: relative;
      top: -60px;
      left: 30px;
      text-align: justify;

      transform-origin: 0 0;
      transform: rotate(-90deg);
      padding: 10px;

    }

    .btn-class {
      /* Abs positioning makes it not take up vert space */
      position: absolute;
      top: 0px;
      text-align: justify;
      /* Border is the new background */

      /* Rotate from top left corner (not default) */
      transform-origin: 0 0;
      /* transform: rotate(-90deg);
      padding: 10px; */

    }

    .btn {
      background-color: #4CAF50;
      border: none;
      color: white;
      padding: 15px 32px;
    }

    .btn-print {
      background-color: #54a5fa;
      border: none;
      color: white;
      padding: 15px 32px;
    }

    @media all {
      .first-page {
        page-break-inside: avoid;
      }
    }
  </style>
</head>

<body class="A4">

  <section class="sheet padding-25mm page-break">
    <div id="hideme" class="btn-class">
      <a href="<?php echo base_url()
                ?>Darta" class="btn"> पछाडी जानुहोस</a>

      <button type="button" class="btn-print" id="basic"> प्रिन्ट गर्नुहोस</button>
    </div>
    <div style="margin-left:151.18px; height:302.3622047244094; width:300px;">
      <p class="csstransforms">श्री <?php echo SITE_OFFICE ?></p>
      <p class="csstransforms" style="margin-left:30px"><?php echo $tokaadesh['tok_aadesh'] ?></p>
    </div>
    <div style="margin-left:500px; height:302.3622047244094; width:300px;">
      <p class="csstransforms-hakim"><?php echo $staff['name'] ?></p>
      <p class="csstransforms-position"><?php echo $staff['designation'] ?></p>
    </div>
    <div style="width:500px;margin-left:241px; margin-top:60px">
      <p style="margin-top:30px;">श्री <?php echo SITE_OFFICE ?></p>
      <p style="margin-top:-10px;margin-left:-30px;">न्यायिक समितीसमक्ष पेश गरेको</p>
      <p style="margin-top:-10px;margin-left:28px"><b>निबेदन पत्र</b> </p>
    </div>
    <p style="margin-left:151.18px;text-align: justify; margin-top: 40px; margin-right:-40px">
      <?php if (!empty($badi)) :
        $i = 1;
        foreach ($badi as $key => $b) : ?>
          <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
      <?php endforeach;
      endif; ?>
    </p>
    <p style="margin-left:291px; margin-right: 40px; text-align: justify; margin-top: 25px;"><b>विरुद्</b></p>
    <p style="margin-left:151.18px; text-align: justify; margin-top: 25px;margin-right:-40px">
      <?php if (!empty($pratibadi)) : $i = 1;
        foreach ($pratibadi as $key => $p) : ?>
          <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
      <?php endforeach;
      endif; ?>
    </p>
    <div style="margin-left:180px;  text-align: justify; margin-top: 40px; font-size:16px; margin-right:-40px"><b>विषय : <?php echo $darta_detail['case_title'] ?></b></div>
    <div style="margin-left:151.18px;  text-align: justify; margin-top: 40px; margin-right:-40px" class="first-page">१. म निम्न लिखित बुदाहरुमा लेखिए बमोजिम निवेदन गर्दछ ।</div>
    <div style="margin-left:151.18px; text-align: justify; margin-top: 10px; margin-right:-40px">
      <?php if (!empty($muddhadetails['muddha_details'])) :
        $decision = explode('<>', $muddhadetails['muddha_details']);
        if (!empty($decision)) :
          $i = 1;
          foreach ($decision as $des) : ?>
            <?php //echo $this->mylibrary->convertedcit($i++)
            ?> <?php echo $des; ?>
        <?php endforeach;
        endif; ?>
      <?php endif; ?>
    </div>
    <div style="text-align: justify; margin-top: 10px;line-height:2em; margin-right:-40px">
      २.यस गाउँपालिका बाट जारी भएको स्थानिय न्यायिक कार्यविधिको दफा १४ बमोजिम
      निवेदन दस्तुर रु <?php echo $this->mylibrary->convertedcit($muddhadetails['nibedan_dastur']) ?> दोस्रो पक्ष एक जनालाई म्याद सुचना दस्तुर रु.<?php echo $this->mylibrary->convertedcit($muddhadetails['suchana_dastur']) ?>,पाना <?php echo $this->mylibrary->convertedcit($muddhadetails['pana']) ?> को प्रतिलिपि दस्तुर रु. <?php echo $this->mylibrary->convertedcit($muddhadetails['pratilipi_dastur']) ?>
      जम्मा रु <?php echo $this->mylibrary->convertedcit($muddhadetails['jamma']) ?> तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छु ।
    </div>
    <div style="text-align: justify; margin-top: 10px;margin-right:-40px">३. यो निवेदन स्थानिय सरकार संचालन ऐन, २०७४ को दफा १ को उपदफा (छ)
      अनुसार यसै समितिको अधिकारक्षेत्र भित्र पर्दछ ।</div>
    <div style="text-align: justify; margin-top: 10px;margin-right:-40px">४. यो निवेदन हदम्याद भित्रै छ र म निवेदकलाई यस बिषयमा निवेदनदिने हकदैया प्राप्त छ।</div>
    <div style="text-align: justify; margin-top: 10px;margin-right:-40px">५. साक्षीहरु :
      <?php $i = 1;
      if (!empty($witness)) : foreach ($witness as $key => $wit) : ?>
          <div style="margin-left:40px;  text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $wit['address'] . ', बस्ने ' . $this->mylibrary->convertedcit($wit['age']) . ' ' . $wit['name'] ?></div>
      <?php endforeach;
      endif; ?>
    </div>
    <div style="text-align: justify; margin-top: 10px;margin-right:-40px">६. संलग्न कागजातहरु :
      <?php $i = 1;
      if (!empty($documents)) : foreach ($documents as $key => $docs) : ?>
          <div style="margin-left:40px;  text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $docs['doc_type'] ?></div>
      <?php endforeach;
      endif; ?>
    </div>

    <div style="margin-left:490px;margin-top:40px;">नेबेदक</div>
    <?php if (!empty($badi)) :
      $i = 1;
      foreach ($badi as $key => $b) :
    ?>
        <div style="margin-left:476px;margin-top:10px;"><?php echo $b['b_name'] ?></div>
        <div style="margin-left:423px;margin-top:5px;"><?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($b['b_ward']) . ' ' . $b['b_address'] ?></div>
    <?php endforeach;
    endif; ?>
    <div style="margin-left: 151.18px; margin-top: 105px;font-size:14px;">इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ............................... ।</div>
  </section>

  <script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#basic').on("click", function() {
        //alert('hello');
        $('#hideme').hide();
        window.print();
      });
    });
  </script>
</body>
<script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>


</html>