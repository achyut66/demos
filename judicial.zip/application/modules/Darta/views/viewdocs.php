<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    <?php echo $doc['doc_type']?>
  </h4>
  <div class="onboarding-text">
   <img src="<?php echo base_url()?>uploads/<?php echo $doc['doc_name']?>" style="width:200px;height:200px;">
  </div>
  
</div>