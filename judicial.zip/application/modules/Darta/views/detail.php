<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <h5 class="form-header"><div class="fa fa-info-circle"></div> <?php echo $this->mylibrary->convertedcit($subject['subject'])?></h5>
              <button type="button" class="btn btn-sm btn-primary"><i class="fa fa-info-circle"></i> दर्ता नं-<?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?></button>
              <button type="button" class="btn btn-sm btn-warning"><i class="fa fa fa-calendar-check-o"></i> मिति-<?php echo $this->mylibrary->convertedcit($darta_detail['date'])?></button>
              <hr>
              <?php if(!empty($badi)) : ?>
                <h6>१) <span style="text-decoration: underline;">वादीको विवरण</span></h6>
                <div class="">
                  <table class="table table-lightbordered table-striped">
                    <thead>
                      <tr>
                        <th>नाम</th>
                        <th>जन्ममिति</th>
                        <th>सम्पर्क नं</th>
                        <th>ना.प्र.प.नं.</th>
                        <th>जारी मिति</th>
                        <th>जारी जिल्ला</th>
                        <th>बाजेको नाम</th>
                        <th>बावुको नाम</th>
                        <th>आमाको नाम</th>
                        <th>पति/पत्निको नाम</th>
                        <th>ठेगाना</th>
                      </tr>
                    </thead>
                      <tbody>
                        <?php $i = 1;
                         foreach($badi as $ba) :?>
                            <tr>
                             
                              <td><?php echo $ba['b_name']?></td>
                              <td><?php echo $ba['b_dob']?></td>
                              <td><?php echo $ba['b_phone']?></td>
                              <td><?php echo $ba['b_cznno']?></td>
                              <td><?php echo $ba['b_czn_date']?></td>
                              <td><?php echo $ba['b_czn_district']?></td>
                              <td><?php echo $ba['b_grandfather']?></td>
                              <td><?php echo $ba['b_father']?></td>
                              <td><?php echo $ba['b_mother']?></td>
                              <td><?php echo $ba['b_husband_wife']?></td>
                              <td><?php echo $ba['b_address']?></td>
                            </tr>
                        <?php endforeach;?>
                      </tbody>
                  </table>
                </div>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>