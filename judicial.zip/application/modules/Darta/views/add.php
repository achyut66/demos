<div class="content-i">
    <div class="content-box">
        <div class="element-wrapper ">
            <div class="element-box-tp">
                <div class="anusuchi">
                    <div class="text-center"><strong>
                            <h2>मुद्दा दर्ता गर्नुहोस </h2>
                        </strong></div>
                    <?php echo form_open('Darta/darta_save', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal save_post')); ?>
                    <div class="form-desc">
                        कृपया <span class="text-danger">&nbsp;*</span> चिन्न भएको ठाउँ खाली नछोड्नु होला |
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-sm-2" for="">दर्ता मिति <span class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                            <div class="date-input">
                                <input type="text" name="date" class="form-control" id="meeting_date" required="true" value="<?php echo convertDate(date('Y-m-d')) ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-sm-2" for="">दफा <span class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                            <select class="form-control dafa" name="dafa" required="true">
                                <option value="">दफा छान्नुहोस्</option>
                                <?php if (!empty($dafa)) : foreach ($dafa as $d) : ?>
                                        <option value="<?php echo $d['name'] ?>"><?php echo $this->mylibrary->convertedcit($d['name']) ?></option>
                                <?php endforeach;
                                endif ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-sm-2" for="">उप दफा <span class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                            <select class="form-control upadafa" name="upa_dafa" required="true">
                                <option value="">उप दफा छान्नुहोस्</option>
                                <?php if (!empty($updafa)) : foreach ($updafa as $d) : ?>
                                        <option value="<?php echo $d['upa_dafa'] ?>"><?php echo $this->mylibrary->convertedcit($d['upa_dafa']) ?></option>
                                <?php endforeach;
                                endif ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-sm-2" for="">मुद्दाको प्रकार<span class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                            <select class="select2 form-control parkar" name="type" required="true">
                                <option value=""></option>
                                <?php if (!empty($types)) :
                                    foreach ($types as $key => $type) : ?>
                                        <option value="<?php echo $type['id'] ?>"><?php echo $type['subject'] ?></option>
                                <?php endforeach;
                                endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-sm-2" for="">मुद्दाको विषय<span class="text-danger">&nbsp;*</span></label>
                        <div class="col-sm-8">
                            <input type="text" name="bisaye" class="form-control" id="" required="true" value="">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-12">
                            <div class="form-buttons-w text-center">
                                <button type="submit" class='btn btn-submit btn-primary btn-block save_btn' name="submit">अगाडी जानुहोस <i class="fa fa-arrow-circle-right"></i></button>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d')) ?>";
        $('.dd_select').select2();
        var mainInput = $("#meeting_date");
        mainInput.nepaliDatePicker({
            ndpYear: true,
            ndpMonth: true,
            ndpYearCount: 100,
            disableAfter: GetCurrentBsDate
        });

        $('.upadafa').change(function() {
            var dafa        = $('.dafa').val();
            var upadafa     = $('.upadafa').val();
            $.ajax({
                method: "POST",
                url: base_url + "Darta/getPrakarByDafa",
                data: {
                    dafa: dafa,
                    updafa:upadafa,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>',
                },
                success: function(resp) {
                    if (resp.status == 'success') {
                        if (resp.data == null) {
                            $(".parkar").html();
                        } else {
                            $(".parkar").html(resp.data);
                        }
                    }
                }

            });
        });

    }); // end of dom
</script>