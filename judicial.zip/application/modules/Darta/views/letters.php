<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
               <div class="element-wrapper">
                <div class="user-profile">
                  <div class="up-contents">
                   
                    <div class="os-tabs-w">
                      <div class="os-tabs-controls">
                        <ul class="nav nav-tabs bigger">
                          <?php if(!empty($aanusuchi)) :
                            foreach($aanusuchi as $key =>  $anu) : ?>
                          <li class="nav-item">
                            <a class="nav-link <?php if($key == 0){ echo 'active';}?>" data-toggle="tab" href="#tab_<?php echo $anu['letter_name']?>">आनुसुची- <?php echo $this->mylibrary->convertedcit($anu['letter_name'])?></a>
                          </li>
                        <?php endforeach; endif;?>
                        </ul>
                      </div>
                      <div class="tab-content">

                        <!-----------------------------------------
                          aanusuchi 1
                        ------------------------------------------->
                        <div class="tab-pane active" id="tab_1" >
                          <div class="text-center">
                            <p>अनुसूची–१</p>
                            <p style="margin-top:-20px;">(दफा ८ को उपदफा (२) सँग सम्बन्धित)</p>
                            <p style="margin-top:-20px;">श्री ज्वालामूखि गाउँपालिकामा दर्ता गरेको नालेस</p>
                          </div>
                            <p><?php echo $badi[0]['b_grandfather']?> को नाती, <?php echo $badi[0]['b_father']?> को छोरा/छोरी (<?php echo $badi[0]['b_husband_wife']?>) को पति/पत्नी, <?php echo $badi[0]['b_address']?> बस्ने वर्ष (उमेर) को (वादीको नाम) (एक भन्दा बढी वादी भएको खण्डमा यसै बमोजिम सबैको नाम उल्लेख गर्ने)</p>
                            <p class="text-center">विरुद्ध</p>
                            <p>(प्रतिवादीको बाजेको नाम) को नाती, (प्रतिवादीको बावुको नाम) को छोरा/छोरी (प्रतिवादीको पति/पत्नीको नाम) (ठेगाना) बस्ने वर्ष (उमेर) को (वादीको नाम) (एक भन्दा बढी वादी भएको खण्डमा यसै बमोजिम सबैको नाम उल्लेख गर्ने)</p>
                            <p class="text-center">विवादको विषयः .....................।</p>
                            <p>
                              १. म/हामी (एक जना भए म, धेरै भए हामी) वादीहरुलाई माथि उल्लेख भए बमोजिमका विपक्षीहरुले अन्याय गर्नु भएको हुनाले उक्त विवादको विषय उपर मुद्दा हेर्न मिल्ने यस ज्वालामूखि गाउँपालिकाको न्यायिक समिति समक्ष कानुन बमोजिमको हद म्याद भित्र प्रस्तुत नालेस लिई आएको छु / आएका छौं । कानुन बमोजिम लाग्ने दस्तुर रु. ....... यसै साथ संलग्न गरेको छु / गरेका छौं । विपक्षीहरुले गर्नु भएको अन्यायको व्यहोरा देहाय बमोजिम रहेको छः-
                              (परेको अन्यायको व्यहोरा विस्तारमा खुलाई लेख्ने र चाहिएको उपचारको व्यहोरासमेत उल्लेख गर्ने र यस ऐन बमोजिम खुलाउनु पर्ने सबै व्यहोरा खुलाउने)</p>
                              <p>२. यो नालेस दर्ता गर्न कानुन व्यवसायी राखेको छु/छैन ।</p>
                              <p>३. विपक्षीहरु जना ..... का लागि प्रति व्यक्ति एकजनाको दरले नालेसको नक्कल प्रति ..... यसैसाथ संलग्न छ ।</p>
                              <p>४. मेरो / हाम्रो दावीको प्रमाण देहाय बमोजिम रहेको छः</p>
                              (कुन विषयको कस्तो प्रमाण कहाँ रहेको छ सबै विस्तृतमा खुलाउने)
                              <p>५. मेरो / हाम्रो देहाय बमोजिमका साक्षी बुझीपाऊँः-</p>
                              (सवै साक्षीको पुरा नाम, थर, ठेगाना, उमेर उल्लेख गर्ने)
                              <p>६. यसमा लेखिएको व्यहोरा ठिक साँचो छ, झुठ्ठा ठहरे कानुन बमोजिम सहुँला बुझाउँला </p>
                            </p>
                        </div>
                        <!-----------------------------------------
                          aanusuchi 1
                        ------------------------------------------->
                        <div class="tab-pane" id="tab_2">
                          <div class="text-center">
                            <p>अनुसूची–२</p>
                            <p style="margin-top:-20px;">(दफा ९ को उपदफा (१) सँग सम्बन्धित</p>
                            <p style="margin-top:-20px;">श्री ज्वालामूखी गाउँपालिका</p>
                            <p style="margin-top:-20px;">न्यायिक समिति</p>
                          </div>

                            <p class="text-left">वादी श्री <?php echo $badi[0]['b_name']?> ले मिति <?php echo $this->mylibrary->convertedcit($darta_detail['date'])?> मा <?php echo $pratibadi[0]['p_name']?> को विरुद्धमा <?php echo $subject['subject']?> विषयमा दर्ता गरेको नालेस यस समितिको दर्ता नं. <?php echo $this->mylibrary->convertedcit($darta_detail['darta_no'])?>  मा दर्ता भएकाले यो भर्पाई दिइएको छ ।
                            <div class="text-left">
                              <p>भपाई गर्ने कर्मचारीको</p>
                              <p>दस्तखतः</p>
                              <p>नामः</p>
                              <p>पदः</p>
                              <p>मितिः</p>
                            </div>
                            <div class="stamp">
                              <p class="">पालिकाको छाप</p>
                            </div>
                            </p>
                        </div>


                        <!-----------------------------------------
                          aanusuchi 3
                        ------------------------------------------->
                        <div class="tab-pane" id="tab_3">
                          <div class="el-tablo">
                            <div class="label">
                              Unique Visitors
                            </div>
                            <div class="value">
                              12,537
                            </div>
                          </div>
                        </div>

                        <!-----------------------------------------
                          aanusuchi 5
                        ------------------------------------------->
                        <div class="tab-pane" id="tab_3">
                          <div class="el-tablo">
                            <div class="label">
                              Unique Visitors
                            </div>
                            <div class="value">
                              12,537
                            </div>
                          </div>
                        </div>




                        <div class="tab-pane" id="tab_conversion"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>