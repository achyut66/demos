<div class="content-i">
    <div class="content-box">
        <div class="element-wrapper">
            <div class="element-box-tp">
                <div class="anusuchi">
                    <div class="text-center"><strong>
                            <h2>वादीको विवरण भर्नुहोस्</h2>
                        </strong></div>
                    <?php if ($this->session->flashdata('MSG_ERROR')) { ?>
                        <div class="alert alert-success alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_ERROR') ?></div>
                    <?php } ?>

                    <?php echo form_open('Darta/badi_save', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal save_post')); ?>
                    <div class="form-desc">
                        <span class="text-danger"> [ कृपया&nbsp;* चिन्न भएको ठाउँ खाली नछोड्नु होला ] </span>
                    </div>

                    <div class="row">

                        <input type="hidden" name="darta_no" class="form-control" value="<?php echo $darta_detail['darta_no'] ?>" readonly>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for=""> मिति</label>
                                <div class="date-input">
                                    <input type="text" name="date" class="form-control" value="<?php echo $darta_detail['date'] ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for="">दफा</label>
                                <div class="">
                                    <input type="text" name="date" class="form-control" value="<?php echo $darta_detail['dafa'] ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="">मुद्दाको प्रकार</label><input class="form-control" type="text" readonly="" value="<?php echo $subject['subject'] ?>">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="">मुद्दाको विषय</label><input class="form-control" type="text" readonly="" value="<?php echo $darta_detail['case_title'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-borderless" id="frm_tbl_mem">
                                <tbody>
                                    <tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">
                                        <td>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> नाम<span class="text-danger">*</span> </label><input type="text" name="b_name[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> गा. पा/न. पा.<span class="text-danger">*</span> </label>
                                                        <select class="form-control select2" name="b_gapa[]">
                                                            <option value="">वडा नं</option>
                                                            <?php if (!empty($gapa)) : foreach ($gapa as $g) : ?>
                                                                    <option value="<?php echo $g['name'] ?>"><?php echo $this->mylibrary->convertedcit($g['name']) ?></option>
                                                            <?php endforeach;
                                                            endif; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> वडा नं<span class="text-danger">*</span> </label>
                                                        <select class="form-control" name="b_ward[]">
                                                            <option value="">वडा नं</option>
                                                            <?php if (!empty($wards)) : foreach ($wards as $ward) : ?>
                                                                    <option value="<?php echo $ward['name'] ?>"><?php echo $this->mylibrary->convertedcit($ward['name']) ?></option>
                                                            <?php endforeach;
                                                            endif; ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> ठेगाना(गाउँ/टोल)<span class="text-danger">*</span> </label><input type="text" name="b_address[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> उमेर<span class="text-danger">*</span> </label>
                                                        <div class="">
                                                            <input type="text" name="b_dob[]" class="form-control dob" id="dob_1" required="true">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> लिङ्ग<span class="text-danger">*</span></label>
                                                        <select class="form-control" name=gender[]>
                                                            <option value="1">पुरुष</option>
                                                            <option value="2">महिला</option>
                                                            <option value="3">अन्य</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> सम्पर्क नं.<span class="text-danger">*</span> </label><input type="text" name="b_phone[]" class="form-control number_field" value="" required="true">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> ना.प्र.प.नं.<span class="text-danger">*</span> </label><input type="text" name="b_cznno[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> जारी मिति <span class="text-danger">*</span> </label>
                                                        <div class="">
                                                            <input type="text" name="b_czn_date[]" class="form-control czn" id="cznFirst" required="true">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> जारी जिल्ला <span class="text-danger">*</span> </label>
                                                        <select class="form-control dd_select" name="b_czn_district[]" required="true">
                                                            <option>छान्नुहोस्</option>
                                                            <?php if (!empty($districts)) :
                                                                foreach ($districts as $district) : ?>
                                                                    <option value="<?php echo $district['name'] ?>" <?php if ($district['name'] == SITE_DISTRICT) {
                                                                                                                        echo 'selected';
                                                                                                                    } ?>><?php echo $district['name'] ?></option>
                                                            <?php endforeach;
                                                            endif; ?>
                                                        </select>
                                                        <!-- <input type="text" name="b_czn_district[]" class="form-control" value="" required="true"> -->
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> बाजेको नाम<span class="text-danger">*</span> </label><input type="text" name="b_grandfather[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> बावुको नाम <span class="text-danger">*</span> </label><input type="text" name="b_father[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> आमाको नाम<span class="text-danger">*</span> </label><input type="text" name="b_mother[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>
                                                <!-- <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> नाता <span class="text-danger">*</span> </label>
                                                        <select class="form-control dd_select" name="b_relation[]" required="true">
                                                            <option value="">छान्नुहोस्</option>
                                                            <option value="1">बुवा</option>
                                                            <option value="2">ससुरा</option>
                                                        </select>
                                                    </div>
                                                </div> -->
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> वादी सँगको नाता <span class="text-danger">*</span> </label>
                                                        <select class="form-control dd_select" name="b_relation[]" required="true">
                                                            <option value="">छान्नुहोस्</option>
                                                            <?php if (!empty($relations)) :
                                                                foreach ($relations as $relation) : ?>
                                                                    <option value="<?php echo $relation['name'] ?>" <?php if ($relation['name'] == SITE_DISTRICT) {
                                                                                                                        echo 'selected';
                                                                                                                    } ?>><?php echo $relation['name'] ?></option>
                                                            <?php endforeach;
                                                            endif; ?>
                                                        </select>
                                                        <!-- <input type="text" name="b_mother[]" class="form-control" value="" required="true"> -->
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for=""> पति/पत्निको नाम<span class="text-danger">*</span> </label><input type="text" name="b_husband_wife[]" class="form-control" value="" required="true">
                                                    </div>
                                                </div>


                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <button type="button" class="btn btn-success btnNewField" style="margin-top: 27px;"><i class="fa fa-plus-circle"></i> वादी एक भन्दा बढी भएमा थप्नुहोस्</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-12">
                            <div class="form-buttons-w text-center">
                                <button type="submit" class='btn btn-submit  btn-primary btn-block save_btn' name="submit">सेभ गर्नुहोस <i class="fa fa-arrow-circle-right"></i></button>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.1.60/inputmask/jquery.inputmask.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        // var mainInput = $("#dob_1");
        var cznFirst = $("#cznFirst");
        cznFirst.nepaliDatePicker({
            ndpYear: true,
            ndpMonth: true,
            ndpYearCount: 100,
            disableAfter: GetCurrentBsDate
        });

        // cznInput.nepaliDatePicker({
        //     ndpYear: true,
        //     ndpMonth: true,
        //     ndpYearCount: 100,
        //     disableAfter: GetCurrentBsDate
        // });
        // $("#date").inputmask();
        $('.btnNewField').click(function(e) {
            e.preventDefault();
            var trOneNew = $('.row_mem').length + 1;
            var new_row = '<tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">' +
                '<td>' +
                '<div class="row">' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> नाम<span class="text-danger">*</span></label>' +
                '<input type="text" name="b_name[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> वडा नं<span class="text-danger">*</span> </label>' +
                '<select class="form-control" name="b_ward[]"><option value="">वडा नं</option><?php if (!empty($wards)) : foreach ($wards as $ward) : ?><option value="<?php echo $ward['name'] ?>"><?php echo $this->mylibrary->convertedcit($ward['name']) ?></option><?php endforeach;
                                                                                                                                                                                                                                                                endif; ?></select>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> ठेगाना(गाउँ/टोल)<span class="text-danger">*</span> </label><input type="text" name="b_address[]" class="form-control" value="" required="true" >' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> उमेर<span class="text-danger">*</span> </label>' +
                '<div class="">' +
                '<input type="text" name="b_dob[]" class="form-control dob" id="dob_' + trOneNew + '" required="true">' +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> लिङ्ग<span class="text-danger">*</span> </label>' +
                '<div class="">' +
                '<select class="form-control" name=gender[]> <option value = "1" > पुरुष </option> <option value = "2" > महिला </option> <option value = "3" > अन्य </option> </select > ' +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> सम्पर्क नं.<span class="text-danger">*</span> </label><input type="text" name="b_phone[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for="">  ना.प्र.प.नं.<span class="text-danger">*</span> </label><input type="text" name="b_cznno[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> जारी मिति <span class="text-danger">*</span> </label>' +
                '<div class="">' +
                '<input type="text" name="b_czn_date[]" class="form-control" id="czn_'+trOneNew+'" required="true">' +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> जारी जिल्ला <span class="text-danger">*</span> </label>' +
                '<select class="form-control dd_select" name="b_czn_district[]"required="true"><option>छान्नुहोस्</option><?php if (!empty($districts)) : foreach ($districts as $district) : ?><option value="<?php echo $district['name'] ?>" <?php if ($district['name'] == SITE_DISTRICT) {
                                                                                                                                                                                                                                                    echo 'selected';
                                                                                                                                                                                                                                                } ?>><?php echo $district['name'] ?></option><?php endforeach;
                                                                                                                                                                                                                                                                                        endif; ?></select>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for="">  बाजेको नाम<span class="text-danger">*</span> </label><input type="text" name="b_grandfather[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> बावुको नाम <span class="text-danger">*</span> </label><input type="text" name="b_father[]" class="form-control" value="" required="true" >' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> आमाको नाम<span class="text-danger">*</span> </label><input type="text" name="b_mother[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +
                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> वादी सँगको नाता <span class="text-danger">*</span> </label>' +
                '<select class="form-control dd_select" name="b_relation[]"required="true"><option value="">छान्नुहोस्</option><?php if (!empty($relations)) : foreach ($relations as $relation) : ?><option value="<?php echo $relation['name'] ?>" <?php if ($relation['name'] == SITE_DISTRICT) {
                                                                                                                                                                                                                                                            echo 'selected';
                                                                                                                                                                                                                                                        } ?>><?php echo $relation['name'] ?></option><?php endforeach;
                                                                                                                                                                                                                                                                                                endif; ?></select>' +
                '</div>' +
                '</div>' +
                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> पति/पत्निको नाम<span class="text-danger">*</span> </label><input type="text" name="b_husband_wife[]" class="form-control" value="" required="true" >' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<button type="button" class="btn btn-danger remove-prastab-row" style="margin-top: 27px;"><i class="os-icon os-icon-ui-15"></i> हटानुहोस </button>' +
                '</div>' +
                '</div>' +

                '</div>' +
                '</td>' +
                '</tr>';
            $("#frm_tbl_mem").append(new_row);
            // var mainInput = $("#dob_" + trOneNew);
            // mainInput.nepaliDatePicker({
            //     ndpYear: true,
            //     ndpMonth: true,
            //     ndpYearCount: 100,
            //     //disableAfter: GetCurrentBsDate
            // });
            var cznInput = $("#czn_" + trOneNew);
            cznInput.nepaliDatePicker({
                ndpYear: true,
                ndpMonth: true,
                ndpYearCount: 100,
                disableAfter: GetCurrentBsDate
            });
        });
        //remove samati members.
        $("body").on("click", ".remove-prastab-row", function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                $(this).parent().parent().parent().parent().remove();
            }
        });

        $('.btnaddNewField').click(function(e) {
            var MaxInputs = 2;
            e.preventDefault();
            var trOneNew = $('.row_mem').length + 1;
            var new_row = '<tr class="row_mem">' +
                '<td><input type="text" name="s_name[]" class="form-control" value="" required="true"></td>' +
                '<td><input type="text" name="s_address[]" class="form-control" value="" required="true"></td>' +
                '<td><input type="text" name="s_age[]" class="form-control" value="" required="true"></td>' +
                '<td><input type="text" name="s_phone[]" class="form-control" value="" required="true"></td>' +
                '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
                '<tr>';
            $("#frm_tbl_wit").append(new_row);
        });
        //remove samati members.
        $("body").on("click", ".remove-muddha-row", function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                $(this).parent().parent().remove();
            }
        });


    });
</script>