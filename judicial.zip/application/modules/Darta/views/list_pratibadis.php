<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp">
                      <div class="anusuchi">
                        <div class="row">
                          <div class="col-sm-12">
                            <div class="form-group">
                             <h4 style="text-decoration:underline;">मुद्दाको प्रकार: <?php echo $subject['subject']?> </h4>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                              <?php if(!empty($pratibadis)) : ?>
                                <table class="table table-lightbordered" id="frm_tbl_mem">
                                    <tbody>
                                      <tr><td colspan="6"><h4 class="text-center">प्रतिवादीको विवरण</h4></td></tr>
                                      <tr>
                                        <td>
                                         <?php if(empty($likhit_jawaf)) : ?>
                                          <a href="<?php echo base_url()?>Darta/addLikhitJawaf/<?php echo $darta_detail['id']?>" class="btn btn-success" data-placement="right" data-toggle="tooltip" title="" type="button" data-original-title="प्रतिवादी"> <i class="fa fa-info-circle"></i> लिखितजवाफ</a>
                                          <?php else : ?>
                                          <a href="<?php echo base_url()?>Darta/generateLikhitPatra/<?php echo $darta_detail['id']?>" class="btn btn-secondary  btn-block " data-placement="right" data-toggle="tooltip" title="" type="button" data-original-title="फिराद पत्र प्रिन्ट गर्नुहोस" target ="_blank"> <i class="fa fa-print"></i> लिखितजवाफ प्रिन्ट गर्नुहोस</a>
                                          <?php endif;?>
                                        </td>
                                        <td>
                                          <?php if(!empty($likhit_jawaf)) : ?>
                                            <a href="<?php echo base_url()?>Darta/editLikhitJawaf/<?php echo $darta_detail['id']?>" class="btn btn-success" data-placement="right" data-toggle="tooltip" title="" type="button" data-original-title="प्रतिवादी"> <i class="fa fa-info-circle"></i> लिखितजवाफको विवरण सम्पादन गर्नुहोस </a>
                                          <?php endif;?>
                                        </td>
                                        
                                          <td><a class="btn btn-block btn-info" href="<?php echo base_url()?>Darta/pratibadiEdit/<?php echo $this->uri->segment(3)?>"><i class="fa fa-pencil"></i> प्रतिवादी विवरण सम्पादन गर्नुहोस </td>
                                        <td><?php if(!empty($likhit_jawaf)):?>
                                          <div class="btn-group mr-1 mb-1">
                                            <button aria-expanded="false" aria-haspopup="true" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" id="dropdownMenuButton6" type="button">आनुसुचीहरु</button>
                                              <div aria-labelledby="dropdownMenuButton6" class="dropdown-menu">
                                                <?php if(!empty($anusuchis)): foreach($anusuchis as $key => $letter):?>
                                                  <a class="dropdown-item" href="<?php echo base_url()?>PratibadiAnusuchi/view/<?php echo $darta_detail['id'].'/'.$letter['letter_name']?>/badi"> <?php echo 'अनुसूची-'.$this->mylibrary->convertedcit($letter['letter_name'])?></a>
                                                <?php endforeach;endif?>
                                              </div>
                                          </div>
                                        <?php endif;?></td>
                                        <td></td>
                                        <td></td>
                                      </tr>
                                      <?php $i=1;foreach($pratibadis as $key => $badi ) :?>
                                        <tr><td colspan="6"><?php echo $this->mylibrary->convertedcit($i++)?>) बिपक्षि</td></tr>
                                        <tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">
                                          <td> <p> लिङ्ग: <?php echo get_gender_text($badi['gender'])?></p></td>
                                          <td> <p> नाम:<?php echo $badi['p_name']?> </p></td>
                                          <td> <p> जन्ममिति:<?php echo $this->mylibrary->convertedcit($badi['p_dob'])?> </p></td>
                                          <td> <p>ना.प्र.प.नं.: <?php echo $this->mylibrary->convertedcit($badi['p_cznno'])?> </p></td>
                                          <td><p>जारी मिति:<?php echo $this->mylibrary->convertedcit($badi['p_czn_date'])?> </p></td>
                                          <td><p>जारी जिल्ला:<?php echo $this->mylibrary->convertedcit($badi['p_czn_district'])?> </p></td>
                                        </tr>

                                        <tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">
                                          <td><p>बाजेको नाम:<?php echo $badi['p_grandfather']?> </p></td>
                                          <td><p> बावुको नाम:<?php echo $badi['p_father']?> </p></td>
                                          <td><p> आमाको नाम:<?php echo $badi['p_mother']?> </p></td>
                                          <td><p> पति/पत्निको नाम:<?php echo $badi['p_husband_wife']?> </p></td>
                                          <td><p> ठेगाना:<?php echo $badi['p_address']?> </p></td>
                                          <td><p> सम्पर्क नं.:<?php echo $this->mylibrary->convertedcit($badi['p_phone'])?> </p></td>
                                        </tr>
                                      <?php endforeach;?>
                                    </tbody>
                                </table>
                              <?php else : ?>
                               <div class="col-md-12">
                                 <div class="alert alert-danger">प्रतिवादी विवरण दाखिला गरिएको छैन</div>
                                  <a href="<?php echo base_url()?>Darta/addPratiBadi/<?php echo $this->uri->segment(3)?>" class="btn btn-primary"><i class="fa fa-plus-circle"></i> प्रतिवादी विवरण थप्नुहोस</a>
                              </div>
                              <?php endif;?>
                            </div>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>