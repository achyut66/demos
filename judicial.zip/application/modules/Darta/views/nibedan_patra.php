dd

<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <title><?php echo SITE_OFFICE?></title>

  <style type="text/css">

    /*table, th, td {

      border: 1px solid black;

    }*/



    /* Center tables for demo */

    table {

      margin: 0 auto;

    }



    /* Default Table Style */

    table {

      color: #333;

      background: white;

      border: 0;

      font-size: 12pt;

      border-collapse: collapse;

    }

    table thead th,

    table tfoot th {

      color: #000;

      background: rgba(0,0,0,.1);

    }

    table caption {

      padding:.5em;

    }

    table th,

    table td {

      padding: .5em;

      border: 0;

    }
    .signature{
    float: right;
    border-top: dotted 1px #000;
    width:160px;
}

  </style>

</head>
  <body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; ">
    <div style="background-color: #fff;"> <!-- main content -->
      
      <div style="margin-left: 280px;"><?php echo SITE_OFFICE?></div>
      <div style="margin-left: 240px;">न्यायिक समिति समक्ष पेश गरेको </div>
      <div style="margin-left: 300px;margin-top:10px;">निबेदन पत्र  </div>
      <?php 
        $year           = substr($badi[0]['b_dob'],0,4);
        $d_year         = substr($darta_detail['date'], 0,4);
        $d_month        = substr($darta_detail['date'], 5,2);
        $d_day          = substr($darta_detail['date'], 8,2);
        $current_date   = convertDate(date('Y-m-d'));
        $current_year   = substr($current_date, 0,4);
        $age            = $current_year - $year;
        $pyear          = substr($badi[0]['b_dob'],0,4);
        $pcurrent_date  = convertDate(date('Y-m-d'));
        $pcurrent_year  = substr($pcurrent_date, 0,4);
        $page           = $pcurrent_year - $pyear;
      ?>
      <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 40px;">
        <?php if(!empty($badi)) :
          $i=1; 
          foreach($badi as $key => $b) : 
            $byear          = substr($b['b_dob'],0,4);
            $bcurrent_date  = convertDate(date('Y-m-d'));
            $bcurrent_year  = substr($bcurrent_date, 0,4);
            $bage           = $bcurrent_year - $byear;
        ?>
        <?php echo $b['b_czn_district']?> जिल्ला <?php echo SITE_OFFICE?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward'])?> <?php echo $b['b_address']?> बस्ने <?php echo $b['b_grandfather']?> <?php echo $b['b_husband_wife']?> को पति/पत्नी, <?php echo $b['b_address']?> बस्ने वर्ष 
        <?php echo $this->mylibrary->convertedcit($bage)?> <?php echo $b['b_name']?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone'])?>)............................... <?php echo $this->mylibrary->convertedcit($i++)?> निवेदक
        <?php endforeach;endif;?>
      </div>
      <div style="margin-left:320px; margin-right: 40px; text-align: justify; margin-top: 40px;">
        बिरुद्
      </div>

    </div> <!-- end of main content -->
  </body>
</html>

