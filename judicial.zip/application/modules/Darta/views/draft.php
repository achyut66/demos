<div class="content-i">
    <div class="content-box">
        <div class="alert alert-info alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <strong><h5>वादीको विवरण भर्नुहोस्</h5></strong></div>
        <div class="element-wrapper">
            <div class="element-box">

                <?php echo form_open('Darta/badi_save', array('name'=>'save', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal save_post'));?>
                    <div class="form-desc">
                      कृपया <span class="text-danger">&nbsp;*</span> चिन्न भएको ठाउँ खाली नछोड्नु होला |
                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for=""> दर्ता नं. </label>
                                <input type="text" name="darta_no" class="form-control" value="<?php echo $darta_detail['darta_no']?>" readonly>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for=""> दर्ता मिति</label>
                                <div class="date-input">
                                    <input type="text" name="date" class="form-control" value="<?php echo $darta_detail['date']?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="">मुद्दाको विषय</label><input class="form-control" type="text" readonly="" value="<?php echo $subject['subject']?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            
                            <table class="table table-borderless" id="frm_tbl_mem">
                            <tbody>
                               <tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">
                                   <td>
                                       <div class="row">
                                           <div class="col-md-12"><b>१) वादीको विवरण</b><hr></div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label for=""> लिङ्ग<span class="text-danger">*</span> </label><br>
                                                    <div class="form-check-inline">
                                                          <label class="form-check-label" for="radio2">
                                                            <input type="radio" class="form-check-input" id="radio2" name="has_lawyer" value="1" checked="true">पुरुष
                                                        </label>
                                                    </div>
                                                    <div class="form-check-inline">
                                                      <label class="form-check-label">
                                                            <input type="radio" class="form-check-input" name="has_lawyer" value="2">महिला
                                                        </label>
                                                    </div>
                                                </div>
                                              
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for=""> पुरा नाम<span class="text-danger">*</span> </label><input type="text" name="b_name[]" class="form-control" value="" required="true">
                                                </div>
                                              
                                            </div>

                                            <div class="col-md-2">
                                               <div class="form-group">
                                                    <label for=""> जन्ममिति<span class="text-danger">*</span> </label>
                                                    <div class="date-input">
                                                        <input type="text" name="b_dob[]" class="form-control dob" id="dob_1" required="true">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> सम्पर्क नं.<span class="text-danger">*</span> </label><input type="text" name="b_phone[]" class="form-control" value="" required="true" >
                                                </div>
                                            </div>
                                            <div class="col-md-12">ठेगाना<hr></div>
                                          
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for=""> प्रदेश<span class="text-danger">*</span> </label><br>
                                                    <select class="form-control select2">
                                                       <option></option>
                                                       <?php if(!empty($state)) :
                                                       foreach($state as $st) : ?>
                                                        <option value="<?php echo $st['Title']?>" <?php if($st['Title'] == SITE_STATE){ echo 'selected';}?>><?php echo $st['Title']?></option>
                                                    <?php endforeach; endif;?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="">जिल्ला<span class="text-danger">*</span> </label>
                                                    <select class="form-control select2">
                                                       <option></option>
                                                       <?php if(!empty($state)) :
                                                       foreach($state as $st) : ?>
                                                        <option value="<?php echo $st['Title']?>" <?php if($st['Title'] == SITE_STATE){ echo 'selected';}?>><?php echo $st['Title']?></option>
                                                    <?php endforeach; endif;?>
                                                    </select>
                                                </div>
                                              
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for=""> पालिको को नाम<span class="text-danger">*</span> </label>
                                                    <select class="form-control select2">
                                                       <option></option>
                                                       <?php if(!empty($state)) :
                                                       foreach($state as $st) : ?>
                                                        <option value="<?php echo $st['Title']?>" <?php if($st['Title'] == SITE_STATE){ echo 'selected';}?>><?php echo $st['Title']?></option>
                                                    <?php endforeach; endif;?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for=""> वडा नं<span class="text-danger">*</span> </label><input type="text" name="b_phone[]" class="form-control" value="" required="true" >
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for="">  ना.प्र.प.नं.<span class="text-danger">*</span> </label><input type="text" name="b_cznno[]" class="form-control" value="" required="true">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> जारी मिति <span class="text-danger">*</span> </label>
                                                    <div class="date-input">
                                                        <input type="text" name="b_czn_date[]" class="form-control czn" id="czn_1" required="true">
                                                    </div>
                                                    <!-- <input type="text" name="date" class="form-control" value="" > -->
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> जारी जिल्ला <span class="text-danger">*</span> </label><input type="text" name="b_czn_district[]" class="form-control" value="" required="true">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for="">  बाजेको नाम<span class="text-danger">*</span> </label><input type="text" name="b_grandfather[]" class="form-control" value=""required="true" >
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> बावुको नाम <span class="text-danger">*</span> </label><input type="text" name="b_father[]" class="form-control" value="" required="true">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> आमाको नाम<span class="text-danger">*</span> </label><input type="text" name="b_mother[]" class="form-control" value="" required="true">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> पति/पत्निको नाम<span class="text-danger">*</span> </label><input type="text" name="b_husband_wife[]" class="form-control" value="" required="true" >
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                    <label for=""> प्रदेश<span class="text-danger">*</span> </label>
                                                    <input type="text" name="b_address[]" class="form-control"  required="true" value="<?php echo SITE_STATE?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                               <div class="form-group">
                                                   <button type="button" class="btn btn-success btnNewField" style="margin-top: 27px;"><i class="fa fa-plus-circle"></i> वादी एक भन्दा बढी भएमा थप्नुहोस्</button>
                                                </div>
                                            </div>

                                       </div>
                                   </td>
                               </tr>
                        </table>
                        </div>
                    </div>
                    <hr>
                    
                    <!-- <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for=""> <b>२) वादीले कानुन व्यवसायी राखेको छ / छैन ? </b><span class="text-danger">*</span> </label>
                                <div class="col-sm-8">

                                    <div class="form-check">
                                        <label class="form-check-label"><input class="form-check-input" name="has_lawyer" type="radio" value="1" checked="true">छ</label>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label"><input class="form-check-input" name="has_lawyer" type="radio" value="2">छैन</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for=""> <b>३) वादीले पेश गरेको मुद्दाको विवरण </b><span class="text-danger">*</span> </label><textarea cols="30" id="" name="case_details" rows="5" class="form-control" required="true"> </textarea>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for=""> <b>४) मुद्दा सम्बन्धी प्रमाण विवरण</b><span class="text-danger">*</span> </label><textarea cols="30" id="" name="proof" rows="5" class="form-control" required="true"> </textarea>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                       <b> ५) वादीको साक्षीहरु सम्बन्धी विवरण </b>
                        <table class="table table-bordered" id="frm_tbl_wit">
                            <thead>
                                <tr>
                                    <th>नाम</th>
                                    <th>ठेगाना</th>
                                    <th>उमेर</th>
                                    <th>सम्पर्क नं.</th>
                                    <th>#</th>
                                </tr>
                            </thead>
                            <tbody>
                               <tr>
                                    <td><input type="text" name="w_name[]" class="form-control" value="" required="true"></td>
                                    <td><input type="text" name="w_address[]" class="form-control" value="" required="true"></td>
                                    <td><input type="text" name="w_age[]" class="form-control" value="" required="true"></td>
                                    <td><input type="text" name="w_phone[]" class="form-control" value="" required="true"></td>
                                    <td><button type="button" class="btn  btn-primary btnaddNewField" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button></td>
                                </tr>
                        </table>
                    </div> -->

                    <div class="form-group row">
                        <div class="col-sm-12">
                             <div class="form-buttons-w text-center">
                                <button type="submit" class='btn btn-submit  btn-primary btn-block save_btn' name="submit">सेभ गर्नुहोस <i class="fa fa-arrow-circle-right"></i></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    
    $('.dd_select').select2();
    var mainInput = $("#dob_1");
    var cznInput = $("#czn_1");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });

    cznInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
        disableAfter: GetCurrentBsDate
    });


  });

</script>

<script type="text/javascript">
  $(document).ready(function() {
    $('.btnNewField').click(function(e) {
        e.preventDefault();
        var trOneNew = $('.row_mem').length+1;
        var new_row =  '<tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">'+
                        '<td>'+
                            '<div class="row">'+
                                    '<div class="col-md-4">'+
                                        '<div class="form-group">'+
                                            '<label for=""> नाम<span class="text-danger">*</span> </label><input type="text" name="b_name[]" class="form-control" value="" required="true" >'+
                                        '</div>'+
                                      
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                        '<div class="form-group">'+
                                            '<label for=""> जन्ममिति<span class="text-danger">*</span> </label>'+
                                            '<div class="date-input">'+
                                                '<input type="text" name="b_dob[]" class="form-control dob" id="dob_'+trOneNew+'" required="true">'+
                                            '</div>'+
                                        '</div>'+
                                   '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> सम्पर्क नं.<span class="text-danger">*</span> </label><input type="text" name="b_phone[]" class="form-control" value="" required="true">'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for="">  ना.प्र.प.नं.<span class="text-danger">*</span> </label><input type="text" name="b_cznno[]" class="form-control" value="" required="true">'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> जारी मिति <span class="text-danger">*</span> </label>'+
                                            '<div class="date-input">'+
                                                '<input type="text" name="b_czn_date[]" class="form-control czn" id="czn_'+trOneNew+'" required="true">'+
                                            '</div>'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> जारी जिल्ला <span class="text-danger">*</span> </label><input type="text" name="b_czn_district[]" class="form-control" value="" required="true" >'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for="">  बाजेको नाम<span class="text-danger">*</span> </label><input type="text" name="b_grandfather[]" class="form-control" value="" required="true">'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> बावुको नाम <span class="text-danger">*</span> </label><input type="text" name="b_father[]" class="form-control" value="" required="true" >'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> आमाको नाम<span class="text-danger">*</span> </label><input type="text" name="b_mother[]" class="form-control" value="" required="true">'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> पति/पत्निको नाम<span class="text-danger">*</span> </label><input type="text" name="b_husband_wife[]" class="form-control" value="" required="true" >'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                            '<label for=""> ठेगाना<span class="text-danger">*</span> </label><input type="text" name="b_address[]" class="form-control" value="" required="true" >'+
                                        '</div>'+
                                    '</div>'+

                                    '<div class="col-md-4">'+
                                       '<div class="form-group">'+
                                           '<button type="button" class="btn btn-danger remove-prastab-row" style="margin-top: 27px;"><i class="os-icon os-icon-ui-15"></i> हटानुहोस </button>'+
                                        '</div>'+
                                    '</div>'+

                               '</div>'+
                           '</td>'+
                        '</tr>';
        $("#frm_tbl_mem").append(new_row);
        var mainInput = $("#dob_"+trOneNew);
            mainInput.nepaliDatePicker({
            ndpYear: true,
            ndpMonth: true,
            ndpYearCount: 100,
            //disableAfter: GetCurrentBsDate
        });
        var cznInput = $("#czn_"+trOneNew);
        cznInput.nepaliDatePicker({
            ndpYear: true,
            ndpMonth: true,
            ndpYearCount: 100,
            disableAfter: GetCurrentBsDate
        });
      });
    //remove samati members.
    $("body").on("click",".remove-prastab-row", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().parent().parent().remove();
      }
    });

    $('.btnaddNewField').click(function(e) {
      var MaxInputs       = 2;
          e.preventDefault();
          var trOneNew = $('.row_mem').length+1;
          var new_row =  '<tr class="row_mem">'+
                            '<td><input type="text" name="s_name[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="s_address[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="s_age[]" class="form-control" value="" required="true"></td>'+
                            '<td><input type="text" name="s_phone[]" class="form-control" value="" required="true"></td>'+
                            '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>'+
                            '<tr>';
                            $("#frm_tbl_wit").append(new_row);
      });
    //remove samati members.
    $("body").on("click",".remove-muddha-row", function(e){
      e.preventDefault();
      var id = $(this).data('id');
      if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
        $(this).parent().parent().remove();
      }
    });


  });
</script>
