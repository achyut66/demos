<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">
    नयाँ मुद्दाको प्रकार थप्नुहोस
  </h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>
  <form action="<?php echo base_url()?>Darta/UpdateDocs" method="post" class="form save_post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <input type = "hidden" name = "doc_id" value="<?php echo $doc['id']?>">
    <input type = "hidden" name = "darta_no" value="<?php echo $doc['darta_no']?>">
    <table class="table table-bordered" id="frm_tbl_mem">
        <thead>
          <tr>
            <th>पेश गरेको कागजातको नाम </th>
            <th>कागजात</th>
          </tr>
        </thead>
        <tbody>
            <tr>
                <td><input type = "text" name = "doc_name" class="form-control" value="<?php echo $doc['doc_type']?>"></td>
                <td>
                    <input type = "file" name = "userfile" class="form-control">
                    <input type = "hidden" name = "old_file" class="form-control" value = "<?php echo $doc['doc_name']?>">
            
                </td>
            </tr>
        </tbody>
    </table>
    <button class="btn btn-primary btn-block btn-xs save_btn" data-toggle="tooltip" title=" गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
  </form>
</div>