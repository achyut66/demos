<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo SITE_OFFICE ?></title>
  <link href="<?php echo base_url() ?>uploads/Nepali Flag.jpg" rel="shortcut icon">
  <link href="apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url() ?>assets/bower_components/select2/dist/css/select2.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/bower_components/dropzone/dist/dropzone.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/bower_components/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/bower_components/perfect-scrollbar/css/perfect-scrollbar.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/bower_components/slick-carousel/slick/slick.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/css/main.css?version=4.4.0" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/icon_fonts_assets/dashicons/dashicons.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/icon_fonts_assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/toastr-master/toastr.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/assets/nepali_datepicker/css/nepali.datepicker.v3.2.min.css" />
  <script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
  <style type="text/css">
    :root {
      --bleeding: 0.5cm;
      --margin: 1cm;
    }

    @page {
      size: A4;
      margin: 0;
    }

    * {
      box-sizing: border-box;
    }

    body {
      /* font-family: Kalimati, Georgia, serif;
    margin: 0 auto;
    padding: 0;
    background: rgb(204, 204, 204);
    display: flex;
    flex-direction: column; */

    }

    /* .page {
    display: inline-block;
    position: relative; */
    /* height: 327mm; */
    /* width: 310mm;
    font-size: 12pt;
    margin: 2em auto;
    padding: calc(var(--bleeding) + var(--margin)); */
    /* background-image: url('../../../assets/img/nepali_kagaz1.jpg');
    background-repeat: no-repeat; /* Do not repeat the image */
    /* background-size: cover; */
    /* -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    padding: 1.5rem 2rem;
    margin-bottom: 1rem;
    border-radius: 6px; */
    /* box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5); */
    /* background: white;
  } */
    /* @media screen {
    .page::after {
      position: absolute;
      content: '';
      top: 0;
      left: 0;
      width: calc(100% - var(--bleeding) * 2);
      height: calc(100% - var(--bleeding) * 2);
      margin: var(--bleeding); */
    /*outline: thin dashed black;*/
    /* pointer-events: none;
      z-index: 9999;
    }
  } */
    /* @media print {
    .page {
      margin: 0;
      overflow: hidden;
    }
    
  } */

    /* @media print {
    .page {
        clear: both;
        page-break-after: always;
    } */
    }
  </style>
</head>

<body style="background-color: #fff; padding: 20px; font-family: freeserif, Kalimati, Georgia, serif; font-size: 18px; ">

  <!-- <button onclick="window.print()" id="">print</button> -->
  <!-- <button class="btn btn-info btn-sm " style="color:#000;" id="basic" type="button"><i class="fa fa-print"></i>प्रिन्ट गर्नुहोस्</button> -->
  <div class="page">
    <!-- <div class="hideme">
          <a href="<?php //echo base_url()
                    ?>Darta" class ="btn btn-success btn-sm"><i class="fa fa-arrow-circle-left"></i> पछाडी जानुहोस</a>
          <a href="<?php //echo base_url()
                    ?>Darta/editNibedanPatra/<?php //echo $muddhadetails['id']
                                              ?>" class ="btn btn-primary btn-sm"><i class="fa fa-pencil"></i> विवरण सम्पादन गर्नुहोस </a>
          <button class="btn btn-secondary btn-sm " id="basic"><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस</button>
      </div> -->

    <!-- <div class="wrap1">
     <p style="transform:translateY(100%) rotate(-90deg);font-size: 16px;"><?php //echo SITE_OFFICE
                                                                            ?></p>
    </div>
    <div class="wrap2">
      <p style="transform:translateY(100%) rotate(-90deg);font-size: 16px; top:-50px;">बाट</p>
    </div> -->

    <!-- <div class="wrap3">
     <?php //echo $muddhadetails['official_stamp']
      ?>
    </div> -->

    <!--   <div class="wrap4">
      <p style="transform:translateY(100%) rotate(-90deg);font-size: 16px;"><?php //echo $officer['designation']
                                                                            ?><br><?php //echo $officer['name']
                                                                                  ?> <br> <?php //echo $this->mylibrary->convertedcit($muddhadetails['darta_date'])
                                                                                                                              ?></p>
    </div>
 -->
    <!--  <div class="palika_details">
      <p><?php //echo SITE_OFFICE_TYPE
          ?>ले भर्ने
      <br>मुद्धा दर्ता नं:- <?php //echo $this->mylibrary->convertedcit($muddhadetails['muddha_id'])
                            ?>
      <br>मुद्धा दर्ता मिति:- <?php //echo $this->mylibrary->convertedcit($muddhadetails['darta_date'])
                              ?></p>
    </div> -->
    <!-- <div style="height: 8cm;"></div> -->
    <div style="margin-left: 280; font-size: 18px;"><?php echo SITE_OFFICE ?></div>
    <div style="margin-left: 240px; font-size: 18px;">न्यायिक समिति समक्ष पेश गरेको </div>
    <p style="margin-left: 310px;margin-top:20px; font-size: 18px;">लिखितजवाफ </p>
    <?php
    $year           = substr($badi[0]['b_dob'], 0, 4);
    $d_year         = substr($darta_detail['date'], 0, 4);
    $d_month        = substr($darta_detail['date'], 5, 2);
    $d_day          = substr($darta_detail['date'], 8, 2);
    $current_date   = convertDate(date('Y-m-d'));
    $current_year   = substr($current_date, 0, 4);
    $age            = $current_year - $year;
    $pyear          = substr($badi[0]['b_dob'], 0, 4);
    $pcurrent_date  = convertDate(date('Y-m-d'));
    $pcurrent_year  = substr($pcurrent_date, 0, 4);
    $page           = $pcurrent_year - $pyear;
    ?>
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 20px;">
      <?php if (!empty($pratibadi)) :
        $i = 1;
        foreach ($pratibadi as $key => $p) :
          $byear          = substr($p['p_dob'], 0, 4);
          $bcurrent_date  = convertDate(date('Y-m-d'));
          $bcurrent_year  = substr($bcurrent_date, 0, 4);
          $bage           = $bcurrent_year - $byear;
      ?>
          <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>
          <?php if ($p['gender'] == 1) {
            echo 'नाती';
          } else {
            echo 'नातिनी';
          } ?> <?php echo $p['p_father'] ?> <?php if ($p['gender'] == 1) {
                                                echo 'छोरा';
                                              } else {
                                                echo 'छोरि';
                                              } ?> <?php echo $p['p_husband_wife'] ?> को <?php if ($p['gender'] == 1) {
                                                            echo 'पत्नी';
                                                          } else {
                                                            echo 'पति';
                                                          } ?>, <?php echo $p['p_address'] ?> बस्ने वर्ष
          <?php echo $this->mylibrary->convertedcit($bage) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... लिखितजवाफ प्रस्तुतकर्ता (दाेस्राे पक्ष) <?php echo $this->mylibrary->convertedcit($i++) ?>
      <?php endforeach;
      endif; ?>
    </div>

    <div style="margin-left:300px; margin-right: 40px; text-align: justify; margin-top: 10px;">
      <b> बिरुद् </b>
    </div>

    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 10px;">
      <?php if (!empty($badi)) :
        $i = 1;
        foreach ($badi as $key => $b) :
          $byear          = substr($b['b_dob'], 0, 4);
          $bcurrent_date  = convertDate(date('Y-m-d'));
          $bcurrent_year  = substr($bcurrent_date, 0, 4);
          $bage           = $bcurrent_year - $byear;
      ?>
          <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?> <?php if ($b['gender'] == 1) {
                                                                                                                                                                                                                          echo 'नाती';
                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                          echo 'नातिनी';
                                                                                                                                                                                                                        } ?> <?php echo $b['b_father'] ?> <?php if ($b['type'] == 2) {
                                                                                                                                                                                                                                                      echo 'बुहारी';
                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                      if ($b['gender'] == 1) {
                                                                                                                                                                                                                                                        echo 'छोरा';
                                                                                                                                                                                                                                                      } else {
                                                                                                                                                                                                                                                        echo 'छोरि';
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                    } ?> <?php echo $b['b_husband_wife'] ?> को <?php if ($b['gender'] == 1) {
                                                                                                                                                                                                                                                                                                                                                              echo 'पत्नी';
                                                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                                                              echo 'पति';
                                                                                                                                                                                                                                                                                                                                                            } ?>, <?php echo $b['b_address'] ?> बस्ने वर्ष
          <?php echo $this->mylibrary->convertedcit($bage) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक
      <?php endforeach;
      endif; ?>
    </div>
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 20px;">
      <p style="text-decoration:underline;">विषय: <?php echo $darta_detail['case_title'] ?></p>
    </div>

    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 10px;">उल्लिखित विपक्षी भएको उक्त विवादमा यस न्यायिक समितिबाट मेरा नाममा जारी भएको म्याद सुचना न्यायिक समितिबाट मिति २०७४।०४।०७ मा प्राप्त भएकोले सो निवेदन बमोजिमको आरोपका सम्बन्धमा देहायको व्यहोराको प्रतिउत्तर पत्र लीई उपस्थित भएको छु ।</div>
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 10px;">१. निवेदकले मलाइ लगाएका आरोपका बिषयहरुका सम्बन्धमा मेरो भएको यथार्थ व्यहोरा निम्न लिखित बुदाहरुमा लेखिए बमोजिम, खुलाएको छु ।
      <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 10px;"><?php echo $likhitjawaf['case_details'] ?></div>
    </div>
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 5px;">२. यस गाउँपालिका बाट जारी भएको स्थानिय न्यायिक कार्यविधिको परिच्छेद -३ को दफा १४ बमोजिम प्रतिउत्तर दस्तुर रु. <?php echo $this->mylibrary->convertedcit($likhitjawaf['dastur']) ?>, तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छ ।</div>
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 5px;">३. यो लिखित जवाफ म्याद भित्रै लिई म आफै उपस्थित भएको छु ।</div>
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 5px;">४. प्रमाण सम्बन्धि संलग्न कागजातहरु :
      <?php $i = 1;
      if (!empty($documents)) : foreach ($documents as $key => $docs) : ?>
          <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $docs['doc_type'] ?></div>
      <?php endforeach;
      endif; ?>
    </div>

    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 10px;">५. साक्षीहरु :
      <?php $i = 1;
      if (!empty($witness)) : foreach ($witness as $key => $wit) : ?>
          <div style="margin-left:40px; margin-right: 40px; text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $wit['address'] . ', बस्ने ' . $this->mylibrary->convertedcit($wit['age']) . ' ' . $wit['name'] ?></div>
      <?php endforeach;
      endif; ?>
    </div>
    <!-- <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 10px;">६. यस विषयमा अन्यत्र कहीं कतै कुनै निकायमा कुनै प्रकारको निवेदन दिईएको छैन ।</div> -->
    <div style="margin-left:40; margin-right: 40px; text-align: justify; margin-top: 10px;">६. यसमा लेखिएको व्यहोरा ठिक साँचो सत्य हुन झुठा ठहरे कानून बमोजिम सजाय भोग्नतयार छु ।</div>
    <div style="height:30px;"></div>
    <div style="margin-left:430;margin-top:-10px;">प्रतिउत्तर पत्र पेश गर्ने : </div>
    <?php if (!empty($pratibadi)) : $i = 1;
      foreach ($pratibadi as $key => $p) : ?>
        <div style="margin-left:450px;margin-top:5px;"><?php echo $p['p_name'] ?></div>
        <div style="margin-left:420;margin-top:5px;"><?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($p['p_ward']) . ' ' . $p['p_address'] ?></div>
    <?php endforeach;
    endif; ?>

    <div style="margin-left: 100px; margin-top: 250px;">इति सम्वत २०७८ साल श्रावण ०४ गते रोज ०२ शुभम् ............................... ।</div>
    <!-- <div style ="height:50px;"></div> -->
  </div>
</body>

</html>
<script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#basic').on("click", function() {
      $('.hideme').hide();
      window.print();
    });
  });
</script>

</body>

</html>