<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span class="os-icon os-icon-close"></span></button>
<div class="onboarding-content with-gradient">
  <h4 class="onboarding-title">न्यायिक समिति दर्ता दस्तुर विवरण</h4>
  <div class="onboarding-text">
    <span class="text-danger">[ कृपया * चिन्न लगाएको ठाउँ खाली नछोड्नुहोला ] </span>
  </div>
  <?php if(empty($badi_nibedan)){ ?>
    <div class ="alert alert-danger">निबेदन पत्र दाखिला गरिएको छैन </div>
    <div><a href="<?php echo base_url()?>Darta/addDetails/<?php echo $muddha_wiwaran['darta_no']?>" class="btn btn-primary">निबेदन पत्र दाखिला गर्नुहोस</a></div>
  <?php } else { ?>
    <form action="<?php echo base_url()?>Darta/saveDartaRasidWiwaran" method="post" class="form save_post">
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        <div class="form-group row">
            <label class="col-form-label col-sm-2" for="">मिति <span
                class="text-danger">&nbsp;*</span></label>
            <div class="col-sm-8">
                <input type="text" name="date" class="form-control" id="" required="true" value="<?php echo convertDate(date('Y-m-d'))?>" >
            </div>
        </div>
        <input type = "hidden" name="muddha_darta_no" value="<?php echo $muddha_wiwaran['darta_no']?>">
        <div class="form-group row">
            <label class="col-form-label col-sm-2" for="">रसिद नं. <span class="text-danger">&nbsp;*</span></label>
            <div class="col-sm-8">
                <input type="text" name="rasid_no" class="form-control" id="" required="true" value="" >
            </div>
        </div>
        <div class="form-group row">
            <label class="col-form-label col-sm-2" for="">दस्तुर शुल्क<span class="text-danger">&nbsp;*</span></label>
            <div class="col-sm-8">
                <input type="text" name="dastur" class="form-control" id="" required="true" value="" >
            </div>
        </div>
        <button class="btn btn-primary btn-block btn-xs save_btn" data-toggle="tooltip" title=" गर्नुहोस्" name="Submit" type="submit" value="Submit">सेभ गर्नुहोस्</button>
    </form>
  <?php } ?>
</div>