<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <!--------------------
                          START - Controls Above Table
                          -------------------->
              <?php if ($this->authlibrary->HasModulePermission('STAFF', "ADD")) { ?>
                <div class="controls-above-table">
                  <div class="row">
                    <div class="col-sm-6">
                      <a class="btn btn-outline-primary" href="<?php echo base_url() ?>Darta/Add"><i class="os-icon os-icon-ui-22"></i><span>नयाँ मुद्दा दर्ता गर्नुहोस</span></a>
                    </div>
                    <!--  <hr> -->
                  </div>
                </div>
              <?php } ?>
              <!--------------------
                          END - Controls Above Table
                          -------------------->
              <!--------------------
                          START - Table with actions
                          ------------------  -->
              <?php if ($this->session->flashdata('MSG_SUCCESS')) { ?>
                <div class="alert alert-success alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_SUCCESS') ?></div>
              <?php } ?>
              <?php if ($this->session->flashdata('MSG_ERR')) { ?>
                <div class="alert alert-danger alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_ERR') ?></div>
              <?php } ?>
              <?php if ($this->session->flashdata('MSG_WARNING')) { ?>
                <div class="alert alert-warning alert-dismissible"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button> <?php echo $this->session->flashdata('MSG_WARNING') ?></div>
              <?php } ?>
              <div class="table-responsive">
                <div class="text-center"><strong>
                    <h2>मुद्दाहरुको सुचि</h2>
                  </strong></div>
                <table class="table table-bordered table-striped" id="dataTable1">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>दर्ता नं.</th>
                      <th>मिति</th>
                      <th>दफा</th>
                      <th>उप दफा</th>
                      <th>विषय</th>
                      <th class="text-center">कार्य</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if (!empty($dartas)) :
                      $i = 1;
                      foreach ($dartas as $key => $value) : ?>
                        <tr>
                          <td class="text-right"><?php echo $this->mylibrary->convertedcit($i++) ?></td>
                          <td><?php if (empty($value['darta_id'])) { ?>
                              <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-primary btn-sm" title="दर्ता गर्नुहोस" data-url="<?php echo base_url() ?>Darta/RasidDetails" data-id="<?php echo $value['id'] ?>">दर्ता गर्नुहोस </button>
                            <?php } else { ?>
                              <a href="<?php echo base_url() ?>Darta/viewDetails/<?php echo $value['darta_no'] ?>" class="btn btn-success circle" data-placement="right" data-toggle="tooltip" title="" type="button" data-original-title="विवरण  गर्नुहोस्"> <?php echo $value['darta_id'] ?></a>
                            <?php } ?>
                          </td>
                          <td><?php echo $this->mylibrary->convertedcit($value['date']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['dafa']) ?></td>
                          <td><?php echo $this->mylibrary->convertedcit($value['upa_dafa']) ?>(<?php echo $value['remarks']?>)</td>
                          <td><?php echo $this->mylibrary->convertedcit($value['case_title']) ?></td>
                          <td style="width:220px;">
                            <?php if (empty($value['darta_id'])) { ?>
                              <?php if ($this->authlibrary->HasModulePermission('DARTA', "EDIT")) { ?>
                                <div class="btn-group">
                                  <button aria-expanded="false" aria-haspopup="true" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown" id="dropdownMenuButton6" type="button">सम्पादन कार्य</button>
                                  <div aria-labelledby="dropdownMenuButton6" class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo base_url() ?>Darta/Edit/<?php echo $value['id'] ?>" class="btn btn-primary" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्">दर्ता विवरण सम्पादन गर्नुहोस्</a>
                                    <a class="dropdown-item" href="<?php echo base_url() ?>Darta/badiEdit/<?php echo $value['id'] ?>" class="btn btn-primary" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्">वादीको विवरण सम्पादन गर्नुहोस्</a>
                                    <a class="dropdown-item" href="<?php echo base_url() ?>Darta/pratibadiEdit/<?php echo $value['id'] ?>" class="btn btn-primary" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="सम्पादन गर्नुहोस्">प्रतिवादीको विवरण सम्पादन गर्नुहोस्</a>
                                  </div>
                                </div>
                            <?php }
                            } ?>

                            <a href="<?php echo base_url() ?>Darta/badiDetails/<?php echo $value['darta_no'] ?>" class="btn btn-outline-success" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="विवरण हेर्नुहोस">विवरण हेर्नुहोस</a>
                            <?php if (!empty($value['darta_id'])) { ?>
                              <div class="btn-group">
                                <button aria-expanded="false" aria-haspopup="true" class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown" id="dropdownMenuButton6" type="button">अनुसुचीहरु</button>
                                <div aria-labelledby="dropdownMenuButton6" class="dropdown-menu">
                                  <?php if (!empty($anusuchi)) : foreach ($anusuchi as $key => $letter) : ?>
                                      <a class="dropdown-item" href="<?php echo base_url() ?>BadiAnusuchi/view/<?php echo $value['id'] . '/' . $letter['letter_name'] ?>"> <?php echo $this->mylibrary->convertedcit($letter['letter_type']) . ' (अनुसूची-' . $this->mylibrary->convertedcit($letter['letter_name']) . ')' ?></a>
                                  <?php endforeach;
                                  endif ?>
                                </div>
                              </div>
                            <?php } ?>
                          </td>
                        </tr>
                    <?php endforeach;
                    endif; ?>
                  </tbody>
                </table>
              </div>
              <!--------------------
                          END - Table with actions
                          -------------------->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>