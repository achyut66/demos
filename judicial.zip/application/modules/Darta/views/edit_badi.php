<div class="content-i">
    <div class="content-box">
        <div class="element-wrapper">
            <div class="element-box-tp">
                <div class="anusuchi">
                    <div class="text-center"><strong>
                            <h2>वादीको विवरण सम्पादन गर्नुहोस</h2>
                        </strong></div>
                    <?php echo form_open('Darta/badi_update', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal save_post')); ?>
                    <div class="form-desc">
                        <span class="text-danger"> [ कृपया &nbsp;* चिन्न भएको ठाउँ खाली नछोड्नु होला ]</span>
                    </div>

                    <input type="hidden" name="darta_no" value="<?php echo $darta['darta_no'] ?>">
                    <div class="row">
                        <div class="col-md-12">
                            <?php $i = 1;
                            if (!empty($rows)) : ?>
                                <?php echo $i++ ?>
                                <table class="table table-borderless" id="frm_tbl_mem">
                                    <tbody style="">
                                        <?php $i = 0;
                                        foreach ($rows as $row) : ?>
                                            <tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">
                                                <td>
                                                    <input type="hidden" name="row_id[]" value="<?php echo $row['id'] ?>">


                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> नाम<span class="text-danger">*</span> </label><input type="text" name="b_name[]" class="form-control" value="<?php echo $row['b_name'] ?>" required="true">
                                                                <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                                            </div>

                                                        </div>
                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> गा. पा/न. पा.<span class="text-danger">*</span> </label>
                                                                <select class="form-control select2" name="b_gapa[]">
                                                                    <option value="">गाउँपालिका/नगरपालिका</option>
                                                                    <?php if (!empty($gapa)) : foreach ($gapa as $g) : ?>
                                                                            <option value="<?php echo $g['name'] ?>"><?php echo $this->mylibrary->convertedcit($g['name']) ?></option>
                                                                    <?php endforeach;
                                                                    endif; ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> वडा नं<span class="text-danger">*</span> </label>
                                                                <select class="form-control" name="b_ward[]">
                                                                    <option value="">वडा नं</option>
                                                                    <?php if (!empty($wards)) : foreach ($wards as $ward) : ?>
                                                                            <option value="<?php echo $ward['name'] ?>" <?php if ($ward['name'] == $row['b_ward']) { echo 'selected';
                                                                            } ?>><?php echo $this->mylibrary->convertedcit($ward['name']) ?></option>
                                                                    <?php endforeach;
                                                                    endif; ?>
                                                                </select>
                                                            </div>
                                                        </div>


                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> ठेगाना(गाउँ/टोल)<span class="text-danger">*</span> </label><input type="text" name="b_address[]" class="form-control" value="<?php echo $row['b_address'] ?>" required="true">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> उमेर<span class="text-danger">*</span> </label>

                                                                <div class="">
                                                                    <input type="text" name="b_dob[]" class="form-control dob" id="dob_1" required="true" value="<?php echo $row['b_dob'] ?>">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> लिङ्ग<span class="text-danger">*</span></label>
                                                                <select class="form-control" name=gender[]>
                                                                    <option value="1" <?php if ($row['gender'] == 1) {
                                                                                            echo 'selected';
                                                                                        } ?>>पुरुष</option>
                                                                    <option value="2" <?php if ($row['gender'] == 2) {
                                                                                            echo 'selected';
                                                                                        } ?>>महिला</option>
                                                                    <option value="3" <?php if ($row['gender'] == 3) {
                                                                                            echo 'selected';
                                                                                        } ?>>अन्य</option>
                                                                </select>
                                                            </div>
                                                        </div>



                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> सम्पर्क नं.<span class="text-danger">*</span> </label><input type="text" name="b_phone[]" class="form-control" value="<?php echo $row['b_phone'] ?>" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> ना.प्र.प.नं.<span class="text-danger">*</span> </label><input type="text" name="b_cznno[]" class="form-control" value="<?php echo $row['b_cznno'] ?>" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> जारी मिति <span class="text-danger">*</span> </label>
                                                                <div class="date-input">
                                                                    <input type="text" name="b_czn_date[]" class="form-control czn" id="czn_1" required="true" value="<?php echo $row['b_czn_date'] ?>">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> जारी जिल्ला <span class="text-danger">*</span> </label>
                                                                <select class="form-control dd_select" name="b_czn_district[]" required="true">
                                                                    <?php if (!empty($districts)) :
                                                                        foreach ($districts as $district) : ?>
                                                                            <option value="<?php echo $district['name'] ?>" <?php if ($district['name'] == $row['b_czn_district']) {
                                                                                                                                echo 'selected';
                                                                                                                            } ?>><?php echo $district['name'] ?></option>
                                                                    <?php endforeach;
                                                                    endif; ?>
                                                                </select>
                                                                <!-- <input type="text" name="b_czn_district[]" class="form-control" value="<?php echo $row['b_czn_district'] ?>" required="true"> -->
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> बाजेको नाम<span class="text-danger">*</span> </label><input type="text" name="b_grandfather[]" class="form-control" value="<?php echo $row['b_grandfather'] ?>" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> बावुको नाम <span class="text-danger">*</span> </label><input type="text" name="b_father[]" class="form-control" value="<?php echo $row['b_father'] ?>" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> आमाको नाम<span class="text-danger">*</span> </label><input type="text" name="b_mother[]" class="form-control" value="<?php echo $row['b_mother'] ?>" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> वादिसंगको नाता <span class="text-danger">*</span> </label>
                                                                <select class="form-control dd_select" name="b_relation[]" required="true">
                                                                    <option value="">छान्नुहोस्</option>
                                                                    <?php if (!empty($relations)) :
                                                                        foreach ($relations as $relation) : ?>
                                                                            <option value="<?php echo $relation['name'] ?>" <?php if ($relation['name'] == $row['b_relation']) {
                                                                                                                                echo 'selected';
                                                                                                                            } ?>><?php echo $relation['name'] ?></option>
                                                                    <?php endforeach;
                                                                    endif; ?>
                                                                </select>
                                                                <!-- <input type="text" name="b_mother[]" class="form-control" value="" required="true"> -->
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for=""> पति/पत्निको नाम<span class="text-danger">*</span> </label><input type="text" name="b_husband_wife[]" class="form-control" value="<?php echo $row['b_husband_wife'] ?>" required="true">
                                                            </div>
                                                        </div>



                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <a href="<?php echo base_url() ?>Darta/badi_delete/<?php echo $row['id'] ?>/<?php echo $darta['darta_no'] ?>" class="btn btn-danger" style="margin-top: 27px;" onclick="return confirm(' Are you sure to remove?')"><i class="fa fa-trash"></i> हटानुहोस</a>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <!-- <tfoot>
                                        <tr>
                                            <td><button type="button" class="btn btn-success btnNewField pull-right" style="margin-top: 27px;"><i class="fa fa-plus-circle"></i> वादी एक भन्दा बढी भएमा थप्नुहोस्</button></td>
                                        </tr>
                                    </tfoot> -->
                                </table>
                            <?php endif ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <div class="form-buttons-w text-center">
                                <button type="submit" class='btn btn-submit btn-primary btn-block save_btn' name="submit" onclick="return confirm(' Are you sure to update details?')"><i class="fa fa-save"></i> सेभ गर्नुहोस </button>
                            </div>
                        </div>
                        <!-- <div class="col-sm-12">
                            <div class="form-buttons-w text-center">
                                <a href="<?php echo base_url() ?>Darta/addPratiBadi/<?php echo $row['darta_no'] ?>" class="btn btn-success btn-block">प्रतिबदिको विवरण थ्पुनुहोस <i class="fa fa-arrow-circle-right"></i></a>
                            </div>
                        </div> -->
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //$('.dd_select').select2();
        var mainInput = $("#dob_1");
        var cznInput = $("#czn_1");
        mainInput.nepaliDatePicker({
            ndpYear: true,
            ndpMonth: true,
            ndpYearCount: 100,
            disableAfter: GetCurrentBsDate
        });
        cznInput.nepaliDatePicker({
            ndpYear: true,
            ndpMonth: true,
            ndpYearCount: 100,
            disableAfter: GetCurrentBsDate
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.btnNewField').click(function(e) {
            e.preventDefault();
            var trOneNew = $('.row_mem').length + 1;
            var new_row = '<tr class="row_mem" style="border: 1px solid #e9ecef; border-radius: 10px;">' +
                '<td>' +
                '<div class="row">' +
                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> लिङ्ग<span class="text-danger">*</span></label>' +
                '<select class="form-control" name=gender[]><option value="1">पुरुष</option><option value="2">महिला</option><option value="3">अन्य</option></select>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> नाम<span class="text-danger">*</span> </label><input type="text" name="b_name_new[]" class="form-control" value="" required="true" >' +
                '</div>' +

                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> जन्ममिति<span class="text-danger">*</span> </label>' +
                '<div class="date-input">' +
                '<input type="text" name="b_dob_new[]" class="form-control dob" id="dob_' + trOneNew + '" required="true">' +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> सम्पर्क नं.<span class="text-danger">*</span> </label><input type="text" name="b_phone_new[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for="">  ना.प्र.प.नं.<span class="text-danger">*</span> </label><input type="text" name="b_cznno_new[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> जारी मिति <span class="text-danger">*</span> </label>' +
                '<div class="date-input">' +
                '<input type="text" name="b_czn_date_new[]" class="form-control czn" id="czn_' + trOneNew + '" required="true">' +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> जारी जिल्ला <span class="text-danger">*</span> </label><input type="text" name="b_czn_district_new[]" class="form-control" value="" required="true" >' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for="">  बाजेको नाम<span class="text-danger">*</span> </label><input type="text" name="b_grandfather_new[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> बावुको नाम <span class="text-danger">*</span> </label><input type="text" name="b_father_new[]" class="form-control" value="" required="true" >' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> आमाको नाम<span class="text-danger">*</span> </label><input type="text" name="b_mother_new[]" class="form-control" value="" required="true">' +
                '</div>' +
                '</div>' +

                '<div class="col-md-4">' +
                '<div class="form-group">' +
                '<label for=""> नाता <span class="text-danger">*</span> </label>' +
                '<select class="form-control dd_select" name="b_relation_new[]"required="true">' +
                '<option value="">छान्नुहोस्</option><?php if (!empty($relations)) : foreach ($relations as $relation) : ?> <
            option value = "<?php echo $relation['name'] ?>"
            <?php if ($relation['name'] == $row['b_relation']) {
                                                                    echo 'selected';
                                                                } ?> > <?php echo $relation['name'] ?> < /option><?php endforeach;
                                                                                                            endif; ?></select > '+
            '</div>' +
            '</div>' +

            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<label for=""> पति/पत्निको नाम<span class="text-danger">*</span> </label><input type="text" name="b_husband_wife_new[]" class="form-control" value="" required="true" >' +
            '</div>' +
            '</div>' +

            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<label for=""> वडा नं<span class="text-danger">*</span> </label>' +
            '<select class="form-control" name="b_ward_new[]"><option value="">वडा नं</option><?php if (!empty($wards)) : foreach ($wards as $ward) : ?><option value="<?php echo $ward['name'] ?>" <?php if ($ward['name'] == $row['b_ward']) {
                                                                                                                                                                                                        echo 'selected';
                                                                                                                                                                                                    } ?>><?php echo $this->mylibrary->convertedcit($ward['name']) ?></option><?php endforeach;
                                                                                                                                                                                                                                                                        endif; ?></select>' +
            '</div>' +
            '</div>' +

            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<label for=""> ठेगाना<span class="text-danger">*</span> </label><input type="text" name="b_address_new[]" class="form-control" value="" required="true" >' +
            '</div>' +
            '</div>' +

            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<button type="button" class="btn btn-danger remove-prastab-row" style="margin-top: 27px;"><i class="os-icon os-icon-ui-15"></i> हटानुहोस </button>' +
            '</div>' +
            '</div>' +

            '</div>' +
            '</td>' +
            '</tr>';
            $("#frm_tbl_mem").append(new_row);
            var mainInput = $("#dob_" + trOneNew);
            mainInput.nepaliDatePicker({
                ndpYear: true,
                ndpMonth: true,
                ndpYearCount: 100,
                //disableAfter: GetCurrentBsDate
            });
            var cznInput = $("#czn_" + trOneNew);
            cznInput.nepaliDatePicker({
                ndpYear: true,
                ndpMonth: true,
                ndpYearCount: 100,
                disableAfter: GetCurrentBsDate
            });
        });
        //remove samati members.
        $("body").on("click", ".remove-prastab-row", function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                $(this).parent().parent().parent().parent().remove();
            }
        });
        //add more witness
        $('.btnaddNewField').click(function(e) {
            var MaxInputs = 2;
            e.preventDefault();
            var trOneNew = $('.row_mem').length + 1;
            var new_row = '<tr class="row_mem">' +
                '<td><input type="text" name="s_name_n[]" class="form-control" value="" required="true"></td>' +
                '<td><input type="text" name="s_address_n[]" class="form-control" value="" required="true"></td>' +
                '<td><input type="text" name="s_age_n[]" class="form-control" value="" required="true"></td>' +
                '<td><input type="text" name="s_phone_n[]" class="form-control" value="" required="true"></td>' +
                '<td><button type="button" class="btn btn-outline-danger remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
                '<tr>';
            $("#frm_tbl_wit").append(new_row);
        });
        //remove samati members.
        $("body").on("click", ".remove-muddha-row", function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                $(this).parent().parent().remove();
            }
        });
    });
</script>