<html>
<title><?php echo !empty($title) ? $title : SITE_OFFICE ?></title>
<meta charset="utf-8">
<meta content="ie=edge" http-equiv="x-ua-compatible">
<meta content="template language" name="keywords">
<meta content="Tamerlan Soziev" name="author">
<meta content="Admin dashboard html template" name="description">
<meta content="width=device-width, initial-scale=1" name="viewport">
<link href="<?php echo base_url() ?>assets/img/nyaik_samiti.png" rel="shortcut icon">
<link href="apple-touch-icon.png" rel="apple-touch-icon">
<link href="<?php echo base_url() ?>assets/css/main.css?version=4.4.0" rel="stylesheet">
<style>
  body {
    font-size: 22px;
    margin: 0px;
    color: black;
  }

  @media print {
    /* body {
      display: table;
      table-layout: fixed;
      margin: 25mm 25mm 25mm 25mm;
      height: auto;
    } */

    @page { 
     margin: 25mm 25mm 25mm 25mm;
    }
  }

  /* @page { */
  /* size: auto; */
  /* font-size: 12px; */
  /* margin: 25mm 25mm 25mm 25mm;
  } */

  .csstransforms {
    position: absolute;
    top: 290px;
    text-align: justify;
    transform-origin: 0 0;
    transform: rotate(-90deg);
    padding: 10px;
    /* margin-top: 350px; */
    width: 500px;
    margin-left: 150px;
  }

  .csstransforms-hakim {
    transform: rotate(-90deg);
  }

  .heading {
    margin-top: 490px;
  }
</style>

<body style="--bleeding: 0.5cm;--margin: 1cm;">
  <div class="row">
    <div class="col-md-12" style="margin-top: 10px;">
      <div class="csstransforms" style="margin-top: 212px;">
        <p style="text-align:center">श्री <?php echo SITE_OFFICE ?></p>
        <p><?php echo $tokaadesh['tok_aadesh'] ?></p>
        <p style="margin-left:205px; margin-top:120px;"><?php echo $staff['name'] ?></p>
        <p style="margin-left:155px;"><?php echo $staff['designation'] ?></p>
      </div>
    </div>

    <div class="col-md-12" style="height:auto;">
      <div class=" heading">
        <p class="text-center" style="">श्री <?php echo SITE_OFFICE ?></p>
        <p class="text-center" style="margin-top:-10px;">न्यायिक समिती समक्ष पेश गरेको</p>
        <p class="text-center" style="margin-top:-10px;"><b>लिखितजवाफ</b> </p>
      </div>

      <div class="pratibadi">
        <p style="margin-left:151.18px; text-align: justify; margin-top: 45px;margin-right:40px">
          <?php if (!empty($pratibadi)) : $i = 1;
            foreach ($pratibadi as $key => $p) : ?>
              <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... लिखितजवाफ प्रस्तुतकर्ता (दाेस्राे पक्ष) <?php echo $this->mylibrary->convertedcit($i++) ?><br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>

      <div class="text-center" style="margin-top:10px;">
        <p style="font-weight: bold;">विरुद्</p>
      </div>
      <div class="badi">
        <p style="margin-left:151.18px;text-align: justify; margin-top: 40px; margin-right:40px">
          <?php if (!empty($badi)) :
            $i = 1;
            foreach ($badi as $key => $b) : ?>
              <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... विपक्षि (निवेदक) <?php echo $this->mylibrary->convertedcit($i++) ?> <br>
          <?php endforeach;
          endif; ?>
        </p>
      </div>
      <div style="margin-left:151.18px;margin-top: 20px;font-weight: bold;">
        <p style="margin-top: 80px;font-weight: bold; text-align:center">विषय : <?php echo $darta_detail['case_title'] ?></p>
      </div>
    </div>
  </div>

  <div class="col-md-12" style="margin-top: 40px;">
    <div style="margin-left:151.18px;  text-align: justify;  margin-right:40px" class="first-page">उल्लिखित विपक्षी भएको उक्त विवादमा यस न्यायिक समितिबाट मेरा नाममा जारी भएको म्याद सुचना न्यायिक समितिबाट मिति <?php echo $this->mylibrary->convertedcit($likhitjawaf['miti']) ?> मा प्राप्त भएकोले सो निवेदन बमोजिमको दावी सम्बन्धमा देहायको व्यहोराको प्रतिउत्तर पत्र लीई उपस्थित भएको छु ।</div>

    <div style="margin-left:151.18px;  text-align: justify; margin-top: 40px; margin-right:40px" class="first-page">१. निवेदकले दावी गरेको बिषयहरुका सम्बन्धमा मेरो भएको यथार्थ व्यहोरा निम्न लिखित बुदाहरुमा लेखिए बमोजिम, खुलाएको छु ।</div>
    <!-- <div style="height: 100px;"></div> -->
    <div style="margin-left:151.18px;text-align: justify; margin-top: 40px; margin-right:20px">
      <?php if (!empty($likhitjawaf['case_details'])) :
        $decision = explode('<>', $likhitjawaf['case_details']);
        if (!empty($decision)) :
          $i = 1;
          foreach ($decision as $des) : ?>
            <p style="margin-top:5px;"><?php echo $des; ?></p>
        <?php endforeach;
        endif; ?>
      <?php endif; ?>
    </div>
    <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;line-height:2em; margin-right:20px">
      २. यस गाउँपालिका बाट जारी भएको स्थानिय न्यायिक कार्यविधिको <?php echo $local_dafa['details'] ?> बमोजिम प्रतिउत्तर दस्तुर रु. <?php echo $this->mylibrary->convertedcit($likhitjawaf['dastur']) ?>, तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छ ।
    </div>
    <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;margin-right:20px">३. यो लिखित जवाफ म्याद भित्रै लिई म आफै उपस्थित भएको छु ।</div>

    <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;margin-right:20px">४. प्रमाण सम्बन्धि संलग्न कागजातहरु :
      <?php $i = 1;
      if (!empty($documents)) : foreach ($documents as $key => $docs) : ?>
          <div style="margin-left:20px;  text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $docs['doc_type'] ?></div>
      <?php endforeach;
      endif; ?>
    </div>

    <!-- <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;margin-right:20px">५. साक्षीहरु :
      <?php $i = 1;
      if (!empty($witness)) : foreach ($witness as $key => $wit) : ?>
          <div style="margin-left:20px;  text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $wit['address'] . ', बस्ने ' . $this->mylibrary->convertedcit($wit['age']) . ' ' . $wit['name'] ?></div>
      <?php endforeach;
      endif; ?>
    </div> -->
    <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;margin-right:20px">
      ५. यसमा मेरो साक्षी <?php echo SITE_OFFICE ?> बस्ने <?php $i = 1;
                                                          if (!empty($witness)) : foreach ($witness as $key => $wit) : ?>
          <div style="margin-left:20px;  text-align: justify; margin-top: 5px;"><?php echo $this->mylibrary->convertedcit($i++) ?>) <?php echo $wit['address'] . ', बस्ने  अन्दाजी वर्ष  ' . $this->mylibrary->convertedcit($wit['age']) . ' ' . $wit['name'] ?></div>
      <?php endforeach;
                                                          endif; ?>
      लाई आवश्यक परेको खण्डमा झिकाई बुझ्न सकिनेछ ।
    </div>

    <!-- <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;margin-right:20px">६. यस विषयमा अन्यत्र कहीं कतै कुनै निकायमा कुनै प्रकारको निवेदन दिईएको छैन ।</div> -->

    <div style="margin-left:151.18px;text-align: justify; margin-top: 10px;margin-right:20px">६. यसमा लेखिएको व्यहोरा ठिक साँचो सत्य हुन झुठा ठहरे कानून बमोजिम सजाय भोग्नतयार छु ।</div>

    <div style="margin-left:720px;margin-top:40px;">प्रतिउत्तर पत्र पेश गर्ने :</div>
    <?php if (!empty($pratibadi)) :
      $i = 1;
      foreach ($pratibadi as $key => $p) :
    ?>
        <div style="margin-left:746px;margin-top:10px;"><?php echo $p['p_name'] ?></div>
        <div style="margin-left:690px;margin-top:5px;"><?php echo SITE_OFFICE ?> <?php echo $this->mylibrary->convertedcit($p['p_ward']) . ' ' . $p['p_address'] ?></div>
    <?php endforeach;
    endif; ?>
    <div style="text-align:center; margin-top: 105px;font-size:18px;">इति सम्वत <?php echo $this->mylibrary->convertedcit(get_current_year()) ?> साल <?php echo getNepaliMonthName(get_current_month()) ?> <?php echo $this->mylibrary->convertedcit(get_current_day()) ?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay()) ?> शुभम् ............................... ।</div>

  </div>
  </div>
</body>
<script type="text/javascript">
  window.print();
</script>

</html>