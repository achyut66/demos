 <table class="table table-striped table-bordered" id="frm_tbl_samiti">
 	<thead>
 		<tr>
 			<td>क्र. स.</td>
 			<th>नाम</th>
 			<th>पद</th>
 			<th>मोवाइल नं.</th>
 			<th>ई-मेल</th>
 		</tr>
 	</thead>
 	<tbody>
 		<?php if(!empty($rows)):
 			  $i=1;
 			foreach($rows as $row) : ?>
	 		<tr>
	 			<td><?php echo $this->mylibrary->convertedcit($i++)?></td>
	 			<td><?php echo $row['name']?></td>
	 			<td><?php echo $row['designation']?></td>
	 			<td><?php echo $this->mylibrary->convertedcit($row['mobile'])?></td>
	 			<td><?php echo $row['email']?></td>
	 			
	 		</tr>
	 	<?php endforeach;endif;?>
 	</tbody>
 </table>