<style>
    table td {
        border: 0;
    }
</style>
<div class="content-i">
    <div class="content-box">
        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <?php echo form_open('Darta/updateNibedanPatra', array('name' => 'save', 'id' => 'save', 'method' => 'post', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data')); ?>
                    <div class="element-box-tp">
                        <?php if ($this->session->flashdata('MSG_ERR')) { ?>
                            <div class="alert alert-danger"><?php echo $this->session->flashdata("MSG_ERR") ?></div>
                        <?php } ?>
                        <div class="anusuchi">
                            <a href="<?php echo base_url() ?>Darta/generateFiradPatra/<?php echo $darta_detail['id'] ?>" class='btn btn-submit btn-primary pull-right'><i class="fa fa-print"></i> प्रिन्ट गर्नुहोस </a>
                            <input type="hidden" name="data_id" value="<?php echo $row['id'] ?>">
                            <input type="hidden" name="darta_no" value="<?php echo $darta_detail['darta_no'] ?>">
                            <div class="text-center">
                                <p style="margin-top:20px;">श्री <?php echo SITE_OFFICE ?></p>
                                <p style="margin-top:-20px;">न्यायिक समितीसमक्ष पेश गरेको</p>
                                <p style="margin-top:-20px;"><b>निबेदन पत्र</b> </p>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px">
                                    <?php if (!empty($badi)) :
                                        $i = 1;
                                        foreach ($badi as $key => $b) : ?>
                                            <?php echo $b['b_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($b['b_ward']) ?> <?php echo $b['b_address'] ?> बस्ने <?php echo $b['b_grandfather'] ?>को <?php if ($b['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $b['b_father'] ?>को <?php echo $b['b_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $b['b_husband_wife'] ?>को <?php if ($b['gender'] == 1) : ?>पति <?php else : ?>पत्नी<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($b['b_dob']) ?> <?php echo $b['b_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($b['b_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> निवेदक <br>
                                    <?php endforeach;
                                    endif; ?>
                                </p>
                                <p style="margin-left:527px; margin-right: 40px; text-align: justify; margin-top: 40px;"><b>विरुद्</b></p>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px">
                                    <?php if (!empty($pratibadi)) : $i = 1;
                                        foreach ($pratibadi as $key => $p) : ?>
                                            <?php echo $p['p_czn_district'] ?> जिल्ला <?php echo SITE_OFFICE ?> वडा नं. <?php echo $this->mylibrary->convertedcit($p['p_ward']) ?> <?php echo $p['p_address'] ?> बस्ने <?php echo $p['p_grandfather'] ?>को <?php if ($p['gender'] == 1) : ?>नाति <?php else : ?>नातिनी<?php endif; ?> <?php echo $p['p_father'] ?>को <?php echo $p['p_relation'] ?> <?php if (!empty($b['b_husband_wife'])) : ?><?php echo $p['p_husband_wife'] ?>को <?php if ($p['gender'] == 1) : ?>पत्नी <?php else : ?>पति<?php endif; ?><?php endif; ?>, वर्ष <?php echo $this->mylibrary->convertedcit($p['p_dob']) ?> <?php echo $p['p_name'] ?> (मो. नं. <?php echo $this->mylibrary->convertedcit($p['p_phone']) ?>)............................... <?php echo $this->mylibrary->convertedcit($i++) ?> बिपक्षि<br>
                                    <?php endforeach;
                                    endif; ?>

                                </p>
                                <p style="margin-left:402px; margin-right: 40px; text-align: justify; margin-top: 40px;"><b>विषयः <span style="text-decoration: underline;"><?php echo $darta_detail['case_title'] ?></span></b></p><br>
                                <?php if (!empty($badi)) {
                                    $total_badi = count($badi);
                                    if ($total_badi >= 1) {
                                        $sombodan = 'हामी';
                                    } else {
                                        $sombodan = 'म';
                                    }
                                } ?>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;"> १. <?php echo $sombodan ?> निम्न लिखित बुदाहरुमा लेखिए बमोजिम निवेदन गर्दछ ।</p>
                                <div style="margin-left:80px; margin-right: 40px; margin-top: 60px;" class="field_wrapper">

                                    <table class="table table-bordered" id="tbl_wiwaran" style="border:color:#000">
                                        <thead>
                                            <tr>
                                                <th>मुद्दाको विवरण </th>
                                                <th>
                                                    <button type="button" class="btn  btn-primary btn-sm btnwiwaran" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php if (!empty($row['muddha_details'])) :
                                                $decision = explode('<>', $row['muddha_details']);
                                                if (!empty($decision)) :
                                                    $i = 1;
                                                    foreach ($decision as $des) : ?>
                                                        <tr>
                                                            <td style="width: 900px;"><textarea class="form-control content" id="content" name="muddha_details[]" oninput="this.style.height = '';this.style.height = this.scrollHeight + 'px'"><?php echo $des ?></textarea></td>
                                                            <td><button type="button" class="btn  btn-outline-danger btn-sm" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-15"></i> </button></td>
                                                        </tr>
                                                <?php endforeach;
                                                endif; ?>
                                            <?php endif; ?>

                                    </table>
                                </div>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;line-height:2em;">
                                    २.यस गाउँपालिका बाट जारी भएको स्थानिय न्यायिक कार्यविधिको दफा १४ बमोजिम
                                    निवेदन दस्तुर रु <input type="text" name="nibedan_dastur" id="nibedan_dastur" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none; width:90px;" placeholder="*" required="true" value="<?php echo $row['nibedan_dastur']; ?>"> दोस्रो पक्ष एक जनालाई म्याद सुचना दस्तुर रु.<input type="text" name="suchana_dastur" id="suchana_dastur" style="outline: 0;border-width: 0 0 2px; border-color:#000;background: none;width:90px;" placeholder="*" required="true" value="<?php echo $row['suchana_dastur']; ?>">,पाना <input type="text" name="pana" id="pana" style="outline: 0;width:50px;border-width: 0 0 2px; border-color:#000;background: none;" placeholder="*" required="true" value="<?php echo $row['pana']; ?>"> को प्रतिलिपि दस्तुर रु. <input type="text" name="pratilipi_dastur" id="pratilipi_dastur" style="outline: 0;width:90px;border-width: 0 0 2px; border-color:#000;background: none;" placeholder="*" required="true" value="<?php echo $row['pratilipi_dastur']; ?>">
                                    जम्मा रु <input type="text" name="jamma" style="outline: 0;width:90px;border-width: 0 0 2px; border-color:#000;background: none;" placeholder="*" required="true" value="<?php echo $row['jamma']; ?>" id="jamma"> तिरेको सक्कल रसिद यसै निवेदन साथ दाखिला गरेको छु ।
                                </p>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">३. यो निवेदन स्थानिय सरकार संचालन ऐन, २०७४ को दफा १ को उपदफा (छ) अनुसार यसै समितिको अधिकारक्षेत्र भित्र पर्दछ ।</p>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">४. यो निवेदन हदम्याद भित्रै छ र म निवेदकलाई यस बिषयमा निवेदनदिने हकदैया प्राप्त छ।</p>
                                <div style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">
                                    <p> ५. संलग्नकागजातहरु </p>
                                    <table class="table table-bordered" id="frm_tbl_upload">
                                        <thead>
                                            <tr>
                                                <th>पेश गरेको कागजातको नाम </th>

                                                <th>
                                                    <button type="button" class="btn btn-primary btn-sm btnUpload" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> नया संलग्न कागजातहरु थप्नुहोस </button>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!empty($documents)) :
                                                foreach ($documents as $doc) : ?>
                                                    <tr>
                                                        <td><input type="text" name="doc_name" class="form-control" value="<?php echo $doc['doc_type'] ?>" readonly></td>

                                                        </td>
                                                        <td>

                                                            <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-success btn-sm" title="" data-url="<?php echo base_url() ?>Darta/viewDocs" data-id="<?php echo $doc['id'] ?>"><i class="fa fa-eye"></i></button>

                                                            <button type="button" data-toggle="modal" href="#onboardingFormModal" class="btn btn-outline-primary btn-sm" title="" data-url="<?php echo base_url() ?>Darta/editDocs" data-id="<?php echo $doc['id'] ?>"><i class="fa fa-pencil"></i></button>
                                                            <button type="button" data-href="<?php echo base_url() ?>BadiAnusuchi/nebidanDocs/" class="btn btn-outline-danger btn-sm deleteWitness" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="हटानुहोस" data-id="<?php echo $doc['id'] ?>"><i class="os-icon os-icon-ui-15"></i></button>
                                                        </td>
                                                    </tr>
                                            <?php endforeach;
                                            endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">५. साक्षीहरु :</p>
                                <div style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">
                                    <table class="table table-bordered" id="frm_tbl_wit" style="border:color:#000">
                                        <thead>
                                            <tr>
                                                <th>नाम</th>
                                                <th>ठेगाना</th>
                                                <th>उमेर</th>
                                                <th>सम्पर्क नं.</th>
                                                <th>
                                                    <button type="button" class="btn  btn-primary btnaddNewField" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="थप्नुहोस"><i class="os-icon os-icon-ui-22"></i> </button>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!empty($witness)) :
                                                foreach ($witness as $w) : ?>
                                                    <tr>
                                                        <input type="hidden" name="w_id[]" value="<?php echo $w['id'] ?>">
                                                        <td><input type="text" name="w_name[]" class="form-control" value="<?php echo $w['name'] ?>" required="true"></td>
                                                        <td><input type="text" name="w_address[]" class="form-control" value="<?php echo $w['address'] ?>" required="true"></td>
                                                        <td><input type="text" name="w_age[]" class="form-control" value="<?php echo $w['age'] ?>" required="true"></td>
                                                        <td><input type="text" name="w_phone[]" class="form-control" value="<?php echo $w['phone'] ?>" required="true"></td>
                                                        <td><button type="button" data-href="<?php echo base_url() ?>BadiAnusuchi/deleteWitness/" class="btn btn-outline-danger deleteWitness" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस" data-id="<?php echo $w['id'] ?>"><i class="os-icon os-icon-ui-15"></i></button></td>
                                                    </tr>
                                            <?php endforeach;
                                            endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">६. यस विषयमा अन्यत्र कहीं कतै कुनै निकायमा कुनै प्रकारको निवेदन दिईएको छैन ।</p>
                                <p style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">७. यसमा लेखिएको व्यहोरा ठिक साँचो सत्य हुन झुठा ठहरे कानून बमोजिम सजाय भोग्नतयार छु ।</p>
                                <div style="margin-left:80px; margin-right: 40px; text-align: justify; margin-top: 40px;">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" name="inlineRadioOptions" id="inlineRadio1" value="1" checked="true">
                                        <label class="form-check-label label label-danger" for="inlineRadio1" style="color:red"><b>तोक-आदेश लगानुहोस</b></label>
                                    </div>
                                    <!-- <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                                        <label class="form-check-label" for="inlineRadio2">तोक-आदेश लगानुहोस</label>
                                    </div> -->
                                </div>
                                <hr>
                                <div class="text-center">
                                    <?php if (!empty($row)) : ?>
                                        <button type="submit" class='btn btn-submit btn-primary' name="submit" value="submit"><i class="fa fa-save"></i> सम्पादन गर्नुहोस</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php echo form_close() ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type=" text/javascript" src="<?php echo base_url() ?>assets/js/custom.js">
    </script>
    <script type="text/javascript">
        textarea = document.querySelector(".content");
        textarea.addEventListener('input', autoResize, false);

        function autoResize() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        }
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.btnaddNewField').click(function(e) {
                var MaxInputs = 2;
                e.preventDefault();
                var trOneNew = $('.row_mem').length + 1;
                var new_row = '<tr class="row_mem">' +
                    '<td><input type="text" name="w_name_new[]" class="form-control" value="" required="true"></td>' +
                    '<td><input type="text" name="w_address_new[]" class="form-control" value="" required="true"></td>' +
                    '<td><input type="text" name="w_age_new[]" class="form-control" value="" required="true"></td>' +
                    '<td><input type="text" name="w_phone_new[]" class="form-control" value="" required="true"></td>' +
                    '<td><button type="button" class="btn btn-danger btn-sm remove-muddha-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
                    '<tr>';
                $("#frm_tbl_wit").append(new_row);
            });
            //remove samati members.
            $("body").on("click", ".remove-muddha-row", function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                    $(this).parent().parent().remove();
                }
            });
            //add new wiwaran field btanwiwaran
            $('.btnwiwaran').click(function(e) {
                var MaxInputs = 2;
                e.preventDefault();
                var trOneNew = $('.row_mem').length + 1;
                var new_row = '<tr><td><textarea class="form-control content" style="width:100%; height100px;" name="muddha_details[]" id="content"></textarea></td>' +
                    '<td><button type="button" class="btn btn-outline-danger btn-sm remove-wiwaran-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
                    '<tr>';
                $("#tbl_wiwaran").append(new_row);
            });
            //remove samati members.
            $("body").on("click", ".remove-wiwaran-row", function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                    $(this).parent().parent().remove();
                }
            });

            //upload files
            $('.btnUpload').click(function(e) {
                var MaxInputs = 2;
                e.preventDefault();
                var trOneNew = $('.row_mem').length + 1;
                var new_row = '<tr class="row_mem">' +
                    '<td><input type = "text" name = "doc_name[]" class="form-control"></td>' +
                    '<td><input type = "file" name = "userfile[]" class="form-control"></td>' +
                    '<td><button type="button" class="btn btn-outline-danger btn-sm remove-file-row" data-placement="bottom" data-toggle="tooltip" title="" data-original-title="प्रस्ताव हटानुहोस"><i class="os-icon os-icon-ui-15" ></i></button></td>' +
                    '<tr>';
                $("#frm_tbl_upload").append(new_row);
            });

            $("body").on("click", ".remove-file-row", function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                    $(this).parent().parent().remove();
                }
            });

            //remove witness
            $(document).on('click', '.deleteWitness', function(e) {
                e.preventDefault();
                if (confirm('के तपाइँ  यसलाई हटाउन निश्चित हुनुहुन्छ ?')) {
                    id = $(this).data('id');
                    url = $(this).data('href');
                    $.ajax({
                        url: url,
                        method: "POST",
                        data: {
                            id: id,
                            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                        },
                        beforeSend: function() {
                            $('.loading_state').html('<i class="fa fa-spinner fa-spin"></i> ');
                        },
                        success: function(resp) {
                            if (resp.status == 'success') {
                                toastr.options = {
                                    "closeButton": false,
                                    "debug": false,
                                    "newestOnTop": false,
                                    "progressBar": false,
                                    "positionClass": "toast-top-right",
                                    "preventDuplicates": true,
                                    "onclick": null,
                                    "showDuration": "1000",
                                    "hideDuration": "2000",
                                    "timeOut": "2000",
                                    "extendedTimeOut": "3000",
                                    "showEasing": "swing",
                                    "hideEasing": "linear",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                }
                                toastr.error(resp.data);
                                location.reload();
                            }
                        }
                    });
                }
            });

            //total dastur
            $(document).on('input', '#suchana_dastur,#nibedan_dastur', function(e) {

                var nibedan_dastur = $('#nibedan_dastur').val() || 0;
                var suchana_dastur = $('#suchana_dastur').val() || 0;
                var total_amount = parseInt(nibedan_dastur) + parseInt(suchana_dastur);
                $('#jamma').val(total_amount);
            });

            $(document).on('input', '#pratilipi_dastur,#pana', function(e) {
                var nibedan_dastur = $('#nibedan_dastur').val() || 0;
                var suchana_dastur = $('#suchana_dastur').val() || 0;
                var pana = $('#pana').val() || 0;
                var pratilipi_dastur = $('#pratilipi_dastur').val() || 0;
                var total_amount = parseInt(nibedan_dastur) + parseInt(suchana_dastur);
                var total_pratilipi = pana * pratilipi_dastur;
                $('#jamma').val(total_amount + total_pratilipi);
            });
        });
    </script>