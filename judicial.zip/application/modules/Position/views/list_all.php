<div class="content-i">
    <div class="content-box">
         <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    
                    <div class="element-box">
                        <!--------------------
                          START - Controls Above Table
                          -------------------->
                        <?php if($this->authlibrary->HasModulePermission('MEETING', "ADD")) { ?>
                        <div class="controls-above-table">
                            <div class="row">
                                <div class="col-sm-6">
                                    <a class="btn btn-primary btn-sm" href="#editModel" data-toggle="modal" data-url="<?php echo base_url()?>Position/add" data-id = ""><i class="os-icon os-icon-ui-22" ></i><span></span>नयाँ पद थप्नुहोस</a>
                                </div>
                            </div>
                        </div>
                      <?php } ?>
                        <!--------------------
                          END - Controls Above Table
                          ------------------ -->
                        <!--------------------
                          START - Table with actions
                          ------------------  -->
                          <table  class="table table-inbox table-bordered table-striped print_table">
                            <thead>
                              <tr>
                                <th text-aligh="right">#</th> 
                                <th>पद</th>
                                <th></th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php if(!empty($sections)) :
                                $i = 1;
                                foreach($sections as $key => $value) : ?>
                                  <tr class="gradeX">
                                    <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                    <td><?php echo $this->mylibrary->convertedcit($value['name'])?></td>
                                    <?php if($this->authlibrary->HasModulePermission('POSITION', "EDIT") || $this->authlibrary->HasModulePermission('POSITION', "DELETE") ) { ?>
                                      <td class="center hidden-phone">
                                        <?php if($this->authlibrary->HasModulePermission('POSITION', "EDIT")) { ?>
                                          <button type="button" data-toggle="modal" href="#editModel" class="btn btn-primary" title="" data-url="<?php echo base_url()?>Position/edit" data-id = "<?php echo $value['id']?>"><i class="fa fa-pencil"></i></button>
                                        <?php } ?>
                                        
                                     </td>
                                   <?php } ?>
                                 </tr>
                               <?php endforeach;endif; ?>
                             </tbody>
                           </table>
                        </div>
                        <!--------------------
                          END - Table with actions
                          -------------------->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>