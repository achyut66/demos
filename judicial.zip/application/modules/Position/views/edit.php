
<form action="<?php echo base_url()?>Position/update" method="post" class="form save_post">
  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <div class="form-group row">
    <label class="col-form-label col-sm-2" for="">पद <span
      class="text-danger">&nbsp;*</span></label>
      <div class="col-sm-8">
        <input type="text" class="form-control" name="position" required="true" value="<?php echo $row['name']?>">
        <input type="hidden" class="form-control" name="id" required="true" value="<?php echo $row['id']?>">
      </div>
    </div>
  <div class="modal-footer">
    <button class="btn btn-primary btn-xs save_btn" data-toggle="tooltip" title="सम्पादन गर्नुहोस्" name="Submit" type="submit" value="Submit">सम्पादन गर्नुहोस्</button>
   
  </div>
</form>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/customjs.js"></script>