<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*This class load model for dashboard*/

class PeshiModel extends CI_Model
{
	// public function TotalCases() {
    //     $this->db->from("darta");
    //     if($this->session->userdata('EM_USER_TPID') != 'su' ) {
    //         $this->db->where('created_by', $this->session->userdata('EM_USER_TPID'));
    //     }
    //     return $this->db->count_all_results();
    // }

    // public function TotalDarta() {
    //     $this->db->where('darta_id !=',null);
    //     if($this->session->userdata('EM_USER_TPID') != 'su' ) {
    //         $this->db->where('created_by', $this->session->userdata('EM_USER_TPID'));
    //     }
    //     $this->db->from("darta");
    //     return $this->db->count_all_results();
    // }

    // public function TotalSubmittedMudda() {
    //     $this->db->where('darta_id',null);
    //     if($this->session->userdata('EM_USER_TPID') != 'su' ) {
    //         $this->db->where('created_by', $this->session->userdata('EM_USER_TPID'));
    //     }
    //     $this->db->from("darta");
    //     return $this->db->count_all_results();
    // }

    public function getDartaDetails() {
        $this->db->select('t1.*')->from('darta t1');
        //$this->db->join('mudda_bisaye t2','t2.id = t1.mudda_bisaye','left');
        //$this->db->join('badi_detail t3','t1.darta_id = t3.darta_no','left');
       // $this->db->join('pratibadi_detail t4','t1.darta_id = t4.darta_no','left');
        $this->db->where('t1.darta_id !=',null);
        $this->db->order_by('t1.darta_no','desc');
        //$this->db->limit(5);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getPeshiDetails($date =NULL) {
        $this->db->select('t1.*')->from('peshi_darta t1');
        // $this->db->join('darta t2','t2.darta_id = t1.darta_no','left');
        // $this->db->join('badi_detail t3','t1.darta_no = t3.darta_no','left');
        // $this->db->join('pratibadi_detail t4','t1.darta_no = t4.darta_no','left');
        // if(!empty($date)){
        //     $this->db->where('t1.peshi_miti',$date);
        // } else {
        //     $today = get_today_np();
        //     $this->db->where('t1.peshi_miti',$today);
        // }
        
        $this->db->order_by('t1.peshi_miti','desc');
        //$this->db->limit(5);
        $query = $this->db->get();
        return $query->result_array();
    }

    //search
    public function getSearch($darta_no = NULL,$from_date = NULL,$to_date = NULL) {
        $this->db->select('t1.*')->from('peshi_darta t1');
        //$this->db->join('darta t2','t2.darta_id = t1.darta_no','inner');
        //$this->db->join('badi_detail t3','t1.darta_no = t3.darta_no','inner');
        //$this->db->join('pratibadi_detail t4','t1.darta_no = t4.darta_no','inner');
        if(!empty($darta_no)){
            $this->db->where('t1.darta_no',$darta_no);
        }
        if(!empty($from_date)) {
            $this->db->where('t1.peshi_miti >=', $from_date);
        }
        if(!empty($from_date)) {
            $this->db->where('t1.peshi_miti <=', $to_date);
        }
        //$this->db->order_by('t1.darta_no','desc');
        //$this->db->limit(5);
        $query = $this->db->get();
        return $query->result_array();
    }
}