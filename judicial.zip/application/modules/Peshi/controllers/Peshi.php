<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Peshi extends MX_Controller
{	
	public function __construct()
	{
		parent:: __construct();
        $this->load->model('PeshiModel');
        $this->load->model('CommonModel');
        if(!$this->authlibrary->IsLoggedIn()){
            $this->session->set_userdata('return_url', current_url());
            redirect('Login');
        }
		$this->container='main';
	}

	public function Index()
	{
        $data['page']   = 'muddha_list';
        $this->breadcrumb->populate(array(
            'ड्यासबोर्ड' => '',
            'पेशी फारम '
        ));
        $data['dartas']             = $this->PeshiModel->getDartaDetails();
        $data['breadcrumb']         = $this->breadcrumb->output();
        $this->load->view('main', $data);
	}
   
    public function save() {
        if($this->input->is_ajax_request()) {
        
            $this->form_validation->set_rules('darta_no[]', 'darta_no', 'required');
            if($this->form_validation->run() == false) {
                $response           = array(
                    'status'                => 'v_errors',
                    'data'     => 'कृपया मुद्दा छान्नुहोस्',
                );
                header("Content-type: application/json");
                echo json_encode($response);
                exit;
            }
            $darta_no       = $this->input->post('darta_no');
            // if(empty($darta_no)){
            //     $response           = array(
            //         'status'                => 'v_errors',
            //         'data'     => 'कृपया * चिन्न लागेको ठाउँ खाली भएको हुनाले सभ हुन असफल भयो',
            //     );
            //     header("Content-type: application/json");
            //     echo json_encode($response);
            //     exit;
            // }
            $post       = array();
            if(!empty($darta_no)) {
                foreach ($darta_no as $key => $indexv) {
                    $post[]    = array(
                        'darta_no'     => $darta_no[$key],
                        'peshi_miti'   => convertDate(date('Y-m-d')),
                        'created_by'     => $this->session->userdata('EM_USER_ID'),
                        'created_at'     => date('y-m-d H:i:s'),
                    );
                }
               $result = $this->CommonModel->batchInsert($post, 'peshi_darta');
                if($result) {
                    $response = array(
                        'status'        => 'success',
                        'data'          => "सफलतापूर्वक सम्मिलित गरियो",
                        'message'       => 'redirect',
                        'redirect_url'  => base_url().'Peshi/suchi/'.convertDate(date('Y-m-d')),
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                } else {
                    $response = array(
                        'status'      => 'error',
                        'data'         => "Fail",
                    );
                    header("Content-type: application/json");
                    echo json_encode($response);
                    exit;
                }
            } 
        } else {
            exit('no direct script allowed');
        }
    }
    public function suchi($date = NULL ) {
        $data['page']   = 'dainik_peshi_suchi';
        $this->breadcrumb->populate(array(
            'ड्यासबोर्ड' => '',
            'पेशी सुची '
        ));
        $data['dartas']             = $this->PeshiModel->getPeshiDetails($date);
       
        $data['breadcrumb']         = $this->breadcrumb->output();
        $this->load->view('main', $data);
    }
    public function printPreview($date = NULL) {
        $data['page']   = 'peshi_preview';
        $this->breadcrumb->populate(array(
            'ड्यासबोर्ड' => ''
        ));
        $data['date']               = !empty($date)?$date:convertDate(date('Y-m-d'));
        $data['dartas']             = $this->PeshiModel->getPeshiDetails($date);
        $data['breadcrumb']         = $this->breadcrumb->output();
        $this->load->view('main', $data);
    }
    //peshi pdf
    public function print($date = NULL) {
        $mpdf                               = new \Mpdf\Mpdf(['mode' => 'utf-8']);
        $mpdf->showImageErrors              = true;
        $mpdf->autoPageBreak                = true;
        $mpdf->shrink_tables_to_fit         = 1;
        $mpdf->AddPage();
        $mpdf->use_kwt                      = true;
        $mpdf->allow_charset_conversion     = true;
        $mpdf->curlAllowUnsafeSslRequests   = true;
        $mpdf->charset_in                   = 'iso-8859-4';
        $darta_no                           = $this->uri->segment(3);
        $data['dartas']                     = $this->PeshiModel->getPeshiDetails($date);
        $html                               = $this->load->view('peshi_pdf',$data,true);
        $mpdf->WriteHTML($html);
        $mpdf->Output(); // opens in browser
    }

    //searchlists
    public function searchList() {
        if($this->input->is_ajax_request()) {
            $darta_no   = $this->input->post('darta_no');
            $from_date  = $this->input->post('from_date');
            $to_date    = $this->input->post('to_date');
            $data['dartas'] = $this->PeshiModel->getSearch($darta_no,$from_date,$to_date);
            $data_view                      = $this->load->view('ajax_peshi_view', $data, true);
            $response                       = array(
            'status'                        => 'success',
            'data'                          => $data_view
            );
            header("Content-type: application/json");
            echo json_encode($response);
            exit;
        } else{
            exit('no direct script allowed');
        }
    }
    
}