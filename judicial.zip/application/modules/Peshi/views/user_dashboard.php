<div class="content-i">
    <div class="content-box ">
        <!-- dashboard count -->
        <div class="row">
            <div class="col-sm-6 col-xxxl-3">
                <a class="element-box el-tablo anusuchi" href="#">
                    <div class="label"> जम्मा मुद्दा</div>
                    <div class="value"> <?php echo $this->mylibrary->convertedcit($mudda)?></div>
                </a>
            </div>
            <div class="col-sm-6 col-xxxl-3">
                <a class="element-box el-tablo anusuchi" href="#">
                    <div class="label">दर्ता भएका मुद्दा </div>
                    <div class="value"><?php echo $this->mylibrary->convertedcit($darta)?></div>
                </a>
            </div>
            <!-- <div class="col-sm-3 col-xxxl-3">
                <a class="element-box el-tablo" href="#">
                    <div class="label">दर्ता नभएका मुद्दा </div>
                    <div class="value"><?php //echo $this->mylibrary->convertedcit($ndarta)?></div>
                </a>
            </div> -->
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-12">
                <div class="element-wrapper">
                    <div class="element-box-tp anusuchi">
                        <div class="controls-above-table">
                            <div class="row">
                            <div class="col-sm-12">
                                <a class="btn btn-primary" href="<?php echo base_url()?>Darta/Add"> <i class="dashicons dashicons-plus-alt"></i> नया मुद्दा दाखिला गर्नुहोस </a>
                                <?php if(!empty($dartas)) : ?><a class="btn btn-success" href="<?php echo base_url()?>Darta"><i class="dashicons dashicons-visibility"></i> मुद्दाहरुको सुचिमा जानुहोस </a><?php endif;?>
                                <?php if(!empty($dartas)) : ?><a class="btn btn-secondary" href="<?php echo base_url()?>Darta"><i class="dashicons dashicons-admin-network"></i> मुद्दाहरुको पेशी गर्नुहोस</a><?php endif;?>
                            </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <?php if(!empty($dartas)) : ?>
                            <table class="table table-padded">
                                <thead style="background-color:#183f9e">
                                    <tr>
                                        <th>क्र. स.</th>
                                        <th> मुद्दाको प्रकार </th>
                                        <th> मुद्दाको विषय</th>
                                        <th> दर्ता नं. </th>
                                        <th>दर्ता मिति</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;if(!empty($dartas)) : foreach($dartas as $darta) : ?>
                                        <tr>
                                            <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($darta['subject'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($darta['case_title'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($darta['darta_id'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($darta['date'])?></td>
                                            <td><a href="<?php echo base_url()?>Darta/badiDetails/<?php echo $darta['darta_no']?>" class="btn btn-success" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="विवरण हेर्नुहोस" target="_blank">विवरण हेर्नुहोस</a></td>
                                        </tr>
                                    <?php endforeach;endif;?>
                                </tbody>
                            </table>
                            <?php else : ?>
                                <div class="alert alert-primary">मुद्दा दर्ता गरिएको छैन!!!</div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class ="element-box anusuchi">
                    <div class="table-responsive">
                        <table class="table table-lightborder">
                            <thead style="background-color:#183f9e;color:#fff">
                                <tr>
                                    <th>विवरण</th>
                                    <th class="text-right"> जम्मा</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="nowrap">न्यायिक समितिबाट भएको निर्णय</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($samitiDecision)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">अन्तरिम संरक्षणात्मक आदेश</td>
                                    <td class="text-right"><?php echo $this->mylibrary->convertedcit($aadesh)?></td>
                                </tr>
                                <tr>
                                    <td class="nowrap">न्यायिक समिति समक्ष पेस गरेको मिलापत्रको निवेदन</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($melmilapnibedan)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">न्यायिक समिति समक्ष भएको मिलापत्र</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($anusuchi10)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">मेलमिलापकर्तामा सूचीकृत हुने निवेदन</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($anusuchi11)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">भरिभराऊको निवेदन पत्र</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($anusuchi12)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">चलन चलाउने निवेदन</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($anusuchi13)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">सम्पति रोक्का को अदेश</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($anusuchi14)?> </td>
                                </tr>
                                <tr>
                                    <td class="nowrap">नक्कलको लागि निवेदन</td>
                                    <td class="text-right"> <?php echo $this->mylibrary->convertedcit($anusuchi15)?> </td>
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- <div class="col-md-6">
                <div class="element-wrapper">
                    <div class="element-box">
                      <form>
                        <h5 class="element-box-header">
                         मुद्दा खोज्नुहोस
                        </h5>
                        <div class="row">
                           
                            
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="lighter" for="">मुद्दाको विषय</label>
                                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                                        <input type = "text" class ="form-control" name = "case_title">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="lighter" for="">दर्ता नं.</label>
                                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                                        <input type = "text" class ="form-control" name = "case_title">
                                    </div>
                                </div>
                            </div>

                            <div class ="col-md-12">
                                <div class="dashboard-search">
                                    <button type="submit" name="submit" class="btn btn-primary btn-block"><i class="fa fa-search"></i> खोज्नुहोस </button>
                                </div>
                            </div>
                        </div>
                      </form>
                    </div>
                  </div>
            </div> -->
        </div>
    </div>
</div>