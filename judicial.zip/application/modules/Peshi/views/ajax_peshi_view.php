<?php if(!empty($dartas)) : ?>
 <table  class="table table-bordered table-lg table-v2 table-striped" >
                        <thead>
                            <tr>
                                <th>क्र.स.</th> 
                                <th>पेशी मिति</th> 
                                <th>मुद्दा दर्ता नं</th>
                                <th>मुद्दा दर्ता मिति</th>
                                <th>मुद्दाको विषय</th>
                                <th>उजुरीकर्ता/वादी</th>
                                <th>विपक्षि/प्रतिवादी</th>
                                <th>विवरण</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($dartas)) :
                            $i = 1;
                            foreach($dartas as $key => $value) :
                                 if(!empty($pbadi_details)) : foreach($pbadi_details as $key => $pbadi) :
                                    $badis = $key++.')'.implode(',', $pbadi['p_name']);
                                endforeach;endif;
                                $darta_details = $this->CommonModel->getWhere('darta', array('darta_no' => $value['darta_no']));
                            ?>
                            <tr>
                                <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                <td><?php echo $this->mylibrary->convertedcit($value['peshi_miti'])?></td>
                                <td><?php echo $this->mylibrary->convertedcit($value['darta_no'])?></td>
                                <td><?php echo $this->mylibrary->convertedcit($darta_details['date'])?></td>
                                <td><?php echo $darta_details['case_title']?></td>
                                <td>
                                <?php 
                                    $badi_details = $this->CommonModel->getWhereAll('badi_detail', array('darta_no' => $value['darta_no']));
                                    if(!empty($badi_details)) : foreach($badi_details as $ij => $badi) :
                                        echo '<b>'. $this->mylibrary->convertedcit($ij+1) . ') '. $badi['b_name'].'<br></b>';
                                     endforeach;endif;
                                 ?>
                                 </td>
                                <td>
                                    <?php 
                                        $pbadi_details = $this->CommonModel->getWhereAll('pratibadi_detail', array('darta_no' => $value['darta_no']));
                                        if(!empty($pbadi_details)) : foreach($pbadi_details as $ijp => $pbadi) :
                                            echo '<b>'.$this->mylibrary->convertedcit($ijp+1) . ') '. $pbadi['p_name'].'<br></b>';
                                         endforeach;endif;
                                    ?>
                                 </td>
                            <td><a href="<?php echo base_url()?>Darta/badiDetails/<?php echo $value['darta_no']?>" class="btn btn-success" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="विवरण हेर्नुहोस" target="_blank">विवरण हेर्नुहोस</a></td>
                            </tr>
                        <?php endforeach;endif; ?>
                        </tbody>
                    </table>
<?php else : ?>
    <div class="alert alert-warning alert-dismissible fade show"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button>पेश गरेको मुद्दा भेटिएन</>
<?php endif;?>