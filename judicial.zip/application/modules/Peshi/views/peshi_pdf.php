<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">

	<title><?php echo SITE_OFFICE?></title>

	<style type="text/css">
		/* Center tables for demo */

		table {

			margin: 0 auto;

		}



		/* Default Table Style */

		table {

			color: #333;

			background: #fff;

			border: 0;

			font-size: 15pt;

			border-collapse: collapse;
            width:100%;

		}

		table thead th,

		table tfoot th {

			color: #000;

			background: #fff;

		}


		table th,

		table td {

			/* padding: .5em; */

			border:1px solid #000;

		}
	</style>

</head>
<body style="background-color: #fff; padding: 20px; font-family: freeserif; font-size: 16px; line-height: 1.43;">
    <div style="margin-left: 282px;">
        <?php if(!empty(SITE_SARKAR_LOGO)) : ?>
        <div class ="avatar-w"><img src="<?php echo base_url()?>uploads/<?php echo SITE_SARKAR_LOGO;?>" style="height:100px;"></div>
        <?php endif;?>
    </div>
    <div style="margin-left: 270px;font-size:22px;"><?php echo SITE_OFFICE?></div>
    <div style="margin-left: 250px;font-size:20px;"><?php echo SITE_PALIKA?></div>
    <div style="margin-left: 260px;font-size:14px;">न्यायिक समिती, <?php echo SITE_OFFICE_ADDRESS?>,<?php echo SITE_DISTRICT?></div>
    <div style="margin-left: 187px;font-size:16px; margin-top:100px; margin-bottom:10px;">मिति : <?php echo $this->mylibrary->convertedcit(get_current_year())?> साल <?php echo getNepaliMonthName(get_current_month())?> <?php echo $this->mylibrary->convertedcit(get_current_day())?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay())?> को दैनिक पेशी सुची</div>
    <?php if(!empty($dartas)) : ?>
    <table class="">
        <thead>
            <tr>
                <th>सि  नं</th>
                <th>दर्ता मिति</th>
                <th>मुद्दा </th>
                <th>मुद्दा  नं</th>
                <th>उजुरीकर्ता/वादी</th>
                <th>विपक्षि/प्रतिवादी</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1;if(!empty($dartas)) : foreach($dartas as $peshi) : ?>
            <tr>
                <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                <td><?php echo $this->mylibrary->convertedcit($peshi['date'])?></td>
                <td><?php echo $this->mylibrary->convertedcit($peshi['case_title'])?></td>
                <td><?php echo $this->mylibrary->convertedcit($peshi['darta_no'])?></td>
                <td><?php echo $this->mylibrary->convertedcit($peshi['b_name'])?></td>
                <td><?php echo $this->mylibrary->convertedcit($peshi['p_name'])?></td>
            </tr>
            <?php endforeach;endif;?>
        </tbody>
    </table>
    <div style="margin-left:560px;margin-top:50px;">
    <?php $sign = $this->CommonModel->getRowByMultipleCondition('staff',array('use_sign' => 1));
    echo $sign['name'].'<br>'.$sign['designation'];?>
    </div>

    <?php else : ?>
        <div class="alert alert-primary">मुद्दा पेशी गरिएको छैन!!!</div>
    <?php endif;?>
  </body>
</html>

