<style>
.table.table-v2 thead tr th, .table.table-v2 tfoot tr th{
    text-align: left;
}
</style>
<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
              <?php if($this->authlibrary->HasModulePermission('DAFA', "ADD")) { ?>
                <div class="controls-above-table">
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>मिति : <?php echo $this->mylibrary->convertedcit(get_current_year())?> साल <?php echo getNepaliMonthName(get_current_month())?> <?php echo $this->mylibrary->convertedcit(get_current_day())?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay())?> को दैनिक पेशी सुची </h4>
                        </div>
                    </div>
                </div>
              <?php } ?>
              <form action="<?php echo base_url()?>Peshi/save" method="post" class="form save_post">
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                    <table  class="table table-bordered table-lg table-v2 table-striped" >
                        <thead>
                            <tr>
                            <th style="text-align:center"><input type="checkbox" class="form-control" name=""></th> 
                            <th>मुद्दा दर्ता नं</th>
                            <th>मुद्दा दर्ता मिति</th>
                            <th>मुद्दाको विषय</th>
                            <th>उजुरीकर्ता/वादी</th>
                            <th>विपक्षि/प्रतिवादी</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($dartas)) :
                            $i = 1;
                            foreach($dartas as $key => $value) : 
                                $darta_details = $this->CommonModel->getWhere('darta', array('darta_no' => $value['darta_no']));
                            ?>
                            <tr>
                                <td style="text-align:center"><input type="checkbox" class="form-control" name="darta_no[]" value="<?php echo $value['darta_id']?>"></td>
                                <td><?php echo $this->mylibrary->convertedcit($value['darta_id'])?></td>
                                <td><?php echo $this->mylibrary->convertedcit($darta_details['date'])?></td>
                                <td><?php echo $darta_details['case_title']?></td>
                               <td>
                                <?php 
                                    $badi_details = $this->CommonModel->getWhereAll('badi_detail', array('darta_no' => $value['darta_no']));
                                    if(!empty($badi_details)) : foreach($badi_details as $ij => $badi) :
                                        echo '<b>'. $this->mylibrary->convertedcit($ij+1) . ') '. $badi['b_name'].'<br></b>';
                                     endforeach;endif;
                                 ?>
                                 </td>
                                <td>
                                    <?php 
                                        $pbadi_details = $this->CommonModel->getWhereAll('pratibadi_detail', array('darta_no' => $value['darta_no']));
                                        if(!empty($pbadi_details)) : foreach($pbadi_details as $ijp => $pbadi) :
                                            echo '<b>'.$this->mylibrary->convertedcit($ijp+1) . ') '. $pbadi['p_name'].'<br></b>';
                                         endforeach;endif;
                                    ?>
                                 </td>
                            </tr>
                        <?php endforeach;endif; ?>
                        </tbody>
                        <tfoot>
                            <tr><td colspan=6><button type="submmit" class="btn btn-secondary btn-block btn-xs save_btn" name="submit">पेश गर्नुहोस </button></td></tr>
                        </tfoot>
                    </table>
                </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>