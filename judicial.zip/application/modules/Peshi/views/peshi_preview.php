<style>
.table.table-v2 thead tr th, .table.table-v2 tfoot tr th{
    text-align: center;
}
</style>
<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
                <div class="controls-above-table">
                    <div class="row">
                        <div class="col-sm-12">
                            <div><a class="btn btn-success" href="<?php echo base_url()?>Peshi/print/<?php echo $date?>" >प्रिन्ट गर्नुहोस</a></div>
                            <div style="margin-left: 432px;">
                                <?php if(!empty(SITE_SARKAR_LOGO)) : ?>
                                <div class ="avatar-w">
                                    <img src="<?php echo base_url()?>uploads/<?php echo SITE_SARKAR_LOGO;?>" style="height:100px;">
                                </div>
                                <?php endif;?>
                                
                            </div>
                            <div style="margin-left: 420px;font-size:22px;"><?php echo SITE_OFFICE?></div>
                            <div style="margin-left: 399px;font-size:18px;"><?php echo SITE_PALIKA?></div>
                            <div style="margin-left: 437px;font-size:14px;">न्यायिक समिती, <?php echo SITE_OFFICE_ADDRESS?>,<?php echo SITE_DISTRICT?></div>
                            <div style="margin-left: 347px;font-size:16px; margin-top:100px;">मिति : <?php echo $this->mylibrary->convertedcit(get_current_year())?> साल <?php echo getNepaliMonthName(get_current_month())?> <?php echo $this->mylibrary->convertedcit(get_current_day())?> गते रोज <?php echo $this->mylibrary->convertedcit(getDay())?> को दैनिक पेशी सुची</div>
                            <?php if(!empty($dartas)) : ?>
                            <table class="table table-bordered table-lg table-v2 table-striped">
                                <thead>
                                    <tr>
                                    <th>सि. नं</th>
                                    <th>दर्ता मिति</th>
                                    <th>मुद्दा </th>
                                    <th>मुद्दा नं</th>
                                    <th>उजुरीकर्ता/वादी</th>
                                    <th>विपक्षि/प्रतिवादी</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1;if(!empty($dartas)) : foreach($dartas as $peshi) : ?>
                                        <tr>
                                            <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($peshi['date'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($peshi['case_title'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($peshi['darta_no'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($peshi['b_name'])?></td>
                                            <td><?php echo $this->mylibrary->convertedcit($peshi['p_name'])?></td>
                                        </tr>
                                    <?php endforeach;endif;?>
                                </tbody>
                            </table>
                            <div class="pull-right" style="margin-right:80px;">
                                <?php $sign = $this->CommonModel->getRowByMultipleCondition('staff',array('use_sign' => 1));
                                echo $sign['name'].'<br>'.$sign['designation'];?>
                            </div>
                            <?php else : ?>
                                <div class="alert alert-primary">मुद्दा पेशी गरिएको छैन!!!</div>
                            <?php endif;?>
                            
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>