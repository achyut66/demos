<style>
.table.table-v2 thead tr th, .table.table-v2 tfoot tr th{
    text-align: center;
}
::placeholder {
  color: red;
  opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
 color: red;
}

::-ms-input-placeholder { /* Microsoft Edge */
 color: red;
}
</style>
<div class="content-i">
  <div class="content-box">
    <div class="row">
      <div class="col-sm-12">
        <div class="element-wrapper">
          <div class="element-box-tp">
            <div class="anusuchi">
                <div class="controls-above-table">
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>पेशी भएका मुद्दाहरुको सुची</h4>
                        </div>
                    </div>
                </div>
                <div class="controls-above-table">
                <?php echo form_open('Peshi/searchList', array('name'=>'search', 'id'=>'save', 'method'=>'post', 'class'=>'form-horizontal search_report'));?>
                        <div class="row">
                            <div class="col-sm-2">
                                <input type="text" class="form-control number_field" placeholder="दर्ता नं" name="darta_no">
                            </div>
                            <div class="col-sm-4">
                                <div class="date-input">
                                    <input type="text"  class="form-control" id="from_date" value=""  placeholder = "देखि मिति" name="from_date">
                                </div>
                            
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" placeholder = "सम्म मिति " id="to_date" name="to_date">
                            </div>
                            <div class="col-sm-2 mt-1">
                                <button type="submit" class="btn btn-secondary btn-block btn_search_report">खोज्नुहोस </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="list_view">
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                    <table  class="table table-bordered table-lg table-v2 table-striped" >
                        <thead>
                            <tr>
                                <th>क्र.स.</th> 
                                <th>पेशी मिति</th> 
                                <th>मुद्दा दर्ता नं</th>
                                <th>मुद्दा दर्ता मिति</th>
                                <th>मुद्दाको विषय</th>
                                <th>उजुरीकर्ता/वादी</th>
                                <th>विपक्षि/प्रतिवादी</th>
                                <th>विवरण</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($dartas)) :
                            $i = 1;
                            foreach($dartas as $key => $value) :
                                 if(!empty($pbadi_details)) : foreach($pbadi_details as $key => $pbadi) :
                                    $badis = $key++.')'.implode(',', $pbadi['p_name']);
                                endforeach;endif;
                                $darta_details = $this->CommonModel->getWhere('darta', array('darta_no' => $value['darta_no']));
                            ?>
                            <tr>
                                <td><?php echo $this->mylibrary->convertedcit($i++)?></td>
                                <td><?php echo $this->mylibrary->convertedcit($value['peshi_miti'])?></td>
                                <td><?php echo $this->mylibrary->convertedcit($value['darta_no'])?></td>
                                <td><?php echo $this->mylibrary->convertedcit($darta_details['date'])?></td>
                                <td><?php echo $darta_details['case_title']?></td>
                                <td>
                                <?php 
                                    $badi_details = $this->CommonModel->getWhereAll('badi_detail', array('darta_no' => $value['darta_no']));
                                    if(!empty($badi_details)) : foreach($badi_details as $ij => $badi) :
                                        echo $this->mylibrary->convertedcit($ij+1) . ') '. $badi['b_name'].'<br>';
                                     endforeach;endif;
                                 ?>
                                 </td>
                                <td>
                                    <?php 
                                        $pbadi_details = $this->CommonModel->getWhereAll('pratibadi_detail', array('darta_no' => $value['darta_no']));
                                        if(!empty($pbadi_details)) : foreach($pbadi_details as $ijp => $pbadi) :
                                            echo $this->mylibrary->convertedcit($ijp+1) . ') '. $pbadi['p_name'].'<br>';
                                         endforeach;endif;
                                    ?>
                                 </td>
                            <td><a href="<?php echo base_url()?>Darta/badiDetails/<?php echo $value['darta_no']?>" class="btn btn-success" data-placement="top" data-toggle="tooltip" title="" type="button" data-original-title="विवरण हेर्नुहोस" target="_blank">विवरण हेर्नुहोस</a></td>
                            </tr>
                        <?php endforeach;endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url()?>assets/js/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/nepali_datepicker/js/nepali.datepicker.v3.2.min.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
    var GetCurrentBsDate = "<?php echo convertDate(date('Y-m-d'))?>";
    $('.dd_select').select2();
    var mainInput = $("#from_date");
    mainInput.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
    });
    var to_date = $("#to_date");
    to_date.nepaliDatePicker({
        ndpYear: true,
        ndpMonth: true,
        ndpYearCount: 100,
    });
    
    $('.dafa').change(function(){
        var dafa = $(this).val();
		$.ajax({
			method: "POST",
			url: base_url + "Darta/getPrakarByDafa",
			data: {
				dafa: dafa,
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',
			},
			success: function(resp) {
				if (resp.status == 'success') {
					if (resp.data == null) {
						$(".parkar").html();
					} else {
						$(".parkar").html(resp.data);
					}
				}
			}

		});
    });

  });// end of dom
</script>
