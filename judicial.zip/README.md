===E-Meeting===

Contributors: bnod.snr

Tags: e-meeting

Requries PHP: 7+

Stable tab: 1.0

License: BMSNEPAL.

License URI:https://www.bmsnepal.net

Easily to implement for e-minutes.

== Description ==


### E-Meeting.

** Easy to use and implements.

## Features

 ** create meeting and send notification
 ** create meeting members
 ** easy notification of meetings
 ** easy to create meeting minutes.



************* !!!HAPPY CODING!!! **********************
